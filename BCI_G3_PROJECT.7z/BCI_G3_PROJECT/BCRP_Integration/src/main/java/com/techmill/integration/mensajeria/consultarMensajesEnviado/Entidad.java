package com.techmill.integration.mensajeria.consultarMensajesEnviado;

public class Entidad {

	private String descripcion;
    private String id;
    private String nombreCorto;
	
    @Override
	public String toString() {
		return "Entidad [descripcion=" + descripcion + ", id=" + id + ", nombreCorto=" + nombreCorto + "]";
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombreCorto() {
		return nombreCorto;
	}

	public void setNombreCorto(String nombreCorto) {
		this.nombreCorto = nombreCorto;
	}
    
    
    
}
