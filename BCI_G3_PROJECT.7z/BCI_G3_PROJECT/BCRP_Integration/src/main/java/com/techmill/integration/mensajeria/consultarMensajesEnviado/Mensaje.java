package com.techmill.integration.mensajeria.consultarMensajesEnviado;

public class Mensaje {

	private String id;

	@Override
	public String toString() {
		return "Mensaje [id=" + id + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}
