package com.techmill.integration.mensajeria.consultarMensajesEnviado;

import java.util.ArrayList;
import java.util.Date;

public class MensajeNoFinanciero {

	private Emisor emisor;
    private Date fecha;
    private String id;
    private ArrayList<Receptore> receptores;
    private String textoMensaje;
	
    @Override
	public String toString() {
		return "MensajeNoFinanciero [emisor=" + emisor + ", fecha=" + fecha + ", id=" + id + ", textoMensaje="
				+ textoMensaje + "]";
	}

	public Emisor getEmisor() {
		return emisor;
	}

	public void setEmisor(Emisor emisor) {
		this.emisor = emisor;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public ArrayList<Receptore> getReceptores() {
		return receptores;
	}

	public void setReceptores(ArrayList<Receptore> receptores) {
		this.receptores = receptores;
	}

	public String getTextoMensaje() {
		return textoMensaje;
	}

	public void setTextoMensaje(String textoMensaje) {
		this.textoMensaje = textoMensaje;
	}
    
    
}
