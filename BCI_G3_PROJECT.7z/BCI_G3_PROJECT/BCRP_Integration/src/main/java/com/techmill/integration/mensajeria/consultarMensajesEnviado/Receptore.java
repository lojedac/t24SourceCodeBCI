package com.techmill.integration.mensajeria.consultarMensajesEnviado;

public class Receptore {

	private Entidad entidad;
	private String id;
	private String leido;
	private Mensaje mensaje;
	
	@Override
	public String toString() {
		return "Receptore [entidad=" + entidad + ", id=" + id + ", leido=" + leido + ", mensaje=" + mensaje + "]";
	}

	public Entidad getEntidad() {
		return entidad;
	}

	public void setEntidad(Entidad entidad) {
		this.entidad = entidad;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLeido() {
		return leido;
	}

	public void setLeido(String leido) {
		this.leido = leido;
	}

	public Mensaje getMensaje() {
		return mensaje;
	}

	public void setMensaje(Mensaje mensaje) {
		this.mensaje = mensaje;
	}
	  
	
}
