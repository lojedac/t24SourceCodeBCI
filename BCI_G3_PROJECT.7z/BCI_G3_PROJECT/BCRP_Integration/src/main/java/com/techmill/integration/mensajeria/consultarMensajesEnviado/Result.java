package com.techmill.integration.mensajeria.consultarMensajesEnviado;

import java.util.ArrayList;

public class Result {

	private ArrayList<MensajeNoFinanciero> mensajeNoFinanciero;
	private String codError;
	private String mensajeError;

	public String getCodError() {
		return codError;
	}

	public void setCodError(String codError) {
		this.codError = codError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public ArrayList<MensajeNoFinanciero> getMensajeNoFinanciero() {
		return mensajeNoFinanciero;
	}

	public void setMensajeNoFinanciero(ArrayList<MensajeNoFinanciero> mensajeNoFinanciero) {
		this.mensajeNoFinanciero = mensajeNoFinanciero;
	}

	@Override
	public String toString() {
		return "Result [mensajeNoFinanciero=" + mensajeNoFinanciero + ", codError=" + codError + ", mensajeError="
				+ mensajeError + "]";
	}
}
