package com.techmill.integration.mensajeria.consultarMensajesEnviado;

public class RootConsultarMensajesEnviado {

	private boolean ok;
	private String description;
	private Result result;

	public RootConsultarMensajesEnviado(boolean ok, String description, Result result) {
		super();
		this.ok = ok;
		this.description = description;
		this.result = result;
	}

	@Override
	public String toString() {
		return "ConsultaMensajesEnviados [ok=" + ok + ", description=" + description + ", result=" + result + "]";
	}

	public boolean isOk() {
		return ok;
	}

	public void setOk(boolean ok) {
		this.ok = ok;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

}
