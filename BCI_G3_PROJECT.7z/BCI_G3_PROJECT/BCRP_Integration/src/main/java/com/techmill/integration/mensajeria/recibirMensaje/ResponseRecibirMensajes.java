package com.techmill.integration.mensajeria.recibirMensaje;

public class ResponseRecibirMensajes {

	private boolean ok;
	private String description;
	
	@Override
	public String toString() {
		return "ResponseRecibirMensajes [ok=" + ok + ", description=" + description + "]";
	}

	public boolean isOk() {
		return ok;
	}

	public void setOk(boolean ok) {
		this.ok = ok;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
