package com.techmill.integration.mensajeria.recibirMensaje;

public class RootRecibirMensajes {

	private String sid;
	private String mensaje;

	public RootRecibirMensajes(String sid, String mensaje) {
		super();
		this.sid = sid;
		this.mensaje = mensaje;
	}

	@Override
	public String toString() {
		return "RecibirMensajes [sid=" + sid + ", mensaje=" + mensaje + "]";
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

}
