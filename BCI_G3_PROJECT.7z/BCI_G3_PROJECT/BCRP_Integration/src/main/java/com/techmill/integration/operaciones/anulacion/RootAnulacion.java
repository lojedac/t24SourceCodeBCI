package com.techmill.integration.operaciones.anulacion;

public class RootAnulacion {
	private String sid;
	private String numRefLBTR;
	private String firma;

	public RootAnulacion(String sid, String numRefLBTR, String firma) {
		this.sid = sid;
		this.numRefLBTR = numRefLBTR;
		this.firma = firma;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getNumRefLBTR() {
		return numRefLBTR;
	}

	public void setNumRefLBTR(String numRefLBTR) {
		this.numRefLBTR = numRefLBTR;
	}

	public String getFirma() {
		return firma;
	}

	public void setFirma(String firma) {
		this.firma = firma;
	}

	@Override
	public String toString() {
		return "Anulacion [sid=" + sid + ", numRefLBTR=" + numRefLBTR + ", firma=" + firma + "]";
	}

}
