package com.techmill.integration.swap.solicitudSwap;

public class DatosFacilidad {

	private String codConcepto;
    private String cuentaDestino;
    private String cuentaOrigen;
    private String montoSolicitado;
    private String numRefOrigen;
    
	@Override
	public String toString() {
		return "DatosFacilidad [codConcepto=" + codConcepto + ", cuentaDestino=" + cuentaDestino + ", cuentaOrigen="
				+ cuentaOrigen + ", montoSolicitado=" + montoSolicitado + ", numRefOrigen=" + numRefOrigen + "]";
	}

	public String getCodConcepto() {
		return codConcepto;
	}

	public void setCodConcepto(String codConcepto) {
		this.codConcepto = codConcepto;
	}

	public String getCuentaDestino() {
		return cuentaDestino;
	}

	public void setCuentaDestino(String cuentaDestino) {
		this.cuentaDestino = cuentaDestino;
	}

	public String getCuentaOrigen() {
		return cuentaOrigen;
	}

	public void setCuentaOrigen(String cuentaOrigen) {
		this.cuentaOrigen = cuentaOrigen;
	}

	public String getMontoSolicitado() {
		return montoSolicitado;
	}

	public void setMontoSolicitado(String montoSolicitado) {
		this.montoSolicitado = montoSolicitado;
	}

	public String getNumRefOrigen() {
		return numRefOrigen;
	}

	public void setNumRefOrigen(String numRefOrigen) {
		this.numRefOrigen = numRefOrigen;
	}
    
	
    
}
