package com.techmill.integration.swap.solicitudSwap;

public class RootSolicitudSwap {

	private String sid;
	private DatosFacilidad datosFacilidad;
	private String firma;

	public RootSolicitudSwap(String sid, DatosFacilidad datosFacilidad, String firma) {
		super();
		this.sid = sid;
		this.datosFacilidad = datosFacilidad;
		this.firma = firma;
	}

	@Override
	public String toString() {
		return "SolicitudSwap [sid=" + sid + ", datosFacilidad=" + datosFacilidad + ", firma=" + firma + "]";
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public DatosFacilidad getDatosFacilidad() {
		return datosFacilidad;
	}

	public void setDatosFacilidad(DatosFacilidad datosFacilidad) {
		this.datosFacilidad = datosFacilidad;
	}

	public String getFirma() {
		return firma;
	}

	public void setFirma(String firma) {
		this.firma = firma;
	}

}
