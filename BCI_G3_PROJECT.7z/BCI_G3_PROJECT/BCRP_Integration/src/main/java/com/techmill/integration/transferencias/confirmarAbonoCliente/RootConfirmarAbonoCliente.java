package com.techmill.integration.transferencias.confirmarAbonoCliente;

public class RootConfirmarAbonoCliente {

	private String sid;
	private String numRefLBTR;
	private String firma;

	public RootConfirmarAbonoCliente(String sid, String numRefLBTR, String firma) {
		super();
		this.sid = sid;
		this.numRefLBTR = numRefLBTR;
		this.firma = firma;
	}

	@Override
	public String toString() {
		return "ConfirmarAbonoCliente [sid=" + sid + ", numRefLBTR=" + numRefLBTR + ", firma=" + firma + "]";
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getNumRefLBTR() {
		return numRefLBTR;
	}

	public void setNumRefLBTR(String numRefLBTR) {
		this.numRefLBTR = numRefLBTR;
	}

	public String getFirma() {
		return firma;
	}

	public void setFirma(String firma) {
		this.firma = firma;
	}

}
