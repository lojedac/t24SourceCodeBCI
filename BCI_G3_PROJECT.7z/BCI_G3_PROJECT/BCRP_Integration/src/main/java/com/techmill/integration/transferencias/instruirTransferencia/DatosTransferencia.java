package com.techmill.integration.transferencias.instruirTransferencia;

import java.util.Date;

public class DatosTransferencia {

	private String codConcepto;
	private String cuentaDestino;
	private String cuentaOrigen;
	private DatosCliente datosCliente;
	private Date fechaLiquidacion;
	private Date fechaRefLBTREnlace;
	private String instruccionesPago;
	private String modalidad;
	private String montoOperacion;
	private String numRefOrigen;
	private String numRefEnlaceOperacion;
	private String prioridad;

	@Override
	public String toString() {
		return "DatosTransferencia [codConcepto=" + codConcepto + ", cuentaDestino=" + cuentaDestino + ", cuentaOrigen="
				+ cuentaOrigen + ", datosCliente=" + datosCliente + ", fechaLiquidacion=" + fechaLiquidacion
				+ ", fechaRefLBTREnlace=" + fechaRefLBTREnlace + ", instruccionesPago=" + instruccionesPago
				+ ", modalidad=" + modalidad + ", montoOperacion=" + montoOperacion + ", numRefOrigen=" + numRefOrigen
				+ ", numRefEnlaceOperacion=" + numRefEnlaceOperacion + ", prioridad=" + prioridad + "]";
	}

	public String getCodConcepto() {
		return codConcepto;
	}

	public void setCodConcepto(String codConcepto) {
		this.codConcepto = codConcepto;
	}

	public String getCuentaDestino() {
		return cuentaDestino;
	}

	public void setCuentaDestino(String cuentaDestino) {
		this.cuentaDestino = cuentaDestino;
	}

	public String getCuentaOrigen() {
		return cuentaOrigen;
	}

	public void setCuentaOrigen(String cuentaOrigen) {
		this.cuentaOrigen = cuentaOrigen;
	}

	public DatosCliente getDatosCliente() {
		return datosCliente;
	}

	public void setDatosCliente(DatosCliente datosCliente) {
		this.datosCliente = datosCliente;
	}

	public Date getFechaLiquidacion() {
		return fechaLiquidacion;
	}

	public void setFechaLiquidacion(Date fechaLiquidacion) {
		this.fechaLiquidacion = fechaLiquidacion;
	}

	public Date getFechaRefLBTREnlace() {
		return fechaRefLBTREnlace;
	}

	public void setFechaRefLBTREnlace(Date fechaRefLBTREnlace) {
		this.fechaRefLBTREnlace = fechaRefLBTREnlace;
	}

	public String getInstruccionesPago() {
		return instruccionesPago;
	}

	public void setInstruccionesPago(String instruccionesPago) {
		this.instruccionesPago = instruccionesPago;
	}

	public String getModalidad() {
		return modalidad;
	}

	public void setModalidad(String modalidad) {
		this.modalidad = modalidad;
	}

	public String getMontoOperacion() {
		return montoOperacion;
	}

	public void setMontoOperacion(String montoOperacion) {
		this.montoOperacion = montoOperacion;
	}

	public String getNumRefOrigen() {
		return numRefOrigen;
	}

	public void setNumRefOrigen(String numRefOrigen) {
		this.numRefOrigen = numRefOrigen;
	}

	public String getNumRefEnlaceOperacion() {
		return numRefEnlaceOperacion;
	}

	public void setNumRefEnlaceOperacion(String numRefEnlaceOperacion) {
		this.numRefEnlaceOperacion = numRefEnlaceOperacion;
	}

	public String getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(String prioridad) {
		this.prioridad = prioridad;
	}

}
