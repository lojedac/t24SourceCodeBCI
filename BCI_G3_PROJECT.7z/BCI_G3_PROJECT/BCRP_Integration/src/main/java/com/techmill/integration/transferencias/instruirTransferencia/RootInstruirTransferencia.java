package com.techmill.integration.transferencias.instruirTransferencia;

public class RootInstruirTransferencia {

	private String sid;
	private DatosTransferencia datosTransferencia;
	private String firma;

	public RootInstruirTransferencia(String sid, DatosTransferencia datosTransferencia, String firma) {
		super();
		this.sid = sid;
		this.datosTransferencia = datosTransferencia;
		this.firma = firma;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public DatosTransferencia getDatosTransferencia() {
		return datosTransferencia;
	}

	public void setDatosTransferencia(DatosTransferencia datosTransferencia) {
		this.datosTransferencia = datosTransferencia;
	}

	public String getFirma() {
		return firma;
	}

	public void setFirma(String firma) {
		this.firma = firma;
	}

	@Override
	public String toString() {
		return "InstruirTransferencia [sid=" + sid + ", datosTransferencia=" + datosTransferencia + ", firma=" + firma
				+ "]";
	}
}
