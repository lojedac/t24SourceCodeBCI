package com.techmill.integration.transferencias.instruirTransferenciaCavali;

import java.util.Date;

public class DatosCavali {

	private String codigoSAB;
    private String cuentaInterbancariaSAB;
    private Date fechaNegociacionCavali;
    private String numRefCavali;
    private String tipoParticipanteCavali;

	@Override
	public String toString() {
		return "DatosCavali [codigoSAB=" + codigoSAB + ", cuentaInterbancariaSAB=" + cuentaInterbancariaSAB
				+ ", fechaNegociacionCavali=" + fechaNegociacionCavali + ", numRefCavali=" + numRefCavali
				+ ", tipoParticipanteCavali=" + tipoParticipanteCavali + "]";
	}

	public String getCodigoSAB() {
		return codigoSAB;
	}

	public void setCodigoSAB(String codigoSAB) {
		this.codigoSAB = codigoSAB;
	}

	public String getCuentaInterbancariaSAB() {
		return cuentaInterbancariaSAB;
	}

	public void setCuentaInterbancariaSAB(String cuentaInterbancariaSAB) {
		this.cuentaInterbancariaSAB = cuentaInterbancariaSAB;
	}

	public Date getFechaNegociacionCavali() {
		return fechaNegociacionCavali;
	}

	public void setFechaNegociacionCavali(Date fechaNegociacionCavali) {
		this.fechaNegociacionCavali = fechaNegociacionCavali;
	}

	public String getNumRefCavali() {
		return numRefCavali;
	}

	public void setNumRefCavali(String numRefCavali) {
		this.numRefCavali = numRefCavali;
	}

	public String getTipoParticipanteCavali() {
		return tipoParticipanteCavali;
	}

	public void setTipoParticipanteCavali(String tipoParticipanteCavali) {
		this.tipoParticipanteCavali = tipoParticipanteCavali;
	}
    
    
    
    
}
