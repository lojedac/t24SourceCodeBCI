package com.techmill.integration.transferencias.instruirTransferenciaCavali;

import com.techmill.integration.transferencias.instruirTransferencia.DatosTransferencia;

public class RootInstruirTransferenciaCavali {

	private String sid;
	private DatosTransferencia datosTransferencia;
	private DatosCavali datosCavali;
	private String firma;

	public RootInstruirTransferenciaCavali(String sid, DatosTransferencia datosTransferencia, DatosCavali datosCavali,
			String firma) {
		super();
		this.sid = sid;
		this.datosTransferencia = datosTransferencia;
		this.datosCavali = datosCavali;
		this.firma = firma;
	}

	@Override
	public String toString() {
		return "InstruirTransferenciaCavali [sid=" + sid + ", datosTransferencia=" + datosTransferencia
				+ ", datosCavali=" + datosCavali + ", firma=" + firma + "]";
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public DatosTransferencia getDatosTransferencia() {
		return datosTransferencia;
	}

	public void setDatosTransferencia(DatosTransferencia datosTransferencia) {
		this.datosTransferencia = datosTransferencia;
	}

	public DatosCavali getDatosCavali() {
		return datosCavali;
	}

	public void setDatosCavali(DatosCavali datosCavali) {
		this.datosCavali = datosCavali;
	}

	public String getFirma() {
		return firma;
	}

	public void setFirma(String firma) {
		this.firma = firma;
	}

}
