# BciL3Apis Source

Este es el repositorio de GitLab para el proyecto BciL3Apis Source, un proyecto Java diseñado para manejar varios requerimientos, incluyendo las operaciones de transferencia para CCE en Perú.

## Descripción

El proyecto BciL3Apis Source es una solución integral para varios requerimientos de la plataforma, incluyendo la gestión de transferencias para CCE en Perú. El proyecto no contiene submódulos.

## Instalación

Para clonar y ejecutar este proyecto, necesitarás [Git](https://git-scm.com) y [JDK 17](https://jdk.java.net/17/) instalados en tu computadora. Desde tu línea de comandos:

```bash
# Clonar este repositorio
$ git clone https://gitlab.com/David_KtL/BciL3Apis_source.git

# Ir al repositorio
$ cd BciL3Apis_source

# Compilar el proyecto
$ javac [nombre_del_archivo_principal].java

# Ejecutar el proyecto
$ java [nombre_del_archivo_principal]
```

## Uso

Por favor, consulte la documentación del proyecto para obtener instrucciones detalladas de uso.

## Desarrolladores

Este proyecto fue desarrollado por:

- [@MarkGit_Nagarro](https://gitlab.com/MarkGit_Nagarro)
- [@damaigualcaNagarro](https://gitlab.com/damaigualcaNagarro)
- [@David_KtL](https://gitlab.com/David_KtL)
- [@andrea.vaca](https://gitlab.com/andrea.vaca)
- [@HaroldNag](https://gitlab.com/HaroldNag)
- [@dsgallegos](https://gitlab.com/dsgallegos)

## Licencia

BciL3Apis Source está licenciado bajo Nagarro EC.