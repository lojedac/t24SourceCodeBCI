package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.complex.eb.templatehook.TransactionData;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.BalanceTypeClass;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementRecord;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementTable;
import com.temenos.t24.api.tables.ebbcilloanvalidate.EbBciLLoanValidateRecord;
import com.temenos.t24.api.tables.ebbcilloanvalidate.EbBciLLoanValidateTable;

/**
 * ------------------------------------------------------------------------------------------------------------------------------------
 * Description : BRD 04-05, Validate Routine to PO duplicates Developed By :
 * Diego Maigualca, Nagarro SAS Development Reference : BRD-04-05 Attached To :
 * VERSION>PAYMENT.ORDER,BCI.CREATE.PO Attached As : Default Routine Jar Name :
 * Bcil3Apis.jar
 * ------------------------------------------------------------------------------------------------------------------------------------
 * M O D I F I C A T I O N S
 ************************** 
 * ------------------------------------------------------------------------------------------------------------------------------------
 * Defect Reference Modified By Date of Change Change Details (RTC/TUT/PACS)
 * ------------------------------------------------------------------------------------------------------------------------------------
 * XXXX <<name of modifier>> <<YYYY-MM-DD>> <<modification details goes here>>
 * ------------------------------------------------------------------------------------------------------------------------------------
 */
public class BciAALoanValidatePo extends RecordLifecycle {

    @Override
    public TValidationResponse validateRecord(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        DataAccess da = new DataAccess(this);

        String loanValId = "";
        String loanValEbTableId = "";
        loanValId = poRec.getOriginalMsgContent().getValue();
        EbBciLLoanValidateRecord ebValidateRecord = new EbBciLLoanValidateRecord(this);
        try {
            ebValidateRecord = new EbBciLLoanValidateRecord(da.getRecord("EB.BCI.L.LOAN.VALIDATE", loanValId));
            loanValEbTableId = ebValidateRecord.getId().getValue();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        if (loanValEbTableId.equals("YES")) {
            poRec.getOriginalMsgContent().setError("ERROR XD");
        }
        return poRec.getValidationResponse();
    }

    @Override
    public void updateRecord(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext,
            List<TransactionData> transactionData, List<TStructure> currentRecords) {
        final PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        final DataAccess da = new DataAccess(this);
        String loanValId = "";
        String loanValFiledId = "";
        String bnkReferenceId = "";
        String idMovement = "";
        String balanceType = "";
        String bnkPoCurr = "";
        String idMovementLst = "";
        int cont = 0;
        
        Session sessObj = new Session(this);
        String mnemonic = sessObj.getCompanyRecord().getMnemonic().getValue();
        
        bnkPoCurr = poRec.getPaymentSystemId().getValue();
        EbBciLLoanValidateRecord ebValidateRecord = new EbBciLLoanValidateRecord(this);
        List<BalanceTypeClass> lstBalanceTypeClass = new ArrayList<BalanceTypeClass>();
        List<String> lstMovement = da.selectRecords(mnemonic, "EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT", "", "WITH IDBNKPO EQ '" + bnkPoCurr + "'");
        try {
            idMovementLst = lstMovement.get(0);
            poRec.setOriginalMsgContent(idMovementLst);
            
        } catch (Exception e) {
           System.out.println(e.getMessage());
        }
        loanValId = poRec.getOriginalMsgContent().getValue();
        try {
            ebValidateRecord = new EbBciLLoanValidateRecord(da.getRecord("EB.BCI.L.LOAN.VALIDATE", loanValId));
            loanValFiledId = ebValidateRecord.getId().getValue();
            if (loanValFiledId.isEmpty()) {
                return;
            }
            if (!loanValFiledId.equals("YES")) {
                String[] vecMovement = loanValFiledId.split("-");
                idMovement = vecMovement[0] + "-" + vecMovement[1];
                balanceType = vecMovement[3];
                bnkReferenceId = poRec.getPaymentSystemId().getValue();
                EbBciLLoanCapitalizeMovementTable bciLLoanCapitalizeMovementTable = new EbBciLLoanCapitalizeMovementTable(this);
                EbBciLLoanCapitalizeMovementRecord bciLLoanCapitalizeMovementRecord = new EbBciLLoanCapitalizeMovementRecord(da.getRecord("EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT", idMovement));

                lstBalanceTypeClass = bciLLoanCapitalizeMovementRecord.getBalanceType();
                for (BalanceTypeClass balanceTypeClass : lstBalanceTypeClass) {
                    String typeBalanceMovem = "";
                    typeBalanceMovem = balanceTypeClass.getBalanceType().getValue();
                    if (balanceType.equals(typeBalanceMovem) && balanceType.equals("CAPEXPENSE")) {
                        balanceTypeClass.setBnkreference(bnkReferenceId);
                    } else if (balanceType.equals(typeBalanceMovem) && balanceType.equals("CAPCOMM")) {
                        balanceTypeClass.setBnkreference(bnkReferenceId);
                    } else if (balanceType.equals(typeBalanceMovem) && balanceType.equals("CAPINT")) {
                        balanceTypeClass.setBnkreference(bnkReferenceId);
                    }
                    bciLLoanCapitalizeMovementRecord.setBalanceType(balanceTypeClass, cont);
                    cont ++;
                }

                bciLLoanCapitalizeMovementTable.write(idMovement, bciLLoanCapitalizeMovementRecord);
                
                ebValidateRecord.setId((CharSequence)"YES");
            }
            final EbBciLLoanValidateTable bciLLoanValidateTable = new EbBciLLoanValidateTable(this);
            bciLLoanValidateTable.write((CharSequence)loanValId, ebValidateRecord);
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
        currentRecords.add(poRec.toStructure());
    }

}
