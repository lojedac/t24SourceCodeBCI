
package com.bci;

import com.temenos.t24.api.records.account.AccountRecord;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.temenos.api.TField;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/*
*
* @author Parthiban
*
*-------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Java hook to validate the local fields L.CRED.ORIGEN and L.SEQUENCE for Refinanced and Restructured type of loans.
* Developed By          : Parthiban Balasubramaniam,Techmill Technologies  
* Development Reference : BRD-06 CAMPOS LOCALES CRÉDITO ORIGEN Y NÚMERO DE SECUENCIA
* Attached To           : ACTIVITY.API>BCI.GROUP.SUB.LOAN.REF.REE.API
* Attached As           : Validation Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/


public class BciAAValCreditOrginSeqNum extends ActivityLifecycle
{
    public TValidationResponse validateRecord(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record1) {
        final DataAccess da = new DataAccess((T24Context)this);
        final AaPrdDesAccountRecord aaPrdDesAccRec = new AaPrdDesAccountRecord(record1);
        TField credOrigenFld = new TField();
        TField sequenceFld = new TField();
        final String errorId1 = "EB-BCI.INVALID.SL.LOAN.ID";
        final String errorId2 = "EB-BCI.SEQ.NUM.MUST.GT.THAN.1";
        try {
            credOrigenFld = aaPrdDesAccRec.getLocalRefField("L.CRED.ORIGEN");
            sequenceFld = aaPrdDesAccRec.getLocalRefField("L.SEQUENCE");
        }
        catch (Exception e1) {
            final Logger l1 = Logger.getLogger("REF.REE.LOAN.LOG");
            final String msg = e1.getMessage();
            l1.log(Level.WARNING, msg);
        }
        final String credOrigenStr = credOrigenFld.getValue();
        final String sequenceStr = sequenceFld.getValue();
        if (!credOrigenStr.isEmpty() && credOrigenStr.startsWith("SL")) {
            TStructure rec1 = null;
            try {
                rec1 = da.getRecord("FACILITY", credOrigenStr);
                if (rec1 == null) {
                    credOrigenFld.setError("EB-BCI.INVALID.SL.LOAN.ID");
                }
            }
            catch (Exception e3) {
                credOrigenFld.setError("EB-BCI.INVALID.SL.LOAN.ID");
            }
        }
        else {
            TStructure rec2 = null;
            AccountRecord accRec = null;
            try {
                rec2 = da.getRecord("ACCOUNT", credOrigenStr);
                accRec = new AccountRecord(rec2);
                final String arrId = accRec.getArrangementId().getValue();
                final TStructure rec3 = da.getRecord("AA.ARRANGEMENT", arrId);
                final AaArrangementRecord aaArrRec = new AaArrangementRecord(rec3);
                final String arrPrdLine = aaArrRec.getProductLine().getValue();
                if (!arrPrdLine.equals("LENDING")) {
                    credOrigenFld.setError("EB-BCI.INVALID.SL.LOAN.ID");
                }
            }
            catch (Exception e4) {
                credOrigenFld.setError("EB-BCI.INVALID.SL.LOAN.ID");
            }
        }
        try {
            final int sequenceNum = Integer.parseInt(sequenceStr);
            if (sequenceNum <= 1) {
                sequenceFld.setError("EB-BCI.SEQ.NUM.MUST.GT.THAN.1");
            }
        }
        catch (Exception e2) {
            final Logger l2 = Logger.getLogger("REF.REE.LOAN.LOG");
            final String msg2 = e2.getMessage();
            l2.log(Level.WARNING, msg2);
        }
        return aaPrdDesAccRec.getValidationResponse();
    }
}
