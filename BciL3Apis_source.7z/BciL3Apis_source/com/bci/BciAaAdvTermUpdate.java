package com.bci;

import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.BalanceTypeClass;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementRecord;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementTable;
import com.temenos.t24.api.tables.ebbcilloanvalidate.EbBciLLoanValidateRecord;
import com.temenos.t24.api.tables.ebbcilloanvalidate.EbBciLLoanValidateTable;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.portransaction.PorTransactionRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentDueType;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentSchedule;
import java.util.ArrayList;
import com.temenos.api.TDate;
import java.util.List;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

public class BciAaAdvTermUpdate extends ActivityLifecycle {
    public List<TDate> rePayTdateCalc(final String startDate1, final String endDate1, final Contract contract,
            final String arrId1) {
        final List<TDate> retTdateList1 = new ArrayList<TDate>();
        contract.setContractId(arrId1);
        final TDate tStartDate = new TDate(startDate1);
        final TDate tEndDate = new TDate(endDate1);
        final List<RepaymentSchedule> rePayScheduleClsList = (List<RepaymentSchedule>) contract
                .getRepaymentSchedule(tStartDate, tEndDate);
        for (final RepaymentSchedule rePayScheduleCls : rePayScheduleClsList) {
            for (final RepaymentDueType rePayDueCls : rePayScheduleCls.getRepaymentDueType()) {
                final String schDueType = rePayDueCls.getDueType();
                if (schDueType.equals("CONSTANT") || schDueType.equals("LINEAR")) {
                    retTdateList1.add(rePayScheduleCls.getDueDate());
                }
            }
        }
        return retTdateList1;
    }

    @Override
    public void postCoreTableUpdate(AaAccountDetailsRecord accountDetailRecord,
            AaArrangementActivityRecord arrangementActivityRecord, ArrangementContext arrangementContext,
            AaArrangementRecord arrangementRecord, AaArrangementActivityRecord masterActivityRecord,
            TStructure productPropertyRecord, AaProductCatalogRecord productRecord, TStructure record,
            List<TransactionData> transactionData, List<TStructure> transactionRecord) {
        try {
            String bnkRef = "";
            bnkRef = masterActivityRecord.getTxnContractId().getValue();
            int posicion = bnkRef.indexOf("\\");
            String subbnk = bnkRef.substring(0, posicion);
            final String masterActivity = masterActivityRecord.getActivity().getValue();
            if (masterActivity.equals("LENDING-APPLYPAYMENT-PR.ADV.TERM")) {
                final DataAccess daObj = new DataAccess(this);
                final Contract contract = new Contract(this);
                final EbBciLLoanCapitalizeMovementTable lnCptlMvmtTab = new EbBciLLoanCapitalizeMovementTable(
                        (T24Context) this);
                final String currAction = arrangementContext.getActivityStatus();

                if (currAction.equals("AUTH")) {
                    final String arrId = arrangementActivityRecord.getArrangement().getValue();
                    final String linkedApplId = arrangementRecord.getLinkedAppl(0).getLinkedApplId().getValue();
                    final String startDate = arrangementRecord.getStartDate().getValue();
                    final String endDate = accountDetailRecord.getMaturityDate().getValue();
                    final List<TDate> rePayTdateList = this.rePayTdateCalc(startDate, endDate, contract, arrId);
                    final int noOfSchd = rePayTdateList.size();
                    final List<String> existIdsMvmtTab = (List<String>) daObj.selectRecords("",
                            "EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT", "", "@ID LIKE " + linkedApplId + "...");
                    final int noOfExist = existIdsMvmtTab.size();
                    int schdDiff = 0;
                    if (noOfSchd < noOfExist) {
                        schdDiff = noOfExist - noOfSchd;
                    }
                    for (int i = 0; i < schdDiff; ++i) {
                        final String currId = existIdsMvmtTab.get(noOfExist - 1 - i);
                        final TStructure rec1 = daObj.getRecord("EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT", currId);
                        final EbBciLLoanCapitalizeMovementRecord cptlzeMvmtRecObj = new EbBciLLoanCapitalizeMovementRecord(
                                rec1);
                        cptlzeMvmtRecObj.setIdBnkPo(subbnk);
                        final List<BalanceTypeClass> balanceTypeList = (List<BalanceTypeClass>) cptlzeMvmtRecObj
                                .getBalanceType();
                        for (int j = 0; j < balanceTypeList.size(); ++j) {
                            final BalanceTypeClass balanceTypeClass = balanceTypeList.get(j);
                            balanceTypeClass.setAdjAmt((CharSequence) balanceTypeClass.getOrigBal().getValue(),
                                    balanceTypeClass.getAdjAmt().size());
                            balanceTypeClass.getBalance().set("0");
                        }
                        cptlzeMvmtRecObj.setSettleStatus((CharSequence) "SETTLED");
                        lnCptlMvmtTab.write((CharSequence) currId, cptlzeMvmtRecObj);
                        final BciCreatePayOrder createPaymentOrder = new BciCreatePayOrder();
                        final List<TStructure> paymentOrderRecord = createPaymentOrder.getPaymentOrderRec(arrId,
                                cptlzeMvmtRecObj, "BNK", daObj, contract, currId);                       
                        final TransactionData txnDataRecord = createPaymentOrder.getTrasactionData();
                        for (int paymentSize = 0; paymentSize < paymentOrderRecord.size(); ++paymentSize) {
                            String idLoanValid = "";
                            PaymentOrderRecord poReco = new PaymentOrderRecord(this);
                            EbBciLLoanValidateRecord ebBciLLoanValidateRecord = new EbBciLLoanValidateRecord(this);
                            EbBciLLoanValidateTable bciLLoanValidateTable = new EbBciLLoanValidateTable(this);
                            try {
                                poReco = new PaymentOrderRecord(paymentOrderRecord.get(paymentSize));
                                idLoanValid = poReco.getOriginalMsgContent().getValue();
                                ebBciLLoanValidateRecord.setId(idLoanValid);
                                bciLLoanValidateTable.write(idLoanValid, ebBciLLoanValidateRecord);
                            } catch (Exception e) {
                                System.err.println(e.getMessage());
                            }

                            transactionRecord.add(paymentOrderRecord.get(paymentSize));
                            transactionData.add(txnDataRecord);

                        }
                    }
                }
            }
        } catch (Exception e1) {
            e1.getMessage();
        }

    }

}
