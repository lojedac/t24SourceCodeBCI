package com.bci;

import com.temenos.api.TField;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.records.aaarraccount.AaArrAccountRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/*
*
* @author malika.v
*
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description     		: Raise Error when length of Office Code and Entity Code is not equal to 3
*Developed By	  		: Mallika V, Techmill Technologies
*Development Reference  : CCI Code Generation 
*Attached To     		: AA.PRD.DES.ACTIVITY.API>GROUP.SUB.API-20210503 
*Attached as     		: Validation Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/

public class BciAaCciValidation extends ActivityLifecycle
{
    public TValidationResponse validateRecord(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record) {
        final AaArrAccountRecord prdAccountRecObj = new AaArrAccountRecord(record);
        final Session sessObj = new Session((T24Context)this);
        String officeCode = "";
        String entityCode = "";
        final String AA_BCI_GENERATE_CCI = "AA-BCI.CANNOT.GENERATE.BCI";
        try {
            officeCode = sessObj.getCompanyRecord().getLocalRefField("L.OFFICE.CODE").getValue();
            entityCode = sessObj.getCompanyRecord().getLocalRefField("L.ENTITY.CODE").getValue();
            if (!officeCode.equals("") && !entityCode.equals("") && (officeCode.length() != 3 || entityCode.length() != 3)) {
                final TField altIdTf = prdAccountRecObj.getAltIdType(0).getAltId();
                altIdTf.setError(AA_BCI_GENERATE_CCI);
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        return prdAccountRecObj.getValidationResponse();
    }
}
