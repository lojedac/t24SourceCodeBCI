package com.bci;

import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.records.aaarraccount.AaArrAccountRecord;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import java.util.List;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/**
 *-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Routine to update the Capitalised Accounts in the Local Fields of COMMITMENT Property
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : BRD 04-05 
*Attached To            : AA.PRD.DES.ACTIVITY.API>BCI.CAP.ACCOUNTS.API-20210504 
*Attached as            : Post Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------acco
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
 *
 */
public class BciAaGetAccountNumber extends ActivityLifecycle
{
    public static final String INT_PRD = "CAPITALIZED.INT";
    public static final String COM_PRD = "CAPITALIZED.COM";
    public static final String EXP_PRD = "CAPITALIZED.EXP";
    public static final String ASSET_PRD = "ASSET.REV.AC";
    public static final String PROPERTY_COM = "COMMITMENT";
    public static final String TERM_APPL = "AA.ARR.TERM.AMOUNT";
    public static final String OFS_VERSION_ID = "PAYMENT.ORDER,BCI.CREATE.PO";
    public static final String OFS_SOURCE = "BCI.CREATE.ACCT";
    public static final String PO_ID = "";
    public static final String FUNC_INPUT = "INPUT";
    static final String NO_OF_AUTH = "0";
    
    public void postCoreTableUpdate(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record, final List<TransactionData> transactionData, final List<TStructure> transactionRecord) {
        if (arrangementContext.getActivityStatus().equals("AUTH")) {
            try {
                final AaArrAccountRecord accountRecordObj = new AaArrAccountRecord(record);
                final Session sessObj = new Session((T24Context)this);
                final DataAccess daObj = new DataAccess((T24Context)this);
                final Contract contractObj = new Contract((T24Context)this);
                final String finMne = sessObj.getCompanyRecord().getFinanFinanMne().getValue();
                final String accountReference = accountRecordObj.getAccountReference().getValue();
                final String getRemarks = arrangementActivityRecord.getRemarks().getValue();
                final String productCode = getRemarks.split("-")[0];
                final String loanArrId = getRemarks.split("-")[1];
                if (!productCode.equals("") && !loanArrId.equals("")) {
                    contractObj.setContractId(loanArrId);
                    final AaPrdDesTermAmountRecord prdDesTermAmountObj = new AaPrdDesTermAmountRecord(contractObj.getConditionForProperty("COMMITMENT"));
                    final String arrTermId = String.valueOf(prdDesTermAmountObj.getIdComp1().getValue()) + "-" + prdDesTermAmountObj.getIdComp2().getValue() + "-" + prdDesTermAmountObj.getIdComp3().getValue();
                    final AaPrdDesTermAmountRecord prdDesTermAmount = new AaPrdDesTermAmountRecord(daObj.getRecord(finMne, "AA.ARR.TERM.AMOUNT", "", arrTermId));
                    final String s;
                    switch (s = productCode) {
                        case "ASSET.REV.AC": {
                            prdDesTermAmount.getLocalRefField("L.AST.REV.ACT").setValue(accountReference);
                            break;
                        }
                        case "CAPITALIZED.COM": {
                            prdDesTermAmount.getLocalRefField("L.CHG.CAP.ACT").setValue(accountReference);
                            break;
                        }
                        case "CAPITALIZED.EXP": {
                            prdDesTermAmount.getLocalRefField("L.OTH.CAP.ACT").setValue(accountReference);
                            break;
                        }
                        case "CAPITALIZED.INT": {
                            prdDesTermAmount.getLocalRefField("L.INT.CAP.ACT").setValue(accountReference);
                            break;
                        }
                        default:
                            break;
                    }
                    daObj.updateLocalfields("AA.ARR.TERM.AMOUNT", arrTermId, prdDesTermAmount.toStructure());
                    this.postPO(prdDesTermAmount, transactionData, transactionRecord);
                }
            }
            catch (Exception e3) {
                e3.getMessage();
            }
        }
    }
    
    public void postPO(final AaPrdDesTermAmountRecord prdDesTermAmount, final List<TransactionData> transactionData, final List<TStructure> transactionRecord) {
        final String interestAcct = prdDesTermAmount.getLocalRefField("L.INT.CAP.ACT").getValue();
        final String commissionAct = prdDesTermAmount.getLocalRefField("L.CHG.CAP.ACT").getValue();
        final String expenseAcct = prdDesTermAmount.getLocalRefField("L.OTH.CAP.ACT").getValue();
        final String assetRevAct = prdDesTermAmount.getLocalRefField("L.AST.REV.ACT").getValue();
        final String intCptlzdAmt = prdDesTermAmount.getLocalRefField("L.INT.CPTLZD").getValue();
        final String chargCptlzdAmt = prdDesTermAmount.getLocalRefField("L.CHARG.CAPTLZD").getValue();
        final String othersCaptlzd = prdDesTermAmount.getLocalRefField("L.OTHER.CAPTLZD").getValue();
        final TransactionData txnDataObj = new TransactionData();
        txnDataObj.setFunction("INPUT");
        txnDataObj.setSourceId("BCI.CREATE.ACCT");
        txnDataObj.setTransactionId("");
        txnDataObj.setVersionId("PAYMENT.ORDER,BCI.CREATE.PO");
        txnDataObj.setNumberOfAuthoriser("0");
        if (!interestAcct.isEmpty()) {
            final TStructure rec1 = this.postPaymentOrder(interestAcct, assetRevAct, intCptlzdAmt);
            transactionData.add(txnDataObj);
            transactionRecord.add(rec1);
        }
        if (!commissionAct.isEmpty()) {
            final TStructure rec2 = this.postPaymentOrder(commissionAct, assetRevAct, chargCptlzdAmt);
            transactionData.add(txnDataObj);
            transactionRecord.add(rec2);
        }
        if (!expenseAcct.isEmpty()) {
            final TStructure rec3 = this.postPaymentOrder(expenseAcct, assetRevAct, othersCaptlzd);
            transactionData.add(txnDataObj);
            transactionRecord.add(rec3);
        }
    }
    
    public TStructure postPaymentOrder(final String debitActNum, final String creditActNum, final String transAmt) {
        final PaymentOrderRecord poRec = new PaymentOrderRecord((T24Context)this);
        try {
            poRec.setPaymentOrderProduct((CharSequence)"LONTRF");
            poRec.setDebitAccount((CharSequence)debitActNum);
            poRec.setCreditAccount((CharSequence)creditActNum);
            poRec.setPaymentAmount((CharSequence)transAmt);
        }
        catch (Exception e2) {
            e2.getMessage();
        }
        return poRec.toStructure();
    }
}
