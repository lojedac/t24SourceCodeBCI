
package com.bci;

import com.temenos.t24.api.records.aaarrangementactivity.FieldNameClass;
import com.temenos.t24.api.records.aaarrangementactivity.PropertyClass;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.t24.api.records.aaarrangementactivity.CustomerClass;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.tables.ebbcihlnrestructcptlzdparam.EbBciHLnRestructCptlzdParamRecord;
import com.temenos.t24.api.system.Session;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import java.util.List;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/**
-------------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Create New Capitalised Accounts using OFS
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : BRD 04-05 
*Attached To            : AA.PRD.DES.ACTIVITY.API>BCI.GROUP.SUB.LOAN.REF.REE.API-20210504 
*Attached as            : Post Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
*                        PARTHIBAN B                     2022-03-15           Modified to store the Loan acct category in the property of ACCOUNT
*------------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*------------------------------------------------------------------------------------------------------------------------------------------------
 *
 */

public class BciAaLoanAcctGen extends ActivityLifecycle
{
    public static final String OFS_VERSION_ID = "AA.ARRANGEMENT.ACTIVITY,";
    public static final String OFS_SOURCE = "BCI.CREATE.ACCT";
    public static final String ACT_ID = "/";
    public static final String FUNC_INPUT = "INPUT";
    public static final String NO_OF_AUTH = "0";
    public static final String ACTIVITY = "ACCOUNTS-NEW-ARRANGEMENT";
    public static final String ARRANGEMENT_ID = "NEW";
    public static final String INT_PRD = "CAPITALIZED.INT";
    public static final String COM_PRD = "CAPITALIZED.COM";
    public static final String EXP_PRD = "CAPITALIZED.EXP";
    public static final String ASSET_PRD = "ASSET.REV.AC";
    public static final String PROPERTY_BAL = "BALANCE";
    String finMne;
    String lnCategCode;
    
    public BciAaLoanAcctGen() {
        this.finMne = "";
        this.lnCategCode = "";
    }
    
    public void postCoreTableUpdate(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record, final List<TransactionData> transactionData, final List<TStructure> transactionRecord) {
        if (arrangementContext.getActivityStatus().equals("AUTH")) {
            final AaPrdDesTermAmountRecord termAmountRecordObj = new AaPrdDesTermAmountRecord(record);
            EbBciHLnRestructCptlzdParamRecord restructCptlRecordObj = null;
            final String arrId = arrangementActivityRecord.getArrangement().getValue();
            final CustomerClass customerId = arrangementActivityRecord.getCustomer(0);
            final AaArrangementActivityRecord actRecordObj = new AaArrangementActivityRecord();
            final String currArrId = arrangementActivityRecord.getArrangement().getValue();
            final DataAccess daObj = new DataAccess((T24Context)this);
            final Session sessionObj = new Session((T24Context)this);
            this.finMne = sessionObj.getCompanyRecord().getFinanFinanMne().getValue();
            String interestProduct = "";
            String chgProduct = "";
            String expProduct = "";
            String asstRevProduct = "";
            try {
                restructCptlRecordObj = new EbBciHLnRestructCptlzdParamRecord(daObj.getRecord(this.finMne, "EB.BCI.H.LN.RESTRUCT.CPTLZD.PARAM", "", "SYSTEM"));
                final String interestCapital = termAmountRecordObj.getLocalRefField("L.INT.CPTLZD").getValue();
                final String expCapital = termAmountRecordObj.getLocalRefField("L.OTHER.CAPTLZD").getValue();
                final String chrgCapital = termAmountRecordObj.getLocalRefField("L.CHARG.CAPTLZD").getValue();
                final Contract cnt = new Contract((T24Context)this);
                cnt.setContractId(currArrId);
                final AaPrdDesAccountRecord acctPrdCndRec = cnt.getAccountCondition("");
                final String acctRef = acctPrdCndRec.getAccountReference().getValue();
                final TStructure rec1 = daObj.getRecord("ACCOUNT", acctRef);
                final AccountRecord acRec = new AccountRecord(rec1);
                this.lnCategCode = acRec.getCategory().getValue();
                if (!interestCapital.isEmpty()) {
                    interestProduct = restructCptlRecordObj.getIntCapitalizedAct().getValue();
                    actRecordObj.setRemarks((CharSequence)("CAPITALIZED.INT-" + arrId));
                    this.postOfs(arrId, daObj, customerId, transactionData, transactionRecord, interestProduct, actRecordObj);
                }
                if (!chrgCapital.isEmpty()) {
                    chgProduct = restructCptlRecordObj.getChgCapitalizedAct().getValue();
                    actRecordObj.setRemarks((CharSequence)("CAPITALIZED.COM-" + arrId));
                    this.postOfs(arrId, daObj, customerId, transactionData, transactionRecord, chgProduct, actRecordObj);
                }
                if (!expCapital.isEmpty()) {
                    expProduct = restructCptlRecordObj.getOthsCapitalizedAct().getValue();
                    actRecordObj.setRemarks((CharSequence)("CAPITALIZED.EXP-" + arrId));
                    this.postOfs(arrId, daObj, customerId, transactionData, transactionRecord, expProduct, actRecordObj);
                }
                if (!interestCapital.isEmpty() || !expCapital.isEmpty() || !chrgCapital.isEmpty()) {
                    asstRevProduct = restructCptlRecordObj.getAssetRevAct().getValue();
                    actRecordObj.setRemarks((CharSequence)("ASSET.REV.AC-" + arrId));
                    this.postOfs(arrId, daObj, customerId, transactionData, transactionRecord, asstRevProduct, actRecordObj);
                }
            }
            catch (Exception e) {
                e.getMessage();
            }
        }
    }
    
    private void postOfs(final String arrId, final DataAccess daObj, final CustomerClass customerId, final List<TransactionData> transactionData, final List<TStructure> transactionRecord, final String prodCode, final AaArrangementActivityRecord actRecordObj) {
        try {
            final AaArrangementRecord actObj = new AaArrangementRecord(daObj.getRecord(this.finMne, "AA.ARRANGEMENT", "", arrId));
            final Session sessObj = new Session((T24Context)this);
            actRecordObj.setCustomer(customerId, 0);
            final String currency = actObj.getCurrency().getValue();
            actRecordObj.setCurrency((CharSequence)currency);
            actRecordObj.setArrangement((CharSequence)"NEW");
            actRecordObj.setActivity((CharSequence)"ACCOUNTS-NEW-ARRANGEMENT");
            actRecordObj.setEffectiveDate((CharSequence)sessObj.getCurrentVariable("!TODAY"));
            actRecordObj.setProduct((CharSequence)prodCode);
            final PropertyClass propClassObj = new PropertyClass();
            propClassObj.setProperty((CharSequence)"BALANCE");
            final FieldNameClass fc = new FieldNameClass();
            fc.setFieldName((CharSequence)"L.REF.REE.CATEG");
            fc.setFieldValue((CharSequence)this.lnCategCode);
            propClassObj.setFieldName(fc, 0);
            actRecordObj.setProperty(propClassObj, 0);
            final TransactionData txnDataObj = new TransactionData();
            txnDataObj.setSourceId("BCI.CREATE.ACCT");
            txnDataObj.setFunction("INPUT");
            txnDataObj.setNumberOfAuthoriser("0");
            txnDataObj.setTransactionId("/");
            txnDataObj.setVersionId("AA.ARRANGEMENT.ACTIVITY,");
            transactionData.add(txnDataObj);
            transactionRecord.add(actRecordObj.toStructure());
        }
        catch (Exception e2) {
            e2.getMessage();
        }
    }
}
