package com.bci;

import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.api.TField;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/**
*
*----------------------------------------------------------------------------------------------------------------
* Description           : AA Validation Routine to raise error when the field value L.PN.AMT.OLD.LN is null and local field values L.INT.CPTLZD, L.CHARG.CPTLZD, L.OTHER.CPTLZD is not null and Local field values is not Negative
* Developed By          : Kalaipriya M,Techmill Technologies     
* Development Reference : BRD-04-05_IDENTIFICAR POR SEPARADO PRINCIPAL, INTERESES, COMISIONES Y GASTOS CAPITALIZADOS 
* Attached To           : Activity.API> BCI.GROUP.SUB.LOAN.REF.REE.API        
* Attached As           : Validation Routine  
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************        
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*   
*/  

public class BciAaLoanFieldValidate extends ActivityLifecycle
{
    public void validateNegativeCheck(final String amtVal, final TField setErrorFld, final String errorId) {
        if (!amtVal.equals("") && amtVal.contains("-")) {
            setErrorFld.setError(errorId);
        }
    }
    
    public TValidationResponse validateRecord(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record) {
        final AaPrdDesTermAmountRecord aaPrdTermAmountObj = new AaPrdDesTermAmountRecord(record);
        TField principalLoan = new TField();
        String principalAmt = "";
        String interestAmt = "";
        String chargeAmt = "";
        String othExpenseAmt = "";
        TField interestAmtFld = null;
        TField chargeAmtFld = null;
        TField othExpenseAmtFld = null;
        final String errorId1 = "AA-BCI.PRINCIPAL.REF.REE.FLD.INCORRECTLY";
        final String errorId2 = "AA-BCI.CAPITALIZED.INTEREST.FLD.INCORRECTLY";
        final String errorId3 = "AA-BCI.CAPITALIZED.COMMISSIONS.FLD.INCORRECTLY";
        final String errorId4 = "AA-BCI.CAPITALIZED.EXPENSES.FLD.INCORRECTLY";
        try {
            principalLoan = aaPrdTermAmountObj.getLocalRefField("L.PN.AMT.OLD.LN");
            principalAmt = principalLoan.getValue();
            this.validateNegativeCheck(principalAmt, principalLoan, errorId1);
            interestAmtFld = aaPrdTermAmountObj.getLocalRefField("L.INT.CPTLZD");
            interestAmt = interestAmtFld.getValue();
            this.validateNegativeCheck(interestAmt, interestAmtFld, errorId2);
            chargeAmtFld = aaPrdTermAmountObj.getLocalRefField("L.CHARG.CAPTLZD");
            chargeAmt = chargeAmtFld.getValue();
            this.validateNegativeCheck(chargeAmt, chargeAmtFld, errorId3);
            othExpenseAmtFld = aaPrdTermAmountObj.getLocalRefField("L.OTHER.CAPTLZD");
            othExpenseAmt = othExpenseAmtFld.getValue();
            this.validateNegativeCheck(othExpenseAmt, othExpenseAmtFld, errorId4);
        }
        catch (Exception e) {
            e.getMessage();
        }
        if ((principalAmt.isEmpty() || principalAmt.equals("0")) && (!interestAmt.isEmpty() || !chargeAmt.isEmpty() || !othExpenseAmt.isEmpty())) {
            principalLoan.setError("AA-BCI.PRINCIPAL.MANDATORY");
        }
        return aaPrdTermAmountObj.getValidationResponse();
    }
}
