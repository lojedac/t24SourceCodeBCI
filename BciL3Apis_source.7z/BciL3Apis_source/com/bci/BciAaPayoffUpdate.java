package com.bci;

import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.BalanceTypeClass;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementRecord;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementTable;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import java.util.List;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

public class BciAaPayoffUpdate extends ActivityLifecycle
{
    public void postCoreTableUpdate(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record, final List<TransactionData> transactionData, final List<TStructure> transactionRecord) {
        try {
            final DataAccess daObj = new DataAccess((T24Context)this);
            final Contract contract = new Contract((T24Context)this);
            final EbBciLLoanCapitalizeMovementTable lnCptlMvmtTab = new EbBciLLoanCapitalizeMovementTable((T24Context)this);
            final String currAction = arrangementContext.getActivityStatus();
            if (currAction.equals("AUTH")) {
                final String arrId = arrangementActivityRecord.getArrangement().getValue();
                final String linkedApplId = arrangementRecord.getLinkedAppl(0).getLinkedApplId().getValue();
                final List<String> remainIdsMvmtTab = (List<String>)daObj.selectRecords("", "EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT", "", "@ID LIKE " + linkedApplId + "... AND SETTLE.STATUS NE SETTLED");
                for (int noOfExist = remainIdsMvmtTab.size(), i = 0; i < noOfExist; ++i) {
                    final String currId = remainIdsMvmtTab.get(i);
                    final TStructure rec1 = daObj.getRecord("EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT", currId);
                    final EbBciLLoanCapitalizeMovementRecord cptlzeMvmtRecObj = new EbBciLLoanCapitalizeMovementRecord(rec1);
                    final List<BalanceTypeClass> balanceTypeList = (List<BalanceTypeClass>)cptlzeMvmtRecObj.getBalanceType();
                    for (int j = 0; j < balanceTypeList.size(); ++j) {
                        final BalanceTypeClass balanceTypeClass = balanceTypeList.get(j);
                        balanceTypeClass.setAdjAmt((CharSequence)balanceTypeClass.getOrigBal().getValue(), balanceTypeClass.getAdjAmt().size());
                        balanceTypeClass.getBalance().set("0");
                    }
                    cptlzeMvmtRecObj.setSettleStatus((CharSequence)"SETTLED");
                    lnCptlMvmtTab.write((CharSequence)currId, cptlzeMvmtRecObj);
                    final BciCreatePayOrder createPaymentOrder = new BciCreatePayOrder();
                    final List<TStructure> paymentOrderRecord = createPaymentOrder.getPaymentOrderRec(arrId, cptlzeMvmtRecObj, "BNK", daObj, contract, currId);
                    final TransactionData txnDataRecord = createPaymentOrder.getTrasactionData();
                    for (int paymentSize = 0; paymentSize < paymentOrderRecord.size(); ++paymentSize) {
                        transactionRecord.add(paymentOrderRecord.get(paymentSize));
                        transactionData.add(txnDataRecord);
                    }
                }
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
    }
}
