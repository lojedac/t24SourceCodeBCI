package com.bci;

import java.util.Iterator;
import java.util.List;
import com.temenos.api.TField;
import java.util.ArrayList;
import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/**
 *
 * 
 * -------------------------------------------------------------------------------------------------------------------------------------------
 * Description          : Sum of Local fields should be equal to Amount field in AA.ARR.TERM.AMOUNT
 * Developed By         : Mallika V, Techmill Technologies Development
 * Development Ref      : BRD 04-05
 * Attached To          :AA.PRD.DES.ACTIVITY.API>BCI.GROUP.SUB.LOAN.REF.REE.API-20210504
 * Attached as          :Validation Routine
 * -------------------------------------------------------------------------------------------------------------------------------------------
 *  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
 *
 */

public class BciAaTermAmountValidate extends ActivityLifecycle
{
    public static final String AA_BCI_INVALID_LOAN_AMOUNT = "AA-BCI.INVALID.LOAN.AMOUNT";
    
    public TValidationResponse validateRecord(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record) {
        final AaPrdDesTermAmountRecord termAmountObj = new AaPrdDesTermAmountRecord(record);
        try {
            final TField amountVal = termAmountObj.getAmount();
            final List<String> localRefField = new ArrayList<String>();
            localRefField.add("L.PN.AMT.OLD.LN");
            localRefField.add("L.INT.CPTLZD");
            localRefField.add("L.CHARG.CAPTLZD");
            localRefField.add("L.OTHER.CAPTLZD");
            double totAmount = 0.0;
            for (final String localRef : localRefField) {
                final TField localrefTfiledObj = termAmountObj.getLocalRefField(localRef);
                final String amountLocal = localrefTfiledObj.getValue();
                final double amount = this.getAmount(amountLocal);
                totAmount += amount;
            }
            final String amountCore = amountVal.getValue();
            final Double amountDouble = Double.parseDouble(amountCore);
            if (amountDouble != totAmount) {
                amountVal.setError("AA-BCI.INVALID.LOAN.AMOUNT");
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        return termAmountObj.getValidationResponse();
    }
    
    public double getAmount(final String amountLocal) {
        double amountLocDouble;
        try {
            amountLocDouble = Double.parseDouble(amountLocal);
        }
        catch (Exception e) {
            amountLocDouble = 0.0;
        }
        return amountLocDouble;
    }
}
