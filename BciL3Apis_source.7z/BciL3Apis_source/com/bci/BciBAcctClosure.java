package com.bci;

import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.system.Session;
import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.servicehook.SynchronousTransactionData;
import com.temenos.t24.api.complex.eb.servicehook.TransactionControl;
import java.util.Iterator;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import java.util.ArrayList;
import java.util.List;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import com.temenos.t24.api.hook.system.ServiceLifecycle;

/**
*
* @author Parthiban B
* 
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description           : To close the fully settled Capitalized Accounts
*Developed By          : Parthiban Balasubramaniam, Techmill Technologies
*Development Reference : BRD 04/05
*Attached To           : BATCH>BNK/BCI.ACCOUNT.CLOSURE
*Attached as           : Online Service Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************        
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*   
*/  

public class BciBAcctClosure extends ServiceLifecycle
{
    public List<String> getIds(final ServiceData serviceData, final List<String> controlList) {
        List<String> acctIds = new ArrayList<String>();
        try {
            final DataAccess da = new DataAccess((T24Context)this);
            String arrIdsStr = "";
            final List<String> refResArrIds = (List<String>)da.selectRecords("", "AA.ARRANGEMENT", "", "WITH PRODUCT.GROUP EQ CAP.ACCOUNTS");
            for (final String currId : refResArrIds) {
                arrIdsStr = arrIdsStr.concat(" ");
                arrIdsStr = arrIdsStr.concat(currId);
            }
            acctIds = (List<String>)da.selectRecords("", "ACCOUNT", "", "WITH AMNT.LAST.DR.BANK NE '' AND WORKING.BALANCE EQ 0 AND ARRANGEMENT.ID EQ" + arrIdsStr);
        }
        catch (Exception e1) {
            e1.getMessage();
        }
        return acctIds;
    }
    
    public void updateRecord(final String id, final ServiceData serviceData, final String controlItem, final TransactionControl transactionControl, final List<SynchronousTransactionData> transactionData, final List<TStructure> records) {
        try {
            final Session sessionObj = new Session((T24Context)this);
            final AaArrangementActivityRecord aaaRec = new AaArrangementActivityRecord();
            aaaRec.setArrangement((CharSequence)id);
            aaaRec.setActivity((CharSequence)"ACCOUNTS-CLOSE-ARRANGEMENT");
            aaaRec.setEffectiveDate((CharSequence)sessionObj.getCurrentVariable("!TODAY"));
            final SynchronousTransactionData txnData = new SynchronousTransactionData();
            txnData.setFunction("INPUT");
            txnData.setNumberOfAuthoriser("0");
            txnData.setSourceId("BCI.CREATE.ACCT");
            txnData.setTransactionId("/");
            txnData.setVersionId("AA.ARRANGEMENT.ACTIVITY,ACCT.CLOSURE");
            transactionData.add(txnData);
            records.add(aaaRec.toStructure());
        }
        catch (Exception e2) {
            e2.getMessage();
        }
    }
}
