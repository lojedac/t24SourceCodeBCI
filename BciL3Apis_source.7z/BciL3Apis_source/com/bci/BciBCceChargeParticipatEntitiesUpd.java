
package com.bci;

import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.servicehook.TransactionData;
import com.temenos.t24.api.tables.ebbcihccepartfilepathparam.EbBciHCcePartFilePathParamRecord;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;
import com.temenos.api.exceptions.T24IOException;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.tables.ebbcihccepartfilepathparam.EbBciHCcePartFilePathParamTable;
import com.temenos.t24.api.tables.ebbcihcceparticipantdir.EbBciHCceParticipantDirRecord;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import java.util.ArrayList;
import java.util.List;
import com.temenos.t24.api.hook.system.ServiceLifecycle;

/**
*@author Kalaipriya.M
*----------------------------------------------------------------------------------------------------------------
* Description           : To update records to EB.BCI.H.CCE.PARTICIPANT.DIR this table 
* Developed By          : Kalaipriya M,Techmill Technologies     
* Development Reference : BRD-010-Information_CCE Charge_Participanting_Entities
* Attached To           : BATCH> BCI.B.CCE.CHARGE.UPD & BCI.B.CCE.CORRECTION.CHRG.UPD
* Attached As           : Service Routine  
*-------------------------------------------------------  ----------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/


public class BciBCceChargeParticipatEntitiesUpd extends ServiceLifecycle
{
    static List<String> outFieldList;
    static List<String> outFieldLengthList;
    static String applVersion;
    static String sourceId;
    
    static {
        BciBCceChargeParticipatEntitiesUpd.outFieldList = new ArrayList<String>();
        BciBCceChargeParticipatEntitiesUpd.outFieldLengthList = new ArrayList<String>();
        BciBCceChargeParticipatEntitiesUpd.applVersion = "EB.BCI.H.CCE.PARTICIPANT.DIR,OFS.INPUT";
        BciBCceChargeParticipatEntitiesUpd.sourceId = "BCI.CCE.OFS";
    }
    
    public String strTrim(String str) {
        str = str.trim();
        return str;
    }
    
    public void initialise(final ServiceData serviceData) {
        this.fieldsAdd(BciBCceChargeParticipatEntitiesUpd.outFieldList, BciBCceChargeParticipatEntitiesUpd.outFieldLengthList);
    }
    
    public void fieldsAdd(final List<String> fieldList, final List<String> fieldLengthList) {
        try {
            fieldList.add("regCode");
            fieldLengthList.add("0,2");
            fieldList.add("entitityNumber");
            fieldLengthList.add("2,5");
            fieldList.add("officeNumber");
            fieldLengthList.add("5,8");
            fieldList.add("officeNoSquare");
            fieldLengthList.add("8,12");
            fieldList.add("ubigeoCode");
            fieldLengthList.add("12,18");
            fieldList.add("ubigeoTransfer");
            fieldLengthList.add("18,24");
            fieldList.add("filled1");
            fieldLengthList.add("24,47");
            fieldList.add("officeName");
            fieldLengthList.add("47,82");
            fieldList.add("officeAddress");
            fieldLengthList.add("82,162");
            fieldList.add("location");
            fieldLengthList.add("162,197");
            fieldList.add("desZipCode");
            fieldLengthList.add("197,201");
            fieldList.add("squareName");
            fieldLengthList.add("201,236");
            fieldList.add("officeType");
            fieldLengthList.add("236,237");
            fieldList.add("ubigeoCodeDisoffice");
            fieldLengthList.add("237,243");
            fieldList.add("exclusivePlaza");
            fieldLengthList.add("243,244");
            fieldList.add("filled2");
            fieldLengthList.add("244,246");
            fieldList.add("longDistPhonePrefix");
            fieldLengthList.add("246,249");
            fieldList.add("directPhNum1");
            fieldLengthList.add("249,257");
            fieldList.add("directPhNum2");
            fieldLengthList.add("257,265");
            fieldList.add("faxPhNum1");
            fieldLengthList.add("265,273");
            fieldList.add("telphoneExchNo");
            fieldLengthList.add("273,281");
            fieldList.add("extensionNo");
            fieldLengthList.add("281,286");
            fieldList.add("reasonUpdate");
            fieldLengthList.add("286,287");
            fieldList.add("updateDate");
            fieldLengthList.add("287,295");
            fieldList.add("filled3");
            fieldLengthList.add("295,300");
        }
        catch (Exception e) {
            e.getMessage();
        }
    }
    
    public List<String> dataExtract(final String data, final List<String> fieldList2, final List<String> fieldLengthList2) {
        final List<String> fielddataList = new ArrayList<String>();
        for (int i = 0; i < fieldList2.size(); ++i) {
            String dataExtracted = "";
            try {
                final String fieldLength = fieldLengthList2.get(i);
                final int startIndex = Integer.parseInt(fieldLength.split(",")[0]);
                final int endIndex = Integer.parseInt(fieldLength.split(",")[1]);
                dataExtracted = data.substring(startIndex, endIndex);
            }
            catch (Exception e2) {
                e2.getMessage();
            }
            fielddataList.add(dataExtracted);
        }
        return fielddataList;
    }
    
    public String localTableRecFrame(final List<String> dataList1, final EbBciHCceParticipantDirRecord rec) {
        String recId2 = "";
        recId2 = String.valueOf(String.valueOf(dataList1.get(0))) + dataList1.get(1) + dataList1.get(2) + dataList1.get(3);
        rec.setUbigeoCode((CharSequence)this.strTrim(dataList1.get(4)));
        rec.setFilled1((CharSequence)this.strTrim(dataList1.get(6)));
        rec.setOfficeName((CharSequence)this.strTrim(dataList1.get(7)));
        rec.setOfficeAddress((CharSequence)this.strTrim(dataList1.get(8)));
        rec.setLocation((CharSequence)this.strTrim(dataList1.get(9)));
        rec.setDestinationZipCode((CharSequence)this.strTrim(dataList1.get(10)));
        rec.setSquareName((CharSequence)this.strTrim(dataList1.get(11)));
        rec.setOfficeType((CharSequence)this.strTrim(dataList1.get(12)));
        rec.setUbigeoCodeDistOff((CharSequence)this.strTrim(dataList1.get(13)));
        rec.setExclusivePlaza((CharSequence)this.strTrim(dataList1.get(14)));
        rec.setFilled2((CharSequence)this.strTrim(dataList1.get(15)));
        rec.setLongDisPhonePrefix((CharSequence)this.strTrim(dataList1.get(16)));
        rec.setDirectPhoneNum1((CharSequence)this.strTrim(dataList1.get(17)));
        rec.setDirectPhoneNum2((CharSequence)this.strTrim(dataList1.get(18)));
        rec.setFaxPhoneNum((CharSequence)this.strTrim(dataList1.get(19)));
        rec.setTelephoneExcgNum((CharSequence)this.strTrim(dataList1.get(20)));
        rec.setExtensionNum((CharSequence)this.strTrim(dataList1.get(21)));
        rec.setReasonUpdate((CharSequence)this.strTrim(dataList1.get(22)));
        rec.setUpdateDate((CharSequence)this.strTrim(dataList1.get(23)));
        rec.setFilled3((CharSequence)this.strTrim(dataList1.get(24)));
        rec.setUbigeoTransfer((CharSequence)this.strTrim(dataList1.get(5)));
        final String reasonUptStr = dataList1.get(22);
        if (reasonUptStr.equals("B") || reasonUptStr.equals("D")) {
            rec.setMarker((CharSequence)"Inactive");
        }
        else {
            rec.setMarker((CharSequence)"Active");
        }
        return recId2;
    }
    
    public List<String> getIds(final ServiceData serviceData, final List<String> controlList) {
        final List<String> dataStringList = new ArrayList<String>();
        final EbBciHCcePartFilePathParamTable paramTable = new EbBciHCcePartFilePathParamTable((T24Context)this);
        EbBciHCcePartFilePathParamRecord paramRec = null;
        String fileName = "";
        String filePath = "";
        try {
            paramRec = paramTable.read((CharSequence)"SYSTEM");
            fileName = paramRec.getFileName().getValue();
            filePath = paramRec.getFilePath().getValue();
        }
        catch (T24IOException e) {
            e.getMessage();
        }
        final File file = new File(filePath, fileName);
        if (file.exists()) {
            try {
                final Scanner fileRead = new Scanner(file);
                while (fileRead.hasNextLine()) {
                    final String data = fileRead.nextLine();
                    dataStringList.add(data);
                }
                fileRead.close();
            }
            catch (FileNotFoundException e2) {
                e2.getMessage();
            }
        }
        return dataStringList;
    }
    
    public void postUpdateRequest(final String id, final ServiceData serviceData, final String controlItem, final List<TransactionData> transactionData, final List<TStructure> records) {
        final String dataIncoming = id;
        final List<String> localTablefielddataList = this.dataExtract(dataIncoming, BciBCceChargeParticipatEntitiesUpd.outFieldList, BciBCceChargeParticipatEntitiesUpd.outFieldLengthList);
        final EbBciHCceParticipantDirRecord cceParticipantRec = new EbBciHCceParticipantDirRecord();
        String cCParticipantRecId = "";
        cCParticipantRecId = this.localTableRecFrame(localTablefielddataList, cceParticipantRec);
        final TransactionData txnData = new TransactionData();
        txnData.setTransactionId(cCParticipantRecId);
        final String coCode = serviceData.getCompanyId();
        txnData.setFunction("I");
        txnData.setNumberOfAuthoriser("0");
        txnData.setSourceId(BciBCceChargeParticipatEntitiesUpd.sourceId);
        txnData.setVersionId(BciBCceChargeParticipatEntitiesUpd.applVersion);
        txnData.setCompanyId(coCode);
        transactionData.add(txnData);
        records.add(cceParticipantRec.toStructure());
    }
}
