package com.bci;

import com.temenos.api.TStructure;
import java.util.Iterator;
import java.util.List;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.CurrencyClass;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceTable;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import java.util.ArrayList;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import com.temenos.t24.api.hook.system.ServiceLifecycle;

/**
* 
* @author Parthiban B 
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Java hook to clear and set the CURR.ACCUMULATED.LIMIT field value as 0.0 in EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE in COB
* Developed By          : Parthiban Balasubramaniam, Techmill Technologies  
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : BATCH>BNK/BCI.DAILY.ACCUM.LIMIT.CLR
* Attached As           : COB Job
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciBFavorBalLimitClr extends ServiceLifecycle
{
    public void process(final String id, final ServiceData serviceData, final String controlItem) {
        try {
            final List<String> favorBalIds = new ArrayList<String>();
            favorBalIds.add("R16");
            favorBalIds.add("R17/R18");
            final DataAccess da = new DataAccess((T24Context)this);
            for (final String curFavoBalId : favorBalIds) {
                final TStructure rec1 = da.getRecord("EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE", curFavoBalId);
                final EbBciDailyLimitFavorableBalanceRecord favorBalLimitRec = new EbBciDailyLimitFavorableBalanceRecord(rec1);
                final EbBciDailyLimitFavorableBalanceTable favorBalLimitTable = new EbBciDailyLimitFavorableBalanceTable((T24Context)this);
                final List<CurrencyClass> currList = (List<CurrencyClass>)favorBalLimitRec.getCurrency();
                int idx = 0;
                for (final CurrencyClass currObj : currList) {
                    currObj.setCurrAccumulatedLimit((CharSequence)"0.0");
                    favorBalLimitRec.setCurrency(currObj, idx);
                    ++idx;
                }
                favorBalLimitTable.write((CharSequence)curFavoBalId, favorBalLimitRec);
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
    }
}
