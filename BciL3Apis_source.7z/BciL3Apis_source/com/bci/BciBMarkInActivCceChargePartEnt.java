
package com.bci;

import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebbcihcceparticipantdir.EbBciHCceParticipantDirRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.servicehook.TransactionData;
import java.util.ArrayList;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import java.util.List;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import com.temenos.t24.api.hook.system.ServiceLifecycle;

/**
*@author Kalaipriya.M
*----------------------------------------------------------------------------------------------------------------
* Description           : To update the MARKER field as Inactive in EB.BCI.H.CCE.PARTICIPANT.DIR table 
* Developed By          : Kalaipriya M,Techmill Technologies     
* Development Reference : BRD-010-Information_CCE Charge_Participanting_Entities
* Attached To           : BATCH> BCI.B.CCE.CHARGE.UPD
* Attached As           : Service Routine          
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*   
*/

public class BciBMarkInActivCceChargePartEnt extends ServiceLifecycle
{
    public List<String> getIds(final ServiceData serviceData, final List<String> controlList) {
        final DataAccess da = new DataAccess((T24Context)this);
        List<String> cCERecIdsList = new ArrayList<String>();
        try {
            cCERecIdsList = (List<String>)da.selectRecords("", "EB.BCI.H.CCE.PARTICIPANT.DIR", "", "");
        }
        catch (Exception e) {
            e.getMessage();
        }
        return cCERecIdsList;
    }
    
    public void postUpdateRequest(final String id, final ServiceData serviceData, final String controlItem, final List<TransactionData> transactionData, final List<TStructure> records) {
        final String cCERecId = id;
        final EbBciHCceParticipantDirRecord cceParticipantRec = new EbBciHCceParticipantDirRecord();
        cceParticipantRec.setMarker((CharSequence)"Inactive");
        final String applVersion = "EB.BCI.H.CCE.PARTICIPANT.DIR,SET.INACTIVE";
        final String sourceId = "BCI.CCE.OFS";
        final TransactionData txnData = new TransactionData();
        txnData.setVersionId(applVersion);
        txnData.setFunction("I");
        txnData.setNumberOfAuthoriser("0");
        final Session sessObj = new Session((T24Context)this);
        final String comp = sessObj.getCompanyId().toString();
        txnData.setCompanyId(comp);
        txnData.setTransactionId(cCERecId);
        txnData.setSourceId(sourceId);
        transactionData.add(txnData);
        records.add(cceParticipantRec.toStructure());
    }
}
