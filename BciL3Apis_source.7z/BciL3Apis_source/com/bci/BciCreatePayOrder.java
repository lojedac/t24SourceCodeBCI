package com.bci;

import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import com.temenos.t24.api.records.paymentorder.InstructionCodeClass;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.BalanceTypeClass;
import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import java.util.ArrayList;
import com.temenos.api.TStructure;
import java.util.List;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementRecord;

/**
 *
 * @author Parthiban B
 * 
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *Description           : Raise Accounting Entries for Capitalized Accounts
 *Developed By          : Parthiban Balasubramaniam, Techmill Technologies
 *Development Reference : BRD 04/05
 *Attached To           : BciRepayAdjBalanceUpdate
 *Attached as           : Calling Routine
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *  M O D I F I C A T I O N S
 * ***************************        
 *-----------------------------------------------------------------------------------------------------------------
 * Defect Reference       Modified By                    Date of Change        Change Details
 * (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
 *-----------------------------------------------------------------------------------------------------------------
 * XXXX                   <<name of modifier>>                                 <<modification details goes here>>
 *-----------------------------------------------------------------------------------------------------------------
 * Include files
 *-----------------------------------------------------------------------------------------------------------------
 *   
 */   

public class BciCreatePayOrder
{
    public static final String PROP = "COMMITMENT";
    
    public List<TStructure> getPaymentOrderRec(final String loanArrId, final EbBciLLoanCapitalizeMovementRecord cptlzeRec, final String finMne, final DataAccess daObj, final Contract contractObj, final String currId) {
        final List<TStructure> paymentRecordList = new ArrayList<TStructure>();
        try {
            contractObj.setContractId(loanArrId);
            final EbBciLLoanCapitalizeMovementRecord capitalMvmtRecord = cptlzeRec;
            final AaPrdDesTermAmountRecord prdDesTermAmountObj = new AaPrdDesTermAmountRecord(contractObj.getConditionForProperty("COMMITMENT"));
            final String assetRevAct = prdDesTermAmountObj.getLocalRefField("L.AST.REV.ACT").getValue();
            String capitalizedActNum = "";
            final List<BalanceTypeClass> balanceTypeList = (List<BalanceTypeClass>)capitalMvmtRecord.getBalanceType();
            String adjAmt = "";
            for (int index = 0; index < balanceTypeList.size(); ++index) {
                final String balanceType = balanceTypeList.get(index).getBalanceType().getValue();
                if (balanceType.equalsIgnoreCase("CAPEXPENSE")) {
                    adjAmt = balanceTypeList.get(index).getOrigBal().getValue();
                    capitalizedActNum = prdDesTermAmountObj.getLocalRefField("L.OTH.CAP.ACT").getValue();
                    final TStructure paymetRec1 = this.paymentRecordMessage(capitalizedActNum, adjAmt, assetRevAct, currId, balanceType);
                    paymentRecordList.add(paymetRec1);
                }
                if (balanceType.equalsIgnoreCase("CAPCOMM")) {
                    adjAmt = balanceTypeList.get(index).getOrigBal().getValue();
                    capitalizedActNum = prdDesTermAmountObj.getLocalRefField("L.CHG.CAP.ACT").getValue();
                    final TStructure paymetRec2 = this.paymentRecordMessage(capitalizedActNum, adjAmt, assetRevAct, currId, balanceType);
                    paymentRecordList.add(paymetRec2);
                }
                if (balanceType.equalsIgnoreCase("CAPINT")) {
                    adjAmt = balanceTypeList.get(index).getOrigBal().getValue();
                    capitalizedActNum = prdDesTermAmountObj.getLocalRefField("L.INT.CAP.ACT").getValue();
                    final TStructure paymetRec3 = this.paymentRecordMessage(capitalizedActNum, adjAmt, assetRevAct, currId, balanceType);
                    paymentRecordList.add(paymetRec3);
                }
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
        return paymentRecordList;
    }
    
    private TStructure paymentRecordMessage(final String capitalizedActNum, final String adjAmt, final String assetRevAct, final String currId, final String balanceType) {
        final PaymentOrderRecord poRec = new PaymentOrderRecord();        
        poRec.setPaymentOrderProduct((CharSequence)"LONTRF");
        poRec.setDebitAccount((CharSequence)assetRevAct);
        poRec.setCreditAccount((CharSequence)capitalizedActNum);
        poRec.setPaymentAmount((CharSequence)adjAmt);
        try {
            poRec.setOriginalMsgContent(currId + "-" + capitalizedActNum + "-" + balanceType);
            
        } catch (Exception e) {
           System.out.println(e.getMessage());
        }
        return poRec.toStructure();
    }
    
    
    
    
    public TransactionData getTrasactionData() {
        final TransactionData txnDataObj = new TransactionData();
        try {
            final String OFS_VERSION_ID = "PAYMENT.ORDER,BCI.CREATE.PO";
            final String OFS_SOURCE = "BCI.CREATE.ACCT";
            final String PO_ID = "/";
            final String FUNC_INPUT = "INPUT";
            final String NO_OF_AUTH = "0";
            txnDataObj.setFunction("INPUT");
            txnDataObj.setSourceId("BCI.CREATE.ACCT");
            txnDataObj.setTransactionId("/");
            txnDataObj.setVersionId("PAYMENT.ORDER,BCI.CREATE.PO");
            txnDataObj.setNumberOfAuthoriser("0");
        }
        catch (Exception e2) {
            e2.getMessage();
        }
        return txnDataObj;
    }
}
