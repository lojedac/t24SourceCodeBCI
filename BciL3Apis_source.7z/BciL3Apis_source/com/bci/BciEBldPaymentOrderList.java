package com.bci;

import com.temenos.t24.api.records.portransaction.PorTransactionRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.eb.enquiryhook.EnquiryContext;
import com.temenos.t24.api.complex.eb.enquiryhook.FilterCriteria;
import java.util.List;
import com.temenos.t24.api.hook.system.Enquiry;

/**
* @author mallika.v 
*
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : To build the filter criteria with list of FTNumber’s which has PO’s with PAYMENT.ORDER.PRODUCT equals to FOVRBAL or ADJSTMTS
* Developed By          : Mallika V, Techmill Technologies  
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : ENQUIRY>PP.REVERSE.PAYMENT.BCI
* Attached As           : Build Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciEBldPaymentOrderList extends Enquiry
{
    public List<FilterCriteria> setFilterCriteria(final List<FilterCriteria> filterCriteria, final EnquiryContext enquiryContext) {
        final DataAccess daObj = new DataAccess((T24Context)this);
        final FilterCriteria fc = new FilterCriteria();
        String messageType = "";
        String finalId = "";
        final StringBuilder strBld = new StringBuilder();
        try {
            final String fieldValue = filterCriteria.get(0).getValue();
            final List<String> selIds = (List<String>)daObj.selectRecords("", "POR.PAYMENTCURRENTSTATUS", "", " WITH CompanyID EQ " + fieldValue);
            for (int index = 0; index < selIds.size(); ++index) {
                String porId = "";
                final String porIds = selIds.get(index);
                final String[] getPorId = porIds.split("-");
                if (getPorId.length != 0) {
                    porId = getPorId[1];
                }
                final PorTransactionRecord porTransactionRecObj = new PorTransactionRecord(daObj.getRecord("", "POR.TRANSACTION", "", porId));
                messageType = porTransactionRecObj.getIncomingmessagetype().getValue();
                if (messageType.equals("ADJSTMTS") || messageType.equals("FOVRBAL")) {
                    strBld.append(porId);
                    strBld.append(" ");
                }
            }
            finalId = strBld.toString();
            fc.setFieldname("FTNumber");
            fc.setOperand("EQ");
            fc.setValue(finalId);
            filterCriteria.add(fc);
        }
        catch (Exception e) {
            e.getMessage();
        }
        return filterCriteria;
    }
}
