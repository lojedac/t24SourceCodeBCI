package com.bci;

import java.util.Iterator;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import java.util.ArrayList;
import com.temenos.t24.api.complex.eb.enquiryhook.EnquiryContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.enquiryhook.FilterCriteria;
import java.util.List;
import com.temenos.t24.api.hook.system.Enquiry;

/**
* 
* @author Parthiban B 
*---------------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Build Routine to provide drop-down values for the field L.COMPENSATE.PLACE in PAYMENT.ORDER,BCI.ADJUSTMENT.R17ANDR18 version and
*                         L.REVOLV.OFFICE in PAYMENT.ORDER,BCI.FOVRBAL.R16
* Developed By          : Parthiban Balasubramaniam, Techmill Technologies  
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : ENQUIRY>BCI.DRPDOWN.REV.OFFICE & ENQUIRY>BCI.DRPDOWN.COMP.PLACE.R17.AND.R18
* Attached As           : Build Routine
*---------------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*---------------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*---------------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*---------------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciEBldRevOffice extends Enquiry
{
    public List<FilterCriteria> setDropdownFilterCriteria(final List<FilterCriteria> filterCriteria, final TStructure currentRecord, final EnquiryContext enquiryContext) {
        final List<FilterCriteria> fcLst = new ArrayList<FilterCriteria>();
        try {
            final DataAccess da = new DataAccess((T24Context)this);
            final FilterCriteria fc = new FilterCriteria();
            final FilterCriteria fcReceived = filterCriteria.get(0);
            final String revEntity = fcReceived.getValue();
            final List<String> ccePartDirIds = (List<String>)da.selectRecords("", "EB.BCI.H.CCE.PARTICIPANT.DIR", "", "");
            String ccePartDirIdsFinal = "";
            final StringBuilder strBld = new StringBuilder();
            for (final String curId : ccePartDirIds) {
                final String entityCode = curId.substring(2, 5);
                if (revEntity.equals(entityCode)) {
                    strBld.append(curId);
                    strBld.append(" ");
                }
            }
            ccePartDirIdsFinal = strBld.toString();
            fc.setFieldname("@ID");
            fc.setOperand("EQ");
            fc.setValue(ccePartDirIdsFinal);
            fcLst.add(fc);
        }
        catch (Exception e1) {
            e1.getMessage();
        }
        return fcLst;
    }
}
