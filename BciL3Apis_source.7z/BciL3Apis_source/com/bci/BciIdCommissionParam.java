
package com.bci;

import com.temenos.api.TStructure;
import java.util.Iterator;
import java.util.List;
import com.temenos.api.exceptions.T24CoreException;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/*
* @author Parthiban B 
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description           : To validate @ID of EB.BCI.TRNS.CLG.COMMISSION.PARAM table
*Developed By          : Parthiban B, Techmill Technologies
*Development Reference : BRD 11 - Commission Transfers & Cheque
*Attached To           : EB.TABLE.PROCEDURES>EB.BCI.TRNS.CLG.COMMISSION.PARAM
*Attached as           : Check Id Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
* M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/

public class BciIdCommissionParam extends RecordLifecycle
{
    static final String EB_LOOKUP = "EB.LOOKUP";
    static final int MAX_NUM_ELEMENTS = 4;
    
    public String checkId(final String currentRecordId, final TransactionContext transactionContext) {
        final String currFunc = transactionContext.getCurrentFunction();
        if (currFunc.equals("INPUT")) {
            final DataAccess da = new DataAccess((T24Context)this);
            String txnType = "";
            String currency = "";
            String commType = "";
            String bankCode = "";
            int currIdArrLen = 0;
            String id2 = "";
            try {
                final String currId = currentRecordId;
                final String[] currIdArr = currId.split("\\.");
                currIdArrLen = currIdArr.length;
                txnType = currIdArr[0];
                currency = currIdArr[1];
                bankCode = currIdArr[2];
                commType = currIdArr[3];
                id2 = String.valueOf(txnType) + "." + currency + "." + bankCode;
            }
            catch (Exception e1) {
                e1.getMessage();
            }
            if (currIdArrLen > 4) {
                throw new T24CoreException("", "EB-BCI.NOT.VALID.ID.FORMAT");
            }
            this.tranTypeValidate(txnType, da);
            this.currencyValidate(currency, da);
            this.bankCodeValidate(bankCode, da);
            this.commTypeValidate(commType, id2, currentRecordId, da);
        }
        return currentRecordId;
    }
    
    void tranTypeValidate(final String txnType, final DataAccess da) {
        final String ebLookupId = "L.TRANSFER.TYPE*" + txnType;
        try {
            da.getRecord("EB.LOOKUP", ebLookupId);
        }
        catch (Exception e2) {
            if (!txnType.equals("CHE")) {
                throw new T24CoreException("", "EB-BCI.NOT.VALID.TRANSFER.TYPE");
            }
        }
    }
    
    void currencyValidate(final String currencyId, final DataAccess da) {
        try {
            da.getRecord("CURRENCY", currencyId);
        }
        catch (Exception e3) {
            throw new T24CoreException("", "EB-BCI.NOT.VALID.CURRENCY");
        }
    }
    
    void bankCodeValidate(final String bankCode1, final DataAccess da) {
        try {
            da.getRecord("EB.BCI.CCE.PARTICIPANTS.BANK.NAME", bankCode1);
        }
        catch (Exception e5) {
            throw new T24CoreException("", "EB-BCI.NOT.VALID.BANK.CODE");
        }
    }
    
    void commTypeValidate(final String commType, final String id2, final String idEntered, final DataAccess da) {
        final String ebLookupId = "L.RATE.CODE*" + commType;
        try {
            da.getRecord("EB.LOOKUP", ebLookupId);
        }
        catch (Exception e2) {
            throw new T24CoreException("", "EB-BCI.INVALID.RATE.CODE");
        }
        final List<String> rateCodeIds = (List<String>)da.selectRecords("", "EB.LOOKUP", "", "WITH @ID LIKE L.RATE.CODE*...");
        for (final String currRateCodeId : rateCodeIds) {
            final String[] currRateCodeArr = currRateCodeId.split("\\*");
            final String idCurr = String.valueOf(id2) + "." + currRateCodeArr[1];
            TStructure rec1 = null;
            try {
                if (!idCurr.equals(idEntered)) {
                    rec1 = da.getRecord("EB.BCI.TRNS.CLG.COMMISSION.PARAM", idCurr);
                }
            }
            catch (Exception e1) {
                e1.getMessage();
            }
            if (rec1 != null) {
                throw new T24CoreException("", "EB-BCI.DIFF.COMM.TYPE.EXIST");
            }
        }
    }
}
