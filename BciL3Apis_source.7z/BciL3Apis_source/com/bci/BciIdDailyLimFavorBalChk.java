package com.bci;

import com.temenos.api.exceptions.T24CoreException;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
* 
* @author Parthiban B 
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : To validate the @ID of EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE
* Developed By          : Parthiban Balasubramaniam, Techmill Technologies  
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : VERSION.CONTROL> EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE
* Attached As           : Check ID routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciIdDailyLimFavorBalChk extends RecordLifecycle
{
    public String checkId(final String currentRecordId, final TransactionContext transactionContext) {
        final String curFunction = transactionContext.getCurrentFunction();
        if (curFunction.equals("INPUT") && !currentRecordId.equals("R16") && !currentRecordId.equals("R17/R18")) {
            throw new T24CoreException("", "EB-BCI.INVALID.ID");
        }
        return currentRecordId;
    }
}
