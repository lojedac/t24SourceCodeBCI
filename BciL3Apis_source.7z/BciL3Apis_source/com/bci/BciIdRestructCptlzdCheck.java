package com.bci;

import com.temenos.api.exceptions.T24CoreException;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
 *
 * @author malika.v
 * 
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *Description           : Validate the ID of the table EB.BCI.H.LN.RESTRUCT.CAPITALIZED.PARAM
 *Developed By          : Mallika V, Techmill Technologies
 *Development Reference : BRD 04/05
 *Attached To           : EB.TABLE.PROCEDURES>EB.BCI.H.LN.RESTRUCT.CAPITALIZED.PARAM
 *Attached as           : ID Routine
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *  M O D I F I C A T I O N S
 * ***************************        
 *-----------------------------------------------------------------------------------------------------------------
 * Defect Reference       Modified By                    Date of Change        Change Details
 * (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
 *-----------------------------------------------------------------------------------------------------------------
 * XXXX                   <<name of modifier>>                                 <<modification details goes here>>
 *-----------------------------------------------------------------------------------------------------------------
 * Include files
 *-----------------------------------------------------------------------------------------------------------------
 *   
 */  

public class BciIdRestructCptlzdCheck extends RecordLifecycle
{
    public String checkId(final String currentRecordId, final TransactionContext transactionContext) {
        if (!currentRecordId.equals("SYSTEM")) {
            throw new T24CoreException("", "AA-ID.NOT.VALID");
        }
        return currentRecordId;
    }
}
