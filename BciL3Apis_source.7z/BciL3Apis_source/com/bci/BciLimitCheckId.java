

package com.bci;

import com.temenos.api.exceptions.T24CoreException;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
/**
* @author Mallika V
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Validate the @ID of the table EB.BCI.LIMIT.CCE.CLEARING.PARAM
* Developed By          : Mallika V, Techmill Technologies  
* Development Reference : BRD-12/15 Addition Field Cheque Clearing and Interbank Transfer
* Attached To           : EB.TABLE.PROCEDURES>EB.BCI.CCE.LIMIT.CLEARING.PARAM
* Attached As           : ID Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciLimitCheckId extends RecordLifecycle
{
    public String checkId(final String currentRecordId, final TransactionContext transactionContext) {
        if (!currentRecordId.equals("SYSTEM")) {
            throw new T24CoreException("", "EB-INVALID.ID");
        }
        return currentRecordId;
    }
}
