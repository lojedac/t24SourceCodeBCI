 

package com.bci;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.temenos.t24.api.records.dates.DatesRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

public class BciPPOEntryPresentDTValidate extends RecordLifecycle
{
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final PaymentOrderRecord po = new PaymentOrderRecord(currentRecord);
        final DataAccess da = new DataAccess((T24Context)this);
        final String orgnlTxnRef = po.getLocalRefField("L.ORGNL.TXN.REF").getValue();
        try {
            final PpOrderEntryRecord ppOrRec = new PpOrderEntryRecord(da.getRecord("PP.ORDER.ENTRY", orgnlTxnRef));
            final String pDate = ppOrRec.getProcessingdate().getValue();
            final DatesRecord dates = new DatesRecord(da.getRecord("DATES", "PE0010001"));
            final String lstWorkingDay = dates.getLastWorkingDay().getValue();
            final DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            final Date dateactual = dateFormat.parse(lstWorkingDay);
            final Date date1 = dateFormat.parse(pDate);
            if (!date1.equals(dateactual)) {
                po.getLocalRefField("L.PRESENTATION.DT").setError("El cheque ingresado no se encuentra dentro del rango de fecha permitida");
            }
        }
        catch (ParseException ex) {}
        return po.getValidationResponse();
    }
    
    public void defaultFieldValues(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final PaymentOrderRecord po = new PaymentOrderRecord(currentRecord);
        final DataAccess da = new DataAccess((T24Context)this);
        final String orgnlTxnRef = po.getLocalRefField("L.ORGNL.TXN.REF").getValue();
        try {
            final PpOrderEntryRecord ppOrRec = new PpOrderEntryRecord(da.getRecord("PP.ORDER.ENTRY", orgnlTxnRef));
            final String pDate = ppOrRec.getProcessingdate().getValue();
            po.getLocalRefField("L.PRESENTATION.DT").setValue(pDate);
            currentRecord.set(po.toStructure());
        }
        catch (Exception ex) {
            ex.getMessage();
        }
    }
}
