
package com.bci;

import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

public class BciPaymentOrder extends RecordLifecycle
{
    public void defaultFieldValues(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        final DataAccess da = new DataAccess((T24Context)this);
        try {
            final AccountRecord accRec = new AccountRecord(da.getRecord("ACCOUNT", poRec.getDebitAccount().getValue()));
            final CustomerRecord cusRec = new CustomerRecord(da.getRecord("CUSTOMER", accRec.getCustomer().getValue()));
            final String shortName = cusRec.getShortName(0).getValue();
            poRec.setOrderingCustName((CharSequence)shortName);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        currentRecord.set(poRec.toStructure());
    }
}
