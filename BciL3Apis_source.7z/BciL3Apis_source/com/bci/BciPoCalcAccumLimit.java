

package com.bci;

import java.util.Iterator;
import java.util.List;
import com.temenos.api.TStructure;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.CurrencyClass;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceTable;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.PaymentApplicationUpdate;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.Flags;
import com.temenos.t24.api.records.ebqueriesanswers.EbQueriesAnswersRecord;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.CommonData;
import com.temenos.t24.api.records.ppcompanyproperties.PpCompanyPropertiesRecord;
import com.temenos.t24.api.records.poraudittrail.PorAuditTrailRecord;
import com.temenos.t24.api.records.porpostingandconfirmation.PorPostingAndConfirmationRecord;
import com.temenos.t24.api.records.poragreementandadvice.PorAgreementAndAdviceRecord;
import com.temenos.t24.api.records.porsupplementaryinfo.PorSupplementaryInfoRecord;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.PaymentContext;
import com.temenos.t24.api.records.portransaction.PorTransactionRecord;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.StatusAction;
import com.temenos.t24.api.hook.payments.PaymentLifecycle;

public class BciPoCalcAccumLimit extends PaymentLifecycle
{
    public void updateRequestToExternalCoreSystem(final StatusAction arg0, final PorTransactionRecord arg1, final PaymentContext arg2, final PorSupplementaryInfoRecord arg3, final PorAgreementAndAdviceRecord arg4, final PorPostingAndConfirmationRecord arg5, final PorAuditTrailRecord arg6, final PpCompanyPropertiesRecord arg7, final CommonData arg8, final EbQueriesAnswersRecord arg9, final Flags arg10, final PaymentApplicationUpdate arg11) {
        try {
            final DataAccess da = new DataAccess((T24Context)this);
            final String payOrdId = arg1.getSendersreferenceincoming().getValue();
            final TStructure rec1 = da.getRecord("PAYMENT.ORDER", payOrdId);
            final PaymentOrderRecord payOrdRec = new PaymentOrderRecord(rec1);
            final String payProduct = payOrdRec.getPaymentOrderProduct().getValue();
            if (payProduct.equals("FOVRBAL") || payProduct.equals("ADJSTMTS")) {
                final String payCurrency = payOrdRec.getPaymentCurrency().getValue();
                final String payAmount = payOrdRec.getPaymentAmount().getValue();
                final Double payAmountNum = Double.parseDouble(payAmount);
                String favBalLimitRecId = "";
                if (payProduct.equals("FOVRBAL")) {
                    favBalLimitRecId = "R16";
                }
                if (payProduct.equals("ADJSTMTS")) {
                    favBalLimitRecId = "R17/R18";
                }
                final TStructure rec2 = da.getRecord("EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE", favBalLimitRecId);
                final EbBciDailyLimitFavorableBalanceRecord favorBalLimitRec = new EbBciDailyLimitFavorableBalanceRecord(rec2);
                final EbBciDailyLimitFavorableBalanceTable favorBalLimitTable = new EbBciDailyLimitFavorableBalanceTable((T24Context)this);
                final List<CurrencyClass> currList = (List<CurrencyClass>)favorBalLimitRec.getCurrency();
                int idx = 0;
                for (final CurrencyClass currObj : currList) {
                    final String limCurrency = currObj.getCurrency().getValue();
                    if (!payCurrency.equals(limCurrency)) {
                        ++idx;
                    }
                    else {
                        final String curAccumLimit = currObj.getCurrAccumulatedLimit().getValue();
                        Double curAccumLimitNum = Double.parseDouble(curAccumLimit);
                        curAccumLimitNum += payAmountNum;
                        currObj.setCurrAccumulatedLimit((CharSequence)curAccumLimitNum.toString());
                        favorBalLimitRec.setCurrency(currObj, idx);
                    }
                }
                favorBalLimitTable.write((CharSequence)favBalLimitRecId, favorBalLimitRec);
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
    }
}
