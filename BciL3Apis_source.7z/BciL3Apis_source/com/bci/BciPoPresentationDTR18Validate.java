
package com.bci;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.temenos.t24.api.records.dates.DatesRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

public class BciPoPresentationDTR18Validate extends RecordLifecycle
{
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final DataAccess da = new DataAccess((T24Context)this);
        final PaymentOrderRecord po = new PaymentOrderRecord(currentRecord);
        final String pDate = po.getLocalRefField("L.PRESENTATION.DT").getValue();
        final DatesRecord dates = new DatesRecord(da.getRecord("DATES", "PE0010001"));
        final String lstWorkingDay = dates.getLastWorkingDay().getValue();
        final DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        try {
            final Date dateactual = dateFormat.parse(lstWorkingDay);
            final Date date1 = dateFormat.parse(pDate);
            if (!date1.equals(dateactual)) {
                po.getLocalRefField("L.PRESENTATION.DT").setError("EL CAMPO DEBE SER LAST.WORKING.DAY");
            }
        }
        catch (ParseException ex) {}
        return po.getValidationResponse();
    }
}
