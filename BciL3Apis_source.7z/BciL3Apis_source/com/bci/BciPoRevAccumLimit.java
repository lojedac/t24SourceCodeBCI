package com.bci;

import com.temenos.t24.api.records.dates.DatesRecord;
import com.temenos.t24.api.system.Date;
import java.util.Iterator;
import java.util.List;
import com.temenos.api.TStructure;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.CurrencyClass;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceTable;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.PaymentApplicationUpdate;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.Flags;
import com.temenos.t24.api.records.ebqueriesanswers.EbQueriesAnswersRecord;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.CommonData;
import com.temenos.t24.api.records.ppcompanyproperties.PpCompanyPropertiesRecord;
import com.temenos.t24.api.records.poraudittrail.PorAuditTrailRecord;
import com.temenos.t24.api.records.porpostingandconfirmation.PorPostingAndConfirmationRecord;
import com.temenos.t24.api.records.poragreementandadvice.PorAgreementAndAdviceRecord;
import com.temenos.t24.api.records.porsupplementaryinfo.PorSupplementaryInfoRecord;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.PaymentContext;
import com.temenos.t24.api.records.portransaction.PorTransactionRecord;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.StatusAction;
import com.temenos.t24.api.hook.payments.PaymentLifecycle;

/**
* @author Parthiban B 
*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Java hook to deduct the PAYMENT.AMOUNT from CURR.ACCUMULATED.LIMIT in EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE table when the PO entry is reversed
* Developed By          : Parthiban Balasubramaniam, Techmill Technologies  
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : PP.STATUS.ACTION>993.*
* Attached As           : PP.STATUS.ACTION Routine
*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciPoRevAccumLimit extends PaymentLifecycle
{
    public void updateRequestToExternalCoreSystem(final StatusAction arg0, final PorTransactionRecord arg1, final PaymentContext arg2, final PorSupplementaryInfoRecord arg3, final PorAgreementAndAdviceRecord arg4, final PorPostingAndConfirmationRecord arg5, final PorAuditTrailRecord arg6, final PpCompanyPropertiesRecord arg7, final CommonData arg8, final EbQueriesAnswersRecord arg9, final Flags arg10, final PaymentApplicationUpdate arg11) {
        try {
            final DataAccess da = new DataAccess((T24Context)this);
            final String payOrdId = arg1.getSendersreferenceincoming().getValue();
            final TStructure rec1 = da.getRecord("PAYMENT.ORDER", payOrdId);
            final PaymentOrderRecord payOrdRec = new PaymentOrderRecord(rec1);
            final String payProduct = payOrdRec.getPaymentOrderProduct().getValue();
            final boolean dtFlg = this.dateChk(payOrdRec);
            if ((payProduct.equals("FOVRBAL") || payProduct.equals("ADJSTMTS")) && dtFlg) {
                final String payCurrency = payOrdRec.getPaymentCurrency().getValue();
                final String payAmount = payOrdRec.getPaymentAmount().getValue();
                final Double payAmountNum = Double.parseDouble(payAmount);
                String favBalLimitRecId = "";
                if (payProduct.equals("FOVRBAL")) {
                    favBalLimitRecId = "R16";
                }
                if (payProduct.equals("ADJSTMTS")) {
                    favBalLimitRecId = "R17/R18";
                }
                final TStructure rec2 = da.getRecord("EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE", favBalLimitRecId);
                final EbBciDailyLimitFavorableBalanceRecord favorBalLimitRec = new EbBciDailyLimitFavorableBalanceRecord(rec2);
                final EbBciDailyLimitFavorableBalanceTable favorBalLimitTable = new EbBciDailyLimitFavorableBalanceTable((T24Context)this);
                final List<CurrencyClass> currList = (List<CurrencyClass>)favorBalLimitRec.getCurrency();
                int idx = 0;
                for (final CurrencyClass currObj : currList) {
                    final String limCurrency = currObj.getCurrency().getValue();
                    if (!payCurrency.equals(limCurrency)) {
                        ++idx;
                    }
                    else {
                        final String curAccumLimit = currObj.getCurrAccumulatedLimit().getValue();
                        Double curAccumLimitNum = Double.parseDouble(curAccumLimit);
                        curAccumLimitNum -= payAmountNum;
                        currObj.setCurrAccumulatedLimit((CharSequence)curAccumLimitNum.toString());
                        favorBalLimitRec.setCurrency(currObj, idx);
                    }
                }
                favorBalLimitTable.write((CharSequence)favBalLimitRecId, favorBalLimitRec);
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
    }
    
    private boolean dateChk(final PaymentOrderRecord poRec) {
        boolean flg = true;
        try {
            final Date dt = new Date((T24Context)this);
            final DatesRecord dtRec = dt.getDates();
            final String today = dtRec.getToday().toString();
            final String payExecDate = poRec.getPaymentExecutionDate().toString();
            final int payExecDateNum = Integer.parseInt(payExecDate);
            final int todayNum = Integer.parseInt(today);
            if (todayNum > payExecDateNum) {
                flg = false;
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
        return flg;
    }
}
