package com.bci;

import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.BalanceTypeClass;
import com.temenos.api.exceptions.T24IOException;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementRecord;
import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementTable;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aabilldetails.AaBillDetailsRecord;
import com.temenos.t24.api.arrangement.Bill;
import java.util.Iterator;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentDueType;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentSchedule;
import java.util.ArrayList;
import com.temenos.api.TDate;
import java.util.List;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/**
 * TODO: Document me!
 *
 * @author malika.v
 * 
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *Description           : Adjust and Update the Amount field in Adj Amount and Balance in EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT during Repayment
 *Developed By          : Mallika V, Techmill Technologies
 *Development Reference : BRD 04/05
 *Attached To           : AA.PRD.DES.ACTIVITY.API>BCI.GROUP.SUB.LOAN.REF.REE.API-20210504     
 *Attached as           : Post Routine
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *  M O D I F I C A T I O N S
 * ***************************               
 *-----------------------------------------------------------------------------------------------------------------
 * Defect Reference       Modified By                    Date of Change        Change Details
 * (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
 *-----------------------------------------------------------------------------------------------------------------
 * XXXX                   <<name of modifier>>                                 <<modification details goes here>>
 *-----------------------------------------------------------------------------------------------------------------
 * Include files
 *-----------------------------------------------------------------------------------------------------------------
 *   
 */   

public class BciRepayAdjBalanceUpdate extends ActivityLifecycle
{
    public List<TDate> rePayTdateCalc(final String startDate1, final String endDate1, final Contract contract, final String arrId1) {
        final List<TDate> retTdateList1 = new ArrayList<TDate>();
        contract.setContractId(arrId1);
        final TDate tStartDate = new TDate(startDate1);
        final TDate tEndDate = new TDate(endDate1);
        final List<RepaymentSchedule> rePayScheduleClsList = (List<RepaymentSchedule>)contract.getRepaymentSchedule(tStartDate, tEndDate);
        for (final RepaymentSchedule rePayScheduleCls : rePayScheduleClsList) {
            for (final RepaymentDueType rePayDueCls : rePayScheduleCls.getRepaymentDueType()) {
                final String schDueType = rePayDueCls.getDueType();
                if (schDueType.equals("CONSTANT") || schDueType.equals("LINEAR")) {
                    retTdateList1.add(rePayScheduleCls.getDueDate());
                }
            }
        }
        return retTdateList1;
    }
    
    public List<Double> billAmtFet(final TDate rePayTdate1, final String arrId2, final Contract contract2, final Bill bill1, final double totCompAmt1, final double principalFldVal1) {
        contract2.setContractId(arrId2);
        final List<Double> retBillAmts1 = new ArrayList<Double>();
        final List<String> billIds = (List<String>)contract2.getBillIdsForDate(rePayTdate1);
        for (final String billId : billIds) {
            bill1.setBillId(billId);
            bill1.setContractId(arrId2);
            final AaBillDetailsRecord billDetailsRecord = bill1.getBillRecord();
            final String billOstotAmt = billDetailsRecord.getOsTotalAmount().getValue();
            double billAmountOs;
            if (billOstotAmt.equals("0")) {
                billAmountOs = 0.0;
            }
            else {
                billAmountOs = 1.0;
            }
            retBillAmts1.add(billAmountOs);
        }
        return retBillAmts1;
    }
    
    public void postCoreTableUpdate(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record, final List<TransactionData> transactionData, final List<TStructure> transactionRecord) {
        final DataAccess daObj = new DataAccess((T24Context)this);
        final Contract contract = new Contract((T24Context)this);
        final Bill bill = new Bill((T24Context)this);
        final EbBciLLoanCapitalizeMovementTable lnCptlMvmtTab = new EbBciLLoanCapitalizeMovementTable((T24Context)this);
        final String currAction = arrangementContext.getActivityStatus();
        if (currAction.equals("AUTH")) {
            final String arrId = arrangementActivityRecord.getArrangement().getValue();
            final String linkedApplId = arrangementRecord.getLinkedAppl(0).getLinkedApplId().getValue();
            final String startDate = arrangementRecord.getStartDate().getValue();
            final String endDate = accountDetailRecord.getMaturityDate().getValue();
            final List<TDate> rePayTdateList = this.rePayTdateCalc(startDate, endDate, contract, arrId);
            final int noOfSchd = rePayTdateList.size();
            String lncptlzId = "";
            contract.setContractId(arrId);
            final AaPrdDesTermAmountRecord aaArrTermAmountRec = new AaPrdDesTermAmountRecord(contract.getConditionForProperty("COMMITMENT"));
            double principalFldVal = 0.0;
            double interestFldVal = 0.0;
            double chargeFldVal = 0.0;
            double othExpenseAmtFldVal = 0.0;
            try {
                principalFldVal = Double.parseDouble(aaArrTermAmountRec.getLocalRefField("L.PN.AMT.OLD.LN").getValue()) / noOfSchd;
            }
            catch (Exception ex) {}
            try {
                interestFldVal = Double.parseDouble(aaArrTermAmountRec.getLocalRefField("L.INT.CPTLZD").getValue()) / noOfSchd;
            }
            catch (Exception ex2) {}
            try {
                chargeFldVal = Double.parseDouble(aaArrTermAmountRec.getLocalRefField("L.CHARG.CAPTLZD").getValue()) / noOfSchd;
            }
            catch (Exception ex3) {}
            try {
                othExpenseAmtFldVal = Double.parseDouble(aaArrTermAmountRec.getLocalRefField("L.OTHER.CAPTLZD").getValue()) / noOfSchd;
            }
            catch (Exception ex4) {}
            final double totCompAmt = principalFldVal + interestFldVal + chargeFldVal + othExpenseAmtFldVal;
            for (final TDate rePayTdate : rePayTdateList) {
                final List<Double> billAmts = this.billAmtFet(rePayTdate, arrId, contract, bill, totCompAmt, principalFldVal);
                lncptlzId = String.valueOf(linkedApplId) + "-" + rePayTdate.get();
                EbBciLLoanCapitalizeMovementRecord cptlzeMvmtRecObj = new EbBciLLoanCapitalizeMovementRecord();
                try {
                    cptlzeMvmtRecObj = lnCptlMvmtTab.read((CharSequence)lncptlzId);
                }
                catch (T24IOException ex5) {}
                final List<BalanceTypeClass> balanceTypeList = (List<BalanceTypeClass>)cptlzeMvmtRecObj.getBalanceType();
                if (!cptlzeMvmtRecObj.getSettleStatus().getValue().equals("SETTLED")) {
                    final int j = 0;
                    final String intialCheck = "";
                    if (billAmts.isEmpty()) {
                        continue;
                    }
                    final double billAmount;
                    final double billAmt = billAmount = billAmts.get(j);
                    if (billAmount != 0.0 || !intialCheck.equals("")) {
                        continue;
                    }
                    for (int i = 0; i < balanceTypeList.size(); ++i) {
                        final BalanceTypeClass balanceTypeClass = balanceTypeList.get(i);
                        balanceTypeClass.setAdjAmt((CharSequence)balanceTypeClass.getOrigBal().getValue(), balanceTypeClass.getAdjAmt().size());
                        balanceTypeClass.getBalance().set("0");
                    }
                    cptlzeMvmtRecObj.setSettleStatus((CharSequence)"SETTLED");
                    try {
                        lnCptlMvmtTab.write((CharSequence)lncptlzId, cptlzeMvmtRecObj);
                    }
                    catch (T24IOException e) {
                        e.getMessage();
                    }
                    final BciCreatePayOrder createPaymentOrder = new BciCreatePayOrder();
                    final List<TStructure> paymentOrderRecord = createPaymentOrder.getPaymentOrderRec(arrId, cptlzeMvmtRecObj, "BNK", daObj, contract, "");
                    final TransactionData txnDataRecord = createPaymentOrder.getTrasactionData();
                    for (int paymentSize = 0; paymentSize < paymentOrderRecord.size(); ++paymentSize) {
                        transactionRecord.add(paymentOrderRecord.get(paymentSize));
                        transactionData.add(txnDataRecord);
                    }
                }
            }
        }
    }
}
