package com.bci;

import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.api.exceptions.T24IOException;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementTable;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.BalanceTypeClass;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementRecord;
import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import java.util.Iterator;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentDueType;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentSchedule;
import com.temenos.api.TDate;
import com.temenos.t24.api.arrangement.accounting.Contract;
import java.util.ArrayList;
import java.util.List;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/**
 *
 * ----------------------------------------------------------------------------------------------------------------
 * Description : Update a Original Bal and Balance field value in
 * BCI.L.LOAN.CAPITALIZE.MOVEMENT table Developed By : Kalaipriya M,Techmill
 * Development Reference : BRD-04-05_IDENTIFICAR POR SEPARADO PRINCIPAL,
 * INTERESES, COMISIONES Y GASTOS CAPITALIZADOS Attached To : Activity.API>
 * BCI.GROUP.SUB.LOAN.REF.REE.API Attached As : Post Routine
 * -----------------------------------------------------------------------------------------------------------------
 * M O D I F I C A T I O N S ***************************
 * -----------------------------------------------------------------------------------------------------------------
 * Defect Reference Modified By Date of Change Change Details (RTC/TUT/PACS)
 * (YYYY-MM-DD)
 * -----------------------------------------------------------------------------------------------------------------
 * XXXX <<name of modifier>> <<modification details goes here>>
 * -----------------------------------------------------------------------------------------------------------------
 * Include files
 * -----------------------------------------------------------------------------------------------------------------
 *
 */

public class BciRepayCalUpdatetoLocalTemp extends ActivityLifecycle
{
    List<String> dueDateList;
    Double retAmt;
    String changeVal;
    
    public BciRepayCalUpdatetoLocalTemp() {
        this.dueDateList = new ArrayList<String>();
        this.retAmt = 0.0;
        this.changeVal = "CHANGE";
    }
    
    public String amtCal(final String amt, final int noofInst) {
        String amtDoublValStr = "";
        if (!amt.equals("")) {
            final Double amtDoublVal = Double.parseDouble(amt);
            try {
                this.retAmt = amtDoublVal / noofInst;
            }
            catch (Exception e) {
                this.retAmt = 0.0;
            }
            if (this.retAmt > 0.0) {
                amtDoublValStr = String.format("%.2f", this.retAmt);
            }
        }
        return amtDoublValStr;
    }
    
    public int noOfSchCal(final Contract contract, final String arrId, final String arrStDate, final String arrMatDate) {
        contract.setContractId(arrId);
        if (!arrStDate.equals("") && !arrMatDate.equals("")) {
            final TDate arrStDateVal = new TDate(arrStDate);
            final TDate arrMatDateVal = new TDate(arrMatDate);
            final List<RepaymentSchedule> schdClsList = (List<RepaymentSchedule>)contract.getRepaymentSchedule(arrStDateVal, arrMatDateVal);
            for (final RepaymentSchedule schdCls : schdClsList) {
                for (final RepaymentDueType rePayDueCls : schdCls.getRepaymentDueType()) {
                    final String schDueType = rePayDueCls.getDueType();
                    if (schDueType.equals("CONSTANT") || schDueType.equals("LINEAR")) {
                        this.dueDateList.add(schdCls.getDueDate().get());
                    }
                }
            }
        }
        return this.dueDateList.size();
    }
    
    public List<String> localFieldvalfet(final AaPrdDesTermAmountRecord aaArrTermAcctRec1, final List<String> fieldNames1) {
        final List<String> fieldvalues = new ArrayList<String>();
        for (final String locFieldName : fieldNames1) {
            String amt = "";
            try {
                amt = aaArrTermAcctRec1.getLocalRefField(locFieldName).getValue();
            }
            catch (Exception e) {
                e.getMessage();
            }
            fieldvalues.add(amt);
        }
        return fieldvalues;
    }
    
    public String actvityChk(final String arrActivity, final String interestFldVal1, final String chargeFldVal1, final String othExpenseAmtFldVal1) {
        String updResFlag = "";
        switch (arrActivity) {
            case "LENDING-CHANGE.TERM-COMMITMENT": {
                updResFlag = this.changeVal;
                break;
            }
            case "LENDING-NEW-ARRANGEMENT": {
                if (!interestFldVal1.equals("") || !chargeFldVal1.equals("") || !othExpenseAmtFldVal1.equals("")) {
                    updResFlag = "NEW";
                    break;
                }
                break;
            }
            default:
                break;
        }
        return updResFlag;
    }
    
    public void recFrame(final List<String> type, final List<String> val, final EbBciLLoanCapitalizeMovementRecord bciUpdlLoanCapMovRec) {
        if (!type.isEmpty()) {
            for (int i = 0; i < type.size(); ++i) {
                final BalanceTypeClass balTypeClas = new BalanceTypeClass();
                balTypeClas.setBalanceType((CharSequence)type.get(i));
                balTypeClas.setOrigBal((CharSequence)val.get(i));
                balTypeClas.setBalance((CharSequence)val.get(i));
                bciUpdlLoanCapMovRec.setBalanceType(balTypeClas, i);
            }
        }
    }
    
    public List<String> oldRecidsFet(final String loanAccNo2) {
        final DataAccess da = new DataAccess((T24Context)this);
        List<String> oldRecIds1 = new ArrayList<String>();
        try {
            oldRecIds1 = (List<String>)da.selectRecords("", "EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT", "", "WITH @ID LIKE " + loanAccNo2 + "...");
        }
        catch (Exception e) {
            e.getMessage();
        }
        return oldRecIds1;
    }
    
    public void recDelete(final List<String> oldRecIds3, final List<String> dueDateList3, final EbBciLLoanCapitalizeMovementTable bciUpdlLoanCapMovTable4) {
        if (!oldRecIds3.isEmpty() && oldRecIds3.size() != dueDateList3.size()) {
            for (final String oldRecId : oldRecIds3) {
                try {
                    bciUpdlLoanCapMovTable4.delete((CharSequence)oldRecId);
                }
                catch (T24IOException e) {
                    e.getMessage();
                }
            }
        }
    }
    
    public EbBciLLoanCapitalizeMovementRecord lastRecAdj(final EbBciLLoanCapitalizeMovementRecord bciUpdlLoanCapMovRec1, final AaPrdDesTermAmountRecord aaArrTermAcctRec, final int maxSchdl) {
        try {
            final List<String> fieldNames = new ArrayList<String>();
            fieldNames.add("L.INT.CPTLZD");
            fieldNames.add("L.CHARG.CAPTLZD");
            fieldNames.add("L.OTHER.CAPTLZD");
            final List<String> fieldValues = this.localFieldvalfet(aaArrTermAcctRec, fieldNames);
            final String interestFldVal = fieldValues.get(0);
            final String chargeFldVal = fieldValues.get(1);
            final String othExpenseAmtFldVal = fieldValues.get(2);
            final List<BalanceTypeClass> balTypeList = (List<BalanceTypeClass>)bciUpdlLoanCapMovRec1.getBalanceType();
            int idx = 0;
            for (final BalanceTypeClass curBalTypeObj : balTypeList) {
                final String curBalTypeFldVal = curBalTypeObj.getBalanceType().getValue();
                if (!othExpenseAmtFldVal.equals("") && curBalTypeFldVal.equals("CAPEXPENSE")) {
                    final Double othExpenseDoublVal = Double.parseDouble(othExpenseAmtFldVal);
                    final String orgBalAmt = curBalTypeObj.getOrigBal().getValue();
                    final Double orgBalDoublVal = Double.parseDouble(orgBalAmt);
                    final Double calcExpenVal = othExpenseDoublVal - orgBalDoublVal * (maxSchdl - 1);
                    final String capExpenseFinal = String.format("%.2f", calcExpenVal);
                    curBalTypeObj.setOrigBal((CharSequence)capExpenseFinal);
                    curBalTypeObj.setBalance((CharSequence)capExpenseFinal);
                    bciUpdlLoanCapMovRec1.setBalanceType(curBalTypeObj, idx);
                    ++idx;
                }
                if (!chargeFldVal.equals("") && curBalTypeFldVal.equals("CAPCOMM")) {
                    final Double chargeDoublVal = Double.parseDouble(chargeFldVal);
                    final String orgBalAmt = curBalTypeObj.getOrigBal().getValue();
                    final Double orgBalDoublVal = Double.parseDouble(orgBalAmt);
                    final Double calcChrgVal = chargeDoublVal - orgBalDoublVal * (maxSchdl - 1);
                    final String capChrgeFinal = String.format("%.2f", calcChrgVal);
                    curBalTypeObj.setOrigBal((CharSequence)capChrgeFinal);
                    curBalTypeObj.setBalance((CharSequence)capChrgeFinal);
                    bciUpdlLoanCapMovRec1.setBalanceType(curBalTypeObj, idx);
                    ++idx;
                }
                if (!interestFldVal.equals("") && curBalTypeFldVal.equals("CAPINT")) {
                    final Double interestDoublVal = Double.parseDouble(interestFldVal);
                    final String orgBalAmt = curBalTypeObj.getOrigBal().getValue();
                    final Double orgBalDoublVal = Double.parseDouble(orgBalAmt);
                    final Double calcIntVal = interestDoublVal - orgBalDoublVal * (maxSchdl - 1);
                    final String capIntFinal = String.format("%.2f", calcIntVal);
                    curBalTypeObj.setOrigBal((CharSequence)capIntFinal);
                    curBalTypeObj.setBalance((CharSequence)capIntFinal);
                    bciUpdlLoanCapMovRec1.setBalanceType(curBalTypeObj, idx);
                    ++idx;
                }
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        return bciUpdlLoanCapMovRec1;
    }
    
    public void dueDateListCheckandWrite(final EbBciLLoanCapitalizeMovementTable bciUpdlLoanCapMovTable1, final String loanAccNo1, EbBciLLoanCapitalizeMovementRecord bciUpdlLoanCapMovRec1, final String updateRestrictFlag, final AaArrangementActivityRecord arrangementActivityRecord, final List<String> dueDateList, final AaPrdDesTermAmountRecord aaArrTermAcctRec) {
        if (!dueDateList.isEmpty()) {
            if (updateRestrictFlag.equals(this.changeVal)) {
                final List<String> oldRecIds = this.oldRecidsFet(loanAccNo1);
                this.recDelete(oldRecIds, dueDateList, bciUpdlLoanCapMovTable1);
                final String arrEffDate = arrangementActivityRecord.getEffectiveDate().getValue();
                final String firstDueDate = dueDateList.get(0);
                final int arrEffDateInt = Integer.parseInt(arrEffDate);
                final int firstDueDateInt = Integer.parseInt(firstDueDate);
                final int oldNoofSchd = oldRecIds.size();
                if (arrEffDateInt < firstDueDateInt && oldNoofSchd == dueDateList.size()) {
                    dueDateList.clear();
                    dueDateList.add(firstDueDate);
                }
                if (arrEffDateInt > firstDueDateInt) {
                    dueDateList.clear();
                }
            }
            int schdlCnt = 0;
            final int maxSchdl = dueDateList.size();
            for (final String dueDate : dueDateList) {
                try {
                    if (++schdlCnt == maxSchdl) {
                        bciUpdlLoanCapMovRec1 = this.lastRecAdj(bciUpdlLoanCapMovRec1, aaArrTermAcctRec, maxSchdl);
                    }
                    final String bciUpdlLoanCapMovRecId = String.valueOf(loanAccNo1) + "-" + dueDate;
                    this.recWrite(bciUpdlLoanCapMovTable1, bciUpdlLoanCapMovRecId, bciUpdlLoanCapMovRec1);
                }
                catch (Exception e1) {
                    e1.getMessage();
                }
            }
        }
    }
    
    public void recWrite(final EbBciLLoanCapitalizeMovementTable bciUpdlLoanCapMovTable2, final String id, final EbBciLLoanCapitalizeMovementRecord rec) {
        try {
            bciUpdlLoanCapMovTable2.write((CharSequence)id, rec);
        }
        catch (T24IOException e) {
            e.getMessage();
        }
    }
    
    public void locFldamtCal(final String othExpenseAmtFldVal3, final String chargeFldVal3, final String interestFldVal3, final List<String> type, final List<String> val, final int noOfArrSchd) {
        final String calExpAmt = this.amtCal(othExpenseAmtFldVal3, noOfArrSchd);
        if (!calExpAmt.equals("")) {
            type.add("CAPEXPENSE");
            val.add(calExpAmt);
        }
        final String calChrgAmt = this.amtCal(chargeFldVal3, noOfArrSchd);
        if (!calChrgAmt.equals("")) {
            type.add("CAPCOMM");
            val.add(calChrgAmt);
        }
        final String calIntAmt = this.amtCal(interestFldVal3, noOfArrSchd);
        if (!calIntAmt.equals("")) {
            type.add("CAPINT");
            val.add(calIntAmt);
        }
    }
    
    public void postCoreTableUpdate(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record, final List<TransactionData> transactionData, final List<TStructure> transactionRecord) {
        if (arrangementContext.getActivityStatus().equals("AUTH")) {
            final String arrActivity = arrangementActivityRecord.getActivity().getValue();
            final AaPrdDesTermAmountRecord aaArrTermAcctRec = new AaPrdDesTermAmountRecord(record);
            final Contract contract = new Contract((T24Context)this);
            final EbBciLLoanCapitalizeMovementTable bciUpdlLoanCapMovTable = new EbBciLLoanCapitalizeMovementTable((T24Context)this);
            final String arrId = arrangementContext.getArrangementId();
            String interestFldVal = "";
            String chargeFldVal = "";
            String othExpenseAmtFldVal = "";
            final String loanAccNo = arrangementRecord.getLinkedAppl(0).getLinkedApplId().getValue();
            int noOfArrSchd = 0;
            final List<String> fieldNames = new ArrayList<String>();
            fieldNames.add("L.INT.CPTLZD");
            fieldNames.add("L.CHARG.CAPTLZD");
            fieldNames.add("L.OTHER.CAPTLZD");
            final List<String> fieldValues = this.localFieldvalfet(aaArrTermAcctRec, fieldNames);
            interestFldVal = fieldValues.get(0);
            chargeFldVal = fieldValues.get(1);
            othExpenseAmtFldVal = fieldValues.get(2);
            final String recUpdFlag = this.actvityChk(arrActivity, interestFldVal, chargeFldVal, othExpenseAmtFldVal);
            if (recUpdFlag.equals("NEW") || recUpdFlag.equals(this.changeVal)) {
                final List<String> type = new ArrayList<String>();
                final List<String> val = new ArrayList<String>();
                final EbBciLLoanCapitalizeMovementRecord bciUpdlLoanCapMovRec = new EbBciLLoanCapitalizeMovementRecord();
                final String arrStDate = arrangementRecord.getStartDate().getValue();
                final String arrMatDate = accountDetailRecord.getMaturityDate().getValue();
                noOfArrSchd = this.noOfSchCal(contract, arrId, arrStDate, arrMatDate);
                this.locFldamtCal(othExpenseAmtFldVal, chargeFldVal, interestFldVal, type, val, noOfArrSchd);
                this.recFrame(type, val, bciUpdlLoanCapMovRec);
                this.dueDateListCheckandWrite(bciUpdlLoanCapMovTable, loanAccNo, bciUpdlLoanCapMovRec, recUpdFlag, arrangementActivityRecord, this.dueDateList, aaArrTermAcctRec);
            }
        }
    }
}
