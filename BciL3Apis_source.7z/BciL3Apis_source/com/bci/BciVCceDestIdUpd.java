
package com.bci;

import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.tables.ebbcihccedestidparam.EbBciHCceDestIdParamTable;
import com.temenos.t24.api.tables.ebbcihccedestidparam.EbBciHCceDestIdParamRecord;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.complex.eb.servicehook.TransactionData;
import java.util.List;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
*
*@author Kalaipriya.M
*----------------------------------------------------------------------------------------------------------------
* Description           : Fetch the 2 to 8 position value from EB.BCI.H.CCE.PARTICIPANT.DIR table to update @ID of EB.BCI.H.CCE.DEST.ID.PARAM table 
* Developed By          : Kalaipriya M,Techmill Technologies     
* Development Reference : BRD-010-Information_CCE Charge_Participanting_Entities
* Attached To           : Version > EB.BCI.H.CCE.PARTICIPANT.DIR,BCI.NAU & EB.BCI.H.CCE.PARTICIPANT.DIR,OFS.INPUT
* Attached As           : Auth Routine  
*-------------------------------------------------------  ----------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files 
*-----------------------------------------------------------------------------------------------------------------
*
*/

public class BciVCceDestIdUpd extends RecordLifecycle
{
    public void postUpdateRequest(final String application, final String currentRecordId, final TStructure currentRecord, final List<TransactionData> transactionData, final List<TStructure> currentRecords, final TransactionContext transactionContext) {
        final EbBciHCceDestIdParamRecord cceDesIdParamRec = new EbBciHCceDestIdParamRecord();
        final EbBciHCceDestIdParamTable cceDesIdParamTable = new EbBciHCceDestIdParamTable((T24Context)this);
        final String cCParticipantRecId = currentRecordId;
        String cceDesid = "";
        try {
            cceDesid = cCParticipantRecId.substring(2, 8);
            cceDesIdParamTable.write((CharSequence)cceDesid, cceDesIdParamRec);
        }
        catch (Exception e) {
            e.getMessage();
        }
    }
}
