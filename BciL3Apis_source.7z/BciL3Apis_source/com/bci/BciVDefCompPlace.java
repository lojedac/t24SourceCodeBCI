
package com.bci;

import com.temenos.t24.api.tables.ebbcihcceparticipantdir.EbBciHCceParticipantDirRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

public class BciVDefCompPlace extends RecordLifecycle
{
    public void defaultFieldValues(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        try {
            final DataAccess da = new DataAccess((T24Context)this);
            final PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
            final String cciDest = poRec.getLocalRefField("L.CCI.DESTINATION").getValue();
            if (!cciDest.isEmpty()) {
                final String ccePartDirId = cciDest.substring(0, 8);
                final TStructure rec1 = da.getRecord("EB.BCI.H.CCE.PARTICIPANT.DIR", ccePartDirId);
                if (rec1 != null) {
                    final EbBciHCceParticipantDirRecord partDirRec = new EbBciHCceParticipantDirRecord(rec1);
                    final String location = partDirRec.getLocation().getValue();
                    poRec.getLocalRefField("L.COMPENSATE.PLACE").setValue(location);
                    currentRecord.set(poRec.toStructure());
                }
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
    }
}
