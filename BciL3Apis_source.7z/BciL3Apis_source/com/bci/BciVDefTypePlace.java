
package com.bci;

import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebbcihcceparticipantdir.EbBciHCceParticipantDirRecord;
import com.temenos.tafj.api.client.impl.T24Context;

/*        
 * @author Kalaipriya M
* 
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Default TYPE.PLACE & L.APPL.CRITERIA Field
*Developed By           : Kalaipriya M, Techmill Technologies
*Development Reference  : BRD 11 - Commission Transfer & cheques   
*Attached To            : Version>PAYMENT.ORDER,DOMESTIC.BCI & PP.ORDER.ENTRY,BCI.CHQ.CLG 
*Attached as            : Default Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/


public class BciVDefTypePlace extends RecordLifecycle {
    public static final String CCI_DESTINATION = "L.CCI.DESTINATION";
    public static final String CCI_CODE_ORIGINATOR = "L.CCI.CODE.ORIG";
    public static final String TYPE_PLACE = "L.TYPE.PLACE";
    public static final String APPL_CRITERIA = "L.APPL.CRITERIA";
    public static final String CR_ENTITY_COD = "L.CR.ENTITY.COD";
    PaymentOrderRecord paymentOrderRecObj;
    PpOrderEntryRecord ppOrderEntryRecObj;

    public BciVDefTypePlace() {
        this.paymentOrderRecObj = null;
        this.ppOrderEntryRecObj = null;
    }

    public void defaultFieldValues(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unakuthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        String cciDestinationVal = "";
        String cciDestinationFldVal = "";
        String cciDestVal1 = "";
        String cciDestVal2 = "";
        String crEntityCodVal = "";
        String cciCodeOrgVal = "";
        final DataAccess da = new DataAccess((T24Context) this);
        String exclusivePlazaCcIDest = "";
        String exclusivePlazaCodeOrig = "";
        String UbigeoCodeDistCcIDest = "";
        String UbigeoCodeDistCodeOrig = "";
        if (application.equals("PAYMENT.ORDER")) {
            this.paymentOrderRecObj = new PaymentOrderRecord(currentRecord);
            try {
                cciDestinationFldVal = this.paymentOrderRecObj.getLocalRefField("L.CCI.DESTINATION").getValue();
                cciDestVal1 = cciDestinationFldVal.substring(0, 3);
                cciDestVal2 = cciDestinationFldVal.substring(3, 6);
                crEntityCodVal = "0" + cciDestVal1 + "0" + cciDestVal2;
                this.paymentOrderRecObj.getLocalRefField("L.CR.ENTITY.COD").setValue(crEntityCodVal);
                cciDestinationVal = cciDestinationFldVal.substring(0, 6);
                final EbBciHCceParticipantDirRecord bciHCcePartDirRec = this.getPartcipantRec(cciDestinationVal, da);
                exclusivePlazaCcIDest = bciHCcePartDirRec.getExclusivePlaza().getValue();
                UbigeoCodeDistCcIDest = bciHCcePartDirRec.getUbigeoCodeDistOff().getValue().substring(0, 4);
                cciCodeOrgVal = this.paymentOrderRecObj.getLocalRefField("L.CCI.CODE.ORIG").getValue().substring(0, 6);
                final EbBciHCceParticipantDirRecord bciHCcePartDirRec2 = this.getPartcipantRec(cciCodeOrgVal, da);
                UbigeoCodeDistCodeOrig = bciHCcePartDirRec2.getUbigeoCodeDistOff().getValue().substring(0, 4);
                exclusivePlazaCodeOrig = bciHCcePartDirRec2.getExclusivePlaza().getValue();
            } catch (Exception e1) {
                e1.getMessage();
            }

            if (exclusivePlazaCcIDest.equals("N") && exclusivePlazaCodeOrig.equals("N")) {
                if (UbigeoCodeDistCcIDest.equals(UbigeoCodeDistCodeOrig)) {
                    this.paymentOrderRecObj.getLocalRefField("L.TYPE.PLACE").setValue("SAME.PLACE");
                    this.paymentOrderRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("M");
                } else {
                    this.paymentOrderRecObj.getLocalRefField("L.TYPE.PLACE").setValue("ANOTHER.PLACE");
                    this.paymentOrderRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("O");
                }
            }
            
            else if (exclusivePlazaCcIDest.equals("S") && exclusivePlazaCodeOrig.equals("S")) {
                if (UbigeoCodeDistCcIDest.equals(UbigeoCodeDistCodeOrig)) {
                    this.paymentOrderRecObj.getLocalRefField("L.TYPE.PLACE").setValue("SAME.PLACE");
                    this.paymentOrderRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("M");
                } else {
                    this.paymentOrderRecObj.getLocalRefField("L.TYPE.PLACE").setValue("EXCLUSIVE.PLACE");
                    this.paymentOrderRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("E");
                }
            } else if (exclusivePlazaCcIDest.equals("N") && exclusivePlazaCodeOrig.equals("S")) {
                if (!UbigeoCodeDistCcIDest.equals(UbigeoCodeDistCodeOrig)) {
                    this.paymentOrderRecObj.getLocalRefField("L.TYPE.PLACE").setValue("ANOTHER.PLACE");
                    this.paymentOrderRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("O");
                }
                
            }
            else if (exclusivePlazaCcIDest.equals("S") && exclusivePlazaCodeOrig.equals("N")) {
                if (!UbigeoCodeDistCcIDest.equals(UbigeoCodeDistCodeOrig)) {
                    this.paymentOrderRecObj.getLocalRefField("L.TYPE.PLACE").setValue("EXCLUSIVE.PLACE");
                    this.paymentOrderRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("E");
                }
                
            }
            /*
             * if (exclusivePlaza.equals("S")) {
             * this.paymentOrderRecObj.getLocalRefField("L.TYPE.PLACE").setValue
             * ("EXCLUSIVE.PLACE");
             * this.paymentOrderRecObj.getLocalRefField("L.APPL.CRITERIA").
             * setValue("E"); } else { try {
             * 
             * } catch (Exception e2) { e2.getMessage(); }
             * this.defaultTypePlace(application, destUbigeoCode,
             * codeOrgUbigeoCode); }
             */
            currentRecord.set(this.paymentOrderRecObj.toStructure());
        }
        if (application.equals("PP.ORDER.ENTRY")) {
            this.ppOrderEntryRecObj = new PpOrderEntryRecord(currentRecord);
            try {
                cciDestinationFldVal = this.ppOrderEntryRecObj.getLocalRefField("L.CCI.DESTINATION").getValue();
                cciDestVal1 = cciDestinationFldVal.substring(0, 3);
                cciDestVal2 = cciDestinationFldVal.substring(3, 6);
                crEntityCodVal = "0" + cciDestVal1 + "0" + cciDestVal2;
                this.ppOrderEntryRecObj.getLocalRefField("L.CR.ENTITY.COD").setValue(crEntityCodVal);
                cciDestinationVal = cciDestinationFldVal.substring(0, 6);
                final EbBciHCceParticipantDirRecord bciHCcePartDirRec = this.getPartcipantRec(cciDestinationVal, da);
                UbigeoCodeDistCcIDest = bciHCcePartDirRec.getUbigeoCode().getValue().substring(0, 4);
            } catch (Exception e3) {
                e3.getMessage();
            }
            try {
                cciCodeOrgVal = this.ppOrderEntryRecObj.getLocalRefField("L.CCI.CODE.ORIG").getValue().substring(0, 6);
                final EbBciHCceParticipantDirRecord bciHCcePartDirRec3 = this.getPartcipantRec(cciCodeOrgVal, da);
                UbigeoCodeDistCodeOrig = bciHCcePartDirRec3.getUbigeoCode().getValue().substring(0, 4);
            } catch (Exception e4) {
                e4.getMessage();
            }
            this.defaultTypePlace(application, UbigeoCodeDistCcIDest, UbigeoCodeDistCodeOrig);
            currentRecord.set(this.ppOrderEntryRecObj.toStructure());
        }
    }

    public EbBciHCceParticipantDirRecord getPartcipantRec(final String cciVal, final DataAccess da) {
        EbBciHCceParticipantDirRecord bciHCcePartDirRec1 = new EbBciHCceParticipantDirRecord((T24Context) this);
        List<String> ccePartDirList = null;
        if (!cciVal.isEmpty()) {
            try {
                ccePartDirList = (List<String>) da.selectRecords("", "EB.BCI.H.CCE.PARTICIPANT.DIR", "",
                        "@ID LIKE ...01" + cciVal + "...");
                final String ccePartdirId = ccePartDirList.get(0);
                bciHCcePartDirRec1 = new EbBciHCceParticipantDirRecord(
                        da.getRecord("EB.BCI.H.CCE.PARTICIPANT.DIR", ccePartdirId));
            } catch (Exception e2) {
                e2.getMessage();
            }
        }
        return bciHCcePartDirRec1;
    }

    public void defaultTypePlace(final String application, final String destUbigeoCode,
            final String codeOrgUbigeoCode) {
        if (application.equals("PAYMENT.ORDER")) {
            if (destUbigeoCode.equals(codeOrgUbigeoCode)) {
                this.paymentOrderRecObj.getLocalRefField("L.TYPE.PLACE").setValue("SAME.PLACE");
                this.paymentOrderRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("M");
            } else if (!codeOrgUbigeoCode.equals("")) {
                this.paymentOrderRecObj.getLocalRefField("L.TYPE.PLACE").setValue("ANOTHER.PLACE");
                this.paymentOrderRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("O");
            }
        }
        if (application.equals("PP.ORDER.ENTRY")) {
            if (destUbigeoCode.equals(codeOrgUbigeoCode)) {
                this.ppOrderEntryRecObj.getLocalRefField("L.TYPE.PLACE").setValue("SAME.PLACE");
                this.ppOrderEntryRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("M");
            } else if (!codeOrgUbigeoCode.equals("")) {
                this.ppOrderEntryRecObj.getLocalRefField("L.TYPE.PLACE").setValue("ANOTHER.PLACE");
                this.ppOrderEntryRecObj.getLocalRefField("L.APPL.CRITERIA").setValue("O");
            }
        }
    }
}
