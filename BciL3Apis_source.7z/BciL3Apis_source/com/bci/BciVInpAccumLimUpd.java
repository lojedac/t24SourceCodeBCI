package com.bci;

import com.temenos.t24.api.records.dates.DatesRecord;
import com.temenos.t24.api.system.Date;
import java.util.Iterator;
import java.util.List;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.CurrencyClass;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceTable;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
* 
* @author Parthiban B 
*-----------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Java hook to update the CURR.ACCUMULATED.LIMIT field in the EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE table based on the function
* Developed By          : Parthiban Balasubramaniam, Techmill Technologies  
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : VERSION> PAYMENT.ORDER,BCI.ADJUSTMENT.R17ANDR18, VERSION> PAYMENT.ORDER,BCI.FOVRBAL.R16
* Attached As           : Input Routine
*-----------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-----------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciVInpAccumLimUpd extends RecordLifecycle
{
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final PaymentOrderRecord payOrdRec = new PaymentOrderRecord(currentRecord);
        try {
            final String curFunction = transactionContext.getCurrentFunction();
            final String curOper = transactionContext.getCurrentOperation();
            if (!curOper.equals("VALIDATE")) {
                final DataAccess da = new DataAccess((T24Context)this);
                final String payProduct = payOrdRec.getPaymentOrderProduct().getValue();
                if (payProduct.equals("FOVRBAL") || payProduct.equals("ADJSTMTS")) {
                    final String payCurrency = payOrdRec.getPaymentCurrency().getValue();
                    final String payAmount = payOrdRec.getPaymentAmount().getValue();
                    final Double payAmountNum = Double.parseDouble(payAmount);
                    String favBalLimitRecId = "";
                    if (payProduct.equals("FOVRBAL")) {
                        favBalLimitRecId = "R16";
                    }
                    if (payProduct.equals("ADJSTMTS")) {
                        favBalLimitRecId = "R17/R18";
                    }
                    final TStructure rec2 = da.getRecord("EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE", favBalLimitRecId);
                    final EbBciDailyLimitFavorableBalanceRecord favorBalLimitRec = new EbBciDailyLimitFavorableBalanceRecord(rec2);
                    final EbBciDailyLimitFavorableBalanceTable favorBalLimitTable = new EbBciDailyLimitFavorableBalanceTable((T24Context)this);
                    final List<CurrencyClass> currList = (List<CurrencyClass>)favorBalLimitRec.getCurrency();
                    int idx = 0;
                    for (final CurrencyClass currObj : currList) {
                        final String limCurrency = currObj.getCurrency().getValue();
                        if (!payCurrency.equals(limCurrency)) {
                            ++idx;
                        }
                        else {
                            String curAccumLimit = currObj.getCurrAccumulatedLimit().getValue();
                            if (curAccumLimit.isEmpty()) {
                                curAccumLimit = "0.0";
                            }
                            final Double curAccumLimitNum = Double.parseDouble(curAccumLimit);
                            final Double calcAccumLimitNum = this.calcAccumLimit(curFunction, curAccumLimitNum, payAmountNum, unauthorisedRecord, currentRecord);
                            currObj.setCurrAccumulatedLimit((CharSequence)calcAccumLimitNum.toString());
                            favorBalLimitRec.setCurrency(currObj, idx);
                        }
                    }
                    favorBalLimitTable.write((CharSequence)favBalLimitRecId, favorBalLimitRec);
                }
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
        return payOrdRec.getValidationResponse();
    }
    
    private Double calcAccumLimit(final String curFunction, final Double curAccumLimitNum, final Double payAmountNum, final TStructure unauthorisedPoRecord, final TStructure currentRecord) {
        Double calcLimVal = curAccumLimitNum;
        try {
            final PaymentOrderRecord poRecUnauth = new PaymentOrderRecord(unauthorisedPoRecord);
            final String payAmtUnauth = poRecUnauth.getPaymentAmount().toString();
            if (curFunction.equals("INPUT")) {
                final boolean dateFlg = this.dateChk(unauthorisedPoRecord);
                if (!payAmtUnauth.isEmpty() && dateFlg) {
                    final Double payAmtUnauthNum = Double.parseDouble(payAmtUnauth);
                    calcLimVal = this.rollback(calcLimVal, payAmtUnauthNum);
                }
                calcLimVal += payAmountNum;
            }
            if (curFunction.equals("DELETE")) {
                final boolean dateFlg = this.dateChk(currentRecord);
                if (dateFlg) {
                    calcLimVal = this.rollback(calcLimVal, payAmountNum);
                }
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
        return calcLimVal;
    }
    
    private Double rollback(final Double existLim, final Double lastTran) {
        return existLim - lastTran;
    }
    
    private boolean dateChk(final TStructure rec1) {
        boolean flg = true;
        try {
            final PaymentOrderRecord poRecUnauth = new PaymentOrderRecord(rec1);
            final String payExecDate = poRecUnauth.getPaymentExecutionDate().toString();
            if (!payExecDate.isEmpty()) {
                final Date dt = new Date((T24Context)this);
                final DatesRecord dtRec = dt.getDates();
                final String today = dtRec.getToday().toString();
                final int payExecDateNum = Integer.parseInt(payExecDate);
                final int todayNum = Integer.parseInt(today);
                if (todayNum > payExecDateNum) {
                    flg = false;
                }
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
        return flg;
    }
}
