package com.bci;

import com.temenos.api.TField;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
* 
* @author Parthiban B 
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Java hook to validate L.CCI.DESTINATION in the version PAYMENT.ORDER,BCI.ADJUSTMENT.R17ANDR18
* Developed By          : Parthiban Balasubramaniam, Techmill Technologies  
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : VERSION>PAYMENT.ORDER,BCI.ADJUSTMENT.R17ANDR18
* Attached As           : Input Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciVInpCciDestValidate extends RecordLifecycle
{
    Session session;
    String finMne;
    DataAccess da;
    public static final String INVALID_CCI_DESTINATION = "EB-BCI.INVALID.CCI.DESTINATION";
    public static final String CHK_DIGIT_NOT_MATCH = "EB-BCI.CHK.DIGIT.NOT.MATCH";
    
    public BciVInpCciDestValidate() {
        this.session = new Session((T24Context)this);
        this.finMne = this.session.getCompanyRecord().getFinancialMne().toString();
        this.da = new DataAccess((T24Context)this);
    }
    
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final PaymentOrderRecord payOrdRec = new PaymentOrderRecord(currentRecord);
        try {
            final BciVerInpCciUpdation cciUpdation = new BciVerInpCciUpdation();
            final TField cciDestFld = payOrdRec.getLocalRefField("L.CCI.DESTINATION");
            final String cciDest1 = cciDestFld.getValue();
            final int cciDestLen = cciDest1.length();
            final boolean entOffFlg = this.entOffCodeValidate(cciDest1);
            if (!entOffFlg && cciDestLen > 0) {
                cciDestFld.setError("EB-BCI.INVALID.CCI.DESTINATION");
            }
            if (cciDestLen == 18 && entOffFlg) {
                final String entOffCode = cciDest1.substring(0, 6);
                final String acctNum = cciDest1.substring(6, 16);
                final String chkDgt1 = cciDest1.substring(16, 17);
                final String chkDgt2 = cciDest1.substring(17, 18);
                final String entOffCodeChkDgt = cciUpdation.entityCalculation(entOffCode);
                final String acctNumChkDgt = cciUpdation.entityCalculation(acctNum);
                if (!entOffCodeChkDgt.equals(chkDgt1) || !acctNumChkDgt.equals(chkDgt2)) {
                    cciDestFld.setError("EB-BCI.CHK.DIGIT.NOT.MATCH");
                }
            }
            else if (entOffFlg && cciDestLen > 0) {
                cciDestFld.setError("EB-BCI.CHK.DIGIT.NOT.MATCH");
            }
        }
        catch (Exception e1) {
            e1.getMessage();
        }
        return payOrdRec.getValidationResponse();
    }
    
    public boolean entOffCodeValidate(final String cciDest2) {
        boolean flg = false;
        try {
            if (!cciDest2.isEmpty() && cciDest2.length() >= 6) {
                final String cciDirId = cciDest2.substring(0, 6);
                this.da.getRecord(this.finMne, "EB.BCI.H.CCE.DEST.ID.PARAM", "", cciDirId);
                flg = true;
            }
        }
        catch (Exception e2) {
            e2.getMessage();
        }
        return flg;
    }
}
