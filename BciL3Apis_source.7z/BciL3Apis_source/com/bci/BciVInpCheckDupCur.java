package com.bci;

import com.temenos.api.TField;
import java.util.List;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.CurrencyClass;
import java.util.ArrayList;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
* @author kalaipriya.m 
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Java hook to check the duplicate entry in the CURRENCY field of EB.BCI.DAILY. LIMIT.FAVORABLE.BALANCE
* Developed By          : Kalaipriya M, Techmill Technologies  
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : VERSION.CONTROL> EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE
* Attached As           : Input Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciVInpCheckDupCur extends RecordLifecycle
{
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final EbBciDailyLimitFavorableBalanceRecord dailyLimFavBalRec = new EbBciDailyLimitFavorableBalanceRecord(currentRecord);
        final List<CurrencyClass> curListVal = (List<CurrencyClass>)dailyLimFavBalRec.getCurrency();
        final int curLen = curListVal.size();
        final List<String> curList = new ArrayList<String>();
        for (int i = 0; i < curLen; ++i) {
            if (i == 0) {
                curList.add(curListVal.get(i).getCurrency().getValue());
            }
            else {
                final String curVal = curListVal.get(i).getCurrency().getValue();
                if (curList.contains(curVal)) {
                    final TField curField = dailyLimFavBalRec.getCurrency().get(i).getCurrency();
                    curField.setError("EB-BCI.DUP.CCY");
                }
                curList.add(curListVal.get(i).getCurrency().getValue());
            }
        }
        return dailyLimFavBalRec.getValidationResponse();
    }
}
