package com.bci;

import java.util.Iterator;
import java.util.List;
import com.temenos.api.TField;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.CurrencyClass;
import com.temenos.t24.api.tables.ebbcidailylimitfavorablebalance.EbBciDailyLimitFavorableBalanceRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
* @author Parthiban B 
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Java hook to validate the PO records for the fields L.TYPE.OF.OPERATION, L.REASON and the Limits of R16 and R17/R18
* Developed By          : Parthiban Balasubramaniam, Techmill Technologies  
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : VERSION> PAYMENT.ORDER,BCI.FOVRBAL.R16, VERSION> PAYMENT.ORDER,BCI.ADJUSTMENT.R17ANDR18
* Attached As           : Input Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciVInpFavorBalLimitChk extends RecordLifecycle
{
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        final String FOVRBALPRD = "FOVRBAL";
        final String ADJSTMTSPRD = "ADJSTMTS";
        try {
            final DataAccess da = new DataAccess((T24Context)this);
            final String payProduct = poRec.getPaymentOrderProduct().getValue();
            final String payCurrency = poRec.getPaymentCurrency().getValue();
            final TField payAmountFld = poRec.getPaymentAmount();
            final String payAmount = payAmountFld.getValue();
            final Double payAmountNum = Double.parseDouble(payAmount);
            final String curFunction = transactionContext.getCurrentFunction();
            final TField typOpeFld = poRec.getLocalRefField("L.TYPE.OF.OPERATION");
            final TField reasonFld = poRec.getLocalRefField("L.REASON");
            final String typOpe = typOpeFld.toString();
            final String reason = reasonFld.toString();
            TStructure rec1 = new TStructure();
            if (payProduct.equals("FOVRBAL")) {
                rec1 = da.getRecord("EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE", "R16");
                if (!typOpe.equals("FOVRBAL") && !typOpe.isEmpty()) {
                    typOpeFld.setError("EB-BCI.INVALID.FOR.FOVRBAL");
                }
                if (!reason.equals("R16") && !reason.isEmpty()) {
                    reasonFld.setError("EB-BCI.INVALID.FOR.FOVRBAL");
                }
            }
            if (payProduct.equals("ADJSTMTS")) {
                rec1 = da.getRecord("EB.BCI.DAILY.LIMIT.FAVORABLE.BALANCE", "R17/R18");
                if (typOpe.equals("FOVRBAL") && !typOpe.isEmpty()) {
                    typOpeFld.setError("EB-BCI.INVALID.FOR.ADJSTMTS");
                }
                if (reason.equals("R16") && !reason.isEmpty()) {
                    reasonFld.setError("EB-BCI.INVALID.FOR.ADJSTMTS");
                }
            }
            final EbBciDailyLimitFavorableBalanceRecord favorBalLimitRec = new EbBciDailyLimitFavorableBalanceRecord(rec1);
            final List<CurrencyClass> currList = (List<CurrencyClass>)favorBalLimitRec.getCurrency();
            int currPos = 0;
            for (final CurrencyClass curElement : currList) {
                final String favorBalLimitCurrency = curElement.getCurrency().getValue();
                if (favorBalLimitCurrency.equals(payCurrency)) {
                    break;
                }
                ++currPos;
            }
            final CurrencyClass currCls = favorBalLimitRec.getCurrency(currPos);
            final String txnLimit = currCls.getTransactionLimit().getValue();
            final String accumLimit = currCls.getAccumulatedLimit().getValue();
            String currAccumLimit = currCls.getCurrAccumulatedLimit().getValue();
            if (currAccumLimit.isEmpty()) {
                currAccumLimit = "0";
            }
            final Double txnLimitNum = Double.parseDouble(txnLimit);
            final Double accumLimitNum = Double.parseDouble(accumLimit);
            final Double currAccumLimitNum = Double.parseDouble(currAccumLimit);
            if (payAmountNum >= txnLimitNum && !curFunction.equals("DELETE")) {
                payAmountFld.setError("EB-BCI.TXN.AMT.EXCEED.LIMIT");
            }
            final Double calcLimit = currAccumLimitNum + payAmountNum;
            if (calcLimit >= accumLimitNum && !curFunction.equals("DELETE")) {
                payAmountFld.setError("EB-BCI.TXN.AMT.EXCEED.ACCUM.LIMIT");
            }
            this.validateCurrency(poRec);
        }
        catch (Exception e1) {
            e1.getMessage();
        }
        return poRec.getValidationResponse();
    }
    
    public void validateCurrency(final PaymentOrderRecord poRec) {
        final String paymentCurrency = poRec.getPaymentCurrency().getValue();
        final String debitCurrency = poRec.getDebitCcy().getValue();
        if (!paymentCurrency.equals(debitCurrency)) {
            poRec.getDebitCcy().setError("EB-BCI.INVALID.CURRENCY");
        }
    }
}
