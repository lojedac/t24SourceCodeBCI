package com.bci;

import java.math.BigDecimal;

import com.temenos.api.TField;
import com.temenos.api.exceptions.T24CoreException;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
*   
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Java hook to validate the L.ORGNL.TXN.REF field with PP.ORDER.ENTRY
* Developed By          : Parthiban Balasubramaniam, Techmill Technologies 
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : VERSION> PAYMENT.ORDER,BCI.ADJUSTMENT.R17ANDR18
* Attached As           : Input Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciVInpOrgTxnRefVal extends RecordLifecycle
{
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final DataAccess da = new DataAccess((T24Context)this);
        final PaymentOrderRecord poRec1 = new PaymentOrderRecord(currentRecord);
        final TField orgTxnRefFld = poRec1.getLocalRefField("L.ORGNL.TXN.REF");
        final String orgTxnRef = orgTxnRefFld.getValue();
        final String errorId = "EB-BCI.INVALID.TXN.REF";
        if (!orgTxnRef.isEmpty()) {
            try {
                final TStructure paymentobj = da.getRecord("PP.ORDER.ENTRY", orgTxnRef);
                final PpOrderEntryRecord ppOrderEntryObj = new PpOrderEntryRecord(paymentobj);
                final String status = ppOrderEntryObj.getStatus().getValue();
                if (!status.equals("999")) {
                    orgTxnRefFld.setError("EB-BCI.INVALID.TXN.REF");
                }
            }
            catch (T24CoreException e2) {
                try {
                    final TStructure paymentobj2 = da.getHistoryRecord("PP.ORDER.ENTRY", orgTxnRef);
                    final PpOrderEntryRecord ppOrderEntryObj2 = new PpOrderEntryRecord(paymentobj2);
                    final String status2 = ppOrderEntryObj2.getStatus().getValue();
                    if (!status2.equals("999")) {
                        orgTxnRefFld.setError("EB-BCI.INVALID.TXN.REF");
                        return poRec1.getValidationResponse();
                    }
                    return poRec1.getValidationResponse();
                }
                catch (T24CoreException e3) {
                    orgTxnRefFld.setError("EB-BCI.INVALID.TXN.REF");
                }
            }
            catch (Exception e1) {
                e1.getMessage();
            }
        }
        return poRec1.getValidationResponse();
    }
    
    public void defaultFieldValues(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final String currVersion = transactionContext.getCurrentVersionId();
        final PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        String amountRecSent = "";
        String chequeAmt = "";
        String reason = "";
        double diffValue = 0.0;
        try {
            if (currVersion.equals(",BCI.ADJUSTMENT.R17ANDR18")) {
                amountRecSent = poRec.getLocalRefField("L.AMT.ENV.REC").getValue();
                chequeAmt = poRec.getLocalRefField("L.CHEQUE.AMT").getValue();
                reason = poRec.getLocalRefField("L.REASON").getValue();
                if (reason.equals("R17") || reason.equals("R18")) {
                    diffValue = this.getDiffValue(amountRecSent, chequeAmt, reason);
                    if (!amountRecSent.isEmpty()) {
                        diffValue = BigDecimal.valueOf(diffValue).setScale(2, 4).doubleValue();
                        poRec.getPaymentAmount().setValue(String.valueOf(diffValue));
                    }
                }
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        currentRecord.set(poRec.toStructure());
    }
    
    public double getDiffValue(final String amountRecSent, final String chequeAmt, final String reason) {
        Double differenceValue = 0.0;
        if (!amountRecSent.isEmpty() && !chequeAmt.isEmpty()) {
            if (reason.equals("R17")) {
                differenceValue = Double.parseDouble(amountRecSent) - Double.parseDouble(chequeAmt);
            }
            else if (reason.equals("R18")) {
                differenceValue = Double.parseDouble(chequeAmt) - Double.parseDouble(amountRecSent);
            }
        }
        return differenceValue;
    }
}
