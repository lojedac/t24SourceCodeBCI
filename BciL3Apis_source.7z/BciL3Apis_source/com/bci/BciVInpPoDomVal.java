
package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TField;
import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;

/*
* @author Parthiban B 
* 
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description           : To validate the L.TRANSFER.TYPE & L.APPL.CRITERIA field
*Developed By          : Parthiban B, Techmill Technologies
*Development Reference : BRD 11 - Commission Transfers & Cheque
*Attached To           : VERSION>PAYMENT.ORDER,DOMESTIC.BCI
*Attached as           : Input Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
*/

public class BciVInpPoDomVal extends RecordLifecycle {
    public TValidationResponse validateRecord(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        final PaymentOrderRecord payOrdRec = new PaymentOrderRecord(currentRecord);
        final List<String> errMessage = new ArrayList<String>();
        try {
            final TField tfrType = payOrdRec.getLocalRefField("L.TRANSFER.TYPE");
            final String grossAmount = payOrdRec.getLocalRefField("L.GROSS.SAL.AMT").getValue();
            final String subTranfType = payOrdRec.getLocalRefField("L.SUBTRASF.TYPE").getValue();
            final String anioMesCts = payOrdRec.getLocalRefField("L.ANIOMES.CTS").getValue();
            final String tfrTypeStr = tfrType.getValue();
            if (tfrTypeStr.isEmpty()) {
                errMessage.add(0, "EB-FIELD.EMPTY");
                errMessage.add(1, "Transfer Type");
                tfrType.setError(errMessage.toString());
            }
            if (tfrTypeStr.equals("223")) {

                try {
                    if (anioMesCts.length() != 6) {
                        payOrdRec.getLocalRefField("L.ANIOMES.CTS")
                                .setError("Error en longitud del campo, debe ser YYYYmm");
                    } else {
                        String mes = anioMesCts.substring(4, 6);
                        int mesInt = Integer.parseInt(mes);
                        if (mesInt > 12 || mesInt < 1) {
                            payOrdRec.getLocalRefField("L.ANIOMES.CTS").setError("Debe ser un mes válido (01-12)");
                        }
                    }
                } catch (Exception e) {

                }

                if (grossAmount.isEmpty()) {
                    errMessage.add(0, "EB-DFE.INP.MANDATORY");
                    errMessage.add(1, "Transfer Type");
                    errMessage.add(2, tfrTypeStr);
                    payOrdRec.getLocalRefField("L.GROSS.SAL.AMT").setError(errMessage.toString());
                } else {
                    String[] separados = grossAmount.split("\\.");
                    if (separados.length == 2) {
                        if (separados[1].length() > 2) {
                            payOrdRec.getLocalRefField("L.GROSS.SAL.AMT")
                                    .setError("Solo se permite máximo 2 decimales");
                        }
                    }
                }

            }
            if (!tfrTypeStr.equals("223") && !grossAmount.isEmpty()) {
                errMessage.add(0, "PO-IS.NOT.MANDATORY");
                errMessage.add(1, "Transfer Type");
                errMessage.add(2, tfrTypeStr);
                payOrdRec.getLocalRefField("L.GROSS.SAL.AMT").setError(errMessage.toString());
            }

            if (tfrTypeStr.equals("223") && (grossAmount.isEmpty() || grossAmount.equals(""))) {
                errMessage.add(0, "EB-DFE.INP.MANDATORY");
                errMessage.add(1, "Transfer Type");
                errMessage.add(2, tfrTypeStr);
                payOrdRec.getLocalRefField("L.GROSS.SAL.AMT").setError(errMessage.toString());
            }

            if (!tfrTypeStr.equals("223") && !anioMesCts.isEmpty()) {
                errMessage.add(0, "PO-IS.NOT.MANDATORY");
                errMessage.add(1, "Transfer Type");
                errMessage.add(2, tfrTypeStr);
                payOrdRec.getLocalRefField("L.ANIOMES.CTS").setError(errMessage.toString());
            }

            if (tfrTypeStr.equals("223") && (anioMesCts.isEmpty() || anioMesCts.equals(""))) {
                errMessage.add(0, "EB-DFE.INP.MANDATORY");
                errMessage.add(1, "Transfer Type");
                errMessage.add(2, tfrTypeStr);
                payOrdRec.getLocalRefField("L.ANIOMES.CTS").setError(errMessage.toString());
            }

            if (!tfrTypeStr.equals("221") && !subTranfType.isEmpty()) {
                errMessage.add(0, "PO-IS.NOT.MANDATORY");
                errMessage.add(1, "Transfer Type");
                errMessage.add(2, tfrTypeStr);
                payOrdRec.getLocalRefField("L.SUBTRASF.TYPE").setError(errMessage.toString());
            }

            if (tfrTypeStr.equals("221") && subTranfType.isEmpty()) {
                errMessage.add(0, "EB-DFE.INP.MANDATORY");
                errMessage.add(1, "Transfer Type");
                errMessage.add(2, tfrTypeStr);
                payOrdRec.getLocalRefField("L.SUBTRASF.TYPE").setError(errMessage.toString());
            }

        } catch (Exception e1) {
            e1.getMessage();
        }
        return payOrdRec.getValidationResponse();
    }
}
