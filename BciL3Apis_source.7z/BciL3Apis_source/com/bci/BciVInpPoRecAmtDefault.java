package com.bci;

import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
*    
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Java hook to default L.REVOLV.ENTITY,L.COMPENSATE.PLACE and L.AMT.ENV.REC fields with PP.ORDER.ENTRY
* Developed By          : Mallika V, Techmill Technologies
* Development Reference : BRD-16 TPH_Cheque_Compensation_Corrections
* Attached To           : VERSION> PAYMENT.ORDER,BCI.ADJUSTMENT.R17ANDR18
* Attached As           : Default Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************   
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciVInpPoRecAmtDefault extends RecordLifecycle
{
    public void defaultFieldValues(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final DataAccess daObj = new DataAccess((T24Context)this);
        final PaymentOrderRecord payRecObj = new PaymentOrderRecord(currentRecord);
        PpOrderEntryRecord ppOrderEntryObj = new PpOrderEntryRecord((T24Context)this);
        String originalTxnRef = "";
        originalTxnRef = payRecObj.getLocalRefField("L.ORGNL.TXN.REF").getValue();
        try {
            ppOrderEntryObj = new PpOrderEntryRecord(daObj.getRecord("PP.ORDER.ENTRY", originalTxnRef));
            this.defaultAmountValue(ppOrderEntryObj, payRecObj, currentRecord);
        }
        catch (Exception e1) {
            ppOrderEntryObj = new PpOrderEntryRecord(daObj.getHistoryRecord("PP.ORDER.ENTRY", originalTxnRef));
            this.defaultAmountValue(ppOrderEntryObj, payRecObj, currentRecord);
        }
    }
    
    public void defaultAmountValue(final PpOrderEntryRecord ppOrderEntryObj, final PaymentOrderRecord payRecObj, final TStructure currentRecord) {
        String cciCodeOrig = "";
        String issueCode = "";
        String prsentSqr = "";
        String transactionAmt = "";
        String reason = "";
        final String poStatus = ppOrderEntryObj.getStatus().getValue();
        if (poStatus.equals("999")) {
            try {
                cciCodeOrig = ppOrderEntryObj.getLocalRefField("L.CCI.CODE.ORIG").getValue();
                issueCode = cciCodeOrig.substring(1, 4);
            }
            catch (Exception e2) {
                e2.getMessage();
            }
            try {
                prsentSqr = ppOrderEntryObj.getLocalRefField("L.PRESNTER.SQUR").getValue();
                transactionAmt = ppOrderEntryObj.getTransactionamount().getValue();
            }
            catch (Exception e3) {
                e3.getMessage();
            }
            try {
                reason = payRecObj.getLocalRefField("L.REASON").getValue();
                if (reason.equals("R17") || reason.equals("R18")) {
                    payRecObj.getLocalRefField("L.REVOLV.ENTITY").setValue(issueCode);
                    payRecObj.getLocalRefField("L.COMPENSATE.PLACE").setValue(prsentSqr);
                    payRecObj.getLocalRefField("L.AMT.ENV.REC").setValue(transactionAmt);
                    currentRecord.set(payRecObj.toStructure());
                }
            }
            catch (Exception e4) {
                e4.getMessage();
            }
        }
    }
}
