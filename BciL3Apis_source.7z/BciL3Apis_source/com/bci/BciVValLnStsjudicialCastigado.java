
package com.bci;

import com.temenos.t24.api.records.account.AccountRecord;
import java.time.LocalDate;
import java.util.logging.Level;
import com.temenos.api.TField;
import java.util.logging.Logger;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/**
*
*----------------------------------------------------------------------------------------------------------------
* Description           : AA Validation Routine to validate the field L.EST.PRESTAMO
* Developed By          : Kalaipriya M,Techmill Technologies     
* Development Reference : BRD-07 CAMPOS LOCALES JUDICIAL-CASTIGADO  
* Attached To           : Activity.API> BCI.GROUP.SUB.LOAN.API & BCI.GROUP.SUB.LOAN.REF.REE.API     
* Attached As           : Validation Routine  
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/

public class BciVValLnStsjudicialCastigado extends ActivityLifecycle
{
    public TValidationResponse validateRecord(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record1) {
        final DataAccess fRead = new DataAccess((T24Context)this);
        final AaPrdDesAccountRecord aaPrdDesAccRec = new AaPrdDesAccountRecord(record1);
        final Logger l1 = Logger.getLogger("AA.LOAN");
        String sysDate = "";
        String arrId = "";
        String stateVal = "";
        String accountNo = "";
        String acLoanStatVal = "";
        String acCurNo = "";
        String acLoanStatHisVal = "";
        String loanArrAgestatus = "";
        String acDateTime = "";
        String acDate = "";
        String accHisId = "";
        String acHisDate = "";
        String acHisDateTime = "";
        final String localFld = "L.EST.PRESTAMO";
        arrId = arrangementContext.getArrangementId();
        TField stateField = new TField();
        try {
            stateField = aaPrdDesAccRec.getLocalRefField(localFld);
            stateVal = stateField.getValue();
            accountNo = arrangementRecord.getLinkedAppl(0).getLinkedApplId().getValue();
        }
        catch (Exception e) {
            l1.log(Level.WARNING, e.getMessage());
        }
        final LocalDate now = LocalDate.now();
        sysDate = now.toString().replace("-", "");
        try {
            final AaAccountDetailsRecord aaActDetRec = new AaAccountDetailsRecord(fRead.getRecord("AA.ACCOUNT.DETAILS", arrId));
            loanArrAgestatus = aaActDetRec.getArrAgeStatus().getValue();
        }
        catch (Exception e2) {
            l1.log(Level.WARNING, e2.getMessage());
        }
        AccountRecord accRec = null;
        try {
            accRec = new AccountRecord(fRead.getRecord("ACCOUNT", accountNo));
            acLoanStatVal = accRec.getLocalRefField(localFld).getValue();
            acDateTime = accRec.getDateTime(0).substring(0, 6);
            acCurNo = accRec.getCurrNo();
            acDate = "20" + acDateTime;
        }
        catch (Exception e3) {
            l1.log(Level.WARNING, e3.getMessage());
        }
        if (!stateVal.equals("")) {
            final String s;
            switch (s = stateVal) {
                case "Castigado": {
                    int errFlg = 0;
                    if (loanArrAgestatus.equals("NAB") || acLoanStatVal.equals("Judicial")) {
                        errFlg = 1;
                    }
                    if (errFlg == 0) {
                        stateField.setError("EB-BCI.NO.CASTIGADO.MARK");
                        break;
                    }
                    break;
                }
                case "Judicial": {
                    if (!loanArrAgestatus.equals("NAB")) {
                        stateField.setError("EB-BCI.NO.JUDICIAL.MARK");
                        break;
                    }
                    break;
                }
                default:
                    break;
            }
        }
        else {
            final int accCurNoNum = Integer.parseInt(acCurNo);
            if (accCurNoNum != 0) {
                if (!acLoanStatVal.equals("") && !acDate.equals(sysDate)) {
                    stateField.setError("EB-REV.ON.SAME.DAY.ONLY");
                }
                else {
                    for (int i = accCurNoNum - 1; i > 0; --i) {
                        accHisId = String.valueOf(accountNo) + ";" + i;
                        AccountRecord acHisRec = null;
                        try {
                            acHisRec = new AccountRecord(fRead.getRecord("", "ACCOUNT", "$HIS", accHisId));
                            acLoanStatHisVal = acHisRec.getLocalRefField(localFld).getValue();
                            if (!acLoanStatVal.equals(acLoanStatHisVal)) {
                                acHisDateTime = acHisRec.getDateTime(0).substring(0, 6);
                                acHisDate = "20" + acHisDateTime;
                                if (!acHisDate.equals(sysDate)) {
                                    stateField.setError("EB-REV.ON.SAME.DAY.ONLY");
                                }
                            }
                        }
                        catch (Exception e4) {
                            l1.log(Level.WARNING, e4.getMessage());
                        }
                    }
                }
            }
        }
        return aaPrdDesAccRec.getValidationResponse();
    }
}
