
package com.bci;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.api.exceptions.T24CoreException;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.account.AltAcctTypeClass;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.teller.TellerRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebbcicceparticipantsbankname.EbBciCceParticipantsBankNameRecord;
import com.temenos.t24.api.tables.ebbcihccedestidparam.EbBciHCceDestIdParamRecord;
import com.temenos.tafj.api.client.impl.T24Context;

/*
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Field Value L.CCI.DESTINATION should be same as @ID of EB.BCI.CCE.PARTICIPANT.DIR
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : Additional Fields - Cheque Clearing
*Attached To            : VERSION>TELLER,BCI.DIR.CHQ.CLG, TELLER,BCI.FOREIGN.CHQS, PAYMENT.ORDER,DOMESTIC.BCI
*Attached as            : Default/Input Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/
public class BciVerCciDestinationValidate extends RecordLifecycle {
    public static final String INVALID_CCI_DESTINATION = "EB-BCI.INVALID.CCI.DESTINATION";
    public static final String INVALID_CONTROL_DIGIT = "EB-BCI.CHK.DIGIT.NOT.MATCH";
    public static String CCI_DESTINATION;
    public static String CCI_DESTINATIONORG;
    public static final String CCI_CODE = "L.CCI.CODE.ORIG";
    DataAccess daAccess;
    Session session;
    String finMne;
    BciVerInpCciUpdation cciUpdation;

    static {
        BciVerCciDestinationValidate.CCI_DESTINATION = "L.CCI.DESTINATION";
        BciVerCciDestinationValidate.CCI_DESTINATIONORG = "L.CCI.DESTINATION";
    }

    public BciVerCciDestinationValidate() {
        this.daAccess = new DataAccess((T24Context) this);
        this.session = new Session((T24Context) this);
        this.finMne = this.session.getCompanyRecord().getFinancialMne().getValue();
        this.cciUpdation = new BciVerInpCciUpdation();
    }

    public TValidationResponse validateRecord(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        String cciDestination = "";
        String cciDestinationCP = "";
        String cciOrigin = "";
        TValidationResponse flag = null;
        String resFlag = "";
        boolean validStr = true;
        Date date = new Date();

        if (application.equals("TELLER")) {
            BciVerCciDestinationValidate.CCI_DESTINATION = "L.CP.CCI.DESTINATION";
            final TellerRecord tellerRecordObj = new TellerRecord(currentRecord);
            cciDestination = tellerRecordObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION).getValue();
            tellerRecordObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATIONORG).setValue(cciDestination);
            resFlag = this.validateCciDestination(cciDestination, this.daAccess, this.finMne);
            try {
                if (!cciDestination.isEmpty()) {
                    this.validateTellerRecord(tellerRecordObj, cciDestination, resFlag);
                }
            } catch (Exception e) {
                e.getMessage();
            }
            flag = tellerRecordObj.getValidationResponse();
        } else if (application.equals("PAYMENT.ORDER")) {
            BciVerCciDestinationValidate.CCI_DESTINATION = "L.CCI.DESTINATION";
            final PaymentOrderRecord paymentOrderRecObj = new PaymentOrderRecord(currentRecord);
            if (paymentOrderRecObj.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                try {
                    cciDestination = paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                            .getValue();
                    cciDestinationCP = paymentOrderRecObj.getLocalRefField("L.CP.CCI.DESTINATION").getValue();
                } catch (Exception ex) {
                    ex.getMessage();
                }
                if (cciDestination.isEmpty() && !cciDestinationCP.isEmpty()) {
                    validStr = false;
                } else if (!cciDestination.isEmpty() && !cciDestinationCP.isEmpty()) {
                    cciDestination = paymentOrderRecObj.getLocalRefField("L.CP.CCI.DESTINATION").getValue();
                    paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATIONORG)
                            .setValue(cciDestination);
                }
                cciOrigin = paymentOrderRecObj.getLocalRefField("L.CCI.CODE.ORIG").getValue();
                resFlag = this.validateCciDestination(cciDestination, this.daAccess, this.finMne);
                try {
                    if (!cciDestination.isEmpty()) {
                        resFlag = this.getCceRecord(cciDestination, this.daAccess, this.finMne);
                        this.validatePaymentOrderRecord(paymentOrderRecObj, cciDestination, resFlag, validStr);
                    }
                    if (!cciOrigin.isEmpty()) {
                        this.validatePaymentOrderOriginRecord(paymentOrderRecObj, cciOrigin, resFlag, validStr);
                    }
                    // flag = paymentOrderRecObj.getValidationResponse();
                } catch (Exception e2) {
                    e2.getMessage();
                }
                Boolean isNumeric = true;
                try {
                    long cciDestination1 = Long.parseLong(cciDestination.substring(0, 10));
                    long cciDestination2 = Long.parseLong(cciDestination.substring(10, 20));

                } catch (Exception e) {
                    paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                            .setError("Solo se permiten caracteres de tipo numérico");
                    isNumeric = false;

                }
                if (cciDestination.length() != 20) {
                    paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                            .setError("La longitud del campo debe ser de 20 caracteres");
                } else if (cciDestination.length() == 20 && isNumeric) {
                    String finalDigit = this.poValidateCciDestination(cciDestination, paymentOrderRecObj, currentRecord,
                            false);
                    String lastDigits = cciDestination.substring(18, 20);
                    if (!finalDigit.equals(lastDigits)) {

                        paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                                .setError("No coincide digito verificador");
                    }
                }

                flag = paymentOrderRecObj.getValidationResponse();
            }
        } else if (application.equals("PP.ORDER.ENTRY")) {
            BciVerCciDestinationValidate.CCI_DESTINATION = BciVerCciDestinationValidate.CCI_DESTINATIONORG;
            final PpOrderEntryRecord ppOrderEntryObj = new PpOrderEntryRecord(currentRecord);
            cciDestination = ppOrderEntryObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION).getValue();
            cciOrigin = ppOrderEntryObj.getLocalRefField("L.CCI.CODE.ORIG").getValue();
            resFlag = this.validateCciDestination(cciDestination, this.daAccess, this.finMne);
            try {
                if (!cciDestination.isEmpty()) {
                    resFlag = this.getCceRecord(cciDestination, this.daAccess, this.finMne);
                    this.validatePpOrderEntryRecord(ppOrderEntryObj, cciDestination, resFlag);
                }
                if (!cciOrigin.isEmpty()) {
                    resFlag = this.getCceRecord(cciOrigin, this.daAccess, this.finMne);
                    this.validatePpOrderOriginEntryRecord(ppOrderEntryObj, cciOrigin, resFlag);
                }
            } catch (Exception e3) {
                e3.getMessage();
            }
            flag = ppOrderEntryObj.getValidationResponse();
        }
        return flag;
    }

    public void validatePaymentOrderOriginRecord(final PaymentOrderRecord paymentOrderRecObj, final String cciOrigin,
            final String resFlag, final boolean validStr) {
        if (cciOrigin.length() != 20) {
            paymentOrderRecObj.getLocalRefField("L.CCI.CODE.ORIG").setError("EB-BCI.INVALID.CCI.DESTINATION");
        }
    }

    public void validatePpOrderOriginEntryRecord(final PpOrderEntryRecord ppOrderEntryObj, final String cciOrigin,
            final String resFlag) {
        if (resFlag.equals("") || cciOrigin.length() != 20) {
            ppOrderEntryObj.getLocalRefField("L.CCI.CODE.ORIG").setError("EB-BCI.INVALID.CCI.DESTINATION");
        }
    }

    public void validatePpOffEntCode(final String ppOffEntCode, final PpOrderEntryRecord ppOrderEntryObj,
            final String ppChqLastDigit, final String ppAccountNumber) {
        final String ppEntityVal = this.cciUpdation.entityCalculation(ppOffEntCode);
        final String ppAccountVal = this.cciUpdation.entityCalculation(ppAccountNumber);
        final String finalPpVal = String.valueOf(ppEntityVal) + ppAccountVal;
        if (!finalPpVal.equals(ppChqLastDigit)) {
            ppOrderEntryObj.getLocalRefField("L.CCI.CODE.ORIG").setError("EB-BCI.CHK.DIGIT.NOT.MATCH");
        }
    }

    public void validateTellerRecord(final TellerRecord tellerRecordObj, final String cciDestination,
            final String resFlag) {
        if (resFlag.equals("") || cciDestination.length() != 18) {
            tellerRecordObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                    .setError("EB-BCI.INVALID.CCI.DESTINATION");
        } else if (cciDestination.length() == 18) {
            final String ttOffEntCode = cciDestination.substring(0, 6);
            final String ttAccountNumber = cciDestination.substring(6, 16);
            final String ttChqLastDigit = cciDestination.substring(16, 18);
            this.validateOffEntCode(ttOffEntCode, tellerRecordObj, ttChqLastDigit, ttAccountNumber);
        }
    }

    public void validateOffEntCode(final String ttOffEntCode, final TellerRecord tellerRecordObj,
            final String ttChqLastDigit, final String ttAccountNumber) {
        final String entityVal = this.cciUpdation.entityCalculation(ttOffEntCode);
        final String accountVal = this.cciUpdation.entityCalculation(ttAccountNumber);
        final String finalTtVal = String.valueOf(entityVal) + accountVal;
        if (!finalTtVal.equals(ttChqLastDigit)) {
            tellerRecordObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                    .setError("EB-BCI.CHK.DIGIT.NOT.MATCH");
        }
    }

    public void validatePaymentOrderRecord(final PaymentOrderRecord paymentOrderRecObj, final String cciDestination,
            final String resFlag, final boolean validStr) {
        if (resFlag.equals("") || cciDestination.length() != 20) {
            if (!validStr) {
                paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                        .setError("EB-BCI.INVALID.CCI.DESTINATION");
            } else if (cciDestination.length() != 18 && validStr) {
                paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                        .setError("EB-BCI.INVALID.CCI.DESTINATION");
            } else if (cciDestination.length() == 20 && !validStr) {
                final String poOffEntCode = cciDestination.substring(0, 6);
                final String poAccountNumber = cciDestination.substring(6, 18);
                final String poChqLastDigit = cciDestination.substring(18, 20);
                this.validatePoOffEntCode(poOffEntCode, paymentOrderRecObj, poChqLastDigit, poAccountNumber);
            } else if (cciDestination.length() == 18 && validStr) {
                final String poOffEntCode = cciDestination.substring(0, 6);
                final String poAccountNumber = cciDestination.substring(6, 16);
                final String poChqLastDigit = cciDestination.substring(16, 18);
                this.validatePoOffEntCode(poOffEntCode, paymentOrderRecObj, poChqLastDigit, poAccountNumber);
            }
        }
    }

    public void validatePoOffEntCode(final String poOffEntCode, final PaymentOrderRecord paymentOrderRecObj,
            final String poChqLastDigit, final String poAccountNumber) {
        final String poEntityVal = this.cciUpdation.entityCalculation(poOffEntCode);
        final String poAccountVal = this.cciUpdation.entityCalculation(poAccountNumber);
        final String finalPoVal = String.valueOf(poEntityVal) + poAccountVal;
        if (!finalPoVal.equals(poChqLastDigit)) {
            paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                    .setError("EB-BCI.CHK.DIGIT.NOT.MATCH");
        }
    }

    public void validatePpOrderEntryRecord(final PpOrderEntryRecord ppOrderEntryObj, final String cciDestination,
            final String resFlag) {
        if (resFlag.equals("") || cciDestination.length() != 20) {
            ppOrderEntryObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                    .setError("EB-BCI.INVALID.CCI.DESTINATION");
        } else if (cciDestination.length() == 20) {
            final String ppOffEntCode = cciDestination.substring(0, 6);
            final String ppAccountNumber = cciDestination.substring(6, 16);
            final String ppChqLastDigit = cciDestination.substring(19, 20);
            this.validatePpOffEntCode(ppOffEntCode, ppOrderEntryObj, ppChqLastDigit, ppAccountNumber);
        }
    }

    public String validateCciDestination(final String cciDestination, final DataAccess daAccess, final String finMne) {
        String cceRespFlag = "";
        if (!cciDestination.isEmpty()) {
            cceRespFlag = this.getCceRecord(cciDestination, daAccess, finMne);
        }
        return cceRespFlag;
    }

    public String getCceRecord(final String cciDestination, final DataAccess daAccess, final String finMne) {
        String flag = "YES";
        List<String> txnIds = new ArrayList<String>();
        String cciId = "";
        try {
            if (!cciDestination.isEmpty() && cciDestination.length() >= 8) {
                flag = this.validateBankName(cciDestination, daAccess);
                if (flag.equalsIgnoreCase("YES")) {
                    final String cciDirId = cciDestination.substring(0, 6);
                    txnIds = (List<String>) daAccess.selectRecords(finMne, "EB.BCI.H.CCE.PARTICIPANT.DIR", "",
                            " WITH @ID LIKE ..." + cciDirId + "..." + " AND MARKER EQ 'Inactive'");
                    if (!txnIds.isEmpty()) {
                        for (int index = 0; index < txnIds.size(); ++index) {
                            cciId = txnIds.get(index);
                            flag = "";
                        }
                    } else {
                        final EbBciHCceDestIdParamRecord paramRecordObj = new EbBciHCceDestIdParamRecord(
                                daAccess.getRecord(finMne, "EB.BCI.H.CCE.DEST.ID.PARAM", "", cciDirId));
                        flag = "YES";
                    }
                }
            }
        } catch (Exception cceExcep) {
            cceExcep.getMessage();
        }
        return flag;
    }

    public String validateBankName(final String cciDestination, final DataAccess daAccess) {
        String marker = "";
        String flagMarker = "YES";
        try {
            final String bankCode = cciDestination.substring(0, 3);
            final EbBciCceParticipantsBankNameRecord bankNameRecordObj = new EbBciCceParticipantsBankNameRecord(
                    daAccess.getRecord(this.finMne, "EB.BCI.CCE.PARTICIPANTS.BANK.NAME", "", bankCode));
            if (bankNameRecordObj != null) {
                marker = bankNameRecordObj.getMarker().getValue();
                if (marker.equals("Inactive")) {
                    flagMarker = "";
                }
            }
        } catch (Exception bankExcep) {
            bankExcep.getMessage();
        }
        return flagMarker;
    }

    public void defaultFieldValues(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        PaymentOrderRecord paymentRecordObj = null;
        TellerRecord tellerRecordObj = null;
        PpOrderEntryRecord ppOrderEntryObj = null;
        String debitAccount = "";
        String cciDest = "";
        String cciDestCP = "";
        String officeEntityCde = "";
        String officeEntDigit = "";
        String accountNoDigit = "";
        String finalDigit = "";
        String ttAccountNo = "";
        boolean validStr = false;
        try {
            List<AltAcctTypeClass> altAcctId = new ArrayList<AltAcctTypeClass>();
            final List<String> altAcctTypeList = new ArrayList<String>();
            if (application.equals("PAYMENT.ORDER")) {
                BciVerCciDestinationValidate.CCI_DESTINATION = BciVerCciDestinationValidate.CCI_DESTINATIONORG;
                final PaymentOrderRecord paymentOrderRecObj = new PaymentOrderRecord(currentRecord);
                if (paymentOrderRecObj.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                    try {
                        cciDest = paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATIONORG)
                                .getValue();
                        cciDestCP = paymentOrderRecObj.getLocalRefField("L.CP.CCI.DESTINATION").getValue();
                    } catch (Exception ex) {
                        ex.getMessage();
                    }
                    if (cciDest.isEmpty() && !cciDestCP.isEmpty()) {
                        validStr = true;
                        cciDest = paymentOrderRecObj.getLocalRefField("L.CP.CCI.DESTINATION").getValue();
                        paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATIONORG)
                                .setValue(cciDest);
                    } else if (!cciDest.isEmpty() && !cciDestCP.isEmpty()) {
                        validStr = true;
                        cciDest = paymentOrderRecObj.getLocalRefField("L.CP.CCI.DESTINATION").getValue();
                        paymentOrderRecObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATIONORG)
                                .setValue(cciDest);
                    }
                    paymentRecordObj = new PaymentOrderRecord(currentRecord);
                    debitAccount = paymentRecordObj.getDebitAccount().getValue();
                    /*
                     * finalDigit = this.poValidateCciDestination(cciDest,
                     * paymentRecordObj, currentRecord, validStr); if
                     * (!finalDigit.isEmpty() && !validStr) {
                     * paymentRecordObj.getLocalRefField(
                     * BciVerCciDestinationValidate.CCI_DESTINATIONORG).
                     * setValue( finalDigit); } else if (!finalDigit.isEmpty()
                     * && validStr) { paymentRecordObj.getLocalRefField(
                     * BciVerCciDestinationValidate.CCI_DESTINATIONORG).
                     * setValue( finalDigit);
                     * paymentRecordObj.getLocalRefField("L.CP.CCI.DESTINATION")
                     * . setValue(finalDigit); }
                     */

                    boolean flgHis = false;
                    AccountRecord acctRecObj = new AccountRecord(this);
                    try {
                        acctRecObj = new AccountRecord(
                                this.daAccess.getRecord(this.finMne, "ACCOUNT", "", debitAccount));
                    } catch (Exception e) {
                        flgHis = true;
                    }

                    if (flgHis) {
                        try {
                            acctRecObj = new AccountRecord(
                                    this.daAccess.getRecord(this.finMne, "ACCOUNT", "$HIS", debitAccount));
                            throw new T24CoreException("", "CUENTA CERRADA");
                        } catch (T24CoreException e2) {
                            throw new T24CoreException("", "CUENTA NO EXISTENTE");
                        } catch (Exception ex) {
                            throw new T24CoreException("", "CUENTA NO EXISTENTE xd");
                        }
                    }

                    altAcctId = (List<AltAcctTypeClass>) acctRecObj.getAltAcctType();
                    for (int idx = 0; idx < altAcctId.size(); ++idx) {
                        final String acctType = altAcctId.get(idx).getAltAcctType().getValue();
                        altAcctTypeList.add(acctType);
                    }
                    final int typeIndex = altAcctTypeList.indexOf("CCI");
                    final String cciCode = acctRecObj.getAltAcctType(typeIndex).getAltAcctId().getValue();
                    paymentRecordObj.getLocalRefField("L.CCI.CODE.ORIG").setValue(cciCode);
                    currentRecord.set(paymentRecordObj.toStructure());
                }
            }
            if (application.equals("TELLER")) {
                BciVerCciDestinationValidate.CCI_DESTINATION = "L.CP.CCI.DESTINATION";
                tellerRecordObj = new TellerRecord(currentRecord);
                cciDest = tellerRecordObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION).getValue();
                tellerRecordObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATIONORG).setValue(cciDest);
                currentRecord.set(tellerRecordObj.toStructure());
                if (cciDest.length() == 16) {
                    officeEntityCde = cciDest.substring(0, 6);
                    ttAccountNo = cciDest.substring(6, 16);
                    officeEntDigit = this.cciUpdation.entityCalculation(officeEntityCde);
                    accountNoDigit = this.cciUpdation.entityCalculation(ttAccountNo);
                    finalDigit = String.valueOf(cciDest) + officeEntDigit + accountNoDigit;
                    tellerRecordObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATIONORG)
                            .setValue(finalDigit);
                    tellerRecordObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION).setValue(finalDigit);
                    currentRecord.set(tellerRecordObj.toStructure());
                }
            }
            if (application.equals("PP.ORDER.ENTRY")) {
                BciVerCciDestinationValidate.CCI_DESTINATION = BciVerCciDestinationValidate.CCI_DESTINATIONORG;
                ppOrderEntryObj = new PpOrderEntryRecord(currentRecord);
                debitAccount = ppOrderEntryObj.getDebitaccountnumber().getValue();
                cciDest = ppOrderEntryObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION).getValue();
                finalDigit = this.pPValidateCciDestination(cciDest, ppOrderEntryObj, currentRecord);
                final AccountRecord acctRecObj2 = new AccountRecord(
                        this.daAccess.getRecord(this.finMne, "ACCOUNT", "", debitAccount));
                altAcctId = (List<AltAcctTypeClass>) acctRecObj2.getAltAcctType();
                for (int idx2 = 0; idx2 < altAcctId.size(); ++idx2) {
                    final String acctType2 = altAcctId.get(idx2).getAltAcctType().getValue();
                    altAcctTypeList.add(acctType2);
                }
                final int typeIndex2 = altAcctTypeList.indexOf("CCI");
                final String cciCode2 = acctRecObj2.getAltAcctType(typeIndex2).getAltAcctId().getValue();
                ppOrderEntryObj.getLocalRefField("L.CCI.CODE.ORIG").setValue(cciCode2);
                currentRecord.set(ppOrderEntryObj.toStructure());
            }
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public String pPValidateCciDestination(final String cciDest, final PpOrderEntryRecord ppOrderEntryObj,
            final TStructure currentRecord) {
        String finalControlDigit = "";
        try {
            if (cciDest.length() == 18) {
                final String offEntCode = cciDest.substring(0, 6);
                final String offEntDigit = this.cciUpdation.entityCalculation(offEntCode);
                final String poAccountNumber = cciDest.substring(6, 18);
                final String accountDigit = this.cciUpdation.entityCalculation(poAccountNumber);
                finalControlDigit = String.valueOf(cciDest) + offEntDigit + accountDigit;
                ppOrderEntryObj.getLocalRefField(BciVerCciDestinationValidate.CCI_DESTINATION)
                        .setValue(finalControlDigit);
                currentRecord.set(ppOrderEntryObj.toStructure());
            }
        } catch (Exception e1) {
            e1.getMessage();
        }
        return finalControlDigit;
    }

    public String poValidateCciDestination(final String cciDest, final PaymentOrderRecord paymentRecordObj,
            final TStructure currentRecord, final boolean validStr) {
        String finalControlDigit = "";
        try {
            if (cciDest.length() == 20 && !validStr) {
                final String offEntCode = cciDest.substring(0, 6);
                final String offEntDigit = this.cciUpdation.entityCalculation(offEntCode);
                final String poAccountNumber = cciDest.substring(6, 18);
                final String accountDigit = this.cciUpdation.entityCalculation(poAccountNumber);
                finalControlDigit = offEntDigit + accountDigit;
            } else if (cciDest.length() == 16 && validStr) {
                final String officeEntityCde = cciDest.substring(0, 6);
                final String ttAccountNo = cciDest.substring(6, 16);
                final String officeEntDigit = this.cciUpdation.entityCalculation(officeEntityCde);
                final String accountNoDigit = this.cciUpdation.entityCalculation(ttAccountNo);
                finalControlDigit = String.valueOf(cciDest) + officeEntDigit + accountNoDigit;
            }
        } catch (Exception e1) {
            e1.getMessage();
        }
        return finalControlDigit;
    }
}
