
package com.bci;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.ftcommissiontype.CurrencyClass;
import com.temenos.t24.api.records.ftcommissiontype.FtCommissionTypeRecord;
import com.temenos.t24.api.records.paymentorder.ChargeTypeClass;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.paymentorderproduct.PaymentOrderProductRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.EbBciTrnsClgCommissionParamRecord;
import com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.PlaceTypeClass;
import com.temenos.tafj.api.client.impl.T24Context;

/*
 * @author malika.v
 * 
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Default the charge amount when charge type is CCECOMMISSION 
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : BRD 11 - Commissions
*Attached To            : VERSION>PAYMENT.ORDER,DOMESTIC.BCI & VERSION>PP.ORDER.ENTRY,BCI.CHQ.CLG
*Attached as            : Input Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/

public class BciVerChargeAmtDefault extends RecordLifecycle {
    public static final String CHARGE_TYPE = "CCECOMMISSION";
    public static final String COMM_AMT = "L.CCI.COMM.AMT";

    @Override
    public void defaultFieldValues(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        String transferType = "";
        String currency = "";
        String commissionParamId = "";
        String cciDestino = "";
        String bankCode = "";
        String amount = "";
        String typePlace = "";
        String rateCodeVal = "";
        Double chargeAmount = 0.0;
        Double minCommission = 0.0;
        Double maxCommission = 0.0;

        // po product
        String idChargeTypePo = "";
        final String versionName = transactionContext.getCurrentVersionId();
        String selCommissionId = "";
        final DataAccess daObj = new DataAccess((T24Context) this);
        final Session sessObj = new Session((T24Context) this);
        final String mnemonic = sessObj.getCompanyRecord().getMnemonic().getValue();
        List<Double> amountList = new ArrayList<Double>();
        final PpOrderEntryRecord ppOrderEntryObj = new PpOrderEntryRecord(currentRecord);
        final PaymentOrderRecord paymentOrderRecordObj = new PaymentOrderRecord(currentRecord);
        List<Double> roundoffVal = new ArrayList<Double>();
        // final Contract contract = new Contract((T24Context)this);
        ChargeTypeClass chargeClassFtCom = new ChargeTypeClass();

        try {
            if (paymentOrderRecordObj.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                if (versionName.equals(",BCI.CHQ.CLG")) {
                    transferType = "CHE";
                    currency = ppOrderEntryObj.getTransactioncurrency().getValue();
                    amount = ppOrderEntryObj.getTransactionamount().getValue();
                    cciDestino = ppOrderEntryObj.getLocalRefField("L.CCI.DESTINATION").getValue();
                    typePlace = ppOrderEntryObj.getLocalRefField("L.TYPE.PLACE").getValue();
                    bankCode = cciDestino.substring(0, 3);
                    commissionParamId = String.valueOf(transferType) + "." + currency + "." + bankCode;
                    selCommissionId = this.getCommissionId(commissionParamId, mnemonic, daObj);
                    rateCodeVal = selCommissionId.split("\\.")[3];
                    amountList = this.calculateChargeAmount(amount, typePlace, daObj, mnemonic, selCommissionId);
                    roundoffVal = this.roundOffAmount(amountList);
                    chargeAmount = roundoffVal.get(0);
                    maxCommission = roundoffVal.get(2);
                    minCommission = roundoffVal.get(1);
                    boolean chgFlag = false;
                    if (chargeAmount == 0.0) {
                        ppOrderEntryObj.getLocalRefField("L.CCI.COMM.AMT").setValue(minCommission.toString());
                        chgFlag = true;
                    }
                    if (minCommission == 0.0 && maxCommission == 0.0) {
                        ppOrderEntryObj.getLocalRefField("L.CCI.COMM.AMT").setValue(chargeAmount.toString());
                        chgFlag = true;
                    }
                    if (chargeAmount < minCommission && !chgFlag) {
                        ppOrderEntryObj.getLocalRefField("L.CCI.COMM.AMT").setValue(minCommission.toString());
                    } else if (chargeAmount > maxCommission && !chgFlag) {
                        ppOrderEntryObj.getLocalRefField("L.CCI.COMM.AMT").setValue(maxCommission.toString());
                    } else if (!chgFlag) {
                        ppOrderEntryObj.getLocalRefField("L.CCI.COMM.AMT").setValue(chargeAmount.toString());
                    }
                    ppOrderEntryObj.getLocalRefField("L.RATE.CODE").setValue(rateCodeVal);

                    currentRecord.set(ppOrderEntryObj.toStructure());
                } else {
                    transferType = paymentOrderRecordObj.getLocalRefField("L.TRANSFER.TYPE").getValue();
                    currency = paymentOrderRecordObj.getPaymentCurrency().getValue();
                    cciDestino = paymentOrderRecordObj.getLocalRefField("L.CCI.DESTINATION").getValue();
                    typePlace = paymentOrderRecordObj.getLocalRefField("L.TYPE.PLACE").getValue();
                    amount = paymentOrderRecordObj.getPaymentAmount().getValue();
                    bankCode = cciDestino.substring(0, 3);
                    commissionParamId = String.valueOf(transferType) + "." + currency + "." + bankCode;
                    selCommissionId = this.getCommissionId(commissionParamId, mnemonic, daObj);
                    rateCodeVal = selCommissionId.split("\\.")[3];
                    amountList = this.calculateChargeAmount(amount, typePlace, daObj, mnemonic, selCommissionId);
                    roundoffVal = this.roundOffAmount(amountList);
                    try {
                        DataAccess da = new DataAccess(this);
                        // final String chargeType =
                        // paymentOrderRecordObj.getChargeType(0).getChargeType().getValue();
                        // if (chargeType.isEmpty()) {
                        String idPoProd = paymentOrderRecordObj.getPaymentOrderProduct().getValue();
                        PaymentOrderProductRecord poProductRecord = new PaymentOrderProductRecord(
                                da.getRecord("PAYMENT.ORDER.PRODUCT", idPoProd));
                        try {
                            idChargeTypePo = poProductRecord.getChargeTypes(0).getChargeTypes().getValue();
                            FtCommissionTypeRecord ftRecord = new FtCommissionTypeRecord(
                                    da.getRecord("FT.COMMISSION.TYPE", idChargeTypePo));
                            String descripFtCom = ftRecord.getDescription(0).getValue();
                            List<CurrencyClass> lstCurrencyPoProd = ftRecord.getCurrency();
                            for (CurrencyClass currencyClass : lstCurrencyPoProd) {
                                String currencyStrPoProd = currencyClass.getCurrency().getValue();
                                String currPoOrg = paymentOrderRecordObj.getPaymentCurrency().getValue();
                                if (currencyStrPoProd.equals(currPoOrg)) {
                                    chargeClassFtCom = new ChargeTypeClass();
                                    String chargeAmFtCom = currencyClass.getFlatAmt().getValue();
                                    chargeClassFtCom.setChargeType(idChargeTypePo);
                                    chargeClassFtCom.setChargeDescription(descripFtCom);
                                    chargeClassFtCom.setChargeCurrency(currPoOrg);
                                    chargeClassFtCom.setChargeAmount(chargeAmFtCom);
                                    // chargeClassFtCom.setChargeAcCcyAmount(chargeAmFtCom);
                                }
                            }
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                        // }
                    } catch (Exception e) {

                    }

                    // if (!chargeType.isEmpty()) {
                    ChargeTypeClass chargeClass = new ChargeTypeClass();
                    chargeClass.setChargeType((CharSequence) "CCECOMMISSION");
                    chargeClass.setChargeDescription((CharSequence) "CCECOMMISSION");
                    chargeClass.setChargeCurrency((CharSequence) currency);
                    final PaymentOrderRecord paymentOrderRecordObj2 = this.chargeTypeDupRemove(paymentOrderRecordObj);
                    this.validatePOChargeAmt(chargeClass, roundoffVal, currentRecord, paymentOrderRecordObj2,
                            rateCodeVal, chargeClassFtCom);
                    // }
                }
            }
        } catch (Exception e) {
        }

    }

    public String getCommissionId(final String commissionParamId, final String mnemonic, final DataAccess daObj) {
        final List<String> selIds = (List<String>) daObj.selectRecords(mnemonic, "EB.BCI.TRNS.CLG.COMMISSION.PARAM", "",
                " WITH @ID LIKE " + commissionParamId + "...");
        String selCommissionId = "";
        if (selIds.size() == 1) {
            selCommissionId = selIds.get(0);
        }
        return selCommissionId;
    }

    public List<Double> roundOffAmount(final List<Double> amountList) {
        List<Double> amountListStr = new ArrayList<Double>();
        double strChargeAmount = 0.0;
        double strMaxCommission = 0.0;
        double strMinCommission = 0.0;
        try {
            final double dobChargeAmount = amountList.get(0);
            final double dobMaxCommission = amountList.get(1);
            final double dobMinCommission = amountList.get(2);
            amountListStr = new ArrayList<Double>();
            if (dobChargeAmount != 0.0) {
                strChargeAmount = BigDecimal.valueOf(dobChargeAmount).setScale(2, 4).doubleValue();
            }
            if (dobMaxCommission != 0.0) {
                strMaxCommission = BigDecimal.valueOf(dobMaxCommission).setScale(2, 4).doubleValue();
            }
            if (dobMinCommission != 0.0) {
                strMinCommission = BigDecimal.valueOf(dobMinCommission).setScale(2, 4).doubleValue();
            }
            amountListStr.add(strChargeAmount);
            amountListStr.add(strMinCommission);
            amountListStr.add(strMaxCommission);
        } catch (Exception e) {
            e.getMessage();
        }
        return amountListStr;
    }

    public PaymentOrderRecord chargeTypeDupRemove(final PaymentOrderRecord paymentOrderRecordObj) {
        final List<ChargeTypeClass> chrgTypeLst = (List<ChargeTypeClass>) paymentOrderRecordObj.getChargeType();
        try {
            for (int i = 0; i < chrgTypeLst.size(); ++i) {
                final ChargeTypeClass currChrgType = chrgTypeLst.get(i);
                final String currChrgTypeStr = currChrgType.getChargeType().getValue();
                if (currChrgTypeStr.equals("CCECOMMISSION")) {
                    paymentOrderRecordObj.removeChargeType(i);
                }
            }
        } catch (Exception e1) {
            e1.getMessage();
        }

        return paymentOrderRecordObj;
    }

    public void validatePOChargeAmt(final ChargeTypeClass chargeClass, final List<Double> roundOffVal,
            final TStructure currentRecord, final PaymentOrderRecord paymentOrderRecordObj2, final String rateCodeVal,
            final ChargeTypeClass chargeClassFtCom) {
        boolean chgFlag = false;
        final double chargeAmount = roundOffVal.get(0);
        final double maxCommission = roundOffVal.get(2);
        final double minCommission = roundOffVal.get(1);
        if (chargeAmount == 0.0) {
            chargeClass.setChargeAmount((CharSequence) String.valueOf(minCommission));
            chgFlag = true;
        }
        if (minCommission == 0.0 && maxCommission == 0.0) {
            chargeClass.setChargeAmount((CharSequence) String.valueOf(chargeAmount));
            chgFlag = true;
        }
        if (chargeAmount < minCommission && !chgFlag) {
            chargeClass.setChargeAmount((CharSequence) String.valueOf(minCommission));
        } else if (chargeAmount > maxCommission && !chgFlag) {
            chargeClass.setChargeAmount((CharSequence) String.valueOf(maxCommission));
        } else if (!chgFlag) {
            chargeClass.setChargeAmount((CharSequence) String.valueOf(chargeAmount));
        }

        paymentOrderRecordObj2.setChargeType(chargeClassFtCom, 0);
        paymentOrderRecordObj2.setChargeType(chargeClass, 1);

        BigDecimal totAmount = new BigDecimal(0);
        final List<ChargeTypeClass> listChargeTipe = (List<ChargeTypeClass>) paymentOrderRecordObj2.getChargeType();
        if (!listChargeTipe.isEmpty()) {
            for (final ChargeTypeClass chargeType : listChargeTipe) {
                try {
                    final String amount = chargeType.getChargeAmount().getValue();
                    totAmount = totAmount.add(new BigDecimal(amount));
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        }
        paymentOrderRecordObj2.getLocalRefField("L.TOTAL.COMMISSION").set(totAmount.toString());
        paymentOrderRecordObj2.getLocalRefField("L.RATE.CODE").setValue(rateCodeVal);
        currentRecord.set(paymentOrderRecordObj2.toStructure());
    }

    public List<Double> calculateChargeAmount(final String amount, final String typePlace, final DataAccess daObj,
            final String mnemonic, final String selCommissionId) {
        final List<Double> amountList = new ArrayList<Double>();
        try {
            final EbBciTrnsClgCommissionParamRecord trnsClgCommissionParamRecordObj = new EbBciTrnsClgCommissionParamRecord(
                    daObj.getRecord(mnemonic, "EB.BCI.TRNS.CLG.COMMISSION.PARAM", "", selCommissionId));
            final List<PlaceTypeClass> placeTypeClass = (List<PlaceTypeClass>) trnsClgCommissionParamRecordObj
                    .getPlaceType();
            String commTypePlace = "";
            for (int index = 0; index < placeTypeClass.size(); ++index) {
                commTypePlace = placeTypeClass.get(index).getPlaceType().getValue();
                if (commTypePlace.equals(typePlace)) {
                    final List<String> placeTypeList = this.getPlace(placeTypeClass);
                    final int placeTypeIndex = placeTypeList.indexOf(typePlace);
                    final Double maxCommission = Double
                            .parseDouble(placeTypeClass.get(placeTypeIndex).getMaxCommission().getValue());
                    final Double minCommission = Double
                            .parseDouble(placeTypeClass.get(placeTypeIndex).getMinCommission().getValue());
                    final Double percentage = Double
                            .parseDouble(placeTypeClass.get(placeTypeIndex).getCommPercentage().getValue());
                    final Double paymentAmount = Double.parseDouble(amount);
                    final Double chargeAmount = paymentAmount * percentage / 100.0;
                    amountList.add(chargeAmount);
                    amountList.add(maxCommission);
                    amountList.add(minCommission);
                }
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return amountList;
    }

    public List<String> getPlace(final List<PlaceTypeClass> placeTypeClass) {
        final List<String> typePlaceList = new ArrayList<String>();
        try {
            for (int placeTypeIndex = 0; placeTypeIndex < placeTypeClass.size(); ++placeTypeIndex) {
                final String typePlaceVal = placeTypeClass.get(placeTypeIndex).getPlaceType().getValue();
                typePlaceList.add(typePlaceVal);
            }
        } catch (Exception e1) {
            e1.getMessage();
        }
        return typePlaceList;
    }
}
