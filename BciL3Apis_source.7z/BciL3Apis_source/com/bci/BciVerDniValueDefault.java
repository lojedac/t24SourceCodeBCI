
package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.beneficiary.BeneficiaryRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.teller.TellerRecord;
/*
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Validate DNI Structure
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : Additional Fields - Cheque Clearing
*Attached To            : VERSION>TELLER,BCI.DIR.CHQ.CLG, TELLER,BCI.FOREIGN.CHQS,PAYMENT.ORDER,DOMESTIC.BCI
*                         VERSION>PP.ORDER.ENTRY,CCE.INWARD.TRANSFER.BCI
*                         VERSION>PP.ORDER.ENTRY,BCI.CTR.OUT.CREATE.NEW
*                         VERSION>PP.ORDER.ENTRY,BCI.CTR.OUT.CREATE.NEW
*                         VERSION>PP.ORDER.ENTRY,BCI.BTR.IN.CREATE.NEW
*                         VERSION>PP.ORDER.ENTRY,BCI.BTR.OUT.CREATE.NEW
*Attached as            : Default Routine/Input Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/
public class BciVerDniValueDefault extends RecordLifecycle {
    public static final String DOC_NUMBER = "L.DRAWER.DOC.NUMBER";
    public static final String DOC_NUMBER_CHK = "L.DNI.CHK";
    public static final String DOC_TYPE = "L.DRAWER.DOC.TYPE";
    public static final String TELLER_APP = "TELLER";
    public static final String PO_APP = "PAYMENT.ORDER";
    public static final String OE_APP = "PP.ORDER.ENTRY";
    public static final String SAME_OWNER = "L.SAME.OWNER";
    public static final String ERR_MSG = "Invalid DNI Id ";
    int constVal;
    TellerRecord tellerRecordObj;
    PaymentOrderRecord paymentOrderRecObj;
    PpOrderEntryRecord ppOrderEntryRecObj;
    BeneficiaryRecord beneficiaryRecObj;
    String dniId;
    String drawerDocType;
    String validateId;
    String extractVal;
    TValidationResponse respFlag;
    String lastDigit;
    String responseFlag;
    List<String> errMessage;
    String flag;

    public BciVerDniValueDefault() {
        this.constVal = 11;
        this.tellerRecordObj = null;
        this.paymentOrderRecObj = null;
        this.ppOrderEntryRecObj = null;
        this.beneficiaryRecObj = null;
        this.dniId = "";
        this.drawerDocType = "";
        this.validateId = "";
        this.extractVal = "";
        this.respFlag = null;
        this.lastDigit = "";
        this.responseFlag = "";
        this.errMessage = new ArrayList<String>();
        this.flag = "YES";
    }

    public void defaultFieldValues(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        try {
            String getVal = "";
            String dniId = "";
            String drawerDocType = "";
            if (application.equals("TELLER")) {
                this.tellerRecordObj = new TellerRecord(currentRecord);
                dniId = this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                drawerDocType = this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                getVal = this.validateDniTTStructure(dniId, drawerDocType, this.tellerRecordObj, currentRecord);
                this.tellerRecordObj.getLocalRefField("L.DNI.CHK").setValue(getVal);
                currentRecord.set(this.tellerRecordObj.toStructure());
            } else if (application.equals("PAYMENT.ORDER")) {
                this.paymentOrderRecObj = new PaymentOrderRecord(currentRecord);
                if (this.paymentOrderRecObj.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                    dniId = this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                    drawerDocType = this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                    getVal = this.validateDniPOStructure(dniId, drawerDocType, currentRecord);
                    this.paymentOrderRecObj.getLocalRefField("L.DNI.CHK").setValue(getVal);
                    currentRecord.set(this.paymentOrderRecObj.toStructure());
                }
            } else if (application.equals("PP.ORDER.ENTRY")) {
                this.ppOrderEntryRecObj = new PpOrderEntryRecord(currentRecord);
                dniId = this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                drawerDocType = this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                getVal = this.validateDniPPStructure(dniId, drawerDocType, this.ppOrderEntryRecObj, currentRecord);
                this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setValue(getVal);
                currentRecord.set(this.ppOrderEntryRecObj.toStructure());
            }
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public String validateDniPPStructure(final String dniId, final String drawerDocType,
            final PpOrderEntryRecord ppOrderEntryRecObj2, final TStructure currentRecord) {
        String dniIdPPExt = "";
        String dniPPId = "";
        try {
            dniIdPPExt = this.extractDniId(dniId, drawerDocType);
            dniPPId = String.valueOf(dniId) + dniIdPPExt;
        } catch (Exception e4) {
            e4.getMessage();
        }
        return dniPPId;
    }

    public String extractDniId(final String dniId, final String drawerDocType) {
        String idVal = "";
        if (dniId.length() == 8 && drawerDocType.equals("DN")) {
            idVal = this.dniDefault(dniId);
        }
        return idVal;
    }

    public String validateDniPOStructure(final String dniId, final String drawerDocType,
            final TStructure currentRecord) {
        String dniIdPoExt = "";
        try {
            dniIdPoExt = this.extractDniId(dniId, drawerDocType);
        } catch (Exception e3) {
            e3.getMessage();
        }
        return dniIdPoExt;
    }

    public String validateDniTTStructure(final String dniId, final String drawerDocType,
            final TellerRecord tellerRecordObj2, final TStructure currentRecord) {
        String dniIdTTExt = "";
        try {
            dniIdTTExt = this.extractDniId(dniId, drawerDocType);
        } catch (Exception e2) {
            e2.getMessage();
        }
        return dniIdTTExt;
    }

    public String dniDefault(final String dniId) {
        final int[] dniNumber = { 3, 2, 7, 6, 5, 4, 3, 2 };
        int remValue = 0;
        String finalDniNumber = "";
        try {
            final int getDniValue = this.getDniValueOperation(dniNumber, dniId);
            final int[] number = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
            final int[] numberSeries = { 6, 7, 8, 9, 0, 1, 1, 2, 3, 4, 5 };
            for (int index = 0; index < number.length; ++index) {
                if (getDniValue == number[index]) {
                    remValue = numberSeries[index];
                    finalDniNumber = String.valueOf(remValue);
                }
            }
        } catch (Exception e1) {
            e1.getMessage();
        }
        return finalDniNumber;
    }

    public int getDniValueOperation(final int[] dniNumber, final String dniId) {
        final String[] docNumber = dniId.split("");
        int sum = 0;
        int divValue = 0;
        int remValue = 0;
        try {
            for (int dniCnt = 0; dniCnt < docNumber.length; ++dniCnt) {
                final int mulValue = Integer.parseInt(docNumber[dniCnt]) * dniNumber[dniCnt];
                sum += mulValue;
            }
            divValue = sum % this.constVal;
            if (divValue != this.constVal) {
                remValue = this.constVal - divValue;
                ++remValue;
            } else {
                remValue = divValue;
            }
        } catch (Exception e3) {
            e3.getMessage();
        }
        return remValue;
    }

    public TValidationResponse validateRecord(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        TValidationResponse responseFlag = null;
        if (application.equals("TELLER")) {
            this.tellerRecordObj = new TellerRecord(currentRecord);
            this.dniId = this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
            this.drawerDocType = this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
            if (this.drawerDocType.equals("DN")) {
                responseFlag = this.validateTtDocumentType(this.dniId, this.drawerDocType);
            }
        } else if (application.equals("PAYMENT.ORDER")) {
            this.paymentOrderRecObj = new PaymentOrderRecord(currentRecord);
            if (this.paymentOrderRecObj.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                this.dniId = this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                this.drawerDocType = this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                if (this.drawerDocType.equals("DN")) {
                    responseFlag = this.validatePoDocumentType(this.dniId, this.drawerDocType);
                }
            }
        } else if (application.equals("PP.ORDER.ENTRY")) {
            this.ppOrderEntryRecObj = new PpOrderEntryRecord(currentRecord);
            this.dniId = this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
            this.drawerDocType = this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
            if (this.drawerDocType.equals("DN")) {
                responseFlag = this.validateOeDocumentType(this.dniId, this.drawerDocType);
            }
        } else if (application.equals("BENEFICIARY")) {
            this.beneficiaryRecObj = new BeneficiaryRecord(currentRecord);
            this.dniId = this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
            this.drawerDocType = this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
            if (drawerDocType.equals("DN")) {
                if (dniId.length() != 9) {
                    this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid length");
                    responseFlag = this.beneficiaryRecObj.getValidationResponse();
                    return responseFlag;
                }
                String getVal = this.validateDniPOStructure(this.dniId.substring(0, 8), this.drawerDocType,
                        currentRecord);
                try {
                    String lastVal = Character.toString(dniId.charAt(8));
                    if (!getVal.equals(lastVal)) {
                        this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid DNI Id");
                    }
                } catch (Exception e) {
                    this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid length");
                }
            }
            responseFlag = this.beneficiaryRecObj.getValidationResponse();
        }
        return responseFlag;
    }

    public TValidationResponse validateBenDocumentType(final String dniId2, final String drawerDocType2) {
        if ((dniId2.length() < 8 || dniId2.length() > 9) && drawerDocType2.equals("DN")) {
            this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid DNI Id ");
            this.respFlag = this.beneficiaryRecObj.getValidationResponse();
        } else if (dniId2.length() == 9) {
            this.lastDigit = this.validateDniId(dniId2);
            this.validateId = this.extractDniValue(dniId2);
            if (!this.lastDigit.equals(this.validateId)) {
                this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid DNI Id ");
                this.respFlag = this.beneficiaryRecObj.getValidationResponse();
            }
        }
        return this.respFlag;
    }

    public TValidationResponse validateOeDocumentType(final String dniId3, final String drawerDocType3) {
        if ((dniId3.length() < 8 || dniId3.length() > 9) && drawerDocType3.equals("DN")) {
            this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid DNI Id ");
            this.respFlag = this.ppOrderEntryRecObj.getValidationResponse();
        } else if (dniId3.length() == 9) {
            this.lastDigit = this.validateDniId(dniId3);
            this.validateId = this.extractDniValue(dniId3);
            if (!this.lastDigit.equals(this.validateId)) {
                this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid DNI Id ");
                this.respFlag = this.ppOrderEntryRecObj.getValidationResponse();
            }
        }
        return this.respFlag;
    }

    public TValidationResponse validatePoDocumentType(final String dniId2, final String drawerDocType2) {
        if ((dniId2.length() < 8 || dniId2.length() > 9) && drawerDocType2.equals("DN")) {
            this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid DNI Id ");
            this.respFlag = this.paymentOrderRecObj.getValidationResponse();
        } else if (dniId2.length() == 9) {
            this.lastDigit = this.validateDniId(dniId2);
            this.validateId = this.extractDniValue(dniId2);
            if (!this.lastDigit.equals(this.validateId)) {
                this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid DNI Id ");
                this.respFlag = this.paymentOrderRecObj.getValidationResponse();
            }
        }
        return this.respFlag;
    }

    public TValidationResponse validateTtDocumentType(final String dniId1, final String drawerDocType1) {
        if ((dniId1.length() < 8 || dniId1.length() > 9) && drawerDocType1.equals("DN")) {
            this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid DNI Id ");
            this.respFlag = this.tellerRecordObj.getValidationResponse();
        } else if (dniId1.length() == 9) {
            this.lastDigit = this.validateDniId(dniId1);
            this.validateId = this.extractDniValue(dniId1);
            if (!this.lastDigit.equals(this.validateId)) {
                this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError("Invalid DNI Id ");
                this.respFlag = this.tellerRecordObj.getValidationResponse();
            }
        }
        return this.respFlag;
    }

    public String extractDniValue(final String dniId) {
        final String idSubstring = dniId.substring(0, 8);
        final String idVal = this.dniDefault(idSubstring);
        return idVal;
    }

    public String validateDniId(final String dniId) {
        final char lastDigitValue = dniId.charAt(dniId.length() - 1);
        final String dniLastDigit = Character.toString(lastDigitValue);
        return dniLastDigit;
    }
}
