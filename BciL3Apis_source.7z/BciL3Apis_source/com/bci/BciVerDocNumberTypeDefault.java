
package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.beneficiary.BeneficiaryRecord;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.customer.LegalIdClass;
import com.temenos.t24.api.records.eblookup.EbLookupRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.teller.TellerRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebbcihdrawerdoctype.EbBciHDrawerDocTypeRecord;
import com.temenos.tafj.api.client.impl.T24Context;

/**
 * @author Mallika V
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 *         Description : Default the document number, type and beneficiary name
 *         when same owner is Yes Developed By : Mallika V, Techmill
 *         Technologies Development Reference : BRD-12/15 Addition Field Cheque
 *         Clearing and Interbank Transfer Attached To :
 *         VERSION>PAYMENT.ORDER,DOMESTIC.BCI, VERSION>TELLER,BCI.DIR.CHQ.CLG,
 *         VERSION>TELLER,BCI.FOREIGN.CHQS Attached As : Input Routine
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 *         M O D I F I C A T I O N S ***************************
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 *         Defect Reference Modified By Date of Change Change Details
 *         (RTC/TUT/PACS) (YYYY-MM-DD)
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 *         CR 386 Mallika V Included validation of Drawer document type based on
 *         length
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 */
public class BciVerDocNumberTypeDefault extends RecordLifecycle {
    public static final String SAME_OWNER = "L.SAME.OWNER";
    public static final String DOC_NUMBER = "L.DRAWER.DOC.NUMBER";
    public static final String DOC_TYPE = "L.DRAWER.DOC.TYPE";
    public static final String BENEFICIARY_NAME = "L.BENEFICIARY.NAME";
    PaymentOrderRecord paymentRec;
    TellerRecord tellerRecord;
    PpOrderEntryRecord ppOrderEntry;
    TValidationResponse flag;
    BeneficiaryRecord beneficiaryRecObj;

    public BciVerDocNumberTypeDefault() {
        this.paymentRec = null;
        this.tellerRecord = null;
        this.ppOrderEntry = null;
        this.beneficiaryRecObj = null;
    }

    public void defaultFieldValues(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        final DataAccess daObj = new DataAccess((T24Context) this);
        final Session sessObj = new Session((T24Context) this);
        try {
            String debitAccount = "";
            String sameOwner = "";
            final String mnemonic = sessObj.getCompanyRecord().getMnemonic().getValue();
            if (application.equals("PAYMENT.ORDER")) {
                this.paymentRec = new PaymentOrderRecord(currentRecord);
                if (this.paymentRec.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                    sameOwner = this.paymentRec.getLocalRefField("L.SAME.OWNER").getValue();
                    if (sameOwner.equals("YES")) {
                        debitAccount = this.paymentRec.getDebitAccount().getValue();
                        this.getLegalIdDetails(debitAccount, mnemonic, daObj, application, currentRecord);
                    }
                }
            }
            if (application.equals("TELLER")) {
                this.tellerRecord = new TellerRecord(currentRecord);
                sameOwner = this.tellerRecord.getLocalRefField("L.SAME.OWNER").getValue();
                if (sameOwner.equals("YES")) {
                    debitAccount = this.tellerRecord.getAccount2().getValue();
                    this.getLegalIdDetails(debitAccount, mnemonic, daObj, application, currentRecord);
                }
            }
            if (application.equals("PP.ORDER.ENTRY")) {
                this.ppOrderEntry = new PpOrderEntryRecord(currentRecord);
                sameOwner = this.ppOrderEntry.getLocalRefField("L.SAME.OWNER").getValue();
                if (sameOwner.equals("YES")) {
                    debitAccount = this.ppOrderEntry.getDebitaccountnumber().getValue();
                    this.getLegalIdDetails(debitAccount, mnemonic, daObj, application, currentRecord);
                }
            }
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public void getLegalIdDetails(final String debitAccount, final String mnemonic, final DataAccess daObj,
            final String application, final TStructure currentRecord) {
        List<String> txnIds = new ArrayList<String>();
        try {
            final AccountRecord acctRec = new AccountRecord(daObj.getRecord(mnemonic, "ACCOUNT", "", debitAccount));
            final String customerId = acctRec.getCustomer().getValue();
            final CustomerRecord custRec = new CustomerRecord(daObj.getRecord("CUSTOMER", customerId));
            final String ownerName = custRec.getName1(0).getValue();
            final List<LegalIdClass> legalIdlist = (List<LegalIdClass>) custRec.getLegalId();
            final String legalId = legalIdlist.get(0).getLegalId().getValue();
            final String legalDocName = legalIdlist.get(0).getLegalDocName().getValue();
            final String drawerDocName = this.getEbLookupName(daObj, legalDocName);
            txnIds = (List<String>) daObj.selectRecords(mnemonic, "EB.BCI.H.DRAWER.DOC.TYPE", "", "");
            for (int idx = 0; idx < txnIds.size(); ++idx) {
                final String docId = txnIds.get(idx);
                final EbBciHDrawerDocTypeRecord ebbcidrawerRec = new EbBciHDrawerDocTypeRecord(
                        daObj.getRecord(mnemonic, "EB.BCI.H.DRAWER.DOC.TYPE", "", docId));
                final String description = ebbcidrawerRec.getDocTypeDescription().getValue();
                final String drawerName = this.getEbLookupName(daObj, description);
                if (drawerName.equalsIgnoreCase(drawerDocName)) {
                    this.defaultDrawerDetails(ownerName, legalId, docId, application, currentRecord);
                }
            }
        } catch (Exception e1) {
            e1.getMessage();
        }
    }

    public String getEbLookupName(final DataAccess daObj, final String lookupId) {
        String drawerDocumnetName = "";
        try {
            final String lookupIdVal = "CUS.LEGAL.DOC.NAME*" + lookupId;
            final EbLookupRecord eblookupRec = new EbLookupRecord(daObj.getRecord("EB.LOOKUP", lookupIdVal));
            drawerDocumnetName = eblookupRec.getDescription(0).getValue();
        } catch (Exception e1) {
            e1.getMessage();
            e1.printStackTrace();
        }
        return drawerDocumnetName;
    }

    public void defaultDrawerDetails(final String ownerName, final String legalId, final String docId,
            final String application, final TStructure currentRecord) {
        if (application.equals("TELLER")) {
            this.tellerRecord.getLocalRefField("L.DRAWER.DOC.NUMBER").setValue(legalId);
            this.tellerRecord.getLocalRefField("L.DRAWER.DOC.TYPE").setValue(docId);
            this.tellerRecord.getLocalRefField("L.BENEFICIARY.NAME").setValue(ownerName);
            currentRecord.set(this.tellerRecord.toStructure());
        }
        if (application.equals("PAYMENT.ORDER")) {
            this.paymentRec.getLocalRefField("L.DRAWER.DOC.NUMBER").setValue(legalId);
            this.paymentRec.getLocalRefField("L.DRAWER.DOC.TYPE").setValue(docId);
            this.paymentRec.setBeneficiaryName((CharSequence) ownerName);
            currentRecord.set(this.paymentRec.toStructure());
        }
        if (application.equals("PP.ORDER.ENTRY")) {
            this.ppOrderEntry.getLocalRefField("L.DRAWER.DOC.NUMBER").setValue(legalId);
            this.ppOrderEntry.getLocalRefField("L.DRAWER.DOC.TYPE").setValue(docId);
            this.ppOrderEntry.setBeneficiaryname((CharSequence) ownerName);
            currentRecord.set(this.ppOrderEntry.toStructure());
        }
    }

    public TValidationResponse validateRecord(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        String drawerDocNumber = "";
        String drawerDocType = "";
        String docNoErrMessage = "";
        try {
            if (application.equals("PAYMENT.ORDER")) {
                this.paymentRec = new PaymentOrderRecord(currentRecord);
                if (this.paymentRec.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                    drawerDocType = this.paymentRec.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                    drawerDocNumber = this.paymentRec.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                    docNoErrMessage = this.validateDocumentType(drawerDocType, drawerDocNumber);
                    this.paymentRec.getLocalRefField("L.DRAWER.DOC.NUMBER").setError(docNoErrMessage.toString());
                    this.flag = this.paymentRec.getValidationResponse();
                }
            } else if (application.equals("TELLER")) {
                this.tellerRecord = new TellerRecord(currentRecord);
                drawerDocType = this.tellerRecord.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                drawerDocNumber = this.tellerRecord.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                docNoErrMessage = this.validateDocumentType(drawerDocType, drawerDocNumber);
                this.tellerRecord.getLocalRefField("L.DRAWER.DOC.NUMBER").setError(docNoErrMessage.toString());
                this.flag = this.tellerRecord.getValidationResponse();
            } else if (application.equals("PP.ORDER.ENTRY")) {
                this.ppOrderEntry = new PpOrderEntryRecord(currentRecord);
                drawerDocType = this.ppOrderEntry.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                drawerDocNumber = this.ppOrderEntry.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                docNoErrMessage = this.validateDocumentType(drawerDocType, drawerDocNumber);
                this.ppOrderEntry.getLocalRefField("L.DRAWER.DOC.NUMBER").setError(docNoErrMessage.toString());
                this.flag = this.ppOrderEntry.getValidationResponse();
            } else if (application.equals("BENEFICIARY")) {
                this.beneficiaryRecObj = new BeneficiaryRecord(currentRecord);
                drawerDocType = this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                drawerDocNumber = this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                docNoErrMessage = this.validateDocumentType(drawerDocType, drawerDocNumber);
                this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError(docNoErrMessage.toString());
                this.flag = this.beneficiaryRecObj.getValidationResponse();
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return this.flag;
    }

    public String validateDocumentType(final String drawerDocType, final String drawerDocNumber) {
        String errMessage = "";
        try {
            if (drawerDocType.equals("LE") && drawerDocNumber.length() != 8) {
                errMessage = this.setErrorMessage(drawerDocType);
            } else if (drawerDocType.equals("LM") && drawerDocNumber.length() != 8) {
                errMessage = this.setErrorMessage(drawerDocType);
            } else if (drawerDocType.equals("CE") && drawerDocNumber.length() > 12) {
                errMessage = this.setErrorMessage(drawerDocType);
            } else if (drawerDocType.equals("PA") && drawerDocNumber.length() > 12) {
                errMessage = this.setErrorMessage(drawerDocType);
            }
        } catch (Exception e1) {
            e1.getMessage();
        }
        return errMessage;
    }

    public String setErrorMessage(final String drawerDocType) {
        String docNoError = "";
        try {
            docNoError = "Invalid " + drawerDocType + " Id";
        } catch (Exception e3) {
            e3.getMessage();
        }
        return docNoError;
    }
}
