
package com.bci;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.beneficiary.BeneficiaryRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.teller.TellerRecord;

/**
 * @author Mallika V
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 *         Description : Validate the drawer document number and raise error
 *         when it has consecutive zeros Developed By : Mallika V, Techmill
 *         Technologies Development Reference : BRD-12/15 Addition Field Cheque
 *         Clearing and Interbank Transfer Attached To :
 *         VERSION>PAYMENT.ORDER,DOMESTIC.BCI, VERSION>TELLER,BCI.DIR.CHQ.CLG,
 *         VERSION>TELLER,BCI.FOREIGN.CHQS Attached As : Input Routine
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 *         M O D I F I C A T I O N S ***************************
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 *         Defect Reference Modified By Date of Change Change Details
 *         (RTC/TUT/PACS) (YYYY-MM-DD)
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 *         CR 389 Mallika V Validation of Beneficiary document Number
 *         ------------------------------------------------------------------------------------------------------------------------------------------------
 */
public class BciVerDocNumberValidate extends RecordLifecycle {
    public static final String DOC_NUMBER = "L.DRAWER.DOC.NUMBER";
    public static final String DOC_TYPE = "L.DRAWER.DOC.TYPE";

    public TValidationResponse validateRecord(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        String documentNo = "";
        String drawerDocType = "";
        String addVal = "";
        String errMessage = "";
        TValidationResponse respFlag = null;
        PaymentOrderRecord paymentOrderRecObj = null;
        try {
            if (application.equals("TELLER")) {
                final TellerRecord tellerRecordObj = new TellerRecord(currentRecord);
                documentNo = tellerRecordObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                drawerDocType = tellerRecordObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                addVal = this.validateDocumentNumber(drawerDocType, documentNo);
                errMessage = this.getErrMessage(addVal, drawerDocType);
                tellerRecordObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError(errMessage);
                respFlag = tellerRecordObj.getValidationResponse();
            } else if (application.equals("PAYMENT.ORDER")) {
                paymentOrderRecObj = new PaymentOrderRecord(currentRecord);
                if (paymentOrderRecObj.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                    documentNo = paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                    drawerDocType = paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                    addVal = this.validateDocumentNumber(drawerDocType, documentNo);
                    errMessage = this.getErrMessage(addVal, drawerDocType);
                    paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError(errMessage);
                    respFlag = paymentOrderRecObj.getValidationResponse();
                }
            } else if (application.equals("PP.ORDER.ENTRY")) {
                final PpOrderEntryRecord ppOrderEntryRecObj = new PpOrderEntryRecord(currentRecord);
                documentNo = ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                drawerDocType = ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                addVal = this.validateDocumentNumber(drawerDocType, documentNo);
                errMessage = this.getErrMessage(addVal, drawerDocType);
                ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError(errMessage);
                respFlag = ppOrderEntryRecObj.getValidationResponse();
            } else if (application.equals("BENEFICIARY")) {
                final BeneficiaryRecord beneficiaryRecObj = new BeneficiaryRecord(currentRecord);
                documentNo = beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                drawerDocType = beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                addVal = this.validateDocumentNumber(drawerDocType, documentNo);
                errMessage = this.getErrMessage(addVal, drawerDocType);
                beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").setError(errMessage);
                respFlag = beneficiaryRecObj.getValidationResponse();
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return respFlag;
    }

    public String getErrMessage(final String addVal, final String drawerDocType) {
        String errMessageDoc = "";
        String drawerdocTypeNew = "";
        try {
            if (addVal.equals("0")) {
                drawerdocTypeNew = this.validateDrawerDocType(drawerDocType);
                errMessageDoc = "Invalid " + drawerdocTypeNew + " Id";
            }
        } catch (Exception e2) {
            e2.getMessage();
        }
        return errMessageDoc;
    }

    public String validateDrawerDocType(final String drawerDocType) {
        String drawerDocVal = "";
        if (drawerDocType.equals("RU")) {
            drawerDocVal = "RUC";
        } else if (drawerDocType.equals("DN")) {
            drawerDocVal = "DNI";
        } else {
            drawerDocVal = drawerDocType;
        }
        return drawerDocVal;
    }

    public String validateDocumentNumber(final String drawerDocType, final String documentNo) {
        int sum = 0;
        try {
            final String[] addValue = documentNo.split("");
            for (int index = 0; index < addValue.length; ++index) {
                final String sumVal = addValue[index];
                final int sum2 = Integer.parseInt(sumVal);
                sum += sum2;
            }
        } catch (Exception e1) {
            e1.getMessage();
        }
        return String.valueOf(sum);
    }
}
