
package com.bci;

import com.temenos.api.exceptions.T24CoreException;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
/*
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Validate the ID of the Local Table 
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : Additional Fields - Cheque Clearing
*Attached To            : EB.TABLE.PROCEDURES>EB.BCI.H.DRAWER.DOC.TYPE
*Attached as            : ID Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/
public class BciVerDrawerTypeIdCheck extends RecordLifecycle
{
    public String checkId(final String currentRecordId, final TransactionContext transactionContext) {
        if (currentRecordId.length() != 2) {
            throw new T24CoreException("", "EB-INVALID.ID");
        }
        return currentRecordId;
    }
}
