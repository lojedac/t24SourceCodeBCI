
package com.bci;

import com.temenos.t24.api.tables.ebbcicceparticipantsbankname.EbBciCceParticipantsBankNameRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.teller.TellerRecord;
import com.temenos.t24.api.system.Session;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;
/*
* @author malika.v 
* 
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Default the Field Value L.NAMEDRWN.BNK with Bank Name of BCI.CCE.PARTICIPANT.DIR
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : Additional Fields - Cheque Clearing
*Attached To            : VERSION>TELLER,BCI.DIR.CHQ.CLG, TELLER,BCI.FOREIGN.CHQS
*Attached as            : Check Record Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/  
public class BciVerDrwnBankNameDefault extends RecordLifecycle
{
    public static String CCI_DESTINATION;
    public static final String DRAWN_BANK = "L.NAME.DRAWN.BNK";
    public static final String CCI_ORIG = "L.CCI.CODE.ORIG";
    public static final String SENDER_INST = "L.SENDER.INSTITUTE";
    
    static {
        BciVerDrwnBankNameDefault.CCI_DESTINATION = "L.CCI.DESTINATION";
    }
    
    public void defaultFieldValues(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final DataAccess daAccess = new DataAccess((T24Context)this);
        final Session session = new Session((T24Context)this);
        TStructure recordObj = null;
        String destinationCCI = "";
        String destinationCCICP = "";
        String bnkName = "";
        try {
            final String finMne = session.getCompanyRecord().getFinancialMne().getValue();
            if (application.equals("TELLER")) {
                final TellerRecord tellerRecordObj = new TellerRecord(currentRecord);
                destinationCCI = tellerRecordObj.getLocalRefField(BciVerDrwnBankNameDefault.CCI_DESTINATION).getValue();
                destinationCCICP = tellerRecordObj.getLocalRefField("L.CP.CCI.DESTINATION").getValue();
                if (destinationCCI.isEmpty() && !destinationCCICP.isEmpty()) {
                    destinationCCI = tellerRecordObj.getLocalRefField("L.CP.CCI.DESTINATION").getValue();
                }
                if (!destinationCCI.isEmpty()) {
                    bnkName = this.getBankName(destinationCCI, daAccess, finMne);
                }
                tellerRecordObj.getLocalRefField("L.NAME.DRAWN.BNK").setValue(bnkName);
                recordObj = tellerRecordObj.toStructure();
            }
            else if (application.equals("PAYMENT.ORDER")) {
                final PaymentOrderRecord paymentOrderRecObj = new PaymentOrderRecord(currentRecord);
                destinationCCI = paymentOrderRecObj.getLocalRefField(BciVerDrwnBankNameDefault.CCI_DESTINATION).getValue();
                destinationCCICP = paymentOrderRecObj.getLocalRefField("L.CP.CCI.DESTINATION").getValue();
                if (destinationCCI.isEmpty() && !destinationCCICP.isEmpty()) {
                    destinationCCI = paymentOrderRecObj.getLocalRefField("L.CP.CCI.DESTINATION").getValue();
                }
                if (!destinationCCI.isEmpty()) {
                    bnkName = this.getBankName(destinationCCI, daAccess, finMne);
                }
                paymentOrderRecObj.getLocalRefField("L.NAME.DRAWN.BNK").setValue(bnkName);
                recordObj = paymentOrderRecObj.toStructure();
            }
            else if (application.equals("PP.ORDER.ENTRY")) {
                final PpOrderEntryRecord ppOrderEntryObj = new PpOrderEntryRecord(currentRecord);
                destinationCCI = ppOrderEntryObj.getLocalRefField("L.CCI.CODE.ORIG").getValue();
                if (!destinationCCI.isEmpty()) {
                    bnkName = this.getBankName(destinationCCI, daAccess, finMne);
                }
                ppOrderEntryObj.getLocalRefField("L.SENDER.INSTITUTE").setValue(bnkName);
                recordObj = ppOrderEntryObj.toStructure();
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        currentRecord.set(recordObj);
    }
    
    public String getBankName(final String destinationCCI, final DataAccess daAccess, final String finMne) {
        String bankName = "";
        if (!destinationCCI.isEmpty() && destinationCCI.length() >= 8) {
            final String cciDirId = destinationCCI.substring(0, 8);
            final String bankNameId = cciDirId.substring(0, 3);
            try {
                final EbBciCceParticipantsBankNameRecord cceParticipantRecordObj = new EbBciCceParticipantsBankNameRecord(daAccess.getRecord(finMne, "EB.BCI.CCE.PARTICIPANTS.BANK.NAME", "", bankNameId));
                bankName = cceParticipantRecordObj.getBankName().getValue();
            }
            catch (Exception e) {
                e.getMessage();
            }
        }
        return bankName;
    }
}
