
package com.bci;

import com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.PlaceTypeClass;
import java.util.List;
import com.temenos.t24.api.tables.ebbcihccecommaxlimitparam.EbBciHCceComMaxLimitParamRecord;
import com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.EbBciTrnsClgCommissionParamRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/*
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Raise Error when user inputs EXCLUSIVE.PLACE for Cheques
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : BRD11 - Commissions
*Attached To            : EB.TABLE.PROCEDURES>EB.BCI.TRNS.CLG.COMMISSION.PARAM , EB.TABLE.PROCEDURES>EB.BCI.H.CCE.COM.MAX.LIMIT.PARAM
*Attached as            : Default/Input Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/

public class BciVerExclusivePlaceValidate extends RecordLifecycle
{
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        TValidationResponse exclusiveFlag = null;
        try {
            final String transId = currentRecordId;
            final String[] splitArray = transId.split("\\.");
            final String commissionType = splitArray[0];
            String typePlace = "";
            if (commissionType.equals("CHE")) {
                final EbBciTrnsClgCommissionParamRecord trnsClgCommissionRecord = new EbBciTrnsClgCommissionParamRecord(currentRecord);
                final List<PlaceTypeClass> transPlaceTypeList = (List<PlaceTypeClass>)trnsClgCommissionRecord.getPlaceType();
                for (int index = 0; index < transPlaceTypeList.size(); ++index) {
                    typePlace = trnsClgCommissionRecord.getPlaceType(index).getPlaceType().getValue();
                    if (typePlace.equals("EXCLUSIVE.PLACE")) {
                        trnsClgCommissionRecord.getPlaceType(index).getPlaceType().setError("EB-BCI.INVALID.TYPE.PLACE");
                        exclusiveFlag = trnsClgCommissionRecord.getValidationResponse();
                    }
                }
            }
            else if (currentRecordId.equals("SYSTEM")) {
                final EbBciHCceComMaxLimitParamRecord comMaxLimitRecordObj = new EbBciHCceComMaxLimitParamRecord(currentRecord);
                final List<com.temenos.t24.api.tables.ebbcihccecommaxlimitparam.PlaceTypeClass> comTypePlaceList = (List<com.temenos.t24.api.tables.ebbcihccecommaxlimitparam.PlaceTypeClass>)comMaxLimitRecordObj.getPlaceType();
                for (int index2 = 0; index2 < comTypePlaceList.size(); ++index2) {
                    typePlace = comMaxLimitRecordObj.getPlaceType(index2).getPlaceType().getValue();
                    if (typePlace.equals("EXCLUSIVE.PLACE")) {
                        comMaxLimitRecordObj.getPlaceType(index2).getPlaceType().setError("EB-BCI.INVALID.TYPE.PLACE");
                        exclusiveFlag = comMaxLimitRecordObj.getValidationResponse();
                    }
                }
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        return exclusiveFlag;
    }
}
