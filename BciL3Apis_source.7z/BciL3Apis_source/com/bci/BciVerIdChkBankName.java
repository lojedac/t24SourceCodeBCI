
package com.bci;

import java.util.Iterator;
import java.util.List;
import com.temenos.api.exceptions.T24CoreException;
import com.temenos.api.exceptions.T24IOException;
import java.util.ArrayList;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.tables.ebbcihcceparticipantdir.EbBciHCceParticipantDirTable;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
*
*@author Kalaipriya.M
*----------------------------------------------------------------------------------------------------------------
* Description           : Validate the ID of the table EB.BCI.CCE.PARTICIPANTS.BANK.NAME
* Developed By          : Kalaipriya M,Techmill Technologies     
* Development Reference : BRD-010-Information_CCE Charge_Participanting_Entities
* Attached To           : EB.TABLE.PROCEDURES>EB.BCI.CCE.PARTICIPANTS.BANK.NAME  
* Attached As           : ID Routine  
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/

public class BciVerIdChkBankName extends RecordLifecycle
{
    public String checkId(final String currentRecordId, final TransactionContext transactionContext) {
        if (!currentRecordId.equals("")) {
            final EbBciHCceParticipantDirTable bciCcePartDirTable = new EbBciHCceParticipantDirTable((T24Context)this);
            final List<String> numList = new ArrayList<String>();
            List<String> recIdsList = new ArrayList<String>();
            try {
                recIdsList = (List<String>)bciCcePartDirTable.select();
            }
            catch (T24IOException exception) {
                exception.getMessage();
            }
            for (final String recID : recIdsList) {
                numList.add(recID.substring(2, 5));
            }
            if (numList.indexOf(currentRecordId) == -1) {
                throw new T24CoreException("", "EB-BCI.ID.NOT.MATCH.WITH.CCE");
            }
        }
        return currentRecordId;
    }
}
