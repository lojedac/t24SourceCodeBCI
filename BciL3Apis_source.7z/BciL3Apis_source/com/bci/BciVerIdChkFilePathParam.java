
package com.bci;

import com.temenos.api.exceptions.T24CoreException;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
*
* @author Kalaipriya.M
* 
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description           : Validate the ID of the table EB.BCI.H.CCE.PART.FILE.PATH.PARAM
*Developed By          : Kalaipriya M, Techmill Technologies
*Development Reference : BRD-010-Information_CCE Charge_Participanting_Entities
*Attached To           : EB.TABLE.PROCEDURES>EB.BCI.H.CCE.PART.FILE.PATH.PARAM
*Attached as           : ID Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************        
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*   
*/ 

public class BciVerIdChkFilePathParam extends RecordLifecycle
{
    public String checkId(final String currentRecordId, final TransactionContext transactionContext) {
        if (!currentRecordId.equals("SYSTEM")) {
            throw new T24CoreException("", "EB-BCI.ID.SHOULD.BE.SYSTEM");
        }
        return currentRecordId;
    }
}
