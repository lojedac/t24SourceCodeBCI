package com.bci;

import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.api.TStructure;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;

/*
*
* @author malika.v
*
*-----------------------------------------------------------------------------------------------------------------------------------------------------
*Description     		: Default the CCI Code to ALTERNATE.ID when ALT.TYPE is legacy based on ACCOUNT.REFERENCE in AA.ARR.ACCOUNT
 *                        and OFFICE.CODE, ENTITY.CODE in COMPANY
*Developed By	  		: Mallika V, Techmill Technologies
*Development Reference  : CCI Code Generation 
*Attached To     		: AA.PRD.DES.ACTIVITY.API>GROUP.SUB.API-20210503   
*Attached as     		: Pre Validation Routine
*-----------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-----------------------------------------------------------------------------------------------------------------------------------------------------
* Mantis 209             Parthiban B                    2021-09-17            Changed the logic of calculating finalControDigit for totalValue 0 to 9
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------------------------------------------
*
*/
public class BciVerInpCciUpdation extends ActivityLifecycle
{
    public void defaultFieldValues(final AaAccountDetailsRecord accountDetailRecord, final AaArrangementActivityRecord arrangementActivityRecord, final ArrangementContext arrangementContext, final AaArrangementRecord arrangementRecord, final AaArrangementActivityRecord masterActivityRecord, final TStructure productPropertyRecord, final AaProductCatalogRecord productRecord, final TStructure record) {
        final AaPrdDesAccountRecord accountRecObj = new AaPrdDesAccountRecord(record);
        String officeCode = "";
        String entityCode = "";
        String accountRef = "";
        try {
            final Session sessObj = new Session((T24Context)this);
            String accountNumber = "";
            officeCode = sessObj.getCompanyRecord().getLocalRefField("L.OFFICE.CODE").getValue();
            entityCode = sessObj.getCompanyRecord().getLocalRefField("L.ENTITY.CODE").getValue();
            if (!officeCode.isEmpty() && !entityCode.isEmpty()) {
                accountRef = accountRecObj.getAccountReference().getValue();
                final int lenAccount = accountRef.length();
                if (lenAccount == 10) {
                    accountNumber = accountRef;
                }
                else {
                    accountNumber = String.format("%010d", Integer.parseInt(accountRef));
                }
                final String altIdType = accountRecObj.getAltIdType(0).getAltIdType().getValue();
                final String entityOfficeCode = String.valueOf(entityCode) + officeCode;
                final String controlDigit1 = this.entityCalculation(entityOfficeCode);
                final String controlDigit2 = this.entityCalculation(accountNumber);
                final String finalValue = String.valueOf(entityCode) + officeCode + accountNumber + controlDigit1 + controlDigit2;
                if (altIdType.equals("LEGACY") && finalValue.length() == 18) {
                    accountRecObj.getAltIdType(0).getAltId().setValue(finalValue);
                }
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        record.set(accountRecObj.toStructure());
    }
    
    public String entityCalculation(final String args) {
        int pos = 0;
        int mpos = 0;
        int argValue = 0;
        int totalValue = 0;
        int number = 0;
        int checkDigValue = 0;
        for (int i = 0; i < args.length(); ++i) {
            pos = i + 1;
            mpos = pos % 2;
            number = Integer.parseInt(args.substring(i, i + 1));
            if (mpos == 1) {
                argValue = number * 1;
                checkDigValue = this.valCheckDigit(argValue);
            }
            else {
                argValue = number * 2;
                checkDigValue = this.valCheckDigit(argValue);
            }
            totalValue += checkDigValue;
        }
        int finalControDigit = 0;
        if (String.valueOf(totalValue).length() == 1) {
            if (totalValue == 0) {
                finalControDigit = totalValue;
            }
            else {
                finalControDigit = 10 - totalValue;
            }
        }
        else {
            final int totalFirstDigit = this.firstDigit(totalValue);
            final int totalSecodDigit = this.secondDigit(totalValue);
            if (totalSecodDigit == 0) {
                finalControDigit = Math.subtractExact(totalValue, totalValue);
            }
            else {
                finalControDigit = totalFirstDigit + 1;
                final String appendValue = String.valueOf(finalControDigit) + "0";
                finalControDigit = Integer.parseInt(appendValue) - totalValue;
            }
        }
        return String.valueOf(finalControDigit);
    }
    
    public int valCheckDigit(final int argValue) {
        int checkVal = 0;
        final int firstDigitVal = this.firstDigit(argValue);
        final int secondDigitVal = this.secondDigit(argValue);
        if (String.valueOf(argValue).length() == 2) {
            checkVal = firstDigitVal + secondDigitVal;
        }
        else {
            checkVal = argValue;
        }
        return checkVal;
    }
    
    public int firstDigit(final int argValue) {
        final char firstDigit = String.valueOf(argValue).charAt(0);
        return Integer.parseInt(String.valueOf(firstDigit));
    }
    
    public int secondDigit(final int argValue) {
        return argValue % 10;
    }
}
