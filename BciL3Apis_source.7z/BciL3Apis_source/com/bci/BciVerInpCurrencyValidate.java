
package com.bci;

import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;
/**
* @author Mallika V
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Validate the debit currency and payment currency in payment order
* Developed By          : Mallika V, Techmill Technologies  
* Development Reference : BRD-12/15 Additional Field Interbank Transfer
* Attached To           : VERSION>PAYMENT.ORDER,DOMESTIC.BCI, VERSION>TELLER,BCI.DIR.CHQ.CLG, VERSION>TELLER,BCI.FOREIGN.CHQS
* Attached As           : Input Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciVerInpCurrencyValidate extends RecordLifecycle
{
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final PaymentOrderRecord paymentRecord = new PaymentOrderRecord(currentRecord);
        try {
            final String debitCurrency = paymentRecord.getDebitCcy().getValue();
            final String paymentCurrency = paymentRecord.getPaymentCurrency().getValue();
            if (!debitCurrency.equals(paymentCurrency)) {
                paymentRecord.getPaymentCurrency().setError("EB-BCI.INVALID.PAYMENT.CURRENCY");
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        return paymentRecord.getValidationResponse();
    }
}
