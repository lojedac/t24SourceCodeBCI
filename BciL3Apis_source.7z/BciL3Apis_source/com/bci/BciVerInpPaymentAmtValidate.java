
package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebbciccelimitclearingparam.CurrencyClass;
import com.temenos.t24.api.tables.ebbciccelimitclearingparam.EbBciCceLimitClearingParamRecord;
import com.temenos.t24.api.tables.ebbciccelimitclearingparam.PaymentOrderProductClass;
import com.temenos.t24.api.tables.ebbciccelimitclearingparam.TransTypeClass;
import com.temenos.tafj.api.client.impl.T24Context;

/**
* @author Mallika V
*------------------------------------------------------------------------------------------------------------------------------------------------
* Description           : Validate the payment amount against the table EB.BCI.LIMIT.CCE.CLEARING.PARAM
* Developed By          : Mallika V, Techmill Technologies  
* Development Reference : BRD-12/15 Addition Field Cheque Clearing and Interbank Transfer
* Attached To           : VERSION>PAYMENT.ORDER,DOMESTIC.BCI
* Attached As           : Input Routine
*------------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*------------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*------------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*------------------------------------------------------------------------------------------------------------------------------------------------
*/
public class BciVerInpPaymentAmtValidate extends RecordLifecycle {

    public TValidationResponse validateRecord(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        final DataAccess daObj = new DataAccess((T24Context) this);
        final Session sessObj = new Session((T24Context) this);
        final PaymentOrderRecord paymentOrderRecord = new PaymentOrderRecord(currentRecord);
        EbBciCceLimitClearingParamRecord clearingParamRecord = null;
        try {

            final String mnemonic = sessObj.getCompanyRecord().getMnemonic().getValue();
            final String paymentCurrency = paymentOrderRecord.getPaymentCurrency().getValue();
            final String poProduct = paymentOrderRecord.getPaymentOrderProduct().getValue();
            String poTransferType = paymentOrderRecord.getLocalRefField("L.TRANSFER.TYPE").getValue();
            final String paymentAmount = paymentOrderRecord.getPaymentAmount().getValue();
            if (poProduct.equals("CCETRANS") && poProduct.equals("LBTRB")) {
                try {
                    clearingParamRecord = new EbBciCceLimitClearingParamRecord(
                            daObj.getRecord(mnemonic, "EB.BCI.CCE.LIMIT.CLEARING.PARAM", "", "SYSTEM"));
                } catch (Exception e1) {
                    e1.getMessage();
                }
                String maxLimitAmount = "";
                String minLimitAmount = "";
                String currency = "";
                int currIndex = -1;
                List<PaymentOrderProductClass> paymentOrderProductList = new ArrayList<PaymentOrderProductClass>();
                paymentOrderProductList = (List<PaymentOrderProductClass>) clearingParamRecord.getPaymentOrderProduct();
                for (PaymentOrderProductClass paymentOrderProductClass : paymentOrderProductList) {
                    final String payPoPrd = paymentOrderProductClass.getPaymentOrderProduct().getValue();
                    if (payPoPrd.equals(poProduct)) {

                        List<TransTypeClass> lstTransType = new ArrayList<>();

                        lstTransType = paymentOrderProductClass.getTransType();

                        for (TransTypeClass transTypeClass : lstTransType) {

                            // Tipo de transferencia
                            String typeTranfer = transTypeClass.getTransType().getValue();
                            if (payPoPrd.equals("LBTRB")) {
                                poTransferType = typeTranfer;
                            }
                            if (typeTranfer.equals(poTransferType)) {
                                currency = transTypeClass.getCurrency().getValue();
                                if (paymentCurrency.equals(currency)) {
                                    minLimitAmount = transTypeClass.getMinLimit().getValue();
                                    maxLimitAmount = transTypeClass.getMaxLimit().getValue();
                                    currIndex = 1;
                                }

                            }

                        }

                    }
                }

                if (currIndex != -1) {
                    final Double payAmount = Double.parseDouble(paymentAmount);
                    final Double minAmount = Double.parseDouble(minLimitAmount);
                    final Double maxAmount = Double.parseDouble(maxLimitAmount);

                    if (poProduct.equals("CCETRANS")) {
                        this.validateCceAmount(payAmount, minAmount, maxAmount, paymentOrderRecord);
                    }
                    if (poProduct.equals("LBTRB")) {
                        this.validateLBTRAmount(payAmount, minAmount, maxAmount, paymentOrderRecord);
                    }
                } else if (currIndex == -1) {
                    paymentOrderRecord.getPaymentAmount().setError("EB-BCI-CCE-LIMIT-NOT-DEF");
                }
            }

        } catch (Exception e2) {
            e2.getMessage();
        }
        return paymentOrderRecord.getValidationResponse();
    }

    public List<String> getCurrency(final List<CurrencyClass> clearingCurrency,
            final EbBciCceLimitClearingParamRecord clearingParamRecord) {
        final List<String> currencyLists = new ArrayList<String>();
        for (CurrencyClass currencyClass : clearingCurrency) {
            String currency = currencyClass.getCurrency().getValue();
            currencyLists.add(currency);
        }

        return currencyLists;
    }

    public void validateCceAmount(final Double payAmount, final Double minAmount, final Double maxAmount,
            final PaymentOrderRecord paymentOrderRecord) {
        if (minAmount <= payAmount && maxAmount >= payAmount) {
            return;
        }
        paymentOrderRecord.getPaymentAmount().setError("EB-BCI.CCE.AMOUNT.NT.IN.RANGE");
    }

    public void validateLBTRAmount(final Double payAmount, final Double minAmount, final Double maxAmount,
            final PaymentOrderRecord paymentOrderRecord) {
        if (minAmount <= payAmount && maxAmount >= payAmount) {
            return;
        }
        paymentOrderRecord.getPaymentAmount().setError("EB-BCI.LBTR.AMOUNT.NT.IN.RANGE");
    }
}
