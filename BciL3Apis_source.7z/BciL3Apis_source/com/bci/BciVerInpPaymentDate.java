package com.bci;

import com.temenos.api.TNumber;
import com.temenos.t24.api.system.Date;
import com.temenos.api.TDate;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.system.Session;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/**
*
*----------------------------------------------------------------------------------------------------------------
* Description           : To Raise Error when Today date is not equal to processing date
* Developed By          : Mallika V, Techmill Technologies     
* Development Reference : Cheque Compensation Correction 
* Attached To           : VERSION>PAYMENT.ORDER,BCI.ADJUSTMENT.R17ANDR18
* Attached As           : Input Routine  
*-------------------------------------------------------  ----------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/
public class BciVerInpPaymentDate extends RecordLifecycle
{
    public static final String ORIGINAL_TXN_REF = "L.ORGNL.TXN.REF";
    public static final String PP_APP = "PP.ORDER.ENTRY";
    
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        TDate tDate = null;
        PpOrderEntryRecord ppRecEntryObj = null;
        TStructure tstructobj = null;
        final DataAccess daObj = new DataAccess((T24Context)this);
        final Session sessObj = new Session((T24Context)this);
        String processingDate = "";
        final PaymentOrderRecord paymentOrderRecordObj = new PaymentOrderRecord(currentRecord);
        try {
            final String todayDate = sessObj.getCurrentVariable("!TODAY");
            final String originalTxnRef = paymentOrderRecordObj.getLocalRefField("L.ORGNL.TXN.REF").getValue();
            if (!originalTxnRef.isEmpty()) {
                try {
                    tstructobj = daObj.getRecord("", "PP.ORDER.ENTRY", "", originalTxnRef);
                }
                catch (Exception e1) {
                    e1.getMessage();
                    tstructobj = null;
                }
                ppRecEntryObj = new PpOrderEntryRecord(tstructobj);
                if (tstructobj != null) {
                    processingDate = ppRecEntryObj.getProcessingdate().getValue();
                }
                else {
                    tstructobj = daObj.getHistoryRecord("PP.ORDER.ENTRY", originalTxnRef);
                    ppRecEntryObj = new PpOrderEntryRecord(tstructobj);
                    processingDate = ppRecEntryObj.getProcessingdate().getValue();
                }
                tDate = new TDate(todayDate);
                final TDate paymentExecutionDte = new TDate(processingDate);
                final Date date = new Date((T24Context)this);
                final String tNumber = "1";
                final TNumber number = new TNumber(tNumber);
                final TDate finaldate = date.addWorkingDays(paymentExecutionDte, number);
                String checkFlag = "";
                if (paymentExecutionDte.toString().equals(tDate.toString())) {
                    checkFlag = "YES";
                }
                if (finaldate.toString().equals(tDate.toString())) {
                    checkFlag = "YES";
                }
                if (checkFlag.isEmpty()) {
                    paymentOrderRecordObj.getLocalRefField("L.ORGNL.TXN.REF").setError("EB-BCI.INVALID.PAYMENT.DATE");
                }
            }
        }
        catch (Exception e2) {
            e2.getMessage();
        }
        return paymentOrderRecordObj.getValidationResponse();
    }
}
