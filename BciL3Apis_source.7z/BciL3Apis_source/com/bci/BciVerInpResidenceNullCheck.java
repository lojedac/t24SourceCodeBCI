package com.bci;

import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;


/**
 * TODO: Document me!
 *
 * @author malika.v
 *
 */
public class BciVerInpResidenceNullCheck extends RecordLifecycle
{
    static final String RES_VAL = "PE";
    static final String RES_TYPE = "1";
    static final String TYPE_RESI = "L.TYPE.RESIDENCIA";
    
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final CustomerRecord custRecObj = new CustomerRecord(currentRecord);
        final String residenceVal = custRecObj.getLocalRefField("L.TYPE.RESIDENCIA").getValue();
        try {
            final String nationality = custRecObj.getNationality().getValue();
            if (!nationality.equals("PE") && residenceVal.isEmpty()) {
                custRecObj.getLocalRefField("L.TYPE.RESIDENCIA").setError("EB-BCI.TYPE.RESIDENCE");
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        return custRecObj.getValidationResponse();
    }
}
