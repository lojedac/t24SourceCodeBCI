package com.bci;

import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

public class BciVerInpResidenceUpd extends RecordLifecycle
{
    static final String RES_VAL = "PE";
    static final String RES_TYPE = "1";
    static final String TYPE_RESI = "L.TYPE.RESIDENCIA";
    
    public void defaultFieldValues(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final CustomerRecord custRecObj = new CustomerRecord(currentRecord);
        final String residenceVal = custRecObj.getLocalRefField("L.TYPE.RESIDENCIA").getValue();
        try {
            final String nationality = custRecObj.getNationality().getValue();
            if (nationality.equals("PE")) {
                custRecObj.setResidence((CharSequence)"PE");
                custRecObj.getLocalRefField("L.TYPE.RESIDENCIA").setValue("1");
            }
            if (!nationality.equals("PE") && residenceVal.equals("1")) {
                custRecObj.getLocalRefField("L.TYPE.RESIDENCIA").setValue("");
            }
            currentRecord.set(custRecObj.toStructure());
        }
        catch (Exception e) {
            e.getMessage();
        }
    }
}
