
package com.bci;

import java.util.ArrayList;
import java.util.List;
import com.temenos.t24.api.tables.ebbcihccecommaxlimitparam.PlaceTypeClass;
import com.temenos.t24.api.tables.ebbcihccecommaxlimitparam.EbBciHCceComMaxLimitParamRecord;
import com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.EbBciTrnsClgCommissionParamRecord;
import com.temenos.t24.api.system.Session;
import com.temenos.tafj.api.client.impl.T24Context;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/*
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Validate the commission percentage in EB.BCI.TRNS.CLG.COMMISSION.PARAM with MAXIMUM.LIMIT value in EB.BCI.H.CCE.COM.MAX.LIMIT.PARAM
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : BRD 11 - Commissions
*Attached To            : EB.TABLE.PROCEDURES>EB.BCI.TRNS.CLG.COMMISSION.PARAM
*Attached as            : Cross Val Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/

public class BciVerLimitPercentageValidate extends RecordLifecycle
{
    public static final String ERR_MSG = "";
    
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final DataAccess daObj = new DataAccess((T24Context)this);
        final Session sessObj = new Session((T24Context)this);
        final String mnemonic = sessObj.getCompanyRecord().getFinancialMne().getValue();
        final EbBciTrnsClgCommissionParamRecord bciTrnsClgCommParam = new EbBciTrnsClgCommissionParamRecord(currentRecord);
        String commTypePlace = "";
        String transTypePlace = "";
        double commMaxLimitPercent = 0.0;
        double transPercentage = 0.0;
        String commissionType = "";
        try {
            final String transId = currentRecordId;
            final String[] splitArray = transId.split("\\.");
            commissionType = splitArray[0];
            if (commissionType.equals("CHE")) {
                final List<com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.PlaceTypeClass> transTypePlaceList = (List<com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.PlaceTypeClass>)bciTrnsClgCommParam.getPlaceType();
                final EbBciHCceComMaxLimitParamRecord bciCceComMaxLimitParam = new EbBciHCceComMaxLimitParamRecord(daObj.getRecord(mnemonic, "EB.BCI.H.CCE.COM.MAX.LIMIT.PARAM", "", "SYSTEM"));
                final List<PlaceTypeClass> commTypePlaceList = (List<PlaceTypeClass>)bciCceComMaxLimitParam.getPlaceType();
                for (int commPlaceCnt = 0; commPlaceCnt < commTypePlaceList.size(); ++commPlaceCnt) {
                    commTypePlace = commTypePlaceList.get(commPlaceCnt).getPlaceType().getValue();
                    commMaxLimitPercent = Double.parseDouble(commTypePlaceList.get(commPlaceCnt).getMaxLimit().getValue());
                    for (int transPlaceCnt = 0; transPlaceCnt < transTypePlaceList.size(); ++transPlaceCnt) {
                        transTypePlace = transTypePlaceList.get(transPlaceCnt).getPlaceType().getValue();
                        if (commTypePlace.equals(transTypePlace)) {
                            transPercentage = Double.parseDouble(transTypePlaceList.get(transPlaceCnt).getCommPercentage().getValue());
                            this.setErrorMessage(transPercentage, commMaxLimitPercent, transTypePlaceList, transPlaceCnt, bciTrnsClgCommParam, currentRecord);
                        }
                    }
                }
            }
        }
        catch (Exception e) {
            e.getMessage();
        }
        return bciTrnsClgCommParam.getValidationResponse();
    }
    
    public void setErrorMessage(final double transPercentage, final double commMaxLimitPercent, final List<com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.PlaceTypeClass> transTypePlaceList, final int transPlaceCnt, final EbBciTrnsClgCommissionParamRecord bciTrnsClgCommParam, final TStructure currentRecord) {
        final List<String> errMessage = new ArrayList<String>();
        if (transPercentage > commMaxLimitPercent) {
            final String transPercent = Double.toString(transPercentage).split("\\.")[0];
            errMessage.add(0, "EB-BCI.COMM.PERCENT.LIMIT");
            errMessage.add(1, String.valueOf(transPercent) + "%");
            transTypePlaceList.get(transPlaceCnt).getCommPercentage().setError(errMessage.toString());
            currentRecord.set(bciTrnsClgCommParam.toStructure());
        }
    }
}
