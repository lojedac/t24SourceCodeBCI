
package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.beneficiary.BeneficiaryRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.teller.TellerRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.tafj.api.client.impl.T24Context;
/*
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Validate DNI/RUC Structure
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : Additional Fields - Cheque Clearing
*Attached To            : VERSION>TELLER,BCI.DIR.CHQ.CLG, TELLER,BCI.FOREIGN.CHQS,PAYMENT.ORDER,DOMESTIC.BCI
*                         VERSION>PP.ORDER.ENTRY,CCE.INWARD.TRANSFER.BCI
*                         VERSION>PP.ORDER.ENTRY,BCI.CTR.OUT.CREATE.NEW
*                         VERSION>PP.ORDER.ENTRY,BCI.CTR.OUT.CREATE.NEW
*                         VERSION>PP.ORDER.ENTRY,BCI.BTR.IN.CREATE.NEW
*                         VERSION>PP.ORDER.ENTRY,BCI.BTR.OUT.CREATE.NEW
*Attached as            : Input Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/
public class BciVerRucDniStructureValidate extends RecordLifecycle {
    public static final String DOC_NUMBER = "L.DRAWER.DOC.NUMBER";
    public static final String DOC_TYPE = "L.DRAWER.DOC.TYPE";
    public static final String TELLER_APP = "TELLER";
    public static final String PO_APP = "PAYMENT.ORDER";
    public static final String OE_APP = "PP.ORDER.ENTRY";
    public static final String INVALID = "Invalid ";
    public static final String ID = " Id";
    List<String> errMessage;
    int constVal;
    TellerRecord tellerRecordObj;
    PaymentOrderRecord paymentOrderRecObj;
    PpOrderEntryRecord ppOrderEntryRecObj;
    BeneficiaryRecord beneficiaryRecObj;

    public BciVerRucDniStructureValidate() {
        this.errMessage = new ArrayList<String>();
        this.constVal = 11;
        this.tellerRecordObj = null;
        this.paymentOrderRecObj = null;
        this.ppOrderEntryRecObj = null;
        this.beneficiaryRecObj = null;
    }

    public TValidationResponse validateRecord(final String application, final String currentRecordId,
            final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord,
            final TransactionContext transactionContext) {
        TValidationResponse response = null;
        final DataAccess daAccess = new DataAccess((T24Context) this);
        String documentNo = "";
        String drawerDocType = "";
        try {
            if (application.equals("TELLER")) {
                this.tellerRecordObj = new TellerRecord(currentRecord);
                documentNo = this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                drawerDocType = this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                response = this.validateDniRucStructure(documentNo, drawerDocType, application, daAccess);
            } else if (application.equals("PAYMENT.ORDER")) {
                this.paymentOrderRecObj = new PaymentOrderRecord(currentRecord);
                if (this.paymentOrderRecObj.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                    documentNo = this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                    drawerDocType = this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                    response = this.validateDniRucStructure(documentNo, drawerDocType, application, daAccess);
                }
            } else if (application.equals("PP.ORDER.ENTRY")) {
                this.ppOrderEntryRecObj = new PpOrderEntryRecord(currentRecord);
                documentNo = this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                drawerDocType = this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                response = this.validateDniRucStructure(documentNo, drawerDocType, application, daAccess);
            } else if (application.equals("BENEFICIARY")) {
                this.beneficiaryRecObj = new BeneficiaryRecord(currentRecord);
                documentNo = this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER").getValue();
                drawerDocType = this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.TYPE").getValue();
                response = this.validateDniRucStructure(documentNo, drawerDocType, application, daAccess);
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return response;
    }

    public TValidationResponse validateDniRucStructure(final String documentNo, final String drawerDocType,
            final String application, final DataAccess daAccess) {
        TValidationResponse flagRes = null;
        String drawerDocumentType = "";
        try {
            if (drawerDocType.equals("RU")) {
                drawerDocumentType = "RUC";
            } else {
                drawerDocumentType = drawerDocType;
            }
            if (!documentNo.isEmpty() && drawerDocumentType.equals("RUC")) {
                flagRes = this.validateRucStructure(documentNo, drawerDocumentType, application);
            }
        } catch (Exception drawerExcep) {
            drawerExcep.getMessage();
        }
        return flagRes;
    }

    public TValidationResponse validateRucStructure(final String documentNo, final String drawerDocumentType,
            final String application) {
        final int[] rucNumber = { 5, 4, 3, 2, 7, 6, 5, 4, 3, 2 };
        String finalRucNumber = "";
        TValidationResponse flag = null;
        String lastDigit = "";
        try {
            if (documentNo.length() == 11) {
                final String rucDocumentNo = documentNo.substring(0, 10);
                final char docLastDigit = documentNo.charAt(documentNo.length() - 1);
                lastDigit = Character.toString(docLastDigit);
                final int getRucValue = this.getRucValueOperation(rucNumber, rucDocumentNo);
                if (getRucValue < 10) {
                    finalRucNumber = String.valueOf(getRucValue);
                } else if (getRucValue == 10) {
                    finalRucNumber = "0";
                } else if (getRucValue == 11) {
                    finalRucNumber = "1";
                }
                flag = this.checkValue(finalRucNumber, application, lastDigit, documentNo, drawerDocumentType);
            } else {
                flag = this.throwError(application, drawerDocumentType);
            }
        } catch (Exception e1) {
            e1.getMessage();
        }
        return flag;
    }

    public TValidationResponse checkValue(final String finalNumber, final String application, final String lastDigits,
            final String documentNo, final String drawerDocumentType) {
        TValidationResponse checkFlg = null;
        try {
            if (!finalNumber.equals(lastDigits) && application.equals("PP.ORDER.ENTRY")) {
                this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER")
                        .setError("Invalid " + drawerDocumentType + " Id");
                checkFlg = this.ppOrderEntryRecObj.getValidationResponse();
            }
            if (!finalNumber.equals(lastDigits) && application.equals("TELLER")) {
                this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.NUMBER")
                        .setError("Invalid " + drawerDocumentType + " Id");
                checkFlg = this.tellerRecordObj.getValidationResponse();
            }
            if (!finalNumber.equals(lastDigits) && application.equals("PAYMENT.ORDER")) {
                if (this.paymentOrderRecObj.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                    this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER")
                            .setError("Invalid " + drawerDocumentType + " Id");
                    checkFlg = this.paymentOrderRecObj.getValidationResponse();
                }
            }
            if (!finalNumber.equals(lastDigits) && application.equals("BENEFICIARY")) {
                this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER")
                        .setError("Invalid " + drawerDocumentType + " Id");
                checkFlg = this.beneficiaryRecObj.getValidationResponse();
            }
        } catch (Exception e3) {
            e3.getMessage();
        }
        return checkFlg;
    }

    public TValidationResponse throwError(final String application, final String drawerDocumentType) {
        TValidationResponse throwErrFlg = null;
        try {
            if (application.equals("PAYMENT.ORDER")) {
                if (this.paymentOrderRecObj.getPaymentOrderProduct().getValue().equals("CCETRANS")) {
                    this.paymentOrderRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER")
                            .setError("Invalid " + drawerDocumentType + " Id");
                    throwErrFlg = this.paymentOrderRecObj.getValidationResponse();
                }
            }
            if (application.equals("TELLER")) {
                this.tellerRecordObj.getLocalRefField("L.DRAWER.DOC.NUMBER")
                        .setError("Invalid " + drawerDocumentType + " Id");
                throwErrFlg = this.tellerRecordObj.getValidationResponse();
            }
            if (application.equals("PP.ORDER.ENTRY")) {
                this.ppOrderEntryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER")
                        .setError("Invalid " + drawerDocumentType + " Id");
                throwErrFlg = this.ppOrderEntryRecObj.getValidationResponse();
            }
            if (application.equals("BENEFICIARY")) {
                this.beneficiaryRecObj.getLocalRefField("L.DRAWER.DOC.NUMBER")
                        .setError("Invalid " + drawerDocumentType + " Id");
                throwErrFlg = this.beneficiaryRecObj.getValidationResponse();
            }
        } catch (Exception err) {
            err.getMessage();
        }
        return throwErrFlg;
    }

    public int getRucValueOperation(final int[] rucNumber, final String documentNo) {
        final String[] docNumber = documentNo.split("");
        int sum = 0;
        int divValue = 0;
        int remValue = 0;
        try {
            for (int rucCnt = 0; rucCnt < docNumber.length; ++rucCnt) {
                final int mulValue = Integer.parseInt(docNumber[rucCnt]) * rucNumber[rucCnt];
                sum += mulValue;
            }
            divValue = sum % this.constVal;
            if (divValue != this.constVal) {
                remValue = this.constVal - divValue;
            } else {
                remValue = divValue;
            }
        } catch (Exception e3) {
            e3.getMessage();
        }
        return remValue;
    }
}
