
package com.bci;

import com.temenos.api.TField;
import java.util.List;
import com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.PlaceTypeClass;
import com.temenos.t24.api.tables.ebbcitrnsclgcommissionparam.EbBciTrnsClgCommissionParamRecord;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.api.TStructure;
import com.temenos.t24.api.hook.system.RecordLifecycle;

/*
*-------------------------------------------------------------------------------------------------------------------------------------------
*Description            : Avoid the Duplication of TYPE.PLACE in local template EB.BCI.TRN.CLG.COMMISSION.PARAM
*Developed By           : Mallika V, Techmill Technologies
*Development Reference  : BRD 11 - Commissions
*Attached To            : EB.TABLE.PROCEDURES>EB.BCI.TRNS.CLG.COMMISSION.PARAM
*Attached as            : Cross Val Routine
*-------------------------------------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-------------------------------------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-------------------------------------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-------------------------------------------------------------------------------------------------------------------------------------------
* Include files
*-------------------------------------------------------------------------------------------------------------------------------------------
*
*/

public class BciVerTypePlaceDuplicate extends RecordLifecycle
{
    public static final String NEGATIVE_VAL_NOT = "EB-BCI.NEGATIVE.VAL.NOT.ALLOWED";
    
    public TValidationResponse validateRecord(final String application, final String currentRecordId, final TStructure currentRecord, final TStructure unauthorisedRecord, final TStructure liveRecord, final TransactionContext transactionContext) {
        final EbBciTrnsClgCommissionParamRecord bciTrnsClgCommParam = new EbBciTrnsClgCommissionParamRecord(currentRecord);
        String commPercentage = "";
        String minCommission = "";
        String maxCommission = "";
        try {
            final List<PlaceTypeClass> transTypePlaceList = (List<PlaceTypeClass>)bciTrnsClgCommParam.getPlaceType();
            for (int transPlaceCnt = 0; transPlaceCnt < transTypePlaceList.size(); ++transPlaceCnt) {
                commPercentage = transTypePlaceList.get(transPlaceCnt).getCommPercentage().getValue();
                minCommission = transTypePlaceList.get(transPlaceCnt).getMinCommission().getValue();
                maxCommission = transTypePlaceList.get(transPlaceCnt).getMaxCommission().getValue();
                if (commPercentage.equals("0.00") && !minCommission.equals(maxCommission)) {
                    bciTrnsClgCommParam.getPlaceType(transPlaceCnt).getCommPercentage().setError("EB-BCI.INVALID.AMOUNT");
                    break;
                }
                for (int transPlaceCnt2 = transPlaceCnt + 1; transPlaceCnt2 < transTypePlaceList.size(); ++transPlaceCnt2) {
                    if (transTypePlaceList.get(transPlaceCnt).getPlaceType().getValue().equals(transTypePlaceList.get(transPlaceCnt2).getPlaceType().getValue())) {
                        bciTrnsClgCommParam.getPlaceType(transPlaceCnt2).getPlaceType().setError("EB-BCI.DUPLICATE.TYPE.PLACE");
                    }
                }
                this.negativeValChk(transTypePlaceList, transPlaceCnt, bciTrnsClgCommParam);
            }
            currentRecord.set(bciTrnsClgCommParam.toStructure());
        }
        catch (Exception e) {
            e.getMessage();
        }
        return bciTrnsClgCommParam.getValidationResponse();
    }
    
    public void negativeValChk(final List<PlaceTypeClass> transTypePlaceList, final int transPlaceCnt, final EbBciTrnsClgCommissionParamRecord bciTrnsClgCommParam) {
        TField comPerFld = null;
        TField minCommFld = null;
        TField maxCommFld = null;
        String comPerFldVal = "";
        String minCommFldVal = "";
        String maxCommFldVal = "";
        comPerFld = transTypePlaceList.get(transPlaceCnt).getCommPercentage();
        minCommFld = transTypePlaceList.get(transPlaceCnt).getMinCommission();
        maxCommFld = transTypePlaceList.get(transPlaceCnt).getMaxCommission();
        comPerFldVal = comPerFld.getValue();
        minCommFldVal = minCommFld.getValue();
        maxCommFldVal = maxCommFld.getValue();
        if (comPerFldVal.contains("-")) {
            bciTrnsClgCommParam.getPlaceType(transPlaceCnt).getCommPercentage().setError("EB-BCI.NEGATIVE.VAL.NOT.ALLOWED");
        }
        if (minCommFldVal.contains("-")) {
            bciTrnsClgCommParam.getPlaceType(transPlaceCnt).getMinCommission().setError("EB-BCI.NEGATIVE.VAL.NOT.ALLOWED");
        }
        if (maxCommFldVal.contains("-")) {
            bciTrnsClgCommParam.getPlaceType(transPlaceCnt).getMaxCommission().setError("EB-BCI.NEGATIVE.VAL.NOT.ALLOWED");
        }
    }
}
