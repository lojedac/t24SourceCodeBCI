package com.bci;

import java.util.List;
import org.apache.commons.lang3.StringUtils;
import java.io.IOException;
import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import com.temenos.t24.api.complex.eb.servicehook.SynchronousTransactionData;
import com.temenos.t24.api.complex.eb.servicehook.TransactionControl;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.hook.system.ServiceLifecycle;
import com.temenos.t24.api.records.aaactivityhistory.AaActivityHistoryRecord;
import com.temenos.t24.api.records.aaactivityhistory.ActivityRefClass;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaarrangement.CustomerClass;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.t24.api.records.aaprddesinterest.AaPrdDesInterestRecord;
import com.temenos.t24.api.records.aaprddesofficers.AaPrdDesOfficersRecord;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.category.CategoryRecord;
import com.temenos.t24.api.records.company.CompanyRecord;
import com.temenos.t24.api.records.customer.ContactTypeClass;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.customer.LegalIdClass;
import com.temenos.t24.api.records.customer.Phone1Class;
import com.temenos.t24.api.records.deptacctofficer.DeptAcctOfficerRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import java.util.ArrayList;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsTable;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.techmill.integration.SoapClient;
import org.apache.commons.lang3.StringUtils;

/**
*
*----------------------------------------------------------------------------------------------------------------
* Description           : Batch routine to pass the all the string values to third party(EngageOne)
* Developed By          : Tamizharasi G,Techmill Technologies    
* Development Reference : IDD050_Interface_Reportes_Transfers
* Attached To           : BATCH>BNK/BciMulTransferActivityDets  
* Attached As           : Batch Routine
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/

/**
 * TODO: Document me!
 *
 * @author tamizharasi.g
 *
 */
public class BciMulTransferActivityDets extends ServiceLifecycle
{

    @Override
    public List<String> getIds(ServiceData serviceData, List<String> controlList)
    {
        
        //*------------ Select the records from EB.BCI.UPDATE.ENGAGEONE.DETAILS ----------------*//
        
        DataAccess fRead = new DataAccess(this);              
        List<String> bciUpdateTransferActDetsList = new ArrayList<String>();
        
        //String selCmd = "WITH (ERROR.FLAG EQ '') AND (EVENT.CODE EQ 'C0005') OR (EVENT.CODE EQ 'N0007')";
        
        try            
        {
            bciUpdateTransferActDetsList = fRead.selectRecords("","EB.BCI.UPDATE.ENGAGEONE.DETAILS","","WITH (ERROR.FLAG EQ '') AND ((EVENT.CODE EQ 'C0005') OR (EVENT.CODE EQ 'N0007'))");       
          
        } 
        catch (Exception e) 
        {   
            bciUpdateTransferActDetsList.clear(); 
        }    
                                            
        return bciUpdateTransferActDetsList; 
       
    }

    @Override
    public void updateRecord(String id, ServiceData serviceData, String controlItem,
            TransactionControl transactionControl, List<SynchronousTransactionData> transactionData,
            List<TStructure> records)
    {
        // TODO Auto-generated method stub
        
            DataAccess da = new DataAccess(this);  
            Contract contract = new Contract(this);
            Session se = new Session(this);
            int flag = 0;
            String bciUpdActivityDetsId = id;
             String aaaId = bciUpdActivityDetsId.split("-")[1];
             String ActName = "ACCOUNTS-DEBIT.SETTLE-ARRANGEMENT";
            
            
             EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetRec = null;
             EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetTable = new EbBciUpdateEngageoneDetailsTable(this);  
            
                try
                {
                    bciUpdEngageoneDetRec = new EbBciUpdateEngageoneDetailsRecord(da.getRecord("EB.BCI.UPDATE.ENGAGEONE.DETAILS", bciUpdActivityDetsId));  
                }        
                catch(Exception e)
                {   
                    flag = 1;
                }  
        
        if(flag == 0)
        {
            //initialise the variable
            String hdrCode = "";
            String detCode = "";
            String eventCode = "";
            String legalID = "";
            String customerName = "";
            String email = "";
            String phoneNo = "";
            String hdrEventDate = "";
            String hdrEventTime = "";
            String branchShortName = "";
            String originAcNo = "";
            String desAcNo = "";
            String openingDt = "";
            String arrId = "";
            String customerCommunication = "";
            String codeProduct = "";
            String legacyVal = "";
            String codeExecutive = "";
            String executiveName = "";
            String executiveTelephone = "";
            String CrEffRate = "";
            String DrEffRate = "";
            String bank = "";
            String hdrNoticeMsg = "";
            String amtTransfer = "";
            String amtInWrds = "";
            String transferType = "";
            String channel = "";
            String treaRate = "";
            String debitBal = "";
            String executiveEmail = "";
            String checkNumber = "";
            String ccyCommisionCharged = "";
            String totCommissionExpenseCharged = "";
            String ccyTaxCharged = "";
            String taxCollected = "";
            String bciCommisionCcy = "";
            String bciCommisionAmt = "";
            String ccyInterbankCommision = "";
            String interbankCommisionAmt = "";
            String ccyTotalChargeToAcc = "";
            String totAmtChargedToAcc = "";
            String paymentDt = "";
            String transferComment = "";
            String typeOfExpenses = "";
            String address = "";
            String detNoticeMsg = "";
            String hdrDetNoticeMsg = "";
            String soapResponse = "";
            String companyName = "";
            String accountCode = "";
            String customerNo = "";
            String AccountNo = "";
            String currency = "";
            String coCode = "";
            String operationNo = "";
            String cmpyMne = "";
            String openingDate = "";
            String openingAcDt = "";
            String companyCode = "";
            String currActivityId = "";
            String closeDateVal = "";
            String aaaDateTime = "";
            String actId = "";
            int acFlag = 0;
            int ecbFlag = 0;
            int bciEngageoneIntRepParamRecFlag = 0;
            int arrFlag = 0;
            int cusFlag = 0;
            int cmpyFlag = 0;
            int aaaFlag = 0;
            int categFlag = 0;
            int flagVal = 0;
            
          //Get the details from EB.BCI.UPDATE.ENGEGONE.DETAILS table
            
            eventCode = bciUpdEngageoneDetRec.getEventCode().getValue();
            arrId = bciUpdEngageoneDetRec.getArragementId().getValue();
            currActivityId = bciUpdEngageoneDetRec.getActivityName().getValue();
                        
            transferType = "";
            channel = "";
            bank = "BCI";
            treaRate = "";
            debitBal = "";
            executiveEmail = "";
            checkNumber = "";
            ccyCommisionCharged = "";
            totCommissionExpenseCharged = "";
            ccyTaxCharged = "";
            taxCollected = "";
            bciCommisionCcy = "";
            bciCommisionAmt = "";
            ccyInterbankCommision = "";
            interbankCommisionAmt = "";
            ccyTotalChargeToAcc = "";
            totAmtChargedToAcc = "";
            paymentDt = "";
            transferComment = "";
            typeOfExpenses = "";
            address = "";
            companyCode = bank;
            operationNo = aaaId;
            
            
            
            
          //Get the fields EVENT.CODE and HEADER.CODE from parameter table 
            
            EbBciEngageoneIntRepParamRecord bciEngageoneIntRepParamRec = null;           
            try
            {        
                bciEngageoneIntRepParamRec = new EbBciEngageoneIntRepParamRecord(da.getRecord("EB.BCI.ENGAGEONE.INT.REP.PARAM", "TRANSFERS"));              
            }
            catch(Exception e1)
            {
                bciEngageoneIntRepParamRecFlag = 1;
            }
              
            if(bciEngageoneIntRepParamRecFlag == 0)
            {
                hdrCode = bciEngageoneIntRepParamRec.getHeaderCode(0).getValue();
                detCode = bciEngageoneIntRepParamRec.getDetailCode(0).getValue();
            }
                  
         // Get Customer Number
            AaArrangementRecord aaRec = new AaArrangementRecord(this);
            try{
                aaRec = new AaArrangementRecord(da.getRecord("AA.ARRANGEMENT",arrId));
            }
            catch(Exception e13){
                arrFlag = 1;
            }
            if(arrFlag == 0)
            {
            
                List<CustomerClass> cusList = aaRec.getCustomer();
                if(!cusList.isEmpty())
                {
                    customerNo = cusList.get(0).getCustomer().getValue();
                }
                
                CustomerRecord cusRec = null;
                try
                {  
                    cusRec = new CustomerRecord(da.getRecord("CUSTOMER", customerNo));
                }
                catch(Exception e2)
                {
                    cusFlag = 1;
                }
                if(cusFlag == 0)
                {
                    customerName = cusRec.getName1().get(0).getValue();
                    companyName = customerName;
                    
             //Get the field LEGAL.ID from customer table
                    List<LegalIdClass> legalIdlist = cusRec.getLegalId();
                    if(!legalIdlist.isEmpty())
                    {
                        legalID = legalIdlist.get(0).getLegalId().getValue();      
                    }
                    else
                    {
                        legalID = "";
                    }
                    
            //Get the fields PHONE.1, EMAIL.1 and customer short name from customer table  
                    
                    List<Phone1Class> phoneList = cusRec.getPhone1();
                    if(!phoneList.isEmpty())
                    {
                    phoneNo = phoneList.get(0).getPhone1().getValue();
                    email = phoneList.get(0).getEmail1().getValue();
                    }
                    else
                    {
                        phoneNo = "";
                        email = "";
                    }
                                  
            //Get the field CONTACT.DATA from customer table 
                    List<ContactTypeClass> contactTypecList = cusRec.getContactType();            
                    if(!contactTypecList.isEmpty())
                    {
                       customerCommunication =  contactTypecList.get(0).getContactData().getValue();
                    }
                    else
                    {
                        customerCommunication = "";
                    }
                }  
                

                currency = aaRec.getCurrency().getValue();
                AccountNo = aaRec.getLinkedAppl(0).getLinkedApplId().getValue();
                desAcNo = AccountNo;
                originAcNo = AccountNo;
            }
            
 
         // Get Company and fetch SHORT.NAME 
            coCode = se.getCompanyId();
            CompanyRecord cmpyRec = new CompanyRecord(this);
            
            try
            {
                cmpyRec = new CompanyRecord(da.getRecord("COMPANY", coCode));
            }
            catch(Exception e2)
            { 
                cmpyFlag = 1;
            }
            
            if (cmpyFlag == 0)
            {
                
                branchShortName = cmpyRec.getCompanyName(0).getValue();
            }   
            

          //Get AAA date time
            
            AaArrangementActivityRecord arrangementActivityRecord = new AaArrangementActivityRecord(this);
            try{
                arrangementActivityRecord = new AaArrangementActivityRecord(da.getRecord("AA.ARRANGEMENT.ACTIVITY", aaaId));
            }
            catch(Exception e14){
                aaaFlag = 1;
            }
            if(aaaFlag == 0)
            {
               try{
                    aaaDateTime = arrangementActivityRecord.getDateTime(0).toString();
                    hdrEventDate = arrangementActivityRecord.getEffectiveDate().getValue();  
               }
               catch(Exception e15)
               {
                   aaaDateTime = ""; 
                   hdrEventDate = "";
               }
            
          // Get Opening date 
                   
                if(!aaaDateTime.equals("")){
                closeDateVal = aaaDateTime.substring(0, 6);
                openingDate = "20"+closeDateVal;
                }
                else
                {
                    openingDate = "";  
                }
            
         // Get hederEventTime
                try
                {
                hdrEventTime = aaaDateTime.substring(6, 8)+aaaDateTime.substring(8,10)+"00";
                }
                catch(Exception e7)
                {
                    hdrEventTime = "";
                }
            }    
            
            
            if(eventCode.equals("C0005"))
            {
            amtTransfer = "";
            amtTransfer = StringUtils.leftPad(amtTransfer, 22, "0");
            amtInWrds = "";
            }
            
            if(eventCode.equals("N0007"))
            {
                openingDt = openingDate;
                cmpyMne = se.getCompanyRecord().getMnemonic().getValue();
                
             // Issue fixing 207 & get amt transfer for N0007 eventcode
                
                try
                {
                     AaActivityHistoryRecord aaActivityHisRec = new AaActivityHistoryRecord(da.getRecord("AA.ACTIVITY.HISTORY", arrId));   

                     
                     List<com.temenos.t24.api.records.aaactivityhistory.EffectiveDateClass> EffDtList = aaActivityHisRec.getEffectiveDate();
                     
                     
                     for(com.temenos.t24.api.records.aaactivityhistory.EffectiveDateClass Effdt : EffDtList)
                     {
                         List<ActivityRefClass> actRefList = Effdt.getActivityRef();
     
                         int actLen = actRefList.size();
             
                         for(int i=0;i<actLen;i++)
                         {
                             actId = actRefList.get(i).getActivity().getValue();
          
                             if(ActName.equals(actId))
                             {
                                 amtTransfer = actRefList.get(i).getActivityAmt().getValue(); 
                                 flagVal = 1;
                                 break;
                             }
                             
                         }
                         
                         if(flagVal == 1)
                         {
                             break;
                         }
                         
                     }    
                 
                }
                catch(Exception e1)
                {
                    
                }
                
                
             // Get amount in words for PAYMENT.AMOUNT field value
                try{
                    amtInWrds = BciEnglishNumberToWords.convert(Long.parseLong(amtTransfer));
                }
                catch(Exception e12){
                    amtInWrds = "";
                }
                
                // Formatting amount
               
                if(amtTransfer.equals(""))
                {
                    amtTransfer = StringUtils.leftPad(amtTransfer, 22, "0");   
                }
                else
                {
                    if((amtTransfer.indexOf(".") == -1))
                    {
                        amtTransfer = amtTransfer+".0";                   
                        amtTransfer = formatAmount(amtTransfer) ;      // Calling Method
                    }
                    else
                    {
                        amtTransfer = formatAmount(amtTransfer) ;    // Calling Method
                    }
                }       

            }
            
            
          //Get Opening Date
        if(eventCode.equals("C0005"))
        {
       AccountRecord acRec = new AccountRecord(this);
       //SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
           
              try
              {
                  acRec = new AccountRecord(da.getRecord("ACCOUNT", AccountNo));            
              }
              catch(Exception e1)
              {
                  acFlag = 1;
              }
              if(acFlag == 0)
              {
                  openingAcDt = acRec.getOpeningDate().getValue();
                  
                  try{
                      //Date parseaDate2 = new SimpleDateFormat ("yyyyMMdd").parse (openingAcDt);    //Format the date from YYYMMDD to DD/MM/YYYY
                      openingDt = openingAcDt;
                     }
                     catch (Exception e6)
                     {
                         openingDt = "";
                    }
              }
              
              // get TREA Rate 
              
              contract.setContractId(arrId);
              AaPrdDesAccountRecord aaPrdDesAcRec = null;
              try
              {
                  aaPrdDesAcRec = new AaPrdDesAccountRecord(contract.getConditionForProperty("BALANCE"));

                  treaRate = aaPrdDesAcRec.getAprType(1).getAprRate().getValue();
                  treaRate = treaRate.replace("-", "");
              }
              catch(Exception e ) 
              {
                  
              }
              
              System.out.println("aaPrdDesAcRec"+" "+aaPrdDesAcRec);

              
              if(treaRate.equals(""))
              {
                  treaRate = StringUtils.leftPad(treaRate, 15, "0");
              }
              else
              {
                  
                  if((treaRate.indexOf(".") == -1))
                  {
                      treaRate = treaRate+".0";                   
                      treaRate = formatRate(treaRate) ;      // Calling Method
                  }
                  else
                  {
                      treaRate = formatRate(treaRate) ;    // Calling Method
                  }
              }
 
        }
        else
        {
            treaRate = StringUtils.leftPad(treaRate, 15, "0");
        }
        
        System.out.println("treaRate"+" "+treaRate);

  
   
            //Get AA ACCOUNT Details
                                 
            contract.setContractId(arrId);
            AaPrdDesAccountRecord aaPrdDesAcctRec = null;
            try
            {
             aaPrdDesAcctRec = new AaPrdDesAccountRecord(contract.getConditionForProperty("BALANCE"));
             codeProduct = aaPrdDesAcctRec.getCategory().getValue();
             CategoryRecord categRec = new CategoryRecord(this);
                 try{
                     categRec = new CategoryRecord(da.getRecord("CATEGORY", codeProduct));
                 }
                 catch(Exception e13)
                 {
                     categFlag = 1;
                 }
                 if(categFlag == 0)
                 {
                     codeProduct = categRec.getDescription().get(1).getValue();
                 }
                 else
                 {
                     codeProduct = "";
                 }
                 try
                 {
                  legacyVal = aaPrdDesAcctRec.getAltIdType(0).getAltIdType().getValue();
                 }
                 catch(Exception e14)
                 {
                     legacyVal = "";  
                 }
             
                 if(legacyVal.equals("LEGACY"))
                 {
                     accountCode = aaPrdDesAcctRec.getAltIdType(0).getAltId().getValue();
                 }

            }
            catch(Exception e )
            {
                codeProduct = "";
                accountCode = "";
            } 
            
            
          //Get Code Executive
            contract.setContractId(arrId);
            AaPrdDesOfficersRecord aaPrdDesOfficerRec = null;
            try
            {
                aaPrdDesOfficerRec = new AaPrdDesOfficersRecord(contract.getConditionForProperty("OFFICERS"));
                codeExecutive = aaPrdDesOfficerRec.getPrimaryOfficer().getValue();           
            }
            catch(Exception e ) 
            {
                codeExecutive = "";
            }
            
            
         // Get CR Interest rate
            if(eventCode.equals("C0005"))
            {
                  
                contract.setContractId(arrId);
                AaPrdDesInterestRecord aaPrdDesInterestRec = null;
                try
                {
                    aaPrdDesInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("CRINTEREST"));
                    CrEffRate = aaPrdDesInterestRec.getFixedRate(0).getEffectiveRate().getValue();               
                    
                }
                catch(Exception e )
                {
                    CrEffRate = "";
                }
                
                if(CrEffRate.equals(""))
                {
                    CrEffRate = StringUtils.leftPad(CrEffRate, 15, "0");   
                }
                else
                {
                        if((CrEffRate.indexOf(".") == -1))
                        {
                            CrEffRate = CrEffRate+".0";                   
                        CrEffRate = formatRate(CrEffRate) ;      // Calling Method
                        }
                        else
                        {
                            CrEffRate = formatRate(CrEffRate) ;    // Calling Method
                        }
                }
               // Get DR Interest rate
                
                contract.setContractId(arrId);
                try
                {
                    aaPrdDesInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("DRINTEREST"));
                    DrEffRate = aaPrdDesInterestRec.getFixedRate(0).getEffectiveRate().getValue();
                }
                catch(Exception e )
                {
                    DrEffRate = "";
                }
                
                if(DrEffRate.equals(""))
                {
                    DrEffRate = StringUtils.leftPad(DrEffRate, 15, "0");   
                }
                else
                {
                    
                    if((DrEffRate.indexOf(".") == -1))
                    {
                        DrEffRate = DrEffRate+".0";                   
                        DrEffRate = formatRate(DrEffRate) ;      // Calling Method
                    }
                    else
                    {
                        DrEffRate = formatRate(DrEffRate) ;    // Calling Method
                    }
                }
            
            }
            
            if(eventCode.equals("N0007"))
            { 
                CrEffRate = "";
                CrEffRate = StringUtils.leftPad(CrEffRate, 15, "0");
                DrEffRate = "";
                DrEffRate = StringUtils.leftPad(DrEffRate, 15, "0"); 
            }
                
            
        //Get Executive Name and Executive Telephone
              if(!codeExecutive.equals(""))
              {
                  try
                  {
                      DeptAcctOfficerRecord deptAcctOffRec = new DeptAcctOfficerRecord(da.getRecord("DEPT.ACCT.OFFICER", codeExecutive));   //Read DEPT.ACCT.OFFICER table and Get the fields NAME & TELERPHONE.NO 
                      executiveName = deptAcctOffRec.getName().getValue();
                      executiveTelephone = deptAcctOffRec.getTelephoneNo().getValue();
                  }
                  catch(Exception e6)
                  {
                      executiveName = "";
                      executiveTelephone = "";
                  }  
              }
              
            
              // Passing Stringutils values
              
              hdrCode = StringUtils.rightPad(hdrCode, 20, " ");
              eventCode = StringUtils.rightPad(eventCode, 5, " ");
              customerNo = StringUtils.rightPad(customerNo, 20, " ");
              customerName = StringUtils.rightPad(customerName, 120, " ");
              legalID = StringUtils.rightPad(legalID, 20, " ");
              email = StringUtils.rightPad(email, 50, " ");
              phoneNo = StringUtils.rightPad(phoneNo, 20, " ");
              hdrEventDate = StringUtils.rightPad(hdrEventDate, 8, "0");
              hdrEventTime = StringUtils.rightPad(hdrEventTime, 8, "0");
              AccountNo = StringUtils.rightPad(AccountNo, 30, " ");
              detCode = StringUtils.rightPad(detCode, 20, " "); 
              currency = StringUtils.rightPad(currency, 5, " ");
              amtInWrds = StringUtils.rightPad(amtInWrds, 120, " ");
              companyName = StringUtils.rightPad(companyName, 120, " ");
              transferType = StringUtils.rightPad(transferType, 20, " ");
              channel = StringUtils.rightPad(channel, 20, " ");
              bank = StringUtils.rightPad(bank, 50, " ");
              originAcNo = StringUtils.rightPad(originAcNo, 30, " ");
              desAcNo = StringUtils.rightPad(desAcNo, 30, " ");
              accountCode = StringUtils.rightPad(accountCode, 30, " ");
              codeProduct = StringUtils.rightPad(codeProduct, 30, " ");       
              companyCode = StringUtils.rightPad(companyCode, 5, " ");
              branchShortName = StringUtils.rightPad(branchShortName, 30, " ");
              codeExecutive = StringUtils.rightPad(codeExecutive, 5, " ");
              executiveName = StringUtils.rightPad(executiveName, 120, " ");
              executiveEmail = StringUtils.rightPad(executiveEmail, 50, " ");
              executiveTelephone = StringUtils.rightPad(executiveTelephone, 20, " ");
              checkNumber = StringUtils.rightPad(checkNumber, 30, " ");
              ccyCommisionCharged = StringUtils.rightPad(ccyCommisionCharged, 5, " ");
              ccyTaxCharged = StringUtils.rightPad(ccyTaxCharged, 5, " ");
              bciCommisionCcy = StringUtils.rightPad(bciCommisionCcy, 5, " ");
              ccyInterbankCommision = StringUtils.rightPad(ccyInterbankCommision, 5, " ");
              interbankCommisionAmt = StringUtils.leftPad(interbankCommisionAmt, 22, "0");
              ccyTotalChargeToAcc = StringUtils.rightPad(ccyTotalChargeToAcc, 5, " ");
              totAmtChargedToAcc = StringUtils.leftPad(totAmtChargedToAcc, 22, "0");
              openingDt = StringUtils.rightPad(openingDt, 8, "0");
              paymentDt = StringUtils.rightPad(paymentDt, 8, "0");
              transferComment = StringUtils.rightPad(transferComment, 150, " ");
              typeOfExpenses = StringUtils.rightPad(typeOfExpenses, 20, " ");
              address = StringUtils.rightPad(address, 30, " ");
              operationNo = StringUtils.rightPad(operationNo, 30, " ");
              customerCommunication = StringUtils.rightPad(customerCommunication, 150, " ");
              DrEffRate = StringUtils.leftPad(DrEffRate, 15, "0"); 
              debitBal = StringUtils.leftPad(debitBal, 15, "0");
              totCommissionExpenseCharged = StringUtils.leftPad(totCommissionExpenseCharged, 22, "0");   
              taxCollected = StringUtils.leftPad(taxCollected, 22, "0"); 
              bciCommisionAmt = StringUtils.leftPad(bciCommisionAmt, 22, "0");
              
            //Form Header Notice message    
              hdrNoticeMsg = hdrCode+eventCode+customerNo+customerName+legalID+email+phoneNo+hdrEventDate+hdrEventTime+AccountNo;
              
            // Form Detail Notice message
              detNoticeMsg = detCode+eventCode+currency+amtTransfer+amtInWrds+companyName+transferType+channel+bank+originAcNo+desAcNo+accountCode+codeProduct+CrEffRate+DrEffRate+treaRate+debitBal+companyCode+branchShortName+codeExecutive+executiveName+executiveEmail+executiveTelephone+checkNumber+ccyCommisionCharged+totCommissionExpenseCharged+ccyTaxCharged+taxCollected+bciCommisionCcy+bciCommisionAmt+ccyInterbankCommision+interbankCommisionAmt+ccyTotalChargeToAcc+totAmtChargedToAcc+openingDt+paymentDt+transferComment+typeOfExpenses+address+operationNo+customerCommunication;   
              
              // Form HeaderdetailNotice message
              hdrDetNoticeMsg = hdrNoticeMsg+"\n"+detNoticeMsg;
              
              //System.out.println("hdrDetNoticeMsg" +"   "+ hdrDetNoticeMsg);
                     
   //Pass the Header Notice and Detail Notice to third Party
              
              SoapClient soapClient = new SoapClient();
        try
        {
       //Pass the Header Notice and Detail Notice to third Party
            //soapResponse = soapClient.processT24Request(hdrDetNoticeMsg);  
            soapResponse = "TAMILPROCESSING200";
        
            //Update the Engageone details in EB.BCI.UPDATE.ENGEGONE.DETAILS table     
            if(!soapResponse.equals(""))
            {                                             
                //EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetRec = new EbBciUpdateEngageoneDetailsRecord(this);
                //EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetTable = new EbBciUpdateEngageoneDetailsTable(this);           
                
                try
                {
                    bciUpdEngageoneDetRec.setArragementId(arrId);
                    bciUpdEngageoneDetRec.setActivityName(currActivityId);
                    bciUpdEngageoneDetRec.setEventCode(eventCode);
                    bciUpdEngageoneDetRec.setRequestMessage(hdrDetNoticeMsg);         
                    
                 //For successful Response, Update the field ERROR.FLAG as No
                    if ((soapResponse.contains("PROCESSING") == true) && (soapResponse.contains("200") == true))
                    {                                                  
                        bciUpdEngageoneDetRec.setErrorFlag("No");                                         
                    }                    
                    
                 //For Failed Response, Update the field ERROR.FLAG as Yes
                    if ((soapResponse.contains("ERROR") == true) && (soapResponse.contains("200") == true))
                    {                        
                        bciUpdEngageoneDetRec.setErrorFlag("Yes");                                                                         
                    }  
                    
                    bciUpdEngageoneDetTable.write(bciUpdActivityDetsId, bciUpdEngageoneDetRec);
                }
                catch (Exception bciUpdEngErr) 
                {
                    bciUpdActivityDetsId = "";
                }
                   
            } 
        
        
        }
        
        //catch (IOException resErr) 
        catch(Exception e17)
        {
            return;
        }

        }
        
    }
    
  //Calling method
    
    public String formatRate(String a)
    {
        
        String a1 = a.split("\\.")[0];
        System.out.println(a1);

        a1 = StringUtils.leftPad(a1, 9, "0");
        System.out.println(a1);


        String b1 = a.split("\\.")[1];
        b1 = StringUtils.rightPad(b1, 6, "0");
        System.out.println(b1);

    String RateVal = a1+b1;

            return RateVal;
        }
    
    public String formatAmount(String amount)
    {
        
        String a1 = amount.split("\\.")[0];
        System.out.println(a1);

        a1 = StringUtils.leftPad(a1, 20, "0");
        System.out.println(a1);


        String b1 = amount.split("\\.")[1];
        b1 = StringUtils.rightPad(b1, 2, "0");
        System.out.println(b1);

    String amountVal = a1+b1;
    
            return amountVal;
        }
    
}
