package com.bci;

import java.text.SimpleDateFormat;
import java.util.List;
import java.text.ParseException;
import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaarrangement.CustomerClass;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.t24.api.records.company.CompanyRecord;
import com.temenos.t24.api.records.customer.ContactTypeClass;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.customer.LegalIdClass;
import com.temenos.t24.api.records.customer.Phone1Class;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import java.util.Date;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EventCodeClass;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsTable;
import com.temenos.t24.api.tables.ebbciupdatetransferactivitydetails.EbBciUpdateTransferActivityDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdatetransferactivitydetails.EbBciUpdateTransferActivityDetailsTable;

/**
*
*----------------------------------------------------------------------------------------------------------------
* Description           : AA routine to fetch required details and updated to local table
* Developed By          : Tamizharasi G,Techmill Technologies    
* Development Reference : IDD050_Interface_Reportes_Transfers
* Attached To           : ACTIVITY.API>GROUP.SUB.API-20210503 
* Attached As           : Post routine
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)     
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/

/**
 * TODO: Document me!
 *
 * @author tamizharasi.g
 *
 */
public class BciPostUpdateTransfersActivityDets extends ActivityLifecycle {

    @Override
    public void postCoreTableUpdate(AaAccountDetailsRecord accountDetailRecord,
            AaArrangementActivityRecord arrangementActivityRecord, ArrangementContext arrangementContext,
            AaArrangementRecord arrangementRecord, AaArrangementActivityRecord masterActivityRecord,
            TStructure productPropertyRecord, AaProductCatalogRecord productRecord, TStructure record,
            List<TransactionData> transactionData, List<TStructure> transactionRecord) {
        // TODO Auto-generated method stub
        
        String currAction = arrangementContext.getActivityStatus().toString();
        
        if(currAction.equals("AUTH")){
            
          String currActivityId = arrangementContext.getCurrentActivity().toString();
          
          DataAccess da = new DataAccess(this);
          Session se = new Session(this);
          
          int bciEngageoneIntRepParamRecFlag = 0;
          int cusFlag = 0;
          int cmpyFlag = 0;
          String eventCode = "";
          Date hdrEventDt ;
          String bciUpdActivityDetsId = "";
          String bank = "";
          String hdrEventTime = "";
          String cusNme = "";
          String captureDate = "";     
          String cmpy = "";
          String shrtName = "";
          String currency = "";
          String coCode = "";
          String activityId = "";
          String operationNo = "";
          
        //*------------------Fetch the details from AAA-----------------*//
          
  //Get the fields EVENT.CODE and HEADER.CODE from parameter table 
            
          EbBciEngageoneIntRepParamRecord bciEngageoneIntRepParamRec = null;            
          try
          {        
              bciEngageoneIntRepParamRec = new EbBciEngageoneIntRepParamRecord(da.getRecord("EB.BCI.ENGAGEONE.INT.REP.PARAM", "TRANSFERS"));              
          }
          catch(Exception e1)
          {
              bciEngageoneIntRepParamRecFlag = 1;
          }
            
          if(bciEngageoneIntRepParamRecFlag == 0)
          {
               List<EventCodeClass> eventCodeClsList = bciEngageoneIntRepParamRec.getEventCode();
              
               for(EventCodeClass eventCodeList : eventCodeClsList)
               {            
                   String actvityNameList = eventCodeList.getActivityName().toString();
                   if(actvityNameList.contains(currActivityId))
                   {
                       eventCode = eventCodeList.getEventCode().getValue();
                       break;
                   }                   
               }
          }  
               
     //Get effective date and date.time from AA.ARRANGEMENT.ACTIVITY table
     // Get Currency and operation number from AA.ARRANGEMENT.ACTIVITY table
                    
              operationNo = arrangementActivityRecord.getArrangement().getValue();
              activityId = arrangementContext.getArrangementActivityId().toString();                    
               
     //Update a details in EB.BCI.UPDATE.ENGEGONE.DETAILS table
          
              EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetRec = new EbBciUpdateEngageoneDetailsRecord(this);
              EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetTable = new EbBciUpdateEngageoneDetailsTable(this);  
          
          bciUpdActivityDetsId = operationNo+"-"+activityId+"-"+eventCode;
          
          
          bciUpdEngageoneDetRec.setEventCode(eventCode);
          bciUpdEngageoneDetRec.setArragementId(operationNo);
          bciUpdEngageoneDetRec.setActivityName(currActivityId);   
      
        //Write a record in EB.BCI.UPDATE.ENGEGONE.DETAILS table         
          try
          {
              bciUpdEngageoneDetTable.write(bciUpdActivityDetsId, bciUpdEngageoneDetRec);
          }
          catch(Exception e)
          {
              bciUpdEngageoneDetRec = null;
          }              
            
        }
        
    
    }

}
