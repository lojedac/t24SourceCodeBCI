package com.bci.loan.details;

import java.util.ArrayList;
import java.util.List;
import com.temenos.api.TDate;
import com.temenos.api.TStructure;
import com.temenos.api.exceptions.T24IOException;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentDueType;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentMethod;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentSchedule;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.t24.api.records.dates.DatesRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EventCodeClass;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsTable;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueDateClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueTypeClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.EbBciUpdateScheduleProjectorRecord;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.EbBciUpdateScheduleProjectorTable;

/**
 *
 * @author Tamizharasi G & Akshaya R
 * 
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *Description           : Updating Loan contract details and schedule details in to the local template
 *Developed By          : Tamizharasi G, Akshaya R & Preethi I, Techmill Technologies
 *Development Reference : IRD - 052
 *Attached To           : ACTIVITY.API
 *Attached as           : Post Routine
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *  M O D I F I C A T I O N S
 * ***************************        
 *-----------------------------------------------------------------------------------------------------------------
 * Defect Reference       Modified By                    Date of Change        Change Details
 * (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
 *-----------------------------------------------------------------------------------------------------------------
 * XXXX                   <<name of modifier>>                                 <<modification details goes here>>
 *-----------------------------------------------------------------------------------------------------------------
 * Include files
 *-----------------------------------------------------------------------------------------------------------------
 *   
 */ 

public class BciPostUpdateLoanOffline extends ActivityLifecycle {

    @Override
    public void postCoreTableUpdate(AaAccountDetailsRecord accountDetailRecord,
            AaArrangementActivityRecord arrangementActivityRecord, ArrangementContext arrangementContext,
            AaArrangementRecord arrangementRecord, AaArrangementActivityRecord masterActivityRecord,
            TStructure productPropertyRecord, AaProductCatalogRecord productRecord, TStructure record,
            List<TransactionData> transactionData, List<TStructure> transactionRecord) {        
        
         String currAction =  arrangementContext.getActivityStatus().toString();
         if(currAction.equals("AUTH"))
         { 
             int bciEngageoneIntRepParamRecFlag = 0;
             String eventCode = "";
             String bciUpdEngageoneDetsId = "";
             String operationNo  = "";
             String aaStartDate = "";
             int dutDateCnt = 0;
             String dueTypeListStr = "";
             int startCnt = 0;
             String today = "";
             int updateRecFlg = 0;
             DataAccess da = new DataAccess(this);
             Session session = new Session(this);
             List<RepaymentSchedule> repaymentScheduleList = null;
             
             String activityName = arrangementContext.getCurrentActivity().toString();
             String aaaId = arrangementContext.getArrangementActivityId();
             operationNo = arrangementActivityRecord.getArrangement().getValue(); 
 
       //Get Today Date
             try
             {
                 String dateId = session.getCompanyId() + "-COB";
                 DatesRecord dateRec = new DatesRecord(da.getRecord("DATES",dateId));
                 today = dateRec.getToday().getValue();
             }
             catch(Exception todayErr)
             {
                 today = ""; 
             }
                   
             if(activityName.equals("LENDING-UPDATE.APR-ACCOUNT"))
             {
                 bciUpdEngageoneDetsId = operationNo+"-"+aaaId;    //Form @ID of schedule table
             }
             else
             {
              //Get the fields EVENT.CODE from parameter table            
                 EbBciEngageoneIntRepParamRecord bciEngageoneIntRepParamRec = null;
                 
                 try 
                 {
                     bciEngageoneIntRepParamRec = new EbBciEngageoneIntRepParamRecord(da.getRecord("EB.BCI.ENGAGEONE.INT.REP.PARAM", "LOAN.OFFLINE.DET"));                 
                 } 
                 catch (Exception bciEngageoneIntRepParamErr)
                 {
                    bciEngageoneIntRepParamRecFlag = 1;
                 }
                    
                 if(bciEngageoneIntRepParamRecFlag == 0)
                 {
                      List<EventCodeClass> eventCodeClsList = bciEngageoneIntRepParamRec.getEventCode();
                      
                      for(EventCodeClass eventCodeList : eventCodeClsList)
                      {             
                          String actvityNameList = eventCodeList.getActivityName().toString();
                          if(actvityNameList.contains(activityName))
                          {
                              eventCode = eventCodeList.getEventCode().getValue();
                              break;
                          }                    
                      }
                 }    
                 bciUpdEngageoneDetsId = operationNo+"-"+aaaId+"-"+eventCode;   //Form @ID of local tables
             }
      
                        
  //----------------------- Write a record in EB.BCI.UPDATE.ENGAGEONE.DETAILS table --------------------------------//


             EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetsRec = new EbBciUpdateEngageoneDetailsRecord(this);        
             EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetsTable= new EbBciUpdateEngageoneDetailsTable(this);           
            
             bciUpdEngageoneDetsRec.setArragementId(operationNo);
             bciUpdEngageoneDetsRec.setEventCode(eventCode);
             bciUpdEngageoneDetsRec.setActivityName(activityName);
             
          
 //----------------------- Update the AA.SCHEDULE.PROJECTOR api values to local table EB.BCI.UPDATE.SCHEDULE.PROJECTOR --------------------------------//
             
             Contract contract = new Contract(this);
             EbBciUpdateScheduleProjectorTable schProjTable = new EbBciUpdateScheduleProjectorTable(this);            
             EbBciUpdateScheduleProjectorRecord scheduleRec = new EbBciUpdateScheduleProjectorRecord();
             String scheduleProjectorRecId = bciUpdEngageoneDetsId;
 
             contract.setContractId(operationNo);            
             try
             {
                 aaStartDate = contract.getContract().getStartDate().getValue();
                 TDate startDate = new TDate(aaStartDate);
                 TDate endDate = contract.getMaturityDate();   
                 
                 repaymentScheduleList = contract.getRepaymentSchedule(startDate, endDate);
                 
                 int i = 0;
                 for(RepaymentSchedule repaymentSchedule :repaymentScheduleList)              
                 {
                     DueDateClass dueDateCls = new DueDateClass();
                     dueDateCls.setDueDate(repaymentSchedule.getDueDate().get());
                     dueDateCls.setDueOutstandingBalance(repaymentSchedule.getDueOutstandingBalance().get());
                     
                     List<RepaymentDueType> repayDueTypeClsList = new ArrayList<RepaymentDueType>();
                     repayDueTypeClsList = repaymentSchedule.getRepaymentDueType();
                     int j = 0;
                     for(RepaymentDueType repayDueTypeCls : repayDueTypeClsList)
                     {
                         DueTypeClass dueTypeCls = new DueTypeClass();
                         dueTypeCls.setDueType(repayDueTypeCls.getDueType());
                         dueTypeCls.setDueTypeAmount(repayDueTypeCls.getDueTypeAmount().get());
                         
                         String repayduemethod = "";
                         String repayDueprop = "";
                         String repayDuePropAmt = "";
                         List<RepaymentMethod> repayMethodClsList = new ArrayList<RepaymentMethod>();
                         repayMethodClsList = repayDueTypeCls.getRepaymentMethod();
                         
                         int k = 1;
                         for(RepaymentMethod repayMethodCls : repayMethodClsList)        //Extract Repayment Method value and make it as String
                         {
                             String dueMethodStr = "";
                             String DuePropertyStr = "";
                             String DuePropertyAmountStr = "";
                             
                             dueMethodStr = repayMethodCls.getDueMethod();
                             DuePropertyStr = repayMethodCls.getDueProperty();
                             DuePropertyAmountStr = repayMethodCls.getDuePropertyAmount();
                             
                             if(k == repayMethodClsList.size()) 
                             {
                                 repayduemethod = repayduemethod + dueMethodStr;
                                 repayDueprop = repayDueprop + DuePropertyStr;
                                 repayDuePropAmt = repayDuePropAmt + DuePropertyAmountStr;
                             }
                             else
                             {
                                 repayduemethod = repayduemethod + dueMethodStr + '/';        //Split the Due method, Due property and Due property amount by given '/'
                                 repayDueprop = repayDueprop + DuePropertyStr + '/';
                                 repayDuePropAmt = repayDuePropAmt + DuePropertyAmountStr + "/";
                             }                           
                             k++;
                         }
                         
                         dueTypeCls.setDueMethod(repayduemethod);
                         dueTypeCls.setDueProperty(repayDueprop);
                         dueTypeCls.setDuePropertyAmount(repayDuePropAmt);           
                         
                         dueDateCls.setDueType(dueTypeCls,j);         //Set Due Type, Due type amount and Repayment Method
                         j++;
                     }                 
                    
                     scheduleRec.setDueDate(dueDateCls,i); 
                     i++;
                 }
                 
                 try
                 {
                    schProjTable.write(scheduleProjectorRecId, scheduleRec);
                 } 
                 catch (T24IOException schProjTableErr)
                 {
                     schProjTableErr.getMessage();
                 }
             }
             catch(Exception scheduleRecErr)
             {
                 scheduleRecErr.getMessage();
             }
             
  //---------------------------------------------------------------------------------------------------------
             
           if(!activityName.equals("LENDING-UPDATE.APR-ACCOUNT"))
           {
               if(eventCode.equals("C0004") && (!activityName.equals("LENDING-APPLYPAYMENT-PR.DUE.PAYMENT")) && (!activityName.equals("LENDING-SETTLE-PR.REPAYMENT")))
               {
                 //Read schedule projector details from local table
                   EbBciUpdateScheduleProjectorRecord scheduleRecord = new EbBciUpdateScheduleProjectorRecord();
                   try
                   {
                       scheduleRecord = new EbBciUpdateScheduleProjectorRecord(da.getRecord("EB.BCI.UPDATE.SCHEDULE.PROJECTOR", bciUpdEngageoneDetsId));
                       
                       List<DueDateClass> dueDateList = scheduleRecord.getDueDate();  
                       dutDateCnt = dueDateList.size();
                       dueTypeListStr = scheduleRecord.getDueDate(0).getDueType().toString();
                     
                       if(!dueTypeListStr.contains("DISBURSEMENT.%"))
                       {
                           startCnt = 0; 
                       }
                       else
                       {
                           startCnt = 1;
                       }
                     
                       for(int k=startCnt; k<dutDateCnt; k++)
                       {                  
                           String dueDate = dueDateList.get(k).getDueDate().getValue();
                           if(dueDate.equals(today))
                           {
                               updateRecFlg = 1;
                               break;
                           }
                       }
                   }
                   catch(Exception scheduleRecordErr)
                   {
                       scheduleRecordErr.getMessage();
                   }
               }
               else 
               {
                   updateRecFlg = 1;
               }
           }
           
           if(updateRecFlg == 1)
           {
               try
               {
                   bciUpdEngageoneDetsTable.write(bciUpdEngageoneDetsId, bciUpdEngageoneDetsRec);
               }
               catch(Exception e2)
               {
                   e2.getMessage();
               }
           }
       }                              
   }
}
