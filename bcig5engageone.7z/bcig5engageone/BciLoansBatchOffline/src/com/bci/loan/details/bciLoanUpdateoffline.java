package com.bci.loan.details;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.commons.lang3.StringUtils;
import com.temenos.api.TField;
import com.temenos.api.TNumber;
import com.temenos.api.TStructure;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.aa.contractapi.BalanceMovement;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import com.temenos.t24.api.complex.eb.servicehook.SynchronousTransactionData;
import com.temenos.t24.api.complex.eb.servicehook.TransactionControl;
import com.temenos.t24.api.hook.system.ServiceLifecycle;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaaccountdetails.RepayReferenceClass;
import com.temenos.t24.api.records.aaactivityhistory.AaActivityHistoryRecord;
import com.temenos.t24.api.records.aaactivityhistory.ActivityConRefClass;
import com.temenos.t24.api.records.aaactivityhistory.ActivityRefClass;
import com.temenos.t24.api.records.aaactivityhistory.EffectiveDateClass;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aabilldetails.AaBillDetailsRecord;
import com.temenos.t24.api.records.aabilldetails.BillStatusClass;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.t24.api.records.aaprddesaccount.AprTypeClass;
import com.temenos.t24.api.records.aaprddescharge.AaPrdDesChargeRecord;
import com.temenos.t24.api.records.aaprddesinterest.AaPrdDesInterestRecord;
import com.temenos.t24.api.records.aaprddesinterest.FixedRateClass;
import com.temenos.t24.api.records.aaprddeslimit.AaPrdDesLimitRecord;
import com.temenos.t24.api.records.aaprddesofficers.AaPrdDesOfficersRecord;
import com.temenos.t24.api.records.aaprddespaymentschedule.AaPrdDesPaymentScheduleRecord;
import com.temenos.t24.api.records.aaprddespaymentschedule.PaymentTypeClass;
import com.temenos.t24.api.records.aaprddespaymentschedule.PropertyClass;
import com.temenos.t24.api.records.aaprddessettlement.AaPrdDesSettlementRecord;
import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import com.temenos.t24.api.records.aaproperty.AaPropertyRecord;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.company.CompanyRecord;
import com.temenos.t24.api.records.customer.AddressClass;
import com.temenos.t24.api.records.customer.ContactTypeClass;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.customer.LegalIdClass;
import com.temenos.t24.api.records.customer.Phone1Class;
import com.temenos.t24.api.records.dates.DatesRecord;
import com.temenos.t24.api.records.deptacctofficer.DeptAcctOfficerRecord;
import com.temenos.t24.api.records.ebcashflow.EbCashflowRecord;
import com.temenos.t24.api.records.limit.CollateralCodeClass;
import com.temenos.t24.api.records.limit.LimitRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebbciengageonegenfilepath.EbBciEngageoneGenFilePathRecord;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsTable;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueDateClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueTypeClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.EbBciUpdateScheduleProjectorRecord;

/**
 *
 * @author Tamizharasi G & Akshaya R
 * 
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *Description           : Updating Loan contract details into a text for the events C0002,C0003,C0004 and N0011 based on the activity triggered
 *Developed By          : Tamizharasi G, Akshaya R & Preethi I, Techmill Technologies
 *Development Reference : IRD - 052
 *Attached To           : Batch
 *Attached as           : service and COB Routine
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *  M O D I F I C A T I O N S
 * ***************************        
 *-----------------------------------------------------------------------------------------------------------------
 * Defect Reference       Modified By                    Date of Change        Change Details
 * (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
 *-----------------------------------------------------------------------------------------------------------------
 * XXXX                   <<name of modifier>>                                 <<modification details goes here>>
 *-----------------------------------------------------------------------------------------------------------------
 * Include files
 *-----------------------------------------------------------------------------------------------------------------
 *   
 */ 

public class bciLoanUpdateoffline extends ServiceLifecycle {
   
    public List<String> getIds(ServiceData serviceData, List<String> controlList) {


     //*------------ Select the records from EB.BCI.UPDATE.ENGAGEONE.DETAILS ----------------*//
        
        DataAccess fRead = new DataAccess(this);             
        List<String> bciUpdateEngageoneDetsList = new ArrayList<String>();
        
        String selCmd = "WITH (REQUEST.MESSAGE EQ '') AND ((EVENT.CODE EQ 'C0002') OR (EVENT.CODE EQ 'C0003') OR (EVENT.CODE EQ 'C0004') OR (EVENT.CODE EQ 'N0011'))";
        try            
        {
            bciUpdateEngageoneDetsList = fRead.selectRecords("","EB.BCI.UPDATE.ENGAGEONE.DETAILS","",selCmd); 
        } 
        catch (Exception e) 
        {   
            bciUpdateEngageoneDetsList.clear();        
        }                                                
        return bciUpdateEngageoneDetsList;
    }

   //*------------ Process----------------*//  
    
    public void updateRecord(String id, ServiceData serviceData, String controlItem,
            TransactionControl transactionControl, List<SynchronousTransactionData> transactionData,
            List<TStructure> records) {
        // TODO Auto-generated method stub
        
       
        DataAccess da = new DataAccess(this);
        Contract contract = new Contract(this);   
        Session session = new Session(this);
        List<String> actDate = new ArrayList<String>(); 

        int flag = 0;
        String bciUpdEngageoneDetsId = id; 
        
        EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetsRec = null;        
        EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetsTable= new EbBciUpdateEngageoneDetailsTable(this);
      
        try
        {
            bciUpdEngageoneDetsRec = new EbBciUpdateEngageoneDetailsRecord(da.getRecord("EB.BCI.UPDATE.ENGAGEONE.DETAILS", bciUpdEngageoneDetsId));  
        }        
        catch(Exception e)
        {   
            flag = 1;
        } 
        
        if(flag == 0)
        {
          //Initialize the Variable
            String eventCode = "";
            String hdrCode = "";
            String aaaId = "";
            String activityName = "";
            int cusFlag = 0;
            String phoneNo = "";                    
            int addressCnt = 0;
            String address = "";
            String email = "";
            String customerCommunication = "";
            String hdrEventDate = "";
            String aaaDateTime = "";
            String hdrEventTime = "";          
            String codeProduct = "";
            String operationNo  = "";
            String currency = "";
            String executiveEmail = "";
            int productDescriptLen = 0;
            String productDescript = "";
            String termVal = "";
            char unitTermChar;
            String establishTerm = "";
            String unitestablishTerm = "";         
            String companyId = "";
            String branchShortName = "";
            String codeExecutive = "";
            String executiveName  = "";
            String executiveTelephone = "";       
            String accountNo = "";            
            String detCode01 = "";
            String detCode02 = "";
            String detCode03 = "";
            String detCode04 = "";
            String detCode05 = "";
            String hdrNoticeMsg = "";
            String hdrDetNoticeMsg = "";
            String detNoticeD01Msg = "";
            String detNoticeD02Msg = "";
            String detNoticeD03Msg = "";
            String detNoticeD04Msg = "";
            String detNoticeD05Msg = "";
            String loanNo = "";
            String noOfD02Recs = "";
            String noOfD03Recs = "";
            String noOfD04Recs = "";
            String noOfD05Recs = "";
            String customerNo1 = "";
            String customerNo2 = "";
            String customerNo3 = "";
            String customerNo4 = "";
            String customerNo5 = "";
            String legalID1 = "";
            String legalID2 = "";
            String legalID3 = "";
            String legalID4 = "";
            String legalID5 = "";
            String customerName1 = "";
            String customerName2 = "";
            String customerName3 = "";
            String customerName4 = "";
            String customerName5 = "";
            String dateOfOperation = "";
            String effectiveDate = "";
            String orgSystemDate = "";
            String maturityDate = "";
            String txnAmount = "";
            String dueType = ""; 
            String principalBalLoan = "";
            int dutDateCnt = 0;
            String dueProperty = "";
            String duePropertyAmt = "";              
            int repayDueTypeCnt = 0;
            String propertyDes = "";
            String installmentDatePaid = "";
            String nextInstallmentExpireDate = "";
            String nextInstallmentduePay = "";
            String firstLoanInstallmentDate = "";
            String commissionDetails = "";
            String paymentScheduleDetails = "";
            String annualAmtLoanPrincipalInstallment = "";
            String annualAmtLoanInterestInstallment = "";
            int totalAmtInstallmentDueLoanInt = 0;
            String totalAmtInstallmentDueLoan = "";
            String totalLoanInstallment = "";
            String dtVal = "";
            String bench = "";
            String bankOfficeCode = "";
            String paymentType = "";
            String paymentMethodPaidEvent = "";
            String formSubmissionStatement = "";
            String noOfEvent = "";
            String noOfInstallmentPaid = "";
            String timeOfOperation = "";
            String loanCcyPreCondition = "";
            String totFeeAmtCancel = "";
            String principalAmtCancel = "";
            String feeInterestCancel = "";
            String principalAmtFeeCancelInterest = "";
            String amtCancelFee = "";
            String totalAmtFeeCancelInsurance = "";
            String secureAmtFeeReliefCancel = "";
            String amtInsuranceFeeCancel = "";
            String amtFeeCancel = "";
            String amtITFCancel = "";
            String amtOtherConceptFeeCancel = "";
            String amtConceptOtherPrincipalIntFeeCancelInsurance = "";
            String comment = "";
            String dateOfGrantLoan = "";
            String Loandisbursementdate = "";
            String dateOfLastModifyLoanTerms = "";
            String finalMaturityDateLoan = "";
            String finalMaturityDateLoanPreCondition = "";
            String unitTermLoanExpressPreCondition = "";
            String termLoanPreCondition = "";
            String propertyName = "";
            String paymentFreq = "";
            String periodicityLoanCapitalInstallment = "";
            String periodicityInterestInstallmentLoan = "";
            String unitGracePeriod = "";
            String loanGracePeriod = "";
            String codeTypeGuaranteeLoan = "";
            String typeLoanGuarantee = "";
            String typeLoanGuaranteePreCondition = "";
            String interestRatePreCondition = "";
            String limitRef = "";
            String interestRateType = "";
            String annualEffectiveInterestRateTEA = "";
            String annualEffectiveInterestRateTEAPreCondition = "";
            String annualEffectiveCostRateTCEA = "";
            String annualEffectiveCostRateTCEAPreCondition = "";    
            String loanFeeType = "";
            String collectionLoanGracePeriod = "";
            String loanGracePeriodAmt = "";
            String penaltyNonPayment = "";
            String penaltyNonPaymentPreCondition = "";
            String totalAmtGrantLoan = "";
            String totalAmtGrantLoanPreCondition = "";
            String totalPrincipalAmtLoan = "";
            String totalPrincipalAmtLoanPreCondition = "";
            String totalAmtLoanInstallmentPreCondition = "";
            String totalNoUnpaidDueYear = "";
            String totalAmtInstallmentCancelLoan = "";
            String additionInsuranceContract = "";
            String additionInsuranceContractPreCondition = "";
            String payInAccountNo = "";
            String payInAccountCcy = "";   
            String paymentMethod = "";
            String loanFilePath = "";
            String minDate = "";
            String actvityConfRef = "";
            String actName = "";
            int duePropertyCnt = 0;
            String dueTypeListStr = "";
            String commissionDets = "";
            String expenseDets = "";
            String duePropertyVal = "";
            String propertyDesVal = "";
            int expenseD05Cnt = 0;
            int expenseFlg = 0;
            String expenseDetails = "";
            int commissionFlg = 0;
            int commissionD03Cnt = 0;
            int commissionAddFlg = 0;
            int expenseAddFlg = 0;
            String interestRateCurVal = "";
            int negotiationCurCnt = 0;
            String dtTime = "";
            double expenseAmtFeeDbl = 0;
            double duePropertyAmtDbl = 0;
            String actvityPropertyName = "";
            String flagTodayDue = "";
            String chrgDueType = "";
            String dtValue = "";
            String fixedRateVal = "";
            String floatingIndexVal = ""; 
            String fixedRatePreVal = "";
            String floatingIndexPreVal = ""; 
            int dtValueInt = 0;  
            int effValInt = 0;
            int noduedt = 0;
            String bciScheduleProjectorApiID = "";
            int scheduleProjectorFlg = 0;
            int annualBreakFlg = 0;
            int annualAmtLoanInterestInstallmentInt = 0;
            int annualAmtLoanPrincipalInstallmentInt = 0;
            String fstAnnualDueDate = "";
            int lastAnnualYearInt = 0;
            String lastAnnualDueDate = "";
            String dueDate = "";
            String today = "";
            List<DueDateClass> dueDateList = new ArrayList<DueDateClass>();
            List<String> billIdDateList = new ArrayList<String>();
            int billIdDateListCnt = 0;
            
   //*------------------------------------------------------------------------------------------------------------------------------*//
       
         //Get the EventCode and Arrangement ID from EB.BCI.UPDATE.ENGAGEONE.DETAILS table          
            eventCode = bciUpdEngageoneDetsRec.getEventCode().getValue();
            operationNo = bciUpdEngageoneDetsRec.getArragementId().getValue();
            activityName = bciUpdEngageoneDetsRec.getActivityName().getValue();
            aaaId = bciUpdEngageoneDetsId.split("-")[1];
            actvityPropertyName = activityName.split("-")[2];
            
            contract.setContractId(operationNo);   //Set Contract Id to Arrangement
            
            if(activityName.equals("LENDING-APPLYPAYMENT-PR.DUE.PAYMENT") || activityName.equals("LENDING-SETTLE-PR.REPAYMENT"))
            {
                try         
                {  
                    AaActivityHistoryRecord aaActivityHisRec = new AaActivityHistoryRecord(da.getRecord("AA.ACTIVITY.HISTORY", operationNo));            
                    List<EffectiveDateClass> effctiveDateClassList = aaActivityHisRec.getEffectiveDate();
                        
                    for(EffectiveDateClass effctiveDateList : effctiveDateClassList)
                    {
                        List<ActivityRefClass> activityRefClassList = effctiveDateList.getActivityRef();
                        int activityRefClassListSize = activityRefClassList.size();
                        
                        for(int r=0; r<activityRefClassListSize; r++)
                        {
                            String aaActivity = activityRefClassList.get(r).getActivity().getValue();
                            String activityRef = activityRefClassList.get(r).getActivityRef().getValue();
                          
                            if((activityRef.equals(aaaId)) && (aaActivity.equals(activityName)))
                            {
                                for(int s=r-1; s>=0; s--)
                                {
                                    String aaActivityAPRAcct = activityRefClassList.get(s).getActivity().getValue();
                                    
                                    if(aaActivityAPRAcct.equals("LENDING-UPDATE.APR-ACCOUNT"))
                                    {
                                        String activityRefAPRAcct = activityRefClassList.get(s).getActivityRef().getValue();
                                        bciScheduleProjectorApiID = operationNo+"-"+activityRefAPRAcct;
                                        break;
                                    }
                                }
                            }
                            if(!bciScheduleProjectorApiID.equals(""))
                            {
                                break;
                            }
                        }
                        if(!bciScheduleProjectorApiID.equals(""))
                        {
                            break;
                        }
                    }
                }  
                catch(Exception aaActHisErr) 
                {
                    bciScheduleProjectorApiID = bciUpdEngageoneDetsId;
                }   
            }
            else
            {
                bciScheduleProjectorApiID = bciUpdEngageoneDetsId;
            }
        
         //Read EB.BCI.UPDATE.SCHEDULE.PROJECTOR record (Get the AA.SCHEDULE.PROJECTOR api values)
            EbBciUpdateScheduleProjectorRecord scheduleProjectorRec = null;
            try
            {
                scheduleProjectorRec = new EbBciUpdateScheduleProjectorRecord(da.getRecord("EB.BCI.UPDATE.SCHEDULE.PROJECTOR", bciScheduleProjectorApiID));    
            }
            catch(Exception scheduleProjectorErr)
            {
                scheduleProjectorFlg = 1;
            }
            
         //Get the Header Code and Detail Code from EB.BCI.ENGAGEONE.INT.REP.PARAM table 
            EbBciEngageoneIntRepParamRecord bciEngageoneIntRepParamRec = null;  
            try
            {        
                bciEngageoneIntRepParamRec = new EbBciEngageoneIntRepParamRecord(da.getRecord("EB.BCI.ENGAGEONE.INT.REP.PARAM", "LOAN.OFFLINE.DET"));
                hdrCode = bciEngageoneIntRepParamRec.getHeaderCode(0).getValue();
                detCode01 = bciEngageoneIntRepParamRec.getDetailCode(0).getValue();
                detCode02 = bciEngageoneIntRepParamRec.getDetailCode(1).getValue();
                detCode03 = bciEngageoneIntRepParamRec.getDetailCode(2).getValue();
                detCode04 = bciEngageoneIntRepParamRec.getDetailCode(3).getValue();
                detCode05 = bciEngageoneIntRepParamRec.getDetailCode(4).getValue();
            }
            catch(Exception engageRecErr)
            {
                detCode05 = "";
            }
      
       //Get the customer Number, Currency, Start Date    
            AaArrangementRecord arrRec = null;          
            try
            {
                arrRec = new AaArrangementRecord(da.getRecord("AA.ARRANGEMENT", operationNo));
                customerNo1 = arrRec.getCustomer(0).getCustomer().getValue();
                currency = arrRec.getCurrency().getValue();
                loanCcyPreCondition = currency;
                accountNo = arrRec.getLinkedAppl(0).getLinkedApplId().getValue();
                loanNo = accountNo;
            }
            catch(Exception arrErr)
            {
                loanNo = "";
            }
            
        //Fetch TCEA field 
            EbCashflowRecord ebCashFlowRec = null;
            try
            {
                ebCashFlowRec = new EbCashflowRecord(da.getRecord("EB.CASHFLOW", accountNo));
                annualEffectiveCostRateTCEA = ebCashFlowRec.getCalcType().get(0).getCalcRate().getValue();
            }
            catch(Exception e3)
            {
                annualEffectiveCostRateTCEA = "";
            }
            
        //Get TODAY date Using session
            try
            {
                String dateId = session.getCompanyId() + "-COB";
                DatesRecord dateRec = new DatesRecord(da.getRecord("DATES",dateId));
                today = dateRec.getToday().getValue();
                dtValue = today;
            }
            catch(Exception datesErr)
            {
                today = "";
            }
            
          //Read CUSTOMER table
            CustomerRecord cusRec = null;
            try
            {  
                cusRec = new CustomerRecord(da.getRecord("CUSTOMER", customerNo1));
            }
            catch(Exception cusErr)
            {
                cusFlag = 1;
            }
               
            if(cusFlag == 0)
            {
                customerName1 = cusRec.getShortName(0).getValue();

            //Get the field LEGAL.ID from customer table       
                List<LegalIdClass> legalIdlist = cusRec.getLegalId();            
                if(!legalIdlist.isEmpty()){
                    legalID1 = legalIdlist.get(0).getLegalId().getValue();      
                }                
                   
           //Get the fields PHONE.1 and EMAIL.1 from customer table 
                List<Phone1Class> phoneList = cusRec.getPhone1();             
                if(!phoneList.isEmpty())
                {
                   phoneNo = phoneList.get(0).getPhone1().getValue();
                   email = phoneList.get(0).getEmail1().getValue();
                }
                   
             //Get the field ADDRESS from customer table 
                List<AddressClass> addressList = cusRec.getAddress();
                if(!addressList.isEmpty())
                {
                    addressCnt = addressList.size();
                    for(int i=0; i<addressCnt; i++)
                    {
                        String add = cusRec.getAddress().get(i).get(0).getValue();                   
                        String ad = add.concat(",");
                        address = address.concat(ad);
                    }
                    address = address.substring(0, address.length()-1);         
                }                 
                  
            //Get the field CONTACT.DATA from customer table 
                List<ContactTypeClass> contactTypecList = cusRec.getContactType();            
                if(!contactTypecList.isEmpty()){
                   customerCommunication =  contactTypecList.get(0).getContactData().getValue();
                }
            }         
            
           //Get Header ORG.SYSTEM.DATE, Event Date and Event Time (DATE.TIME)           
               AaArrangementActivityRecord aaaRec = null;          
               try
               {
                   aaaRec = new AaArrangementActivityRecord(da.getRecord("AA.ARRANGEMENT.ACTIVITY", aaaId));
                   orgSystemDate = aaaRec.getOrgSystemDate().getValue();
                   effectiveDate = aaaRec.getEffectiveDate().getValue();
                   
                   aaaDateTime = aaaRec.getDateTime(0);
                   hdrEventDate = "20"+aaaDateTime.substring(0,6);
                   hdrEventTime = aaaDateTime.substring(6)+"00"; 
               }
               catch(Exception aaaErr)
               {
                   hdrEventTime = "";
               }
               
                              
            //Get the value of the field Disbursement Date from AA.ACTIVITY.HISTORY 
               try
               {
                    AaActivityHistoryRecord aaActivityHisRec = new AaActivityHistoryRecord(da.getRecord("AA.ACTIVITY.HISTORY", operationNo));            
                    List<ActivityConRefClass> actvityConRefList = aaActivityHisRec.getActivityConRef();
              
                    for(ActivityConRefClass activityRefList : actvityConRefList)
                    {
                        actvityConfRef = activityRefList.getActivityConRef().getValue();
                        actName = "LENDING-AUTO.DISBURSE-COMMITMENT#@#TXN.AMOUNT";
                        if(actvityConfRef.equals(actName))
                        {
                            actDate.add(activityRefList.getActDate().get(0).getActDate().toString());
                        }
                    }
                    minDate = Collections.min(actDate);
               }
               catch(Exception e1)
               {
                   minDate = "";
               }
              
             
           //Get Company ID and Company Name
                companyId = session.getCompanyId();
                    
                int companyIdLen = companyId.length();
                if(companyIdLen >= 5)
                {
                    bankOfficeCode = companyId.substring(0, 5);
                } 
                                      
                try
                {
                    CompanyRecord companyRec = new CompanyRecord(da.getRecord("COMPANY", companyId));   //Read COMPANY table and Get the value of NAME field 
                    bench = companyRec.getCompanyName(0).getValue();
                    branchShortName = bench;
                        
                    int branchShortNameLen = bench.length();
                    if(branchShortNameLen >= 30)
                    {
                        branchShortName = branchShortName.substring(0, 30);
                    }                     
                }
                catch(Exception companyErr)
                {
                    branchShortName = "";
                }     
                
           //Get Code Executive           
                AaPrdDesOfficersRecord aaPrdDesOfficerRec = null;
                try
                {
                    aaPrdDesOfficerRec = new AaPrdDesOfficersRecord(contract.getConditionForProperty("OFFICERS"));
                    codeExecutive = aaPrdDesOfficerRec.getPrimaryOfficer().getValue(); 
                }
                catch(Exception offErr)
                {
                    codeExecutive = "";
                }
                     
            //Get Executive Name and Executive Telephone
                 if(!codeExecutive.equals(""))
                 {
                     try
                     {
                         DeptAcctOfficerRecord deptAcctOffRec = new DeptAcctOfficerRecord(da.getRecord("DEPT.ACCT.OFFICER", codeExecutive));   //Read DEPT.ACCT.OFFICER table and Get the fields NAME & TELERPHONE.NO 
                         executiveName = deptAcctOffRec.getName().getValue();
                         executiveTelephone = deptAcctOffRec.getTelephoneNo().getValue();
                     }
                     catch(Exception deptOffErr)
                     {
                         executiveName = "";
                         executiveTelephone = "";
                     }                  
                 } 
            
             //Get the value of the fields CATEGORY and ACCOUNT.TITLE.1 from AA.ARR.ACCOUNT table
                 AaPrdDesAccountRecord aaPrdDesAcctRec = null;
                 try
                 {
                     aaPrdDesAcctRec = new AaPrdDesAccountRecord(contract.getConditionForProperty("ACCOUNT"));
                     codeProduct = aaPrdDesAcctRec.getCategory().getValue();           
                     productDescript = aaPrdDesAcctRec.getAccountTitle1().get(0).getValue(); 
                     productDescriptLen = productDescript.length();
                    
                     if(productDescriptLen >= 30)
                     {
                         productDescript = productDescript.substring(0, 30);
                     }
                    
                     if(eventCode.equals("C0003"))
                     {
                         String currnocnt=aaPrdDesAcctRec.getCurrNo();
                         int curcnt=Integer.parseInt(currnocnt);
                         if (curcnt >1 )
                         {
                             dateOfLastModifyLoanTerms = aaPrdDesAcctRec.getAuditDateTime();
                         }    
                     }
                 }
                 catch(Exception aaArrAccErr)
                 {
                     aaArrAccErr.getMessage();              
                 }   
                 
                 
              //Get loanGracePeriod, Periodicity loan Capital Installment and Periodicity Interest Installment loan from AA.ARR.PAYMENT.SCHEDULE Details 
                 unitGracePeriod = "DIAS";
                 AaPrdDesPaymentScheduleRecord AaPrdDesPaymentScheduleRec = null;
                 try
                 {
                     AaPrdDesPaymentScheduleRec = new AaPrdDesPaymentScheduleRecord(contract.getConditionForProperty("SCHEDULE"));                     
                     List<PaymentTypeClass> paymentTypeList = AaPrdDesPaymentScheduleRec.getPaymentType();                            
                     int a  = paymentTypeList.size();
                                  
                     for(int i=0; i<a; i++)
                     {
                   //Get Unit Grace period and Loan grace period
                         String billType = "";
                         String paymentBillStartDate = "";
                         String principalBillStartDt = "";
                         String interestBillStartDt = "";
                         
                         billType = paymentTypeList.get(i).getBillType().getValue();     
                                            
                         if((billType.equals("INSTALLMENT")) && (loanGracePeriod.equals("")))
                         {                                 
                             String daysUnit = "";
                             char unitGracePeriodChar;
                             String BillStartDate = "";
                             try
                             {
                                 paymentBillStartDate = paymentTypeList.get(i).getPercentage(0).getStartDate().getValue(); 
                             }
                             catch(Exception payStartDtErr)
                             {
                                 paymentBillStartDate = "";
                             }
                               
                             if(!paymentBillStartDate.equals(""))
                             {

                                 if(!paymentBillStartDate.contains("+"))
                                 {
                                     if (paymentBillStartDate.length() > 8) 
                                     {
                                         BillStartDate = paymentBillStartDate.substring(paymentBillStartDate.length() - 8);
                                     } 
                                     else
                                     {
                                         BillStartDate = paymentBillStartDate;
                                     }
                                     
                                     SimpleDateFormat format2 = new SimpleDateFormat("yyyyMMdd");
                                     try 
                                     {
                                         Date d1 = format2.parse(orgSystemDate);
                                         Date d2 = format2.parse(BillStartDate);
                                         
                                         long diff = d2.getTime() - d1.getTime();
                                         long loanGracePeriodLong = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
                                         loanGracePeriod = Long.toString(loanGracePeriodLong);
                                         unitGracePeriod = "DIAS";
                                     }
                                     catch (ParseException gracePeriodErr) {
                                         loanGracePeriod = "";
                                     }                                     
                                 }
                                 else
                                 {
                                     try
                                     {
                                         daysUnit = paymentBillStartDate.substring(paymentBillStartDate.indexOf("+")+1, paymentBillStartDate.length());
                                         loanGracePeriod = daysUnit.replaceAll("[^0-9]", "");        //Get the numeric value from TERM                         
                                         unitGracePeriodChar = daysUnit.charAt(daysUnit.length()-1);
                                         unitGracePeriod = Character.toString(unitGracePeriodChar);
                                         switch(unitGracePeriod)
                                         {
                                             case "D":
                                                 unitGracePeriod = "DIAS";
                                                 break;
                                             case "M":
                                                 unitGracePeriod = "MESES";
                                                 break;
                                          }
                                     }
                                     catch(Exception gracePeriodErr)
                                     {
                                         loanGracePeriod = "";
                                     }
                                 }
                             }
                         }
                         
              //Get Periodicity loan Capital Installment and Periodicity Interest Installment loan
                         
                         paymentFreq = paymentTypeList.get(i).getPaymentFreq().getValue();    
                         paymentType = paymentTypeList.get(i).getPaymentType().getValue();
                         paymentMethod = paymentTypeList.get(i).getPaymentMethod().getValue();
                         
                         if(paymentMethod.equals("DUE") && ((paymentType.equals("LINEAR")) || (paymentType.equals("INTEREST.ONLY")) || paymentType.equals("ACTUAL") || paymentType.equals("CONSTANT") || paymentType.equals("INTEREST")))
                         {                                           
                             List<PropertyClass> propertylist = paymentTypeList.get(i).getProperty();
                             int b = propertylist.size();
                             
                             for(int j=0; j<b; j++)
                             {
                                 propertyName = propertylist.get(j).getProperty().getValue();
                                 switch(propertyName)
                                 {
                                     case "ACCOUNT":
                                         if(periodicityLoanCapitalInstallment.equals(""))
                                         {
                                             if(paymentFreq.equals(""))
                                             {
                                                 try
                                                 {
                                                     principalBillStartDt = paymentTypeList.get(i).getPercentage(j).getStartDate().getValue();
                                                     if(principalBillStartDt.contains("MATURITY"))
                                                     {
                                                         periodicityLoanCapitalInstallment = "Al Vencimiento";
                                                     }
                                                 }
                                                 catch(Exception startDtErr)
                                                 {
                                                     principalBillStartDt = "";
                                                 }
                                             }
                                             else
                                             {
                                                 periodicityLoanCapitalInstallment = paymentFreqCls(paymentFreq);      //Calling paymentFreqCls Class for getting Frequency Enrichment
                                             }
                                         }
                                         break; 
                                          
                                     case "PRINCIPALINTE":
                                         if(periodicityInterestInstallmentLoan.equals(""))
                                         {
                                             if(paymentFreq.equals(""))
                                             {
                                                 try
                                                 {
                                                     interestBillStartDt = paymentTypeList.get(i).getPercentage(j).getStartDate().getValue();
                                                     if(interestBillStartDt.contains("MATURITY"))
                                                     { 
                                                         periodicityInterestInstallmentLoan = "Al Vencimiento";
                                                     } 
                                                 }
                                                 catch(Exception startDtErr)
                                                 {
                                                     interestBillStartDt = "";
                                                 } 
                                             }
                                             else
                                             {
                                                 periodicityInterestInstallmentLoan = paymentFreqCls(paymentFreq);      //Calling paymentFreqCls Class for getting Frequency Enrichment 
                                             }
                                         }
                                         break;                                            
                                }  
                            }
                        }                                                      
                    }
                     
                    if(periodicityInterestInstallmentLoan.equals(""))
                    {
                        periodicityInterestInstallmentLoan = periodicityLoanCapitalInstallment;
                    }
                }
                catch(Exception aaScheduleErr)
                {
                    aaScheduleErr.getMessage();
                } 
                 
              //Get the collection loan grace period 
                 if(!loanGracePeriod.equals(""))
                 {
                     collectionLoanGracePeriod = "SI";
                 }
                 else
                 {
                     collectionLoanGracePeriod = "NO";
                 }
                    
                 
             //Get type Loan Guarantee from AA.ARR.LIMIT details                      
                 AaPrdDesLimitRecord AaPrdDesLimitRec = null;
                 try
                 {
                     AaPrdDesLimitRec = new AaPrdDesLimitRecord(contract.getConditionForProperty("LIMIT"));
                     limitRef = AaPrdDesLimitRec.getLimit().getValue();      //Get Limit ID
                      
                     try
                     {
                         LimitRecord limitRec = new LimitRecord(da.getRecord("LIMIT", limitRef));     //Read Limit Record                  
                         
                         List<CollateralCodeClass> CodeTypelist = limitRec.getCollateralCode();       
                         if (!CodeTypelist.isEmpty())
                         {
                             codeTypeGuaranteeLoan = CodeTypelist.get(0).getCollateralCode().getValue();     //Get COLLATERAL.CODE
                             typeLoanGuarantee = CodeTypelist.get(0).getCollateralCode().getEnrichment();
                         }
                     }
                     catch(Exception limitErr)
                     {
                         typeLoanGuarantee = "";
                     }                                                 
                 }
                 catch(Exception aaLimitErr)
                 {
                     typeLoanGuarantee = "";
                 }
              
                 
             //Get the value of the field PAYIN.ACCOUNT from AA.ARR.SETTLEMENT table                   
                 AaPrdDesSettlementRecord AaPrdDesSettlementRec=null;
                 try
                 {
                      AaPrdDesSettlementRec = new AaPrdDesSettlementRecord(contract.getConditionForProperty("SETTLEMENT"));
                      payInAccountNo = AaPrdDesSettlementRec.getPayinCurrency(0).getDdMandateRef(0).getPayinAccount().getValue();                         
                               
                      if(!payInAccountNo.equals(""))
                      {
                          comment = "PAGO PROGRAMADO EN CUENTA CORRIENTE";                       
                      }
                                 
                   //Get Payin Account Curreny 
                      try
                      {
                          AccountRecord accRec = new AccountRecord(da.getRecord("ACCOUNT", payInAccountNo));                    
                          payInAccountCcy = accRec.getCurrency().getValue();                   
                      }
                      catch(Exception accErr)
                      {
                          payInAccountCcy = "";
                      } 
                  }
                  catch(Exception aaArrSettleErr)
                  {
                      payInAccountCcy = "";
                  }                  
                    
             //Get the value of the field CHARGE.TYPE from AA.ARR.CHARGE table 
                 AaPrdDesChargeRecord aaArrChargeRec = null;
                 try
                 {
                     aaArrChargeRec = new AaPrdDesChargeRecord(contract.getConditionForProperty("BCIPEGASTNOTCR"));
                     String chargeType = aaArrChargeRec.getChargeType().getValue();
                      
                     switch(chargeType)
                     {
                         case "FIXED":
                         loanFeeType = "FIJA";
                         break;
                         
                         case "CALCULATED":
                         loanFeeType = "VARIABLE";
                         break;   
                     }
                 }
                 catch(Exception chrgErr)
                 {
                     loanFeeType = "";
                 }   
                 
                 
             //Get the value of the field EFFECTIVE.RATE from AA.ARR.INTEREST table                 
                 AaPrdDesInterestRecord aaInterestRec = null;
                 try
                 {
                     aaInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("PENALTYINT"));
                     
                     List<FixedRateClass> fixedRatelist = aaInterestRec.getFixedRate();       //Get the field EFFECTIVE.RATE value          
                     if(!fixedRatelist.isEmpty())
                     {
                          penaltyNonPayment = fixedRatelist.get(0).getEffectiveRate().getValue();
                     }               
                 }
                 catch(Exception aaArrIntErr)
                 {
                     penaltyNonPayment = "";
                 }                     
 
                 if(penaltyNonPayment.equals(""))
                 {
                     try
                     {
                          aaInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("PENALINT"));                                  
                          List<FixedRateClass> fixedRatelist = aaInterestRec.getFixedRate();       //Get the field EFFECTIVE.RATE value          
                          if(!fixedRatelist.isEmpty())
                          {
                              penaltyNonPayment = fixedRatelist.get(0).getEffectiveRate().getValue();
                          }               
                     }
                     catch(Exception e2)
                     {
                         penaltyNonPayment = "";
                     }
                 }              
                    
              //Get Working Balance from Account Table
                 try
                 {
                     AccountRecord accRec1 = new AccountRecord(da.getRecord("ACCOUNT", accountNo));                    
                     totalPrincipalAmtLoan = accRec1.getWorkingBalance().getValue();                   
                 }
                 catch(Exception accErr)
                 {
                     totalPrincipalAmtLoan = "";
                 }     
                
                 
             //Get the value of the field EFFECTIVE.RATE AND FIXED.RATE from AA.ARR.INTEREST table
                 AaPrdDesInterestRecord aaArrInterestRec = null;       
                 try
                 {
                     aaArrInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("PRINCIPALINTE"));  
                     annualEffectiveInterestRateTEA = aaArrInterestRec.getFixedRate().get(0).getEffectiveRate().getValue();       //Get EFFECTIVE.RATE field Value                                                  
                 }
                 catch(Exception aaArrIntErr)
                 {
                     annualEffectiveInterestRateTEA = "";
                 } 
                                   
                 
             //Get  the value of field EFFECTIVE.RATE from previous AA.ARR.INTEREST table
                 AaPrdDesInterestRecord aaArrInterestRecVal = null;        
                 try
                 {
                     aaArrInterestRecVal = new AaPrdDesInterestRecord(contract.getPreviousProperty("PRINCIPALINTE"));  
                     
                     annualEffectiveInterestRateTEAPreCondition = aaArrInterestRecVal.getFixedRate().get(0).getEffectiveRate().getValue();       //Get EFFECTIVE.RATE field Value                                                  
                 }
                 catch(Exception aaArrIntErr)
                 {
                     annualEffectiveInterestRateTEAPreCondition = "";
                 } 
                 
                 
            //Get Total No. of Unpaid Due
                 List<String> bciBillDetails = new ArrayList<String>();
                 String selCmd = "WITH (ARRANGEMENT.ID EQ "+operationNo+") AND (SETTLE.STATUS EQ 'UNPAID') AND (BILL.STATUS UNLIKE ...SETTLED...)";                 
                 try           
                 {
                     bciBillDetails = da.selectRecords("","AA.BILL.DETAILS","",selCmd); 
                     totalNoUnpaidDueYear = Integer.toString(bciBillDetails.size());
                 }  
                 catch(Exception billDetErr)
                 {
                     totalNoUnpaidDueYear = ""; 
                 }    
                 
                 
             //Get Bill Dates based on Bill Id's for LENDING-APPLYPAYMENT-PR.DUE.PAYMENT and LENDING-SETTLE-PR.REPAYMENT
                 if(eventCode.equals("C0004") && ((activityName.equals("LENDING-APPLYPAYMENT-PR.DUE.PAYMENT") || activityName.equals("LENDING-SETTLE-PR.REPAYMENT"))))
                 {
                     AaBillDetailsRecord aabillDetsRec = new AaBillDetailsRecord();
                     String orgRepayId = aaaId+"-"+effectiveDate;
                     String billStatusDate = "";
                     
                     try                   
                     {  
                         AaAccountDetailsRecord aaAcctDetailsRec = new AaAccountDetailsRecord(da.getRecord("AA.ACCOUNT.DETAILS", operationNo));
                         List<RepayReferenceClass> repayReferenceClsList = aaAcctDetailsRec.getRepayReference();
                         
                         for(RepayReferenceClass repayReferenceCls : repayReferenceClsList)
                         {
                             String repayRefId = repayReferenceCls.getRepayReference().getValue();
                             if(repayRefId.equals(orgRepayId))        
                             {
                                 List<TField> rpyBillIdList = repayReferenceCls.getRpyBillId();
                                 
                                 for(TField rpyBillIdTField : rpyBillIdList)
                                 {
                                     try
                                     {
                                         billStatusDate = "";
                                         String rpyBillId = rpyBillIdTField.getValue();
                                         aabillDetsRec = new AaBillDetailsRecord(da.getRecord("AA.BILL.DETAILS", rpyBillId)); 
                                         List<BillStatusClass> billStatusClsList = aabillDetsRec.getBillStatus();
                                         String billStatusClsListStr = billStatusClsList.toString();
                                         
                                         if(billStatusClsListStr.contains("SETTLED"))
                                         {
                                             for(BillStatusClass billStatusCls : billStatusClsList)
                                             {
                                                 String billStatus = billStatusCls.getBillStatus().getValue();
                                                 if(billStatus.equals("ISSUED"))
                                                 {
                                                     billStatusDate = billStatusCls.getBillStChgDt().getValue();
                                                     break;
                                                 }
                                             }
                                             
                                             try   //add the Bill Dates to Sting array
                                             {
                                                 billIdDateList.add(billStatusDate);
                                             }
                                             catch(Exception billIdDtListErr)
                                             {
                                                 billIdDtListErr.getMessage(); 
                                             }
                                         }
                                     } 
                                     catch(Exception billDetsErr)
                                     {
                                         billDetsErr.getMessage();
                                     }
                                 }
                                 break;
                             }
                         }
                     }
                     catch(Exception accountDetsErr)
                     {
                         accountDetsErr.getMessage();
                     }
                     
                     billIdDateListCnt = billIdDateList.size();
                 }
                 else
                 {
                     billIdDateListCnt = 1;
                 }
                 
    //*******************************************Fetch C0002, C0003, C000 & N0011 Details*********************************************
                
                 for(int a=0; a<billIdDateListCnt; a++)
                 {
                     flagTodayDue = "";
                     int startCnt = 0;
                     hdrDetNoticeMsg = "";
                     detNoticeD01Msg = "";
                     detNoticeD02Msg = "";
                     detNoticeD03Msg = "";
                     detNoticeD04Msg = "";
                     detNoticeD05Msg = "";
                     paymentScheduleDetails= "";
                     nextInstallmentExpireDate = "";
                     amtCancelFee = "";
                     amtConceptOtherPrincipalIntFeeCancelInsurance = "";
                     feeInterestCancel = "";
                     principalAmtCancel = "";
                     principalAmtFeeCancelInterest = "";
                     totFeeAmtCancel = "";
                     totalAmtInstallmentCancelLoan = "";
                     noOfEvent = "";
                     interestRateType = "";
                     establishTerm = "";
                     unitestablishTerm = "";
                     finalMaturityDateLoan = "";
                     dateOfGrantLoan = "";
                     totalAmtGrantLoan = "";
                     paymentMethodPaidEvent = "";
                     
                     if(scheduleProjectorFlg == 0) 
                     {
                         dueDateList = scheduleProjectorRec.getDueDate();  
                         dutDateCnt = dueDateList.size();   
                         dueTypeListStr = scheduleProjectorRec.getDueDate(0).getDueType().toString();
                         
                         if(!dueTypeListStr.contains("DISBURSEMENT.%"))      
                         {
                             startCnt = 0; 
                         }else
                         {
                             startCnt = 1;
                         }
                         
                         if(eventCode.equals("C0004") && ((activityName.equals("LENDING-APPLYPAYMENT-PR.DUE.PAYMENT") || activityName.equals("LENDING-SETTLE-PR.REPAYMENT"))))
                         {
                             String billDate = "";
                             try
                             {
                                 billDate = billIdDateList.get(a);
                             }
                             catch(Exception billDateErr)
                             {
                                 billDate = today;
                             }
                             dtValue = billDate;
                             
                             String fstDueDate = scheduleProjectorRec.getDueDate(0).getDueDate().getValue();
                             if(fstDueDate.equals(billDate))
                             {
                                 startCnt = 0;
                             }
                         }
                      
                      //Get No. of Account and Interest
                         fstAnnualDueDate = scheduleProjectorRec.getDueDate(0).getDueDate().getValue();
                         lastAnnualYearInt = Integer.parseInt(fstAnnualDueDate.substring(3, 4)) + 1;
                         lastAnnualDueDate = fstAnnualDueDate.substring(0, 3)+lastAnnualYearInt+fstAnnualDueDate.substring(4,8);
                         
                         for(int k=startCnt; k<dutDateCnt; k++)
                         { 
                             dueDate = dueDateList.get(k).getDueDate().getValue();
                             
                             if(dueDate.equals(dtValue))
                             {
                                 flagTodayDue = "YES";
                             }
                             if(annualBreakFlg == 0)
                             {
                                 try
                                 {
                                     SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                                     Date date1 = sdf.parse(dueDate);
                                     Date date2 = sdf.parse(lastAnnualDueDate);
                                     
                                     if((date1.before(date2)) || (date1.equals(date2)))
                                     {
                                         List<DueTypeClass> repayDueTypeList = scheduleProjectorRec.getDueDate().get(k).getDueType();
                                         repayDueTypeCnt = repayDueTypeList.size();
                                         
                                         for(int r=0; r<repayDueTypeCnt; r++) 
                                         {
                                             switch(dueType)
                                             {
                                                 case "INTEREST.ONLY": case "INTEREST": case "ACTUAL":    
                                                     annualAmtLoanInterestInstallmentInt = annualAmtLoanInterestInstallmentInt + 1;
                                                     break;                                   
                                                     
                                                 case "LINEAR":
                                                     annualAmtLoanPrincipalInstallmentInt = annualAmtLoanPrincipalInstallmentInt + 1;
                                                     break;
                                                     
                                                 case "CONSTANT":     
                                                     String[] duePropertyConstantStringList = repayDueTypeList.get(r).getDueProperty().getValue().split("/");
                                                     List<String> duePropertyConstantList = new ArrayList<String>();

                                                     for(String duePropertyConstantStr : duePropertyConstantStringList)       
                                                     {
                                                         duePropertyConstantList.add(duePropertyConstantStr);
                                                     }
                                                     for(int m=0; m<duePropertyConstantList.size(); m++)
                                                     {
                                                         duePropertyVal = "";
                                                         duePropertyVal = duePropertyConstantList.get(m);
                                                         switch(duePropertyVal)
                                                         {
                                                             case "PRINCIPALINTE":
                                                                 annualAmtLoanInterestInstallmentInt = annualAmtLoanInterestInstallmentInt + 1;
                                                                 break;
                                                                 
                                                             case "ACCOUNT":
                                                                 annualAmtLoanPrincipalInstallmentInt = annualAmtLoanPrincipalInstallmentInt + 1;
                                                                 break;
                                                         }
                                                     }
                                                     break;
                                              } 
                                         }
                                     }
                                     else
                                     {
                                         annualBreakFlg = 1; 
                                     }
                                 }
                                 catch(ParseException ex){
                                     ex.printStackTrace();
                                 }
                             }
                         }
                     }
                     annualAmtLoanPrincipalInstallment = Integer.toString(annualAmtLoanPrincipalInstallmentInt);
                     annualAmtLoanInterestInstallment = Integer.toString(annualAmtLoanInterestInstallmentInt);
                     
             //****************************************Fetch C0003 Details*************************************************
    
                     if(eventCode.equals("C0003"))
                     {
                      //Get Effective date and HdrEventTime
                         dateOfOperation = effectiveDate;
                         timeOfOperation = hdrEventTime;
                            
                      //Get Date of Grant loan & Loan disbursement date
                         dateOfGrantLoan = orgSystemDate;
                         Loandisbursementdate = minDate;
                          
                      //----------Get the values for D03 Commission and D05 Expense--------------

                         if(scheduleProjectorFlg == 0)   //Get the values from EB.BCI.UPDATE.SCHEDULE.PROJECTOR
                         {
                             principalBalLoan = scheduleProjectorRec.getDueDate(0).getDueOutstandingBalance().getValue();                       
                                            
                             if(dueTypeListStr.contains("CHARGE"))         //Get Commission details D03 or Expense details D05, if CHARGE due type is existing in first multivalue set  
                             {    
                                 List<DueTypeClass> dueTypeList = scheduleProjectorRec.getDueDate(0).getDueType();
                                 int dueTypeCnt = dueTypeList.size();
                                   
                                 for(int p=0; p<dueTypeCnt; p++)
                                 {                             
                                     chrgDueType = dueTypeList.get(p).getDueType().getValue();
                                     if(chrgDueType.equals("CHARGE"))
                                     {
                                         String[] duePropertyStringList = dueTypeList.get(p).getDueProperty().getValue().split("/");
                                         String[] duePropertyAmtStringList = dueTypeList.get(p).getDuePropertyAmount().getValue().split("/");
                                            
                                         List<String> duePropertyList = new ArrayList<String>();
                                         List<String> duePropertyAmtList = new ArrayList<String>();

                                         for(String duePropertyStr : duePropertyStringList)
                                         {
                                             duePropertyList.add(duePropertyStr);
                                         }
                                         for(String duePropertyAmtStr : duePropertyAmtStringList)
                                         {
                                             duePropertyAmtList.add(duePropertyAmtStr);
                                         }
                                        
                                     //Format the Detail Notice D03 and D05 string values based on the length 
                                         detCode03 = StringUtils.rightPad(detCode03, 20, " ");
                                         detCode05 = StringUtils.rightPad(detCode05, 20, " ");
                                         eventCode = StringUtils.rightPad(eventCode, 5, " ");  
                                         currency = StringUtils.rightPad(currency, 5, " ");
                                            
                                         duePropertyCnt = duePropertyList.size();
                                         for(int q=0; q<duePropertyCnt; q++)
                                         {
                                             commissionDets = "";
                                             expenseDets = "";
                                             duePropertyAmt = "";
                                             duePropertyVal = "";
                                             propertyDes = "";
                                                
                                             duePropertyVal = StringUtils.rightPad(duePropertyList.get(q), 5, " ");                                    
                                             dueProperty = duePropertyVal;
                                             if(dueProperty.length() >= 5)
                                             {
                                                 dueProperty = duePropertyVal.substring(0, 5);                                       
                                             }
                                             
                                          //Get property Description
                                             try
                                             {
                                                 AaPropertyRecord propertyRec = new AaPropertyRecord(da.getRecord("AA.PROPERTY", duePropertyVal));                                           
                                                 propertyDesVal = propertyRec.getDescription(0).getValue();
                                                    
                                                 propertyDes = propertyDesVal;
                                                 if(propertyDes.length() >= 30)
                                                 {
                                                     propertyDes = propertyDes.substring(0, 30);
                                                 }                 
                                             }
                                             catch(Exception propertyErr)
                                             {
                                                 propertyDes = "";   
                                             }                                    
            
                                             propertyDes = StringUtils.rightPad(propertyDes, 30, " ");
                                             duePropertyAmt = formatAmt(duePropertyAmtList.get(q));       //Calling formatAmt class for formating the amount
                                              
                                             if((duePropertyVal.contains("BCIPEGAS")) || (propertyDesVal.contains("Gasto")))      //If the property is related to Expense
                                             {
                                              //Form Detail Notice D05 Message 
                                                 expenseFlg = 1;
                                                 expenseD05Cnt = expenseD05Cnt + 1;
                                                 expenseDets = detCode05+eventCode+dueProperty+propertyDes+currency+duePropertyAmt;                                       
                                                 if(expenseD05Cnt == 1)
                                                 {
                                                     expenseDetails = expenseDets;
                                                 }else
                                                 {
                                                     expenseDetails = expenseDetails+'\n'+expenseDets;
                                                 }   
                                             }
                                             else         //If the property is related to Commission
                                             {
                                              //Form Detail Notice D03 Message
                                                 commissionFlg = 1;
                                                 commissionD03Cnt = commissionD03Cnt + 1;
                                                 commissionDets = detCode03+eventCode+dueProperty+propertyDes+currency+duePropertyAmt;
                                                    
                                                 if(commissionD03Cnt == 1)
                                                 {
                                                     commissionDetails = commissionDets;
                                                 }else
                                                 {
                                                     commissionDetails = commissionDetails+'\n'+commissionDets;
                                                 }     
                                             }                                                              
                                         } 
                                         break;
                                     }
                                 }                    
                             }
                             
                             for(int k=startCnt; k<dutDateCnt; k++)
                             {                                                 
                                 List<DueTypeClass> repayDueTypeList = scheduleProjectorRec.getDueDate().get(k).getDueType();
                                 String dueTypeListChrgStr = scheduleProjectorRec.getDueDate(k).getDueType().toString();
                                 String dueTypeChrg = "";
                                 
                                 if(dueTypeListChrgStr.contains("CHARGE"))    //If CONSTANT due type include the Charge Property
                                 {
                                     dueTypeChrg = "CHARGE";
                                 }
                                 else if((dueTypeListChrgStr.contains("CONSTANT")) && (dueTypeListChrgStr.contains("BCIPE")))    
                                 {
                                     dueTypeChrg = "CONSTANT";
                                 }
                                 
                                 repayDueTypeCnt = repayDueTypeList.size();
                                 dueDate = dueDateList.get(k).getDueDate().getValue();
                                    
                                 for(int r=0; r<repayDueTypeCnt; r++) 
                                 {
                                   dueType = repayDueTypeList.get(r).getDueType().getValue();
                                     
                                   if((!dueTypeChrg.equals("")) && (dueType.equals(dueTypeChrg)))
                                   {
                                      //Get Commission details D03 and Expense details D05                                                                      
                                       if(((commissionFlg == 0) && (commissionAddFlg == 0)) || ((expenseFlg == 0) && (expenseAddFlg == 0)))       //If Commission or Expense details is not exist with first set
                                       {                                        
                                           String[] duePropertyStringList = repayDueTypeList.get(r).getDueProperty().getValue().split("/");
                                           String[] duePropertyAmtStringList = repayDueTypeList.get(r).getDuePropertyAmount().getValue().split("/");
                                                  
                                           List<String> duePropertyList = new ArrayList<String>();
                                           List<String> duePropertyAmtList = new ArrayList<String>();

                                           for(String duePropertyStr : duePropertyStringList)       
                                           {
                                               duePropertyList.add(duePropertyStr);
                                           }
                                           for(String duePropertyAmtStr : duePropertyAmtStringList)
                                           {
                                               duePropertyAmtList.add(duePropertyAmtStr);
                                           }
                                               
                                           detCode05 = StringUtils.rightPad(detCode05, 20, " ");
                                           detCode03 = StringUtils.rightPad(detCode03, 20, " ");      //Format the Detail Notice D03/D05 string values based on the length                                        
                                           eventCode = StringUtils.rightPad(eventCode, 5, " ");  
                                           currency = StringUtils.rightPad(currency, 5, " ");
                                                  
                                           duePropertyCnt = duePropertyList.size();
                                           for(int m=0; m<duePropertyCnt; m++)
                                           {
                                               commissionDets = "";
                                               expenseDets = "";
                                               duePropertyAmt = "";
                                               duePropertyVal = "";
                                               propertyDes = "";
                                                        
                                               duePropertyVal = StringUtils.rightPad(duePropertyList.get(m), 5, " ");                                          
                                               dueProperty = duePropertyVal;
                                               int duePropertyLen = dueProperty.length();
                                               if(duePropertyLen >= 5)
                                               {
                                                  dueProperty = dueProperty.substring(0, 5);
                                               }                                        
                                                      
                                            //Get Property Description
                                               try
                                               {
                                                   AaPropertyRecord propertyRec = new AaPropertyRecord(da.getRecord("AA.PROPERTY", duePropertyVal));
                                                   propertyDesVal = propertyRec.getDescription(0).getValue();
                                                        
                                                   propertyDes = propertyDesVal;
                                                   if(propertyDes.length() >= 30)
                                                   {
                                                       propertyDes = propertyDes.substring(0, 30);
                                                   }               
                                               }
                                               catch(Exception propertyErr)
                                               {
                                                   propertyDes = "";   
                                               }                                          
                                                      
                                               propertyDes = StringUtils.rightPad(propertyDes, 30, " ");
                                               duePropertyAmt = formatAmt(duePropertyAmtList.get(m));       //Calling formatAmt class for formating the amount
                                                
                                               if(duePropertyVal.contains("BCIPE"))
                                               {
                                                   if(((!duePropertyVal.contains("BCIPEGAS")) || (!propertyDesVal.contains("Gasto"))) && ((commissionFlg == 0) && (commissionAddFlg == 0)))
                                                   {
                                                   //Form Detail Notice D03 Message
                                                       commissionAddFlg = 1;
                                                       commissionD03Cnt = commissionD03Cnt + 1;
                                                       commissionDets = detCode03+eventCode+dueProperty+propertyDes+currency+duePropertyAmt;
                                                                
                                                       if(commissionD03Cnt == 1)
                                                       {
                                                          commissionDetails = commissionDets;
                                                       }else
                                                       {
                                                          commissionDetails = commissionDetails+'\n'+commissionDets;
                                                       }  
                                                   }
                                                            
                                                   if((duePropertyVal.contains("BCIPEGAS") || propertyDesVal.contains("Gasto")) && ((expenseFlg == 0) && (expenseAddFlg == 0)))
                                                   {
                                                     //Form Detail Notice D05 Message 
                                                       expenseAddFlg = 1;
                                                       expenseD05Cnt = expenseD05Cnt + 1;
                                                       expenseDets = detCode05+eventCode+dueProperty+propertyDes+currency+duePropertyAmt;                                       
                                                       if(expenseD05Cnt == 1)
                                                       {
                                                           expenseDetails = expenseDets;
                                                       }else
                                                       {
                                                           expenseDetails = expenseDetails+'\n'+expenseDets;
                                                       }  
                                                   }
                                               }
                                           }                                                        
                                       }                                         
                                   }
                               }
                          }
                          noOfD03Recs = Integer.toString(commissionD03Cnt);
                          noOfD05Recs = Integer.toString(expenseD05Cnt);
                                 
                          detNoticeD03Msg = commissionDetails;
                          detNoticeD05Msg = expenseDetails;
                      }
                            
         //*---------------------------------------Get D01 details--------------------------------------------------------*//
                                                                 
                    //Get Latest record from AA.ARR.TERM.AMOUNT 
                       AaPrdDesTermAmountRecord aaPrdDesTermAmtRec = null; 
                       try
                       {
                           aaPrdDesTermAmtRec = new AaPrdDesTermAmountRecord(contract.getConditionForProperty("COMMITMENT"));
                           txnAmount = aaPrdDesTermAmtRec.getAmount().getValue();
                           maturityDate = aaPrdDesTermAmtRec.getMaturityDate().getValue();
                                                    
                           termVal = aaPrdDesTermAmtRec.getTerm().getValue();       
                           if(!termVal.equals(""))
                           {
                               establishTerm = termVal.replaceAll("[^0-9]", "");        //Get the numeric value from TERM                         
                               unitTermChar = termVal.charAt(termVal.length()-1);       //Get the unit from TERM field
                               unitestablishTerm = Character.toString(unitTermChar);
                               switch(unitestablishTerm)
                               {
                                  case "D":
                                      unitestablishTerm = "DIAS";
                                      break;
                                  case "M":
                                      unitestablishTerm = "MESES";
                                      break;
                                  case "Y":
                                      unitestablishTerm = "ANOS";
                                      break;                                   
                                 }
                              } 
                          }
                          catch(Exception termErr)
                          {
                              establishTerm = "";
                              unitestablishTerm = "";
                          }   
                          finalMaturityDateLoan = maturityDate;
                          totalAmtGrantLoan = txnAmount;
                             
                     //Get maturity date previous condition
                          AaPrdDesTermAmountRecord aaPrdDesTermAmtRecVal = null;
                          try
                          {
                              aaPrdDesTermAmtRecVal = new AaPrdDesTermAmountRecord(contract.getPreviousProperty("COMMITMENT"));
                              totalAmtGrantLoanPreCondition = aaPrdDesTermAmtRecVal.getAmount().getValue();
                              finalMaturityDateLoanPreCondition = aaPrdDesTermAmtRecVal.getMaturityDate().getValue();
                          }
                          catch(Exception termErr)
                          {
                              termErr.getMessage();
                          }
                                               
                          if(totalAmtGrantLoanPreCondition.equals(""))
                          {
                              totalAmtGrantLoanPreCondition = txnAmount; 
                          }
                                               
                          if(finalMaturityDateLoanPreCondition.equals("") && (!maturityDate.equals("")))
                          {
                              finalMaturityDateLoanPreCondition =  maturityDate;
                          }
                                               
                       //Get the value of the field EFFECTIVE RATE  from previous record of AA.ARR.INTEREST table
                           AaPrdDesInterestRecord aaPrdDesInterestRec = null;
                           try
                           {
                               aaPrdDesInterestRec = new AaPrdDesInterestRecord(contract.getPreviousProperty("PENALTYINT"));
                               List<FixedRateClass> fixedRatelist = aaPrdDesInterestRec.getFixedRate();   //Get the field EFFECTIVE.RATE value   
                               if(!fixedRatelist.isEmpty())
                               {
                                   penaltyNonPaymentPreCondition = fixedRatelist.get(0).getEffectiveRate().getValue();
                               } 
                            }
                            catch(Exception e12)
                            {
                                penaltyNonPaymentPreCondition = "";
                            }
                          
                            if(penaltyNonPaymentPreCondition.equals(""))
                            {
                                AaPrdDesInterestRecord aaPrdDesInterestpenalRec = null;
                                try
                                {
                                    aaPrdDesInterestpenalRec = new AaPrdDesInterestRecord(contract.getPreviousProperty("PENALINT"));
                                     List<FixedRateClass> fixedRatelist = aaPrdDesInterestpenalRec.getFixedRate();   //Get the field EFFECTIVE.RATE value   
                                     if(!fixedRatelist.isEmpty())
                                     {
                                         penaltyNonPaymentPreCondition = fixedRatelist.get(0).getEffectiveRate().getValue();
                                     } 
                                }
                                catch(Exception e12)
                                {
                                    penaltyNonPaymentPreCondition = "";
                                }      
                            }                  
                                             
                        //Get the value of the field Interest rate type from current record of AA.ARR.INTEREST
                            AaPrdDesInterestRecord aaArrInterestRecValue = null;        
                            try
                            {
                                aaArrInterestRecValue = new AaPrdDesInterestRecord(contract.getConditionForProperty(actvityPropertyName));  
                                try
                                {
                                    fixedRateVal = aaArrInterestRecValue.getFixedRate().get(0).getFixedRate().getValue();
                                } 
                                catch(Exception e)
                                {
                                    fixedRateVal = "";
                                } 
                                try
                                {
                                    floatingIndexVal = aaArrInterestRecValue.getFixedRate().get(0).getFloatingIndex().getValue();
                                } 
                                catch(Exception e)
                                {
                                    floatingIndexVal = "";
                                } 
                               
                                if (!fixedRateVal.equals(""))
                                {
                                    interestRateType = "FIJA";
                                }
                                else if(!floatingIndexVal.equals(""))
                                {     
                                    interestRateType = "VARIABLE";
                                }
                            }
                            catch(Exception aaArrIntErr)
                            {
                                interestRateType = "";
                            } 
                      
                        //Get the value of the field TCEA previous condition from AA.ARR.ACCOUNT table
                            List<AprTypeClass> aprRateType;
                            String aprRatetype = "";
                            
                            AaPrdDesAccountRecord aaPrdDesAcRec = null;
                            try
                            {
                                aaPrdDesAcRec = new AaPrdDesAccountRecord(contract.getPreviousProperty("ACCOUNT"));
                                aprRateType = aaPrdDesAcRec.getAprType();
                                for(AprTypeClass rateType:aprRateType)
                                {
                                    aprRatetype = rateType.getAprType().getValue();
                                    if(aprRatetype.equals("PEACCT.TCEA.LENDING"))
                                    {
                                        annualEffectiveCostRateTCEAPreCondition = rateType.getAprRate().getValue();
                                        annualEffectiveCostRateTCEAPreCondition = annualEffectiveCostRateTCEAPreCondition.replace("-", "");
                                        break;
                                    }
                                }
                            }
                            catch(Exception tceaErr) 
                            {
                                tceaErr.getMessage();
                            }      
                            
                        //Get the value of the field Tier Type  from previous record of AA.ARR.INTEREST table
                            AaPrdDesInterestRecord aaPrdDesInterestprincipalRec = null;
                            try
                            {
                                aaPrdDesInterestprincipalRec = new AaPrdDesInterestRecord(contract.getPreviousProperty(actvityPropertyName));
                                try
                                {
                                    fixedRatePreVal = aaPrdDesInterestprincipalRec.getFixedRate().get(0).getFixedRate().getValue();
                                } 
                                catch(Exception e)
                                {
                                    fixedRatePreVal = "";
                                } 
                                    
                                try
                                {
                                    floatingIndexPreVal = aaPrdDesInterestprincipalRec.getFixedRate().get(0).getFloatingIndex().getValue();
                                } 
                                catch(Exception e)
                                {
                                    floatingIndexPreVal = "";   
                                } 
                                
                                if(!fixedRatePreVal.equals(""))
                                {
                                    interestRatePreCondition = "FIJA";
                                }
                                else if(!floatingIndexPreVal.equals(""))
                                {     
                                    interestRatePreCondition = "VARIABLE";
                                }
                            }
                            catch(Exception e)
                            {
                                interestRatePreCondition = "";
                            }
                                         
                            if(interestRatePreCondition.equals("") && (!interestRateType.equals("")))
                            {
                                interestRatePreCondition = interestRateType;
                            } 
                            
                            
                 //*-----------------Get D03 details------------------*//                                  
                            if(detNoticeD03Msg.equals(""))
                            {
                                noOfD03Recs = "1";
                                dueProperty = "";
                                duePropertyAmt = "";
                                propertyDes = "";
                                String commissionCcy = "";
                              
                            //Format the Detail Notice D03 string values based on the length 
                                detCode03 = StringUtils.rightPad(detCode03, 20, " ");
                                eventCode = StringUtils.rightPad(eventCode, 5, " ");                                         
                                dueProperty = StringUtils.rightPad(dueProperty, 5, " ");                                      
                                propertyDes = StringUtils.rightPad(propertyDes, 30, " ");      
                                commissionCcy = StringUtils.rightPad(commissionCcy, 5, " ");
                                    
                                duePropertyAmt = formatAmt(duePropertyAmt);
                                           
                            //Form Detail Notice D03 Message         
                                commissionDetails = detCode03+eventCode+dueProperty+propertyDes+commissionCcy+duePropertyAmt;  
                                detNoticeD03Msg = commissionDetails;
                            }
                           
                            
                  //*------------------Get D04 details-----------------*//                                  
                            if(detNoticeD04Msg.equals(""))
                            {
                                String secureLoanCode = "";
                                String descriptLoanInsurance = "";
                                String loanInsuranceCcy = "";
                                String secureLoanAmt = "";
                                noOfD04Recs = "1";
                                     
                            //Format the Detail Notice D04 string values based on the length
                                detCode04 = StringUtils.rightPad(detCode04, 20, " ");
                                eventCode = StringUtils.rightPad(eventCode, 5, " ");
                                secureLoanCode = StringUtils.rightPad(secureLoanCode, 5, " ");
                                descriptLoanInsurance = StringUtils.rightPad(descriptLoanInsurance, 30, " ");
                                loanInsuranceCcy = StringUtils.rightPad(loanInsuranceCcy, 5, " ");
                                secureLoanAmt = StringUtils.leftPad(secureLoanAmt, 22, "0");
                             
                            //Form Detail Notice D04 Message
                                detNoticeD04Msg = detCode04+eventCode+secureLoanCode+descriptLoanInsurance+loanInsuranceCcy+secureLoanAmt;
                            }
                         
                            
                  //*----------------Get D05 details-----------------*//
                            if(detNoticeD05Msg.equals(""))
                            {
                                String loanExpenseCode = "";
                                String descriptionLoanExpense = "";
                                String loanExpenditureCcy = "";
                                String amtLoanExpense = "";
                                noOfD05Recs = "1";

                             //Format the Detail Notice D05 string values based on the length
                                detCode05 = StringUtils.rightPad(detCode05, 20, " ");
                                eventCode = StringUtils.rightPad(eventCode, 5, " ");
                                loanExpenseCode = StringUtils.rightPad(loanExpenseCode, 5, " ");
                                descriptionLoanExpense = StringUtils.rightPad(descriptionLoanExpense, 30, " ");
                                loanExpenditureCcy = StringUtils.rightPad(loanExpenditureCcy, 5, " ");
                                amtLoanExpense = StringUtils.leftPad(amtLoanExpense, 22, "0");
                                    
                             //Form Detail Notice D05 Message
                                detNoticeD05Msg = detCode05+eventCode+loanExpenseCode+descriptionLoanExpense+loanExpenditureCcy+amtLoanExpense;                                  
                            }   
                      }
                 
     //**************************************************Fetch C0002 & C0004 & N0011 Details*****************************************************//

                     if(eventCode.equals("C0002") || eventCode.equals("N0011") || eventCode.equals("C0004"))
                     {
                         if(scheduleProjectorFlg == 0) 
                         {
                             int noOfEventVal = 0;
                             int dateCount = 0;

                             try
                             {
                                 if(eventCode.equals("C0002") || eventCode.equals("C0004"))
                                 {
                                  //Get Next Installment Expire Date
                                     if(eventCode.equals("C0002"))
                                     {
                                         principalBalLoan = scheduleProjectorRec.getDueDate(0).getDueOutstandingBalance().getValue();
                                     }
                                  
                                     for(int k=startCnt; k<dutDateCnt; k++)
                                     {   
                                         dueDate = "";
                                         double totalFeeAmtDbl = 0;
                                         double capitalBalDbl = 0;
                                         double principalAmtDbl = 0;
                                         double interestAmtFeeDbl = 0;
                                         double insuranceAmtFeeDbl = 0;
                                         double commissionAmtFeeDbl = 0;
                                         expenseAmtFeeDbl = 0;
                                         int dtValInt = 0;
                                         int todayValInt = 0;
                                         String totalFeeAmt = "";
                                         String commissionAmtFee = "";
                                         String capitalBal = "";
                                         String principalAmt = "";
                                         String interestAmtFee = "";
                                         String insuranceAmtFee = "";
                                         String largeAmtFee = "";
                                         String expenseAmtFee = "";
                                         String itfAmtFee = "";
                                         String reducedAmtFee = "";
                                         String insuranceTaxAmtFee = "";
                                         String noOfQuoto = "";
                                         String otherInsuranceAmt = "";
                                         String paymentScheduleDets = "";
                                         String currentInterestAmtFee = "";
                                         double currentInterestAmtFeeDbl = 0;
                                         
                                         if(startCnt == 0)
                                         {
                                             noOfQuoto = Integer.toString(k+1);
                                             totalAmtInstallmentDueLoan = Integer.toString(dutDateCnt);
                                             totalLoanInstallment = totalAmtInstallmentDueLoan;
                                         }else
                                         {
                                             noOfQuoto = Integer.toString(k);
                                             totalAmtInstallmentDueLoanInt = dutDateCnt-1;
                                             totalAmtInstallmentDueLoan = Integer.toString(totalAmtInstallmentDueLoanInt);
                                             totalLoanInstallment = totalAmtInstallmentDueLoan;
                                         }
                                        
                                         capitalBal = dueDateList.get(k).getDueOutstandingBalance().getValue();
                                         capitalBalDbl = Double.parseDouble(capitalBal);
                                         
                                         dueDate = dueDateList.get(k).getDueDate().getValue();    
                                         if(installmentDatePaid.equals(""))
                                         {
                                             installmentDatePaid = dueDate;
                                             if(eventCode.equals("C0002"))
                                             {
                                                 nextInstallmentExpireDate = dueDate;   
                                             }
                                             nextInstallmentduePay = dueDateList.get(0).getDueDate().getValue();
                                             firstLoanInstallmentDate = dueDate;
                                         }
                                        
                                         List<DueTypeClass> repayDueTypeList = scheduleProjectorRec.getDueDate().get(k).getDueType();
                                         repayDueTypeCnt = repayDueTypeList.size();
                                       
                                         for(int r=0; r<repayDueTypeCnt; r++) 
                                         {
                                             dueType = repayDueTypeList.get(r).getDueType().getValue();
                                             switch(dueType)
                                             {
                                                 case "INTEREST.ONLY":  case "ACTUAL":  case "INTEREST":
                                                     interestAmtFee = repayDueTypeList.get(r).getDueTypeAmount().getValue(); 
                                                     interestAmtFeeDbl = Double.parseDouble(interestAmtFee);
                                                     break;                                   
                                                                                             
                                                 case "LINEAR":
                                                     principalAmt = repayDueTypeList.get(r).getDueTypeAmount().getValue();
                                                     principalAmtDbl = Double.parseDouble(principalAmt); 
                                                     break;
                                                     
                                                 case "CURRENT":           //Include CURRENT due type
                                                     currentInterestAmtFee = repayDueTypeList.get(r).getDueTypeAmount().getValue();
                                                     currentInterestAmtFeeDbl = Double.parseDouble(currentInterestAmtFee); 
                                                     break;
                                                     
                                                 case "CONSTANT":   //Include CONSTANT payment Type
                                                     
                                                     String[] duePropertyConstantStringList = repayDueTypeList.get(r).getDueProperty().getValue().split("/");
                                                     String[] duePropertyAmtConstantStringList = repayDueTypeList.get(r).getDuePropertyAmount().getValue().split("/");
                                                   
                                                     List<String> duePropertyConstantList = new ArrayList<String>();
                                                     List<String> duePropertyAmtConstantList = new ArrayList<String>();

                                                     for(String duePropertyConstantStr : duePropertyConstantStringList)       
                                                     {
                                                         duePropertyConstantList.add(duePropertyConstantStr);
                                                     }
                                                     for(String duePropertyAmtConstantStr : duePropertyAmtConstantStringList)
                                                     {
                                                         duePropertyAmtConstantList.add(duePropertyAmtConstantStr);
                                                     }
                                                     
                                                     for(int m=0; m<duePropertyConstantList.size(); m++)
                                                     {
                                                         duePropertyVal = "";
                                                         duePropertyVal = duePropertyConstantList.get(m);
                                                         switch(duePropertyVal)
                                                         {
                                                             case "PRINCIPALINTE":
                                                                 interestAmtFee = duePropertyAmtConstantList.get(m); 
                                                                 interestAmtFeeDbl = Double.parseDouble(interestAmtFee);
                                                                 break;
                                                                 
                                                             case "ACCOUNT":
                                                                 principalAmt = duePropertyAmtConstantList.get(m);
                                                                 principalAmtDbl = Double.parseDouble(principalAmt); 
                                                                 break;
                                                                 
                                                             default:
                                                                 if(duePropertyVal.contains("BCIPE"))    //If CONSTANT due type include the Charge Property
                                                                 {
                                                                     commissionDets = "";
                                                                     expenseDets = "";
                                                                     duePropertyAmt = "";
                                                                     propertyDesVal = "";                                                                                  
                                                                     duePropertyAmtDbl = 0;
                                                                     
                                                                     duePropertyAmt = duePropertyAmtConstantList.get(m);      
                                                                     duePropertyAmtDbl = Double.parseDouble(duePropertyAmt);                                          
                                                                   
                                                                //Get Property Description
                                                                     try
                                                                     {
                                                                         AaPropertyRecord propertyRec = new AaPropertyRecord(da.getRecord("AA.PROPERTY", duePropertyVal));
                                                                         propertyDesVal = propertyRec.getDescription(0).getValue();
                                                                     }
                                                                     catch(Exception propertyErr)
                                                                     {
                                                                         propertyDesVal = "";   
                                                                     }                                                                                  

                                                                     if((!duePropertyVal.contains("BCIPEGAS")) || (!propertyDesVal.contains("Gasto")))
                                                                     {                                          
                                                                         commissionAmtFeeDbl = commissionAmtFeeDbl + duePropertyAmtDbl;
                                                                     }
                                                                     else
                                                                     {
                                                                         expenseAmtFeeDbl = expenseAmtFeeDbl + duePropertyAmtDbl;
                                                                     }
                                                                 }
                                                         }
                                                     }
                                                     break;
                                                     
                                                 case "CHARGE":
                                                     String[] duePropertyStringList = repayDueTypeList.get(r).getDueProperty().getValue().split("/");
                                                     String[] duePropertyAmtStringList = repayDueTypeList.get(r).getDuePropertyAmount().getValue().split("/");
                                                   
                                                     List<String> duePropertyList = new ArrayList<String>();
                                                     List<String> duePropertyAmtList = new ArrayList<String>();

                                                     for(String duePropertyStr : duePropertyStringList)       
                                                     {
                                                         duePropertyList.add(duePropertyStr);
                                                     }
                                                     for(String duePropertyAmtStr : duePropertyAmtStringList)
                                                     {
                                                         duePropertyAmtList.add(duePropertyAmtStr);
                                                     }
                                                     
                                                     duePropertyCnt = duePropertyList.size();
                                                     for(int m=0; m<duePropertyCnt; m++)
                                                     {
                                                         commissionDets = "";
                                                         expenseDets = "";
                                                         duePropertyAmt = "";
                                                         duePropertyVal = "";
                                                         propertyDesVal = "";                                                                                  
                                                         duePropertyAmtDbl = 0;
                                                         
                                                         duePropertyAmt = duePropertyAmtList.get(m);      
                                                         duePropertyAmtDbl = Double.parseDouble(duePropertyAmt);                                          
                                                         duePropertyVal = duePropertyList.get(m);                                          
                                                                                              
                                                    //Get Property Description
                                                         try
                                                         {
                                                             AaPropertyRecord propertyRec = new AaPropertyRecord(da.getRecord("AA.PROPERTY", duePropertyVal));
                                                             propertyDesVal = propertyRec.getDescription(0).getValue();
                                                         }
                                                         catch(Exception propertyErr)
                                                         {
                                                             propertyDesVal = "";   
                                                         }                                                                                  

                                                         if((!duePropertyVal.contains("BCIPEGAS")) || (!propertyDesVal.contains("Gasto")))
                                                         {                                          
                                                             commissionAmtFeeDbl = commissionAmtFeeDbl + duePropertyAmtDbl;
                                                         }
                                                         else
                                                         {
                                                             expenseAmtFeeDbl = expenseAmtFeeDbl + duePropertyAmtDbl;
                                                         }
                                                     }
                                                     break;
                                                 }
                                             }
                                             
                                             totalFeeAmtDbl = principalAmtDbl + interestAmtFeeDbl + insuranceAmtFeeDbl + commissionAmtFeeDbl + expenseAmtFeeDbl;
                                             
                                             capitalBal = String.format("%.2f", capitalBalDbl);
                                             expenseAmtFee = String.format("%.2f", expenseAmtFeeDbl); 
                                             principalAmt = String.format("%.2f", principalAmtDbl);
                                             interestAmtFee = String.format("%.2f", interestAmtFeeDbl + currentInterestAmtFeeDbl);    //Add the CURRENT and INTEREST/INTEREST.ONLY due type for Interest Value
                                             insuranceAmtFee = String.format("%.2f", insuranceAmtFeeDbl);
                                             commissionAmtFee = String.format("%.2f", commissionAmtFeeDbl);
                                             totalFeeAmt = String.format("%.2f", totalFeeAmtDbl);
                                             
                                        //Format the Detail Notice D02 string values based on the length   
                                             detCode02 = StringUtils.rightPad(detCode02, 20, " ");
                                             eventCode = StringUtils.rightPad(eventCode, 5, " ");
                                             dueDate = StringUtils.rightPad(dueDate, 8, "0");                                    
                                                 
                                             totalFeeAmt = formatAmt(totalFeeAmt);       //Calling formatAmt Class for getting Amount Format
                                             capitalBal = formatAmt(capitalBal);
                                             principalAmt = formatAmt(principalAmt);
                                             interestAmtFee = formatAmt(interestAmtFee);
                                             insuranceAmtFee = formatAmt(insuranceAmtFee);
                                             insuranceTaxAmtFee = formatAmt(insuranceTaxAmtFee);
                                             otherInsuranceAmt = formatAmt(otherInsuranceAmt);
                                             commissionAmtFee = formatAmt(commissionAmtFee);
                                             largeAmtFee = formatAmt(largeAmtFee);
                                             expenseAmtFee = formatAmt(expenseAmtFee);
                                             itfAmtFee = formatAmt(itfAmtFee);
                                             reducedAmtFee = formatAmt(reducedAmtFee);                            
                                             
                                        //Form Detail Notice D02 Message         
                                             dtValInt = Integer.parseInt(dueDate);
                                             todayValInt = Integer.parseInt(dtValue);
                                           
                                             if(eventCode.equals("C0004") && (dtValInt <= todayValInt))
                                             {
                                                 noOfEventVal = noOfEventVal + 1;
                                             }
                                             
                                             if(eventCode.equals("C0004") && (dtValInt > todayValInt))
                                             {
                                                 if(dateCount <= 5)
                                                 { 
                                                     dateCount = dateCount + 1;
                                                     String noOfQuotoStr = StringUtils.leftPad(Integer.toString(dateCount), 5, "0");
                                                     
                                                     paymentScheduleDets = detCode02+eventCode+noOfQuotoStr+dueDate+totalFeeAmt+capitalBal+principalAmt+interestAmtFee+insuranceAmtFee+insuranceTaxAmtFee+otherInsuranceAmt+commissionAmtFee+expenseAmtFee+largeAmtFee+itfAmtFee+reducedAmtFee;  
                                                     if(dateCount == 1)
                                                     {
                                                         paymentScheduleDetails = paymentScheduleDets;
                                                     }else
                                                     {
                                                         paymentScheduleDetails = paymentScheduleDetails+"\n"+paymentScheduleDets;
                                                     } 
                                                 }   
                                                 else
                                                 {
                                                     break;
                                                 }
                                             }  
                                             else
                                             {
                                                 if(eventCode.equals("C0002"))
                                                 {
                                                     noOfQuoto = StringUtils.leftPad(noOfQuoto, 5, "0");
                                                     paymentScheduleDets = detCode02+eventCode+noOfQuoto+dueDate+totalFeeAmt+capitalBal+principalAmt+interestAmtFee+insuranceAmtFee+insuranceTaxAmtFee+otherInsuranceAmt+commissionAmtFee+expenseAmtFee+largeAmtFee+itfAmtFee+reducedAmtFee;  
                                                     if(k==startCnt)
                                                     {
                                                         paymentScheduleDetails = paymentScheduleDets;
                                                     }else
                                                     {
                                                         paymentScheduleDetails = paymentScheduleDetails+"\n"+paymentScheduleDets;
                                                     }
                                                 }
                                             }
                                             noOfD02Recs = totalLoanInstallment;
                                             noOfD03Recs = Integer.toString(commissionD03Cnt);
                                             noOfD05Recs = Integer.toString(expenseD05Cnt);
                                              
                                             detNoticeD02Msg = paymentScheduleDetails;
                                             detNoticeD03Msg = commissionDetails;
                                             detNoticeD05Msg = expenseDetails;
                                         }     
                                     
                                      if(eventCode.equals("C0004"))
                                      {
                                          if(activityName.equals("LENDING-APPLYPAYMENT-PR.DUE.PAYMENT") || activityName.equals("LENDING-SETTLE-PR.REPAYMENT"))
                                          {
                                              nextInstallmentExpireDate = dtValue;
                                          }else
                                          {
                                               nextInstallmentExpireDate = scheduleProjectorRec.getDueDate(noOfEventVal).getDueDate().getValue();   //Vencimiento
                                          }
                                      }
                                 }
                             }
                             catch(Exception detNoticeMsgErr)
                             {
                                 detNoticeMsgErr.getMessage();
                             }
                        
                         //Get principal, interest and charges values from SCHEDULE PROJECTOR    
                             try
                             {
                                 int i = 0;
                                 int Dtcnt = 0;
                                 int processFlg = 0;
                                 Dtcnt = scheduleProjectorRec.getDueDate().size();
                                 String gastoPropertyAmt = "";
                                 
                                 List<DueTypeClass> dueTypeClsList = new ArrayList<DueTypeClass>();
                                 int dueTypeClsListCnt = 0;
                             
                                 for(i=0; i<Dtcnt; i++)
                                 {
                                     dtVal = scheduleProjectorRec.getDueDate(i).getDueDate().getValue();
                                     if(eventCode.equals("C0002") || eventCode.equals("C0004"))
                                     { 
                                         if(dtVal.equals(dtValue))
                                         {
                                             processFlg = 1;
                                             break;
                                         }
                                     }
                                     else
                                     {
                                         try
                                         {
                                             dtValueInt = Integer.parseInt(dtVal);
                                             effValInt = Integer.parseInt(effectiveDate);
                                         }
                                         catch(Exception e1)
                                         {
                                             e1.getMessage();
                                         }
                                         if(dtValueInt > effValInt)
                                         { 
                                             processFlg = 1;
                                             break;
                                         }
                                     }
                                 }
                                     
                                 if(processFlg == 1)
                                 {
                                     String dueTypeChrg = "";
                                     String prinicipalAmt = "";
                                     String interest = "";
                                     String chrg = "";
                                     double prinicipalAmtDbl = 0;
                                     double interestDbl = 0;
                                     double chrgDbl = 0;
                                     String dueTypeListChrgStr = scheduleProjectorRec.getDueDate(i).getDueType().toString();
                                     
                                     dueTypeClsList =  scheduleProjectorRec.getDueDate(i).getDueType();
                                     dueTypeClsListCnt = dueTypeClsList.size();
                                     
                                   //Get Amount in fees/Cancellation fees from schedule projector
                                     if(!eventCode.equals("C0002"))
                                     {
                                         if(dueTypeListChrgStr.contains("CHARGE"))     //If CONSTANT due type include the Charge Property
                                         {
                                             dueTypeChrg = "CHARGE";
                                         }
                                         else if((dueTypeListChrgStr.contains("CONSTANT")) && (dueTypeListChrgStr.contains("BCIPE")))
                                         {
                                             dueTypeChrg = "CONSTANT";
                                         }
                                         
                                         for(int p=0; p<dueTypeClsListCnt; p++)
                                         {
                                             double dueGastoPropertyAmtDbl = 0;
                                             double dueCommPropertyAmtDbl = 0;
                                             
                                             String chrgDueTypeVal = dueTypeClsList.get(p).getDueType().getValue();
                                             if((!dueTypeChrg.equals("")) && (chrgDueTypeVal.equals(dueTypeChrg)))
                                             {
                                                 String[] duePropertyStringList = dueTypeClsList.get(p).getDueProperty().getValue().split("/");
                                                 String[] duePropertyAmtStringList = dueTypeClsList.get(p).getDuePropertyAmount().getValue().split("/");
                                                 
                                                 List<String> duePropertyList = new ArrayList<String>();
                                                 List<String> duePropertyAmtList = new ArrayList<String>();

                                                 for(String duePropertyStr : duePropertyStringList)
                                                 {
                                                     duePropertyList.add(duePropertyStr);
                                                 }
                                                 for(String duePropertyAmtStr : duePropertyAmtStringList)
                                                 {
                                                     duePropertyAmtList.add(duePropertyAmtStr);
                                                 }
                                                
                                                 int duePropertyCntVal = duePropertyList.size();
                                                 for(int q=0; q<duePropertyCntVal; q++)
                                                 {
                                                    duePropertyAmt = "";
                                                    duePropertyVal = "";
                                                    propertyDesVal = "";    
                                                    String dueGastoPropertyAmt = "";
                                                    String dueCommPropertyAmt = "";
                                                    double dueCommPropAmtDbl = 0;
                                                    double dueGastoPropAmtDbl = 0;
                                                   
                                                    duePropertyVal = duePropertyList.get(q);
                                                  //Get property Description
                                                     try
                                                     {
                                                         AaPropertyRecord propertyRec = new AaPropertyRecord(da.getRecord("AA.PROPERTY", duePropertyVal));                                           
                                                         propertyDesVal = propertyRec.getDescription(0).getValue();
                                                     }
                                                     catch(Exception propertyErr)
                                                     {
                                                         propertyDesVal = "";   
                                                     }                                    
                                                     
                                                     if(duePropertyVal.contains("BCIPE"))
                                                     {
                                                         if((duePropertyVal.contains("BCIPEGAS")) || (propertyDesVal.contains("Gasto")))      //If the property is related to Expense
                                                         {
                                                             dueGastoPropertyAmt = duePropertyAmtList.get(q);
                                                             dueGastoPropAmtDbl = Double.parseDouble(dueGastoPropertyAmt);
                                                             dueGastoPropertyAmtDbl = dueGastoPropertyAmtDbl + dueGastoPropAmtDbl;
                                                           
                                                         }else   //If the property is related to Commission
                                                         {
                                                             dueCommPropertyAmt = duePropertyAmtList.get(q);
                                                             dueCommPropAmtDbl = Double.parseDouble(dueCommPropertyAmt);
                                                             dueCommPropertyAmtDbl = dueCommPropertyAmtDbl + dueCommPropAmtDbl;
                                                         } 
                                                     }
                                                 }    
                                                 amtCancelFee = String.format("%.2f", dueCommPropertyAmtDbl);     //Comisión
                                                 gastoPropertyAmt = String.format("%.2f", dueGastoPropertyAmtDbl);
                                                 amtConceptOtherPrincipalIntFeeCancelInsurance = String.format("%.2f", dueGastoPropertyAmtDbl + dueCommPropertyAmtDbl);    //Otros cargos
                                                 break;
                                             }
                                         }
                                     }
                                     
                                     for(int j=0; j<dueTypeClsListCnt; j++)
                                     {
                                         String dueTypeVal = dueTypeClsList.get(j).getDueType().getValue(); 
                                         switch(dueTypeVal)
                                         {
                                             case "LINEAR":
                                                 prinicipalAmt = dueTypeClsList.get(j).getDueTypeAmount().getValue();
                                                 prinicipalAmtDbl = Double.parseDouble(prinicipalAmt);
                                                 break;
                                                     
                                             case "CHARGE":
                                                 chrg = dueTypeClsList.get(j).getDueTypeAmount().getValue();
                                                 chrgDbl = Double.parseDouble(chrg);
                                                 break;
                                                    
                                             case "INTEREST.ONLY":  case "ACTUAL":  case "INTEREST":
                                                 interest = dueTypeClsList.get(j).getDueTypeAmount().getValue();
                                                 interestDbl = Double.parseDouble(interest);
                                                 break;
                                                  
                                             case "CONSTANT":      //Include CONSTANT payment Type
                                                    
                                                 String[] duePropertyConstantStringList = dueTypeClsList.get(j).getDueProperty().getValue().split("/");
                                                 String[] duePropertyAmtConstantStringList = dueTypeClsList.get(j).getDuePropertyAmount().getValue().split("/");
                                                   
                                                 List<String> duePropertyConstantList = new ArrayList<String>();
                                                 List<String> duePropertyAmtConstantList = new ArrayList<String>();

                                                 for(String duePropertyConstantStr : duePropertyConstantStringList)       
                                                 {
                                                     duePropertyConstantList.add(duePropertyConstantStr);
                                                 }
                                                 for(String duePropertyAmtConstantStr : duePropertyAmtConstantStringList)
                                                 {
                                                     duePropertyAmtConstantList.add(duePropertyAmtConstantStr);
                                                 }
                                                     
                                                 for(int m=0; m<duePropertyConstantList.size(); m++)
                                                 {
                                                     duePropertyVal = "";
                                                     double chrgConstantDbl = 0;
                                                     duePropertyVal = duePropertyConstantList.get(m);
                                                     switch(duePropertyVal)
                                                     {
                                                         case "PRINCIPALINTE":
                                                             interest = duePropertyAmtConstantList.get(m); 
                                                             interestDbl = Double.parseDouble(interest);
                                                             break;
                                                                 
                                                         case "ACCOUNT":
                                                             prinicipalAmt = duePropertyAmtConstantList.get(m);
                                                             prinicipalAmtDbl = Double.parseDouble(prinicipalAmt);
                                                             break;
                                                            
                                                         default:
                                                             if(duePropertyVal.contains("BCIPE"))     //If CONSTANT due type include the Charge Property
                                                             {
                                                                 chrg = duePropertyAmtConstantList.get(m);
                                                                 chrgConstantDbl = Double.parseDouble(chrg);
                                                                 chrgDbl = chrgDbl + chrgConstantDbl;
                                                             }
                                                     }
                                                 }
                                                 break;
                                         }
                                     }   
                                     
                                     principalAmtCancel = String.format("%.2f", prinicipalAmtDbl);      //Amortización
                                     feeInterestCancel = String.format("%.2f", interestDbl);    //Intereses
                                     
                                     principalAmtFeeCancelInterest = String.format("%.2f", prinicipalAmtDbl + interestDbl);   //Total cuota
                                     totFeeAmtCancel = String.format("%.2f", prinicipalAmtDbl + interestDbl + chrgDbl);      //Total pagado
                                 }
                                 
                                 if(eventCode.equals("N0011"))
                                 {
                                     amtFeeCancel = gastoPropertyAmt;
                                     nextInstallmentExpireDate = dtVal;
                                     nextInstallmentduePay = dtVal; 
                                     noduedt = dtValueInt;
                                     noOfD02Recs = "";
                                     noOfD03Recs = "";
                                     noOfD04Recs = "";
                                     noOfD05Recs = "";
                                  
                                     for(int k=startCnt; k<dutDateCnt; k++)
                                     {                  
                                         dueDate = "";
                                         int dtValInt = 0;
                                         if(startCnt == 0)
                                         {
                                             totalAmtInstallmentDueLoan = Integer.toString(dutDateCnt);
                                             totalLoanInstallment = totalAmtInstallmentDueLoan;
                                         }
                                         else
                                         {
                                             totalAmtInstallmentDueLoanInt = dutDateCnt-1;
                                             totalAmtInstallmentDueLoan = Integer.toString(totalAmtInstallmentDueLoanInt);
                                             totalLoanInstallment = totalAmtInstallmentDueLoan;
                                         }
                                        
                                         dueDate = dueDateList.get(k).getDueDate().getValue();
                                         dtValInt = Integer.parseInt(dueDate);
                                         try
                                         {
                                              if(dtValInt<= noduedt)
                                              {
                                                   noOfEventVal = noOfEventVal + 1;                                       
                                              }
                                         }
                                         catch(Exception e2)
                                         {
                                             e2.getMessage();
                                         }
                                         if(installmentDatePaid.equals(""))
                                         {
                                             installmentDatePaid = dueDate;
                                             firstLoanInstallmentDate = dueDate;
                                         }
                                     }
                                
                                 //Get Total Amount Installment Cancel Loan
                                     List<String> bciBillDetailsVal = new ArrayList<String>();
                                     String selCmdOne = "WITH (ARRANGEMENT.ID EQ "+operationNo+") AND (SETTLE.STATUS EQ 'REPAID') AND (BILL.STATUS UNLIKE ...ADVANCED...) AND (PAYMENT.DATE NE "+minDate+")";                       
                                     try           
                                     {
                                         bciBillDetailsVal = da.selectRecords("","AA.BILL.DETAILS","",selCmdOne); 
                                         totalAmtInstallmentCancelLoan = Integer.toString(bciBillDetailsVal.size());                               
                                     }  
                                     catch(Exception billDetErr)
                                     {
                                         totalAmtInstallmentCancelLoan = "";
                                     }
                                 }
                             }
                             catch(Exception principalIntChrgErr)
                             {
                                 principalIntChrgErr.getMessage();
                             }
                             noOfEvent = Integer.toString(noOfEventVal);   //Actual
                         }
                   
                      //Get Interest Rate type
                         try
                         {
                             negotiationCurCnt = aaArrInterestRec.getNegotiatedFlds().size() - 1;                   
                             interestRateCurVal = aaArrInterestRec.getNegotiatedFlds().get(negotiationCurCnt).getValue();
                     
                             if (interestRateCurVal.equals("FIXED.RATE"))
                             {
                                 interestRateType = "FIJA";
                             }
                             else if(interestRateCurVal.equals("FLOATING.INDEX"))
                             {     
                                 interestRateType = "VARIABLE";
                             }
                         }
                         catch(Exception e)
                         {
                             interestRateType = "";
                         } 
                         
                     //Get the value of the fields AMOUNT, MATURITY.DATE and Get Date of last modification Loan TERM from AA.ARR.TERM.AMOUNT table                   
                         AaPrdDesTermAmountRecord aaPrdDesTermAmtRec = null;
                         try
                         {
                             aaPrdDesTermAmtRec = new AaPrdDesTermAmountRecord(contract.getConditionForProperty("COMMITMENT"));
                             txnAmount = aaPrdDesTermAmtRec.getAmount().getValue();
                             maturityDate = aaPrdDesTermAmtRec.getMaturityDate().getValue();
                             dtTime = aaPrdDesTermAmtRec.getDateTime(0).toString();
                             dateOfLastModifyLoanTerms = dtTime.substring(0, 6);
                             dateOfLastModifyLoanTerms = "20"+dateOfLastModifyLoanTerms;
                             
                             termVal = aaPrdDesTermAmtRec.getTerm().getValue();       
                             if(!termVal.equals(""))
                             {
                                 establishTerm = termVal.replaceAll("[^0-9]", "");        //Get the numeric value from TERM                         
                                 unitTermChar = termVal.charAt(termVal.length()-1);       //Get the unit from TERM field
                                 unitestablishTerm = Character.toString(unitTermChar);
                                 switch(unitestablishTerm)
                                 {
                                     case "D":
                                         unitestablishTerm = "DIAS";
                                         break;
                                     case "M":
                                         unitestablishTerm = "MESES";
                                          break;
                                     case "Y":
                                         unitestablishTerm = "ANOS";
                                         break;                                   
                                 }
                             }
                         }
                         catch(Exception termErr)
                         {
                             establishTerm = "";
                             unitestablishTerm = "";         
                         }   
                         finalMaturityDateLoan = maturityDate;
                         totalAmtGrantLoan = txnAmount;
                  
                         
                     //Get maturity date previous condition
                         AaPrdDesAccountRecord aaPrdDesAcctRecord = null;
                         AaPrdDesTermAmountRecord aaPrdDesTermAmtRecVal = null;
                         try
                         {
                              aaPrdDesAcctRecord = new AaPrdDesAccountRecord(contract.getConditionForProperty("ACCOUNT"));
                              String currnocnt = aaPrdDesAcctRecord.getCurrNo();
                              int curcnt = Integer.parseInt(currnocnt);

                              if (curcnt >1 )
                              {
                                  aaPrdDesTermAmtRecVal = new AaPrdDesTermAmountRecord(contract.getPreviousProperty("COMMITMENT"));             
                                  finalMaturityDateLoanPreCondition = aaPrdDesTermAmtRecVal.getMaturityDate().getValue();
                              }
                              
                              if(finalMaturityDateLoanPreCondition.equals("") && (!maturityDate.equals("")))
                              {
                                  finalMaturityDateLoanPreCondition =  maturityDate;
                              }
                               
                          }
                          catch(Exception termErr)
                          {
                              termErr.getMessage();
                          }
                         
                           timeOfOperation = hdrEventTime;
                           dateOfOperation = effectiveDate;
                           Loandisbursementdate = minDate;
                        
                           if(eventCode.equals("C0002"))
                           {
                               dateOfGrantLoan = orgSystemDate;
                           }else
                           {
                               try
                               {
                                   AaArrangementRecord arrangementRec = new AaArrangementRecord(da.getRecord("AA.ARRANGEMENT", operationNo));
                                   dateOfGrantLoan = arrangementRec.getStartDate().getValue();
                               }
                               catch(Exception dateOfGrantLoanErr)
                               {
                                   dateOfGrantLoan = ""; 
                               }
                           }
                           
                        //Get CAPITAL Amount (Total amount grant loan) from ECB
                           if(eventCode.equals("C0004") || eventCode.equals("N0011"))
                           {
                               try
                               {
                                   List<BalanceMovement> Value4 = contract.getContractBalanceMovements("CURACCOUNT", "");
                                   TNumber tAmt = new TNumber();
                                   tAmt = Value4.get(0).getBalance();
                                      
                                   List<BalanceMovement> dueAccount = contract.getContractBalanceMovements("DUEACCOUNT", "");
                                   TNumber tdueAmt = new TNumber();
                                   tdueAmt = dueAccount.get(0).getBalance();
                                    
                                   List<BalanceMovement> grcAccount = contract.getContractBalanceMovements("GRCACCOUNT", "");
                                   TNumber tgrcAmnt = new TNumber();
                                   tgrcAmnt = grcAccount.get(0).getBalance();
                                      
                                   List<BalanceMovement> delAccount = contract.getContractBalanceMovements("DELACCOUNT", "");
                                   TNumber tdelAmt = new TNumber();
                                   tdelAmt = delAccount.get(0).getBalance();
                                      
                                   List<BalanceMovement> nabAccount = contract.getContractBalanceMovements("NABACCOUNT", "");
                                   TNumber tnabAmt = new TNumber();
                                   tnabAmt = nabAccount.get(0).getBalance();
                                     
                                   double totalamount = tAmt.doubleValue() + tdueAmt.doubleValue() + tgrcAmnt.doubleValue() + tdelAmt.doubleValue() + tnabAmt.doubleValue();
                                     
                                   principalBalLoan = String.format("%.2f", totalamount);   //Capital
                                   
                                   if(eventCode.equals("C0004"))
                                   {
                                       paymentMethodPaidEvent = "DEBITO EN CUENTA";
                                       totalAmtGrantLoan = principalBalLoan;
                                   }
                               }
                               catch(Exception e2)
                               {
                                   totalAmtGrantLoan = "";
                               }
                           }
                     }

  //************************************************************************************************************************************//
                    
                     try
                     {
                      //Format the Header Notice String value based on the length
                         hdrCode = StringUtils.rightPad(hdrCode, 20, " ");
                         eventCode = StringUtils.rightPad(eventCode, 5, " ");
                         noOfD02Recs = StringUtils.leftPad(noOfD02Recs, 5, "0");
                         noOfD03Recs = StringUtils.leftPad(noOfD03Recs, 5, "0");
                         noOfD04Recs = StringUtils.leftPad(noOfD04Recs, 5, "0");
                         noOfD05Recs = StringUtils.leftPad(noOfD05Recs, 5, "0");
                         customerNo1 = StringUtils.rightPad(customerNo1, 20, " ");
                         customerName1 = StringUtils.rightPad(customerName1, 120, " ");
                         legalID1 = StringUtils.rightPad(legalID1, 20, " ");
                         customerNo2 = StringUtils.rightPad(customerNo2, 20, " ");
                         customerName2 = StringUtils.rightPad(customerName2, 120, " ");
                         legalID2 = StringUtils.rightPad(legalID2, 20, " ");
                         customerNo3 = StringUtils.rightPad(customerNo3, 20, " ");
                         customerName3 = StringUtils.rightPad(customerName3, 120, " ");
                         legalID3 = StringUtils.rightPad(legalID3, 20, " ");
                         customerNo4 = StringUtils.rightPad(customerNo4, 20, " ");
                         customerName4 = StringUtils.rightPad(customerName4, 120, " ");
                         legalID4 = StringUtils.rightPad(legalID4, 20, " ");
                         customerNo5 = StringUtils.rightPad(customerNo5, 20, " ");
                         customerName5 = StringUtils.rightPad(customerName5, 120, " ");
                         legalID5 = StringUtils.rightPad(legalID5, 20, " ");
                         address = StringUtils.rightPad(address, 120, " ");
                         email = StringUtils.rightPad(email, 50, " ");
                         phoneNo = StringUtils.rightPad(phoneNo, 20, " ");
                         hdrEventDate = StringUtils.rightPad(hdrEventDate, 8, "0");
                         hdrEventTime = StringUtils.rightPad(hdrEventTime, 8, "0");
                         loanNo = StringUtils.rightPad(loanNo, 30, " ");        
                         
                   
                    //Format the Detail Notice D01 string values based on the length
                         detCode01 = StringUtils.rightPad(detCode01, 20, " ");
                         eventCode = StringUtils.rightPad(eventCode, 5, " ");  
                         loanNo = StringUtils.rightPad(loanNo, 30, " ");        
                         codeProduct = StringUtils.rightPad(codeProduct, 5, " ");        
                         productDescript = StringUtils.rightPad(productDescript, 30, " ");        
                         legalID1 = StringUtils.rightPad(legalID1, 20, " ");        
                         bench = StringUtils.rightPad(bench, 50, " ");        
                         bankOfficeCode = StringUtils.rightPad(bankOfficeCode, 5, " "); 
                         branchShortName = StringUtils.rightPad(branchShortName, 30, " ");        
                         codeExecutive = StringUtils.rightPad(codeExecutive, 5, " ");      
                         executiveName = StringUtils.rightPad(executiveName, 100, " ");        
                         executiveTelephone = StringUtils.rightPad(executiveTelephone, 20, " ");        
                         executiveEmail = StringUtils.rightPad(executiveEmail, 50, " ");        
                         paymentType = StringUtils.rightPad(paymentType, 30, " ");        
                         paymentMethodPaidEvent = StringUtils.rightPad(paymentMethodPaidEvent, 30, " ");        
                         formSubmissionStatement = StringUtils.rightPad(formSubmissionStatement, 30, " ");        
                         noOfEvent = StringUtils.leftPad(noOfEvent, 5, "0");        
                         noOfInstallmentPaid = StringUtils.leftPad(noOfInstallmentPaid,5, "0");        
                         installmentDatePaid = StringUtils.rightPad(installmentDatePaid, 8, "0");        
                         nextInstallmentExpireDate = StringUtils.rightPad(nextInstallmentExpireDate, 8, "0");        
                         nextInstallmentduePay = StringUtils.rightPad(nextInstallmentduePay, 8, "0");        
                         dateOfOperation = StringUtils.rightPad(dateOfOperation, 8, "0");        
                         timeOfOperation = StringUtils.rightPad(timeOfOperation, 8, "0");        
                         currency = StringUtils.rightPad(currency, 5, " ");        
                         loanCcyPreCondition = StringUtils.rightPad(loanCcyPreCondition, 5, " ");              
                         payInAccountNo = StringUtils.rightPad(payInAccountNo, 30, " ");        
                         payInAccountCcy = StringUtils.rightPad(payInAccountCcy, 5, " ");        
                         comment = StringUtils.rightPad(comment, 50, " ");        
                         dateOfGrantLoan = StringUtils.rightPad(dateOfGrantLoan, 8, "0");        
                         Loandisbursementdate = StringUtils.rightPad(Loandisbursementdate, 8, "0");        
                         dateOfLastModifyLoanTerms = StringUtils.rightPad(dateOfLastModifyLoanTerms, 8, "0");        
                         firstLoanInstallmentDate = StringUtils.rightPad(firstLoanInstallmentDate, 8, "0");        
                         finalMaturityDateLoan = StringUtils.rightPad(finalMaturityDateLoan, 8, "0");        
                         finalMaturityDateLoanPreCondition = StringUtils.rightPad(finalMaturityDateLoanPreCondition, 8, "0");        
                         unitestablishTerm = StringUtils.rightPad(unitestablishTerm, 5, " ");
                         unitTermLoanExpressPreCondition = StringUtils.rightPad(unitTermLoanExpressPreCondition, 5, " ");
                         establishTerm = StringUtils.leftPad(establishTerm, 5, "0");
                         termLoanPreCondition = StringUtils.leftPad(termLoanPreCondition, 5, "0");
                         periodicityLoanCapitalInstallment = StringUtils.rightPad(periodicityLoanCapitalInstallment, 30, " ");
                         periodicityInterestInstallmentLoan = StringUtils.rightPad(periodicityInterestInstallmentLoan, 30, " ");
                         annualAmtLoanPrincipalInstallment = StringUtils.leftPad(annualAmtLoanPrincipalInstallment, 5, "0");
                         annualAmtLoanInterestInstallment = StringUtils.leftPad(annualAmtLoanInterestInstallment, 5, "0");
                         unitGracePeriod = StringUtils.rightPad(unitGracePeriod, 5, " ");
                         loanGracePeriod = StringUtils.leftPad(loanGracePeriod, 5, "0");
                         codeTypeGuaranteeLoan = StringUtils.rightPad(codeTypeGuaranteeLoan, 5, " ");
                         typeLoanGuarantee = StringUtils.rightPad(typeLoanGuarantee, 30, " ");
                         typeLoanGuaranteePreCondition = StringUtils.rightPad(typeLoanGuaranteePreCondition, 30, " ");
                         interestRateType = StringUtils.rightPad(interestRateType, 30, " ");
                         interestRatePreCondition = StringUtils.rightPad(interestRatePreCondition, 30, " ");
                         loanFeeType = StringUtils.rightPad(loanFeeType, 30, " ");
                         collectionLoanGracePeriod = StringUtils.rightPad(collectionLoanGracePeriod, 2, " ");        
                         totalLoanInstallment = StringUtils.leftPad(totalLoanInstallment, 5, "0");
                         totalAmtLoanInstallmentPreCondition = StringUtils.leftPad(totalAmtLoanInstallmentPreCondition, 5, "0");
                         totalNoUnpaidDueYear = StringUtils.leftPad(totalNoUnpaidDueYear, 5, "0");
                         totalAmtInstallmentDueLoan = StringUtils.leftPad(totalAmtInstallmentDueLoan, 5, "0");
                         totalAmtInstallmentCancelLoan = StringUtils.leftPad(totalAmtInstallmentCancelLoan, 5, "0");
                         additionInsuranceContract = StringUtils.rightPad(additionInsuranceContract, 120, " ");
                         additionInsuranceContractPreCondition = StringUtils.rightPad(additionInsuranceContractPreCondition, 120, " ");
                         customerCommunication = StringUtils.rightPad(customerCommunication, 150, " "); 
                         
                         penaltyNonPayment = formatRate(penaltyNonPayment);      //Calling formatRate Class for getting rate Format
                         penaltyNonPaymentPreCondition = formatRate(penaltyNonPaymentPreCondition);
                         
                         annualEffectiveInterestRateTEA = formatRate(annualEffectiveInterestRateTEA); 
                         annualEffectiveInterestRateTEAPreCondition = formatRate(annualEffectiveInterestRateTEAPreCondition);
                         
                         loanGracePeriodAmt = formatAmt(loanGracePeriodAmt);     //Calling formatAmt Class for getting Amount Format
                         totFeeAmtCancel = formatAmt(totFeeAmtCancel);
                         principalAmtCancel = formatAmt(principalAmtCancel);
                         feeInterestCancel = formatAmt(feeInterestCancel);
                         principalAmtFeeCancelInterest = formatAmt(principalAmtFeeCancelInterest);
                         amtCancelFee = formatAmt(amtCancelFee);
                         totalAmtFeeCancelInsurance = formatAmt(totalAmtFeeCancelInsurance);
                         secureAmtFeeReliefCancel = formatAmt(secureAmtFeeReliefCancel);
                         amtInsuranceFeeCancel = formatAmt(amtInsuranceFeeCancel);
                         amtFeeCancel = formatAmt(amtFeeCancel);
                         amtITFCancel = formatAmt(amtITFCancel);
                         amtOtherConceptFeeCancel = formatAmt(amtOtherConceptFeeCancel);
                         totalAmtGrantLoan = formatAmt(totalAmtGrantLoan);
                         totalPrincipalAmtLoan = formatAmt(totalPrincipalAmtLoan);
                         totalPrincipalAmtLoanPreCondition = formatAmt(totalPrincipalAmtLoanPreCondition);
                         totalAmtGrantLoanPreCondition = formatAmt(totalAmtGrantLoanPreCondition);
                         principalBalLoan = formatAmt(principalBalLoan);
                         annualEffectiveCostRateTCEA = formatRate(annualEffectiveCostRateTCEA);
                         annualEffectiveCostRateTCEAPreCondition = formatRate(annualEffectiveCostRateTCEAPreCondition);
                         amtConceptOtherPrincipalIntFeeCancelInsurance = formatAmt(amtConceptOtherPrincipalIntFeeCancelInsurance);  
                     }
                     catch(Exception formatErr)
                     {
                         formatErr.getMessage();
                     }
                           
                 //Form Header Notice Message
                     hdrNoticeMsg = hdrCode+eventCode+noOfD02Recs+noOfD03Recs+noOfD04Recs+noOfD05Recs+customerNo1+customerName1+legalID1+customerNo2+customerName2+legalID2+customerNo3+customerName3+legalID3+customerNo4+customerName4+legalID4+customerNo5+customerName5+legalID5+address+email+phoneNo+hdrEventDate+hdrEventTime+loanNo; 
                  
                 //Form Detail Notice D01 Message         
                       detNoticeD01Msg = detCode01+eventCode+loanNo+codeProduct+productDescript+legalID1+bench+bankOfficeCode+branchShortName+codeExecutive+executiveName+executiveTelephone+executiveEmail+paymentType+
                    paymentMethodPaidEvent+formSubmissionStatement+noOfEvent+noOfInstallmentPaid+installmentDatePaid+
                    nextInstallmentExpireDate+nextInstallmentduePay+dateOfOperation+timeOfOperation+currency+loanCcyPreCondition+
                    totFeeAmtCancel+principalAmtCancel+feeInterestCancel+principalAmtFeeCancelInterest+amtCancelFee+totalAmtFeeCancelInsurance+
                    secureAmtFeeReliefCancel+amtInsuranceFeeCancel+amtFeeCancel+amtITFCancel+amtOtherConceptFeeCancel+amtConceptOtherPrincipalIntFeeCancelInsurance+payInAccountNo+payInAccountCcy+
                    comment+dateOfGrantLoan+Loandisbursementdate+dateOfLastModifyLoanTerms+firstLoanInstallmentDate+
                    finalMaturityDateLoan+finalMaturityDateLoanPreCondition+unitestablishTerm+unitTermLoanExpressPreCondition+
                    establishTerm+termLoanPreCondition+periodicityLoanCapitalInstallment+periodicityInterestInstallmentLoan+annualAmtLoanPrincipalInstallment+annualAmtLoanInterestInstallment+
                    unitGracePeriod+loanGracePeriod+codeTypeGuaranteeLoan+typeLoanGuarantee+typeLoanGuaranteePreCondition+
                    interestRateType+interestRatePreCondition+annualEffectiveInterestRateTEA+annualEffectiveInterestRateTEAPreCondition+annualEffectiveCostRateTCEA+annualEffectiveCostRateTCEAPreCondition+
                    loanFeeType+collectionLoanGracePeriod+loanGracePeriodAmt+penaltyNonPayment+penaltyNonPaymentPreCondition+
                    totalAmtGrantLoan+totalAmtGrantLoanPreCondition+totalPrincipalAmtLoan+totalPrincipalAmtLoanPreCondition+
                    totalLoanInstallment+totalAmtLoanInstallmentPreCondition+totalNoUnpaidDueYear+totalAmtInstallmentDueLoan+
                    totalAmtInstallmentCancelLoan+principalBalLoan+additionInsuranceContract+additionInsuranceContractPreCondition+customerCommunication;
                 
             //************************************************************************************************************************************//               
                        
                    switch(eventCode)
                    {
                        case "C0002":
                            hdrDetNoticeMsg = hdrNoticeMsg+'\n'+detNoticeD01Msg+'\n'+detNoticeD02Msg;
                            hdrDetNoticeMsg = hdrDetNoticeMsg.replaceAll("\n", "\r\n");
                            break;
                           
                        case "C0003":
                            hdrDetNoticeMsg = hdrNoticeMsg+'\n'+detNoticeD01Msg+'\n'+detNoticeD03Msg+'\n'+detNoticeD04Msg+'\n'+detNoticeD05Msg;
                            hdrDetNoticeMsg = hdrDetNoticeMsg.replaceAll("\n", "\r\n");
                            break;
                           
                        case "N0011":
                            hdrDetNoticeMsg = hdrNoticeMsg+'\n'+detNoticeD01Msg;
                            hdrDetNoticeMsg = hdrDetNoticeMsg.replaceAll("\n", "\r\n");
                            break;
                           
                        case "C0004":
                           if(flagTodayDue.equals("YES"))
                           {
                               hdrDetNoticeMsg = hdrNoticeMsg+'\n'+detNoticeD01Msg+'\n'+detNoticeD02Msg;
                               hdrDetNoticeMsg = hdrDetNoticeMsg.replaceAll("\n", "\r\n");
                           }
                           break;
                      }
                   
                    
                      if(!hdrDetNoticeMsg.equals("")) 
                      {           
                      //Get PATH from EB.BCI.ENGAGEONE.GEN.FILE.PATH (To which path need to be generate the file)
                          try
                          {
                              EbBciEngageoneGenFilePathRecord engageGenFilePathrec = new EbBciEngageoneGenFilePathRecord(da.getRecord("EB.BCI.ENGAGEONE.GEN.FILE.PATH","LOAN.OFFLINE"));
                              loanFilePath = engageGenFilePathrec.getPath().getValue();
                          }
                          catch(Exception pathErr)
                          {
                              loanFilePath = "";
                          }
                         
                      //Get Current time
                          String currTime = "";
                          try
                          {
                              DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HHmmss");
                              LocalDateTime now = LocalDateTime.now();
                              currTime = dtf.format(now);
                          }
                          catch(Exception currTimeErr)
                          {
                              currTimeErr.getMessage();
                          }
                        
                          String fileName = eventCode+"-"+today+"-"+currTime+".txt";    //File name
                          String currFileNameEventDate = eventCode+"-"+today;
                        
                          try
                          {
                              List<String> results = new ArrayList<String>();
                              File[] files = new File(loanFilePath+"/").listFiles();  //List the all files from the mentioned path
                            
                           //If this pathname does not denote a directory, then listFiles() returns null. 
                              for (File file : files)
                              {
                                  if (file.isFile())
                                  {
                                      results.add(file.getName());    //Add the file names to String array
                                  }
                              } 
                              for(int count = 0 ; count <results.size() ; count++ )
                              {
                                  String existFilename = "";
                                  String existFileNameEventDate = "";   
                                
                                  existFilename = results.get(count);
                                  
                                  try
                                  {
                                      existFileNameEventDate = existFilename.split("-")[0]+"-"+existFilename.split("-")[1];
                                  }
                                  catch(Exception existFileNameErr)
                                  {
                                      existFileNameEventDate = "";
                                  }
                                  
                                  if(existFileNameEventDate.equals(currFileNameEventDate))    //If the file is already exist with same event code under the TODAY, then assign the file name as existing file name
                                  {
                                      fileName = existFilename;
                                      break;
                                  }
                              }
                          }
                          catch(Exception exitFileNameErr)
                          {
                              exitFileNameErr.getMessage();
                          }
                          
                     
                       //To write the Header and Detail notice message to the .txt file under the mentioned path with given file name
                          try
                          {
                              File OutputFile = new File(loanFilePath+"/"+fileName);
                              FileWriter writer;
                              if(OutputFile.exists())
                              { 
                                  writer = new FileWriter(OutputFile, true);
                              } 
                              else
                              {
                                  OutputFile.createNewFile();
                                  writer = new FileWriter(OutputFile);
                              }
                            
                              BufferedWriter bufferedWriter = new BufferedWriter(writer);
                              BufferedReader br = new BufferedReader(new FileReader(loanFilePath+"/"+fileName));
                              try 
                              {
                                  if (br.readLine()!= null) 
                                  {
                                      hdrDetNoticeMsg = "\r\n" + hdrDetNoticeMsg;    //If the file is exist with some line, then add the current message to the existing line
                                  }
                               }
                               catch(Exception readerErr)
                               {
                                   readerErr.getMessage();
                               }
                                 
                               bufferedWriter.write((new StringBuilder(hdrDetNoticeMsg).toString()));  
                               bufferedWriter.close();
                               br.close();
                           } 
                           catch (IOException ioe)
                           {
                               ioe.getMessage();
                           } 
                          
                       //Update the Request Message in EB.BCI.UPDATE.ENGAGEONE.DETAILS table
                          try
                          {
                              String exitRequestMsg = "";
                              exitRequestMsg = bciUpdEngageoneDetsRec.getRequestMessage().getValue();
                              
                              if(!exitRequestMsg.equals(""))
                              {
                                  hdrDetNoticeMsg = exitRequestMsg+"\r\n"+hdrDetNoticeMsg;
                              }
                              
                              bciUpdEngageoneDetsRec.setRequestMessage(hdrDetNoticeMsg);                  
                              bciUpdEngageoneDetsTable.write(bciUpdEngageoneDetsId, bciUpdEngageoneDetsRec);
                          }
                          catch (Exception bciUpdEngErr) 
                          {
                              bciUpdEngErr.getMessage();   
                          } 
                      } 
                  }
              }
          }
    
  //*----------------------Format the Rate field values (15 fixed Length)-----------------------------*//
    
    public String formatRate(String rateVal){
        
        String c1 = "";
        if(rateVal.equals(""))
        {
            c1 = StringUtils.leftPad(rateVal, 15, "0");
        }else
        {        
            if((rateVal.indexOf("-") != -1))
            {
                rateVal = rateVal.substring(1);
            }
            
            if((rateVal.indexOf(".") == -1))
            {
                rateVal = rateVal+".0";
            }
            
            String a1 = rateVal.split("\\.")[0];
            a1 = StringUtils.leftPad(a1, 9, "0");
    
            String b1 = rateVal.split("\\.")[1];
            b1 = StringUtils.rightPad(b1, 6, "0");
    
            c1 = a1+b1;
            if(c1.length() > 15)
            {
                c1 = c1.substring(0, 15);
            }
        }
        return c1;
    }
    
    
 //*-----------------------Format the Amount field values (22 fixed Length)-----------------------------*//
    
    public String formatAmt(String amtVal){
        
        String c2 = "";

        if(amtVal.equals(""))
        {
            c2 = StringUtils.leftPad(amtVal, 22, "0");
        }else
        {         
            if((amtVal.indexOf("-") != -1))
            {
                amtVal = amtVal.substring(1);
            }
            
            if((amtVal.indexOf(".") == -1))
            {
                amtVal = amtVal+".0";
            }
            
            String a2 = amtVal.split("\\.")[0];
            a2 = StringUtils.leftPad(a2, 20, "0");
    
            String b2 = amtVal.split("\\.")[1];
            b2 = StringUtils.rightPad(b2, 2, "0");
    
            c2 = a2+b2; 
            if(c2.length() > 22)
            {
                c2 = c2.substring(0, 22);
            }
        }
        return c2;
     } 
    
//*------------Get Payment Frequency Enrichment---------------------------------------*//
    
 public String paymentFreqCls(String paymentFreqVal){
        
        String frequency = "";   
            
        if(!paymentFreqVal.equals(""))
        {
           String[] payFrequenyList = paymentFreqVal.split(" ", 5);             
           for (String payFrequeny : payFrequenyList)
           {
               String payFreqTerm = payFrequeny.substring(2, 3);
               String payFreqNum = payFrequeny.substring(1, 2);
               
               if(!payFreqNum.equals("0"))
               {
                   switch(payFreqTerm)
                   {
                       case "Y":                             //*For Yearly Frequency      
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "Anual";  
                           }else
                           {
                               frequency = "Cada "+payFreqNum+" Anos";
                           }                                                                              
                           break;
                           
    
                       case "M":                            //*For Monthly Frequency         
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "Mensual";  
                           }else
                           {
                               frequency = "Cada "+payFreqNum+" Meses";
                           }
                           break;
                           
                                                                             
                       case "W":                           //*For Weekly Frequency  
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "Semanal";  
                           }else
                           {
                               frequency = "Cada "+payFreqNum+" Semanas";
                           }
                           break;
                           
                         
                       case "D":                          //*For daily Frequency  
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "Diario";  
                           }else 
                           {
                               frequency = "Cada "+payFreqNum+" Dias";
                           }                      
                           break;
                           
                           
                       case "F":                         //*For Fortnight Frequency  
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "QUINCENAL";  
                           }else
                           {
                               frequency = "Cada "+payFreqNum+" QUINCENAS";
                           }                        
                           break;
                   }                
                   break;  
               }
           }
        }
        return frequency;
    } 
}
