package com.bci;

import java.util.List;
import com.temenos.api.TStructure;
import com.temenos.api.exceptions.T24IOException;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.aa.contractapi.BalanceMovement;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.complex.eb.templatehook.TransactionData;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.tables.ebbciupdateloanbalancesdetails.EbBciUpdateLoanBalancesDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateloanbalancesdetails.EbBciUpdateLoanBalancesDetailsTable;


/**
*
*----------------------------------------------------------------------------------------------------------------
* Description           : Update a record in EB.BCI.UPDATE.LOAN.BALANCES.DETAILS table
* Developed By          : Preethi I,Techmill Technologies
* Development Reference : BCI_G5_IDD051_Interface_Prestamos_Online_Reportes
* Attached To           : VERSION >PAYMENT.ORDER,BCIM.LOAN.ADVANCE.PAYMENT
* Attached As           : Before Auth Routine
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)       
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/

public class BciAuthUpdateLoanBalanceDets extends RecordLifecycle {

    @Override
    public void updateRecord(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext,
            List<TransactionData> transactionData, List<TStructure> currentRecords) {
        // TODO Auto-generated method stub
        
        
        PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        DataAccess da = new DataAccess(this);
        Contract contract = new Contract(this);
        
     //----------INIT-----------
        
        String operationNo = "";
        double aalAccountBalDbl = 0;
        double aalInterestBalDbl = 0;
        double aalChargeBalDbl = 0;
        double aalPenaltyBalDbl = 0;
        double uncAccountBalDbl = 0;
        double totalAmtDbl = 0;
        String totalAmt = "";
        
    //-------------------------- 
        
        String paymentSysId = poRec.getPaymentSystemId().getValue();
        String creditAcctNo = poRec.getCreditAccount().getValue();
    
        try
        {
            AccountRecord accRec = new AccountRecord(da.getRecord("ACCOUNT", creditAcctNo));    //Get Arrangement ID from Account record
            operationNo = accRec.getArrangementId().getValue();
            System.out.println("operationNo..."+operationNo);
            
        }
        catch(Exception accRecErr)
        {
            operationNo = "";
        }
                 
    //----------------------- Get the details of Loan Balances --------------------------------//
        
        contract.setContractId(operationNo);
        try
        {
            List<BalanceMovement> aalAccount = contract.getContractBalanceMovements("AALACCOUNT", "");     //Get Capital Amount
            aalAccountBalDbl = Math.abs(aalAccount.get(0).getBalance().doubleValue());
            
            List<BalanceMovement> aalInterest = contract.getContractBalanceMovements("AALINTEREST", "");    //Get Interest Amount
            aalInterestBalDbl = Math.abs(aalInterest.get(0).getBalance().doubleValue());
                        
            List<BalanceMovement> aalCharge = contract.getContractBalanceMovements("AALCHARGE", "");    //Get Charge Amount
            aalChargeBalDbl = Math.abs(aalCharge.get(0).getBalance().doubleValue());
                        
            List<BalanceMovement> aalPenalty = contract.getContractBalanceMovements("AALPENALTY", "");    //Get Mora Amount
            aalPenaltyBalDbl = Math.abs(aalPenalty.get(0).getBalance().doubleValue());
                        
            List<BalanceMovement> uncAccount = contract.getContractBalanceMovements("UNCACCOUNT", "");     //Get UNC Amount
            uncAccountBalDbl = Math.abs(uncAccount.get(0).getBalance().doubleValue());
                        
            totalAmtDbl = aalAccountBalDbl +  aalInterestBalDbl + aalChargeBalDbl + aalPenaltyBalDbl + uncAccountBalDbl;     //Get Total Amount
            totalAmt = String.format("%.2f", totalAmtDbl);
        }
        
        catch(Exception LoanBalErr)
        {
            LoanBalErr.getMessage();
        }
        
        
    //----------------------- Write a record in EB.BCI.UPDATE.LOAN.BALANCES.DETAILS table--------------------------------//
        
        EbBciUpdateLoanBalancesDetailsRecord bciUpdLoanBalancesDetsRec = new EbBciUpdateLoanBalancesDetailsRecord(this);
        EbBciUpdateLoanBalancesDetailsTable bciUpdLoanBalancesDetsTable = new EbBciUpdateLoanBalancesDetailsTable(this);
          
        String bciUpdLoanBalancesDetsId = operationNo +"-"+paymentSysId;
        
        bciUpdLoanBalancesDetsRec.setCapital(Double.toString(aalAccountBalDbl));
        bciUpdLoanBalancesDetsRec.setInterest(Double.toString(aalInterestBalDbl));
        bciUpdLoanBalancesDetsRec.setCharge(Double.toString(aalChargeBalDbl));
        bciUpdLoanBalancesDetsRec.setMora(Double.toString(aalPenaltyBalDbl));
        bciUpdLoanBalancesDetsRec.setUnc(Double.toString(uncAccountBalDbl));
        bciUpdLoanBalancesDetsRec.setTotalPay(totalAmt);
               
        try
        {
            bciUpdLoanBalancesDetsTable.write(bciUpdLoanBalancesDetsId, bciUpdLoanBalancesDetsRec);
        } 
        catch (T24IOException bciUpdLoanBalDetsErr)
        {
            bciUpdLoanBalDetsErr.getMessage();
        }
    }

}
