package com.bci;

import java.util.List;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import com.temenos.api.TStructure;
import com.temenos.api.TField;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.aa.contractapi.BalanceMovement;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import com.temenos.t24.api.complex.eb.servicehook.SynchronousTransactionData;
import com.temenos.t24.api.complex.eb.servicehook.TransactionControl;
import com.temenos.t24.api.hook.system.ServiceLifecycle;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import com.temenos.t24.api.records.aaproperty.AaPropertyRecord;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.aaprddesinterest.AaPrdDesInterestRecord;
import com.temenos.t24.api.records.aaprddeslimit.AaPrdDesLimitRecord;
import com.temenos.t24.api.records.aaprddesofficers.AaPrdDesOfficersRecord;
import com.temenos.t24.api.records.aaprddespaymentschedule.AaPrdDesPaymentScheduleRecord;
import com.temenos.t24.api.records.aaprddespaymentschedule.PaymentTypeClass;
import com.temenos.t24.api.records.limit.LimitRecord;
import com.temenos.t24.api.records.limit.CollateralCodeClass;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aabilldetails.AaBillDetailsRecord;
import com.temenos.t24.api.records.aabilldetails.InfoPayPrpClass;
import com.temenos.t24.api.records.aabilldetails.InfoPayTypeClass;
import com.temenos.t24.api.records.aabilldetails.PropertyClass;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.t24.api.records.company.CompanyRecord;
import com.temenos.t24.api.records.customer.AddressClass;
import com.temenos.t24.api.records.customer.ContactTypeClass;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.customer.LegalIdClass;
import com.temenos.t24.api.records.customer.Phone1Class;
import com.temenos.t24.api.records.dates.DatesRecord;
import com.temenos.t24.api.records.deptacctofficer.DeptAcctOfficerRecord;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaaccountdetails.BillPayDateClass;
import com.temenos.t24.api.records.aaaccountdetails.RepayReferenceClass;
import com.temenos.t24.api.records.aaaccountdetails.BillIdClass;
import com.temenos.t24.api.records.aaactivityhistory.AaActivityHistoryRecord;
import com.temenos.t24.api.records.aaactivityhistory.ActivityRefClass;
import com.temenos.t24.api.records.aaactivityhistory.EffectiveDateClass;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaprddescharge.AaPrdDesChargeRecord;
import com.temenos.t24.api.records.aaprddessettlement.AaPrdDesSettlementRecord;
import com.temenos.t24.api.records.ebcashflow.EbCashflowRecord;
import com.temenos.t24.api.records.ebcontractbalances.EbContractBalancesRecord;
import com.temenos.t24.api.records.ebcontractbalances.TypeSysdateClass;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsTable;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueDateClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueTypeClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.EbBciUpdateScheduleProjectorRecord;
import com.temenos.t24.api.tables.ebbciupdateloanbalancesdetails.EbBciUpdateLoanBalancesDetailsRecord;
import com.techmill.integration.SoapClient;
import org.apache.commons.lang3.StringUtils;
import java.util.Date;  
import java.util.concurrent.TimeUnit;
import java.text.ParseException;


/**
*
*----------------------------------------------------------------------------------------------------------------
* Description           : Pass the Header Notice and detail Notice Message to third party using SoapClient method 
* Developed By          : Preethi I,Techmill Technologies
* Development Reference : BCI_G5_IDD051_Interface_Prestamos_Online_Reportes
* Attached To           : BATCH> BCI.MUL.LOAN.ACTIVITY.DETS
* Attached As           : Service Routine
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)       
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/

public class BciMulLoanEventDetsInterface extends ServiceLifecycle {   
    
        
  //*------------ Select the records from EB.BCI.UPDATE.ENGAGEONE.DETAILS ----------------*//
    
    public List<String> getIds(ServiceData serviceData, List<String> controlList) {
        
        DataAccess fRead = new DataAccess(this);              
        List<String> bciUpdateEngageoneDetsList = new ArrayList<String>();
        
        String selCmd = "WITH (ERROR.FLAG EQ '') AND ((EVENT.CODE EQ 'N0001') OR (EVENT.CODE EQ 'C0001'))";
        try            
        {
            bciUpdateEngageoneDetsList = fRead.selectRecords("","EB.BCI.UPDATE.ENGAGEONE.DETAILS","",selCmd); 
        } 
        catch (Exception bciEngageErr) {   
            bciUpdateEngageoneDetsList.clear();        
        }            
       
        return bciUpdateEngageoneDetsList;         
    }       
    
  //*------------ Process----------------*//  
    
    @Override
    public void updateRecord(String id, ServiceData serviceData, String controlItem,
            TransactionControl transactionControl, List<SynchronousTransactionData> transactionData,
            List<TStructure> records) {
        
        DataAccess da = new DataAccess(this);
        Contract contract = new Contract(this);   
        int flag = 0;
        String bciUpdEngageoneDetsId = id; 
        
        EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetsRec = null;        
        EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetsTable= new EbBciUpdateEngageoneDetailsTable(this);
        
        try
        {
            bciUpdEngageoneDetsRec = new EbBciUpdateEngageoneDetailsRecord(da.getRecord("EB.BCI.UPDATE.ENGAGEONE.DETAILS", bciUpdEngageoneDetsId));  
        }        
        catch(Exception e)
        {   
            flag = 1;
        } 
     
        if(flag == 0)
        {

        //Initialize the Variable
            String eventCode = "";
            String hdrCode = "";
            String today = "";
            int scheduleFlg = 0;
            int cusFlag = 0;
            String phoneNo = "";                    
            int addressCnt = 0;
            String address = "";
            String email = "";
            String customerCommunication = "";
            String hdrEventDate = "";
            String aaaDateTime = "";
            String hdrEventTime = "";          
            String codeProduct = "";
            String operationNo  = "";
            String currency = "";
            String executiveEmail = "";
            String aaaId = "";
            int productDescriptLen = 0;
            String productDescript = "";
            String termVal = "";
            String establishTerm = "";
            String unitestablishTerm = "";         
            String companyId = "";
            String branchShortName = "";
            String codeExecutive = "";
            String executiveName  = "";
            String executiveTelephone = "";       
            String accountNo = "";            
            String detCode01 = "";
            String detCode02 = "";
            String detCode03 = "";
            String detCode04 = "";
            String detCode05 = "";
            String hdrNoticeMsg = "";
            String hdrDetNoticeMsg = "";
            String detNoticeD01Msg = "";
            String detNoticeD02Msg = "";
            String detNoticeD03Msg = "";
            String detNoticeD04Msg = "";
            String detNoticeD05Msg = "";
            String soapResponse = "";
            String loanNo = "";
            String noOfD02Recs = "";
            String noOfD03Recs = "";
            String noOfD04Recs = "";
            String noOfD05Recs = "";
            String customerNo1 = "";
            String customerNo2 = "";
            String customerNo3 = "";
            String customerNo4 = "";
            String customerNo5 = "";
            String legalID1 = "";
            String legalID2 = "";
            String legalID3 = "";
            String legalID4 = "";
            String legalID5 = "";
            String customerName1 = "";
            String customerName2 = "";
            String customerName3 = "";
            String customerName4 = "";
            String customerName5 = "";
            String dateOfOperation = "";
            String effectiveDate = "";
            String orgSystemDate = "";
            String maturityDate = "";
            String txnAmount = "";  
            String workBal = "";           
            String dueType = ""; 
            String dueTypeListStr = "";
            String principalBalLoan = "";
            int startCnt = 0;
            int dutDateCnt = 0;            
            String fstAnnualDueDate = "";
            String annualYear = "";
            int lastAnnualYearInt = 0;           
            String dueProperty = "";
            String duePropertyVal = "";
            String duePropertyAmt = "";              
            int repayDueTypeCnt = 0;
            int duePropertyCnt = 0;
            int commissionD03Cnt = 0;
            int expenseD05Cnt = 0;
            int commissionFlg = 0;
            int expenseFlg = 0;
            int commissionAddFlg = 0;
            int expenseAddFlg = 0;
            String propertyDesVal = "";
            String propertyDes = "";
            String installmentDatePaid = "";
            String nextInstallmentExpireDate = "";
            String nextInstallmentduePay = "";
            String firstLoanInstallmentDate = "";
            String commissionDets = "";
            String commissionDetails = "";
            String expenseDets = "";
            String expenseDetails = "";
            String paymentScheduleDetails = "";
            String annualAmtLoanPrincipalInstallment = "";
            String annualAmtLoanInterestInstallment = "";
            int totalAmtInstallmentDueLoanInt = 0;
            String totalAmtInstallmentDueLoan = "";
            String totalLoanInstallment = "";        
            String bench = "";
            String bankOfficeCode = "";
            String paymentType = "";
            String paymentMethodPaidEvent = "";
            String formSubmissionStatement = "";
            String noOfEvent = "";
            String noOfInstallmentPaid = "";
            String timeOfOperation = "";
            String loanCcyPreCondition = "";
            String totFeeAmtCancel = "";
            String principalAmtCancel = "";
            String feeInterestCancel = "";
            String principalAmtFeeCancelInterest = "";
            String amtCancelFee = "";
            String totalAmtFeeCancelInsurance = "";
            String secureAmtFeeReliefCancel = "";
            String amtInsuranceFeeCancel = "";
            String amtFeeCancel = "";
            String amtITFCancel = "";
            String amtOtherConceptFeeCancel = "";
            String amtConceptOtherPrincipalIntFeeCancelInsurance = "";
            String comment = "";
            String dateOfGrantLoan = "";
            String Loandisbursementdate = "";
            String dateOfLastModifyLoanTerms = "";
            String finalMaturityDateLoan = "";
            String finalMaturityDateLoanPreCondition = "";
            String unitTermLoanExpressPreCondition = "";
            String termLoanPreCondition = "";
            String propertyName = "";
            String paymentFreq = "";
            String periodicityLoanCapitalInstallment = "";
            String periodicityInterestInstallmentLoan = "";
            String unitGracePeriod = "";
            String loanGracePeriod = "";          
            String codeTypeGuaranteeLoan = "";
            String typeLoanGuarantee = "";
            String typeLoanGuaranteePreCondition = "";
            String interestRatePreCondition = "";
            String LimitRef = "";         
            String interestRateType = "";
            String annualEffectiveInterestRateTEA = "";
            String annualEffectiveInterestRateTEAPreCondition = "";
            String annualEffectiveCostRateTCEA = "";
            String annualEffectiveCostRateTCEAPreCondition = "";    
            String loanFeeType = "";
            String collectionLoanGracePeriod = "";
            String loanGracePeriodAmt = "";
            String penaltyNonPayment = "";
            String penaltyNonPaymentPreCondition = "";
            String totalAmtGrantLoan = "";
            String totalAmtGrantLoanPreCondition = "";
            String totalPrincipalAmtLoan = "";
            String totalPrincipalAmtLoanPreCondition = "";
            String totalAmtLoanInstallmentPreCondition = "";
            String totalNoUnpaidDueYear = "";
            String totalAmtInstallmentCancelLoan = "";
            String additionInsuranceContract = "";
            String additionInsuranceContractPreCondition = "";
            String payInAccountNo = "";
            String payInAccountCcy = "";   
            String activity = "";
            String paymentMethod = "";
            String billId = "";
            String intPrinicpalinteAmt = "";
            String intPenaltyintAmt = "";
            String intPenalintAmt = "";
            double intPrinicpalinteAmtDbl = 0;
            double intPenaltyintAmtDbl = 0;
            double intPenalintAmtDbl = 0;
            double principalAmtCancelDbl = 0;
            double feeInterestCancelDbl = 0;
            String lastAnnualDueDate = "";
            int annualAmtLoanPrincipalInstallmentInt = 0;
            int annualAmtLoanInterestInstallmentInt = 0;
            int annualBreakFlg = 0;
            String chrgDueType = "";
            String BillStartDt = "";
            double duePropertyAmtDbl = 0;
            String interestRateVal = "";
            String propertyVal = "";
            String principalinteAmt = "";
            String penaltyintAmt = "";
            String penalintAmt = "";
            double principalinteAmtDbl = 0;
            double penaltyintAmtDbl = 0;
            double penalintAmtDbl = 0;
           
   //*------------------------------------------------------------------------------------------------------------------------------*//
            
       
         //Get the EventCode and Arrangement ID from EB.BCI.UPDATE.ENGAGEONE.DETAILS table          
            eventCode = bciUpdEngageoneDetsRec.getEventCode().getValue();
            operationNo = bciUpdEngageoneDetsRec.getArragementId().getValue();
            activity = bciUpdEngageoneDetsRec.getActivityName().getValue();
            
            contract.setContractId(operationNo);

         //Get the Header Code and Detail Code from EB.BCI.ENGAGEONE.INT.REP.PARAM table 
            EbBciEngageoneIntRepParamRecord bciEngageoneIntRepParamRec = null;  
            try
            {        
                bciEngageoneIntRepParamRec = new EbBciEngageoneIntRepParamRecord(da.getRecord("EB.BCI.ENGAGEONE.INT.REP.PARAM", "LOAN"));
                hdrCode = bciEngageoneIntRepParamRec.getHeaderCode(0).getValue();
                detCode01 = bciEngageoneIntRepParamRec.getDetailCode(0).getValue();
                detCode02 = bciEngageoneIntRepParamRec.getDetailCode(1).getValue();
                detCode03 = bciEngageoneIntRepParamRec.getDetailCode(2).getValue();
                detCode04 = bciEngageoneIntRepParamRec.getDetailCode(3).getValue();
                detCode05 = bciEngageoneIntRepParamRec.getDetailCode(4).getValue();
            }
            catch(Exception engageRecErr)
            {
                engageRecErr.getMessage();
            }
            
       //Read EB.BCI.UPDATE.SCHEDULE.PROJECTOR table
            EbBciUpdateScheduleProjectorRecord scheduleProjectorRec = null;
            try
            {
                scheduleProjectorRec = new EbBciUpdateScheduleProjectorRecord(da.getRecord("EB.BCI.UPDATE.SCHEDULE.PROJECTOR", bciUpdEngageoneDetsId));
            }
            catch(Exception scheduleProjectorErr)
            {
                scheduleFlg = 1;
            }
            
       //Get the customer Number, Currency, Start Date    
            AaArrangementRecord arrRec = null;          
            try
            {
                arrRec = new AaArrangementRecord(da.getRecord("AA.ARRANGEMENT", operationNo));
                customerNo1 = arrRec.getCustomer(0).getCustomer().getValue();
                currency = arrRec.getCurrency().getValue();
                accountNo = arrRec.getLinkedAppl(0).getLinkedApplId().getValue();  
                loanNo = accountNo;
            }
            catch(Exception arrErr)
            {
                loanNo = "";
            }
            
          //Read CUSTOMER table
               CustomerRecord cusRec = null;
               try
               {  
                   cusRec = new CustomerRecord(da.getRecord("CUSTOMER", customerNo1));
               }
               catch(Exception e2)
               {
                   cusFlag = 1;
               }
               
               if(cusFlag == 0)
               {
             //Get the field SHORT.NAME and LEGAL.ID from customer table
                   customerName1 = cusRec.getShortName(0).getValue();
                   List<LegalIdClass> legalIdlist = cusRec.getLegalId();            
                   if(!legalIdlist.isEmpty())
                   {
                       legalID1 = legalIdlist.get(0).getLegalId().getValue();      
                   }                
                   
             //Get the fields PHONE.1 and EMAIL.1 from customer table 
                   List<Phone1Class> phoneList = cusRec.getPhone1();             
                   if(!phoneList.isEmpty())
                   {
                       phoneNo = phoneList.get(0).getPhone1().getValue();
                       email = phoneList.get(0).getEmail1().getValue();
                   }
                   
             //Get the field ADDRESS from customer table 
                   List<AddressClass> addressList = cusRec.getAddress();
                   if(!addressList.isEmpty())
                   {
                       addressCnt = addressList.size();
                       for(int i=0; i<addressCnt; i++)
                       {
                           String add = "";
                           add = cusRec.getAddress().get(i).get(0).getValue().concat(",");                   
                           address = address.concat(add);
                       }
                       address = address.substring(0, address.length()-1);         
                   }                 
                   
             //Get the field CONTACT.DATA from customer table 
                   List<ContactTypeClass> contactTypecList = cusRec.getContactType();            
                   if(!contactTypecList.isEmpty()){
                      customerCommunication =  contactTypecList.get(0).getContactData().getValue();
                   }
               }         
            
            
           //Get Header ORG.SYSTEM.DATE, Event Date and Event Time (DATE.TIME)  
               aaaId = bciUpdEngageoneDetsId.split("-")[1];
               
               AaArrangementActivityRecord aaaRec = null;          
               try
               {
                   aaaRec = new AaArrangementActivityRecord(da.getRecord("AA.ARRANGEMENT.ACTIVITY", aaaId));
                   orgSystemDate = aaaRec.getOrgSystemDate().getValue();
                   effectiveDate = aaaRec.getEffectiveDate().getValue();
                   
                   aaaDateTime = aaaRec.getDateTime(0);
                   hdrEventDate = "20"+aaaDateTime.substring(0,6);
                   hdrEventTime = aaaDateTime.substring(6)+"00"; 
               }
               catch(Exception aaaErr)
               {
                   hdrEventTime = "";
               }
   
             
           //Get Company ID and Company Name
                companyId = serviceData.getCompanyId();
                    
                int companyIdLen = companyId.length();
                if(companyIdLen >= 5)
                {
                    bankOfficeCode = companyId.substring(0, 5);
                } 
                                      
                try
                {
                    CompanyRecord companyRec = new CompanyRecord(da.getRecord("COMPANY", companyId));   //Read COMPANY table and Get the value of NAME field 
                    bench = companyRec.getCompanyName(0).getValue();
                    branchShortName = bench;
                        
                    int branchShortNameLen = bench.length();
                    if(branchShortNameLen >= 30)
                    {
                        branchShortName = branchShortName.substring(0, 30);
                    }                     
                }
                catch(Exception companyErr)
                {
                    branchShortName = "";
                }     
                
           //Get TODAY
                try               
                {      
                    DatesRecord datesrec = new DatesRecord(da.getRecord("DATES",companyId));
                    today = datesrec.getToday().getValue();   
                }
                catch (Exception datesErr) {                               
                     today = "";
                }   
                
           //Get Code Executive           
                AaPrdDesOfficersRecord aaPrdDesOfficerRec = null;
                try
                {
                    aaPrdDesOfficerRec = new AaPrdDesOfficersRecord(contract.getConditionForProperty("OFFICERS"));
                    codeExecutive = aaPrdDesOfficerRec.getPrimaryOfficer().getValue(); 
                }
                catch(Exception offErr)
                {
                    codeExecutive = "";
                }
                     
            //Get Executive Name and Executive Telephone
                  if(!codeExecutive.equals(""))
                  {
                      try
                      {
                          DeptAcctOfficerRecord deptAcctOffRec = new DeptAcctOfficerRecord(da.getRecord("DEPT.ACCT.OFFICER", codeExecutive));   //Read DEPT.ACCT.OFFICER table and Get the fields NAME & TELERPHONE.NO 
                          executiveName = deptAcctOffRec.getName().getValue();
                          executiveTelephone = deptAcctOffRec.getTelephoneNo().getValue();
                      }
                      catch(Exception deptOffErr)
                      {
                          executiveName = "";
                          executiveTelephone = "";
                      }                  
                  } 
                  
             //Get the value of the fields CATEGORY and ACCOUNT.TITLE.1 from AA.ARR.ACCOUNT table
                  AaPrdDesAccountRecord aaPrdDesAcctRec = null;
                  try
                   {
                       aaPrdDesAcctRec = new AaPrdDesAccountRecord(contract.getConditionForProperty("ACCOUNT"));
                       codeProduct = aaPrdDesAcctRec.getCategory().getValue();           
                       productDescript = aaPrdDesAcctRec.getAccountTitle1().get(0).getValue();      //Get product Description
                       productDescriptLen = productDescript.length();
                       
                       if(productDescriptLen >= 30)
                       {
                           productDescript = productDescript.substring(0, 30);
                       }
                       
                       String currNoCnt = "";
                       int curCnt = 0;
                       currNoCnt = aaPrdDesAcctRec.getCurrNo();
                       curCnt = Integer.parseInt(currNoCnt);                              
                       if (curCnt >1 )
                       {
                          dateOfLastModifyLoanTerms = aaPrdDesAcctRec.getAuditDateTime();
                       }                           
                    }
                    catch(Exception aaArrAccErr)
                    {
                        dateOfLastModifyLoanTerms = "";              
                    }  
                 
                  
                //Get fetch TEA value and Interest Rate type from AA.ARR.INTEREST                 
                    AaPrdDesInterestRecord aaArrInterestRec = null;        
                    try
                    {
                        aaArrInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("PRINCIPALINTE"));                          
                        try
                        {
                            
                            int negotiationCurCnt = aaArrInterestRec.getNegotiatedFlds().size() - 1;                         
                            interestRateVal = "";
                            interestRateVal = aaArrInterestRec.getNegotiatedFlds().get(negotiationCurCnt).getValue();   //Get last multi-value set of NEGOTIATE.FLDS 
                            
                            if (interestRateVal.equals("FIXED.RATE"))
                            {
                                interestRateType = "FIJA";
                            }
                            else if(interestRateVal.equals("FLOATING.INDEX"))
                            {     
                                interestRateType = "VARIABLE";
                            }                   
                        }
                        catch(Exception e)
                        {
                            interestRateType = "";
                        }
                      
                        annualEffectiveInterestRateTEA = aaArrInterestRec.getFixedRate().get(0).getEffectiveRate().getValue();       //Get EFFECTIVE.RATE field Value                                                  
                    }
                    catch(Exception aaArrIntErr)
                    {
                        annualEffectiveInterestRateTEA = "";
                    }  
                    
                    
                 //Get Tasa de costo Efectivo Anual (EB.CASHFLOW > CALC.RATE)
                    
                    EbCashflowRecord ebCashFlowRec = null; 
                    try
                    {  
                        ebCashFlowRec = new EbCashflowRecord(da.getRecord("EB.CASHFLOW", accountNo));
                        annualEffectiveCostRateTCEA = ebCashFlowRec.getCalcType().get(0).getCalcRate().getValue();
                    }
                    catch(Exception TCEAErr)
                    {
                        annualEffectiveCostRateTCEA = "";
                    }
                    
                    
                 //Issue fix for interest rate and prev condition fields
      
                    if(interestRateType.equals("") && (interestRateVal.equals("RATE.TIER.TYPE") || interestRateVal.equals("RATE.TYPE")))
                    {
                       int negotiationCurCnt = 0;
                       String interestRateCurVal = "";
                       
                       try
                       {
                           aaArrInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("PRINCIPALINTE"));  
                           
                           negotiationCurCnt = aaArrInterestRec.getNegotiatedFlds().size() - 2;
                           interestRateCurVal = aaArrInterestRec.getNegotiatedFlds().get(negotiationCurCnt).getValue();
                           
                           if (interestRateCurVal.equals("FIXED.RATE"))
                           {
                               interestRateType = "FIJA";
                           }
                           else if(interestRateCurVal.equals("FLOATING.INDEX"))
                           {     
                               interestRateType = "VARIABLE";
                           }
                       }
                       catch(Exception e1)
                       {
                           interestRateType = "";
                       }
                    }
                    
                //Get Working Balance from Account Table
                    try
                    {
                        AccountRecord accRec1 = new AccountRecord(da.getRecord("ACCOUNT", accountNo));                    
                        workBal = accRec1.getWorkingBalance().getValue();                   
                    }
                    catch(Exception accErr)
                    {
                        workBal = "";
                    } 
                        
  //************************************************************************************************************************************************//

               if(eventCode.equals("C0001"))
               {                   
                 //Get the value of the fields AMOUNT, MATURITY.DATE and TERM from AA.ARR.TERM.AMOUNT table                   

                   AaPrdDesTermAmountRecord aaPrdDesTermAmtRec = null;
                   try
                   {
                        aaPrdDesTermAmtRec = new AaPrdDesTermAmountRecord(contract.getConditionForProperty("COMMITMENT"));
                        txnAmount = aaPrdDesTermAmtRec.getAmount().getValue();
                        maturityDate = aaPrdDesTermAmtRec.getMaturityDate().getValue();
                          
                        termVal = aaPrdDesTermAmtRec.getTerm().getValue();       
                        if(!termVal.equals(""))
                        {
                            establishTerm = termVal.replaceAll("[^0-9]", "");              //Get the numeric value from TERM   
                            unitestablishTerm = termVal.substring(termVal.length()-1);     //Get the unit from TERM field
                           
                            switch(unitestablishTerm)
                            {
                                case "D":
                                    unitestablishTerm = "DIAS";
                                    break;
                                case "M":
                                    unitestablishTerm = "MESES";
                                     break;
                                case "Y":
                                    unitestablishTerm = "ANOS";
                                    break;                                   
                            }
                         }
                    }
                    catch(Exception termErr)
                    {
                        establishTerm = "";
                        unitestablishTerm = "";
                    }   
                   
  //*-----------------------Get D02 and D03 details-------------------------*//
                           
                  unitGracePeriod = "DIAS";
                  timeOfOperation = hdrEventTime;
                  dateOfOperation = effectiveDate;
                  Loandisbursementdate = orgSystemDate;
                  dateOfGrantLoan = orgSystemDate;
                  totalPrincipalAmtLoan = workBal;

            //Get the AA.SCHEDULE.PROJECTOR api values from EB.BCI.UPDATE.SCHEDULE.PROJECTOR  
                  
                  if(scheduleFlg == 0)
                  {
                      principalBalLoan = scheduleProjectorRec.getDueDate(0).getDueOutstandingBalance().getValue();
                      fstAnnualDueDate = scheduleProjectorRec.getDueDate(0).getDueDate().getValue();
                      
                      annualYear = fstAnnualDueDate.substring(3, 4);
                      lastAnnualYearInt = Integer.parseInt(annualYear) + 1;
                      lastAnnualDueDate = fstAnnualDueDate.substring(0, 3)+lastAnnualYearInt+fstAnnualDueDate.substring(4,8);

                                          
                      List<DueDateClass> dueDateList = scheduleProjectorRec.getDueDate();  
                      dutDateCnt = dueDateList.size();  
                      dueTypeListStr = scheduleProjectorRec.getDueDate(0).getDueType().toString();
                      
                                                                                 
                      if(dueTypeListStr.contains("CHARGE"))         //Get Commission details D03 or Expense details D05, if CHARGE due type is existing in first multivalue set  
                      {    
                          List<DueTypeClass> dueTypeList = scheduleProjectorRec.getDueDate(0).getDueType();
                          int dueTypeCnt = dueTypeList.size();
                         
                          for(int p=0; p<dueTypeCnt; p++)
                          {               
                              chrgDueType = dueTypeList.get(p).getDueType().getValue();
                              if(chrgDueType.equals("CHARGE"))
                              {                               
                                  String[] duePropertyStringList = dueTypeList.get(p).getDueProperty().getValue().split("/");
                                  String[] duePropertyAmtStringList = dueTypeList.get(p).getDuePropertyAmount().getValue().split("/");
                                  
                                  List<String> duePropertyList = new ArrayList<String>();
                                  List<String> duePropertyAmtList = new ArrayList<String>();

                                  for(String duePropertyStr : duePropertyStringList)
                                  {
                                      duePropertyList.add(duePropertyStr);
                                  }
                                  for(String duePropertyAmtStr : duePropertyAmtStringList)
                                  {
                                      duePropertyAmtList.add(duePropertyAmtStr);
                                  }
                                
                              //Format the Detail Notice D03 and D05 string values based on the length 
                                  detCode03 = StringUtils.rightPad(detCode03, 20, " ");
                                  detCode05 = StringUtils.rightPad(detCode05, 20, " ");
                                  eventCode = StringUtils.rightPad(eventCode, 5, " ");  
                                  currency = StringUtils.rightPad(currency, 5, " ");
                                  
                                  duePropertyCnt = duePropertyList.size();
                                  for(int q=0; q<duePropertyCnt; q++)
                                  {
                                      commissionDets = "";
                                      expenseDets = "";
                                      duePropertyAmt = "";
                                      duePropertyVal = "";
                                      propertyDes = "";
                                      
                                      duePropertyVal = StringUtils.rightPad(duePropertyList.get(q), 5, " ");                                    
                                      dueProperty = duePropertyVal;
                                      if(dueProperty.length() >= 5)
                                      {
                                          dueProperty = duePropertyVal.substring(0, 5);                                       
                                      }
                                   
                                   //Get property Description
                                      try
                                      {
                                          AaPropertyRecord propertyRec = new AaPropertyRecord(da.getRecord("AA.PROPERTY", duePropertyVal));                                           
                                          propertyDesVal = propertyRec.getDescription(0).getValue();
                                          
                                          propertyDes = propertyDesVal;
                                          if(propertyDes.length() >= 30)
                                          {
                                              propertyDes = propertyDes.substring(0, 30);
                                          }                 
                                      }
                                      catch(Exception propertyErr)
                                      {
                                          propertyDes = "";   
                                      }                                    
  
                                      propertyDes = StringUtils.rightPad(propertyDes, 30, " ");
                                      duePropertyAmt = formatAmt(duePropertyAmtList.get(q));       //Calling formatAmt class for formating the amount
                                    
                                      if((duePropertyVal.contains("BCIPEGAS")) || (propertyDesVal.contains("Gasto")))      //If the property is related to Expense
                                      {
                                       //Form Detail Notice D05 Message 
                                          expenseFlg = 1;
                                          expenseD05Cnt = expenseD05Cnt + 1;
                                          expenseDets = detCode05+eventCode+dueProperty+propertyDes+currency+duePropertyAmt;                                       
                                          if(expenseD05Cnt == 1)
                                          {
                                              expenseDetails = expenseDets;
                                          }else
                                          {
                                              expenseDetails = expenseDetails+'\n'+expenseDets;
                                          }   
                                      }                                     
                                      else        //If the property is related to Commission
                                      {
                                       //Form Detail Notice D03 Message
                                          commissionFlg = 1;
                                          commissionD03Cnt = commissionD03Cnt + 1;
                                          commissionDets = detCode03+eventCode+dueProperty+propertyDes+currency+duePropertyAmt;
                                          
                                          if(commissionD03Cnt == 1)
                                          {
                                              commissionDetails = commissionDets;
                                          }else
                                          {
                                              commissionDetails = commissionDetails+'\n'+commissionDets;
                                          }     
                                      }                                                              
                                  } 
                                  break;
                              }
                          }                    
                      }          
                      
                      if(!dueTypeListStr.contains("DISBURSEMENT.%"))        //If first multivalue set having %DISBURSEMENT, then leave the that set
                      {
                          startCnt = 0; 
                      }else
                      {
                          startCnt = 1;
                      }
                      
                      for(int k=startCnt; k<dutDateCnt; k++)
                      {                   
                          String dueDate = "";
                          double totalFeeAmtDbl = 0;
                          double capitalBalDbl = 0;
                          double principalAmtDbl = 0;
                          double interestAmtFeeDbl = 0;
                          double insuranceAmtFeeDbl = 0;
                          double commissionAmtFeeDbl = 0;
                          double expenseAmtFeeDbl = 0;
                          
                          String totalFeeAmt = "";
                          String commissionAmtFee = "";
                          String capitalBal = "";
                          String principalAmt = "";
                          String interestAmtFee = "";
                          String insuranceAmtFee = "";
                          String largeAmtOtherFee = "";
                          String expenseAmtFee = "";
                          String itfAmtFee = "";
                          String reducedAmtFee = "";
                          String insuranceTaxAmtFee = "";
                          String noOfQuoto = "";
                          String otherInsuranceAmt = "";
                          String paymentScheduleDets = "";                        
                          dueDate = "";
                          
                          dueDate = dueDateList.get(k).getDueDate().getValue();
                          if(startCnt == 0)
                          {
                              noOfQuoto = Integer.toString(k+1);
                              totalAmtInstallmentDueLoan = Integer.toString(dutDateCnt);
                              totalLoanInstallment = totalAmtInstallmentDueLoan;
                          }else
                          {
                              noOfQuoto = Integer.toString(k);
                              totalAmtInstallmentDueLoanInt = dutDateCnt-1;
                              totalAmtInstallmentDueLoan = Integer.toString(totalAmtInstallmentDueLoanInt);
                              totalLoanInstallment = totalAmtInstallmentDueLoan;
                          }                       
                                                                  
                          capitalBal = dueDateList.get(k).getDueOutstandingBalance().getValue();
                          capitalBalDbl = Double.parseDouble(capitalBal);
                                                     
                          if(installmentDatePaid.equals(""))
                          {
                              installmentDatePaid = dueDate;
                              nextInstallmentExpireDate = dueDate;
                              nextInstallmentduePay = dueDateList.get(0).getDueDate().getValue();
                              firstLoanInstallmentDate = dueDate;
                          }
                         
                          List<DueTypeClass> repayDueTypeList = scheduleProjectorRec.getDueDate().get(k).getDueType();
                          repayDueTypeCnt = repayDueTypeList.size();

                          for(int r=0; r<repayDueTypeCnt; r++) 
                          {
                              dueType = repayDueTypeList.get(r).getDueType().getValue();
                                                                
                              if(annualBreakFlg == 0)                       //Get No. of Capital and Loan Installment
                              {
                                  try{                            
                                      SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                                      Date date1 = sdf.parse(dueDate);
                                      Date date2 = sdf.parse(lastAnnualDueDate);
                                      
                                      if((date1.before(date2)) || (date1.equals(date2)))
                                      {
                                          switch(dueType)
                                          {
                                              case "INTEREST.ONLY": case "INTEREST": case "ACTUAL":    //Mantis Issue - 398 (Include INTEREST payment Type)
                                                  annualAmtLoanInterestInstallmentInt = annualAmtLoanInterestInstallmentInt + 1;
                                                  break;                                   
                                                  
                                              case "LINEAR":
                                                  annualAmtLoanPrincipalInstallmentInt = annualAmtLoanPrincipalInstallmentInt + 1;
                                                  break;
                                                  
                                              case "CONSTANT":        //Mantis Issue - 397 (Include CONSTANT payment Type)
                                                  
                                                  String[] duePropertyConstantStringList = repayDueTypeList.get(r).getDueProperty().getValue().split("/");
                                                  List<String> duePropertyConstantList = new ArrayList<String>();

                                                  for(String duePropertyConstantStr : duePropertyConstantStringList)       
                                                  {
                                                      duePropertyConstantList.add(duePropertyConstantStr);
                                                  }
                                                  for(int m=0; m<duePropertyConstantList.size(); m++)
                                                  {
                                                      duePropertyVal = "";
                                                      duePropertyVal = duePropertyConstantList.get(m);
                                                      switch(duePropertyVal)
                                                      {
                                                          case "PRINCIPALINTE":
                                                              annualAmtLoanInterestInstallmentInt = annualAmtLoanInterestInstallmentInt + 1;
                                                              break;
                                                              
                                                          case "ACCOUNT":
                                                              annualAmtLoanPrincipalInstallmentInt = annualAmtLoanPrincipalInstallmentInt + 1;
                                                              break;
                                                      }
                                                  }
                                                  break;
                                           } 
                                      }                                 
                                      else
                                      {                                 
                                          annualBreakFlg = 1; 
                                      }
                                  }
                                  catch(ParseException ex){
                                      ex.printStackTrace();
                                  }
                              }
                              
                              switch(dueType)
                              {
                                  case "INTEREST.ONLY": case "INTEREST":  case "ACTUAL":   //Mantis Issue - 398 (Include INTEREST payment Type)
                                      interestAmtFee = repayDueTypeList.get(r).getDueTypeAmount().getValue(); 
                                      interestAmtFeeDbl = Double.parseDouble(interestAmtFee);
                                      break;                                   
                                                                 
                                  case "LINEAR":
                                      principalAmt = repayDueTypeList.get(r).getDueTypeAmount().getValue();
                                      principalAmtDbl = Double.parseDouble(principalAmt); 
                                      break;
                                      
                                  case "CONSTANT":    //Mantis Issue - 397 (Include CONSTANT payment Type)
                                      
                                      String[] duePropertyConstantStringList = repayDueTypeList.get(r).getDueProperty().getValue().split("/");
                                      String[] duePropertyAmtConstantStringList = repayDueTypeList.get(r).getDuePropertyAmount().getValue().split("/");
                                    
                                      List<String> duePropertyConstantList = new ArrayList<String>();
                                      List<String> duePropertyAmtConstantList = new ArrayList<String>();

                                      for(String duePropertyConstantStr : duePropertyConstantStringList)       
                                      {
                                          duePropertyConstantList.add(duePropertyConstantStr);
                                      }
                                      for(String duePropertyAmtConstantStr : duePropertyAmtConstantStringList)
                                      {
                                          duePropertyAmtConstantList.add(duePropertyAmtConstantStr);
                                      }
                                      
                                      for(int m=0; m<duePropertyConstantList.size(); m++)
                                      {
                                          duePropertyVal = "";
                                          duePropertyVal = duePropertyConstantList.get(m);
                                          switch(duePropertyVal)
                                          {
                                              case "PRINCIPALINTE":
                                                  interestAmtFee = duePropertyAmtConstantList.get(m); 
                                                  interestAmtFeeDbl = Double.parseDouble(interestAmtFee);
                                                  break;
                                                  
                                              case "ACCOUNT":
                                                  principalAmt = duePropertyAmtConstantList.get(m);
                                                  principalAmtDbl = Double.parseDouble(principalAmt); 
                                                  break;
                                          }
                                      }
                                      break;
                                      
                                  case "CHARGE":                                     
                                      String[] duePropertyStringList = repayDueTypeList.get(r).getDueProperty().getValue().split("/");
                                      String[] duePropertyAmtStringList = repayDueTypeList.get(r).getDuePropertyAmount().getValue().split("/");
                                    
                                      List<String> duePropertyList = new ArrayList<String>();
                                      List<String> duePropertyAmtList = new ArrayList<String>();

                                      for(String duePropertyStr : duePropertyStringList)       
                                      {
                                          duePropertyList.add(duePropertyStr);
                                      }
                                      for(String duePropertyAmtStr : duePropertyAmtStringList)
                                      {
                                          duePropertyAmtList.add(duePropertyAmtStr);
                                      }
                                      
                                      duePropertyCnt = duePropertyList.size();
                                      for(int m=0; m<duePropertyCnt; m++)
                                      {
                                          commissionDets = "";
                                          expenseDets = "";
                                          duePropertyAmt = "";
                                          duePropertyVal = "";
                                          propertyDes = "";                                                                                  
                                          duePropertyAmtDbl = 0;
                                          
                                          duePropertyAmt = duePropertyAmtList.get(m);      
                                          duePropertyAmtDbl = Double.parseDouble(duePropertyAmt);                                          
                                                                                   
                                          duePropertyVal = StringUtils.rightPad(duePropertyList.get(m), 5, " ");                                          
                                          dueProperty = duePropertyVal;
                                          int duePropertyLen = dueProperty.length();
                                          if(duePropertyLen >= 5)
                                          {
                                              dueProperty = dueProperty.substring(0, 5);
                                          }                                        
                                        
                                     //Get Property Description
                                          try
                                          {
                                              AaPropertyRecord propertyRec = new AaPropertyRecord(da.getRecord("AA.PROPERTY", duePropertyVal));
                                              propertyDesVal = propertyRec.getDescription(0).getValue();
                                            
                                              propertyDes = propertyDesVal;
                                              if(propertyDes.length() >= 30)
                                              {
                                                  propertyDes = propertyDes.substring(0, 30);
                                              }               
                                          }
                                          catch(Exception propertyErr)
                                          {
                                              propertyDes = "";   
                                          }                                                                                  

                                          if((!duePropertyVal.contains("BCIPEGAS")) || (!propertyDesVal.contains("Gasto")))
                                          {                                          
                                              commissionAmtFeeDbl = commissionAmtFeeDbl + duePropertyAmtDbl;
                                          }else
                                          {
                                              expenseAmtFeeDbl = expenseAmtFeeDbl + duePropertyAmtDbl;
                                          }
                                          
                                          propertyDes = StringUtils.rightPad(propertyDes, 30, " ");                                
                                          duePropertyAmt = formatAmt(duePropertyAmt);       //Calling formatAmt class for formating the amount
                                          
                                    //Get Commission details D03 and Expense details D05                                                                      
                                          if(((commissionFlg == 0) && (commissionAddFlg == 0)) || ((expenseFlg == 0) && (expenseAddFlg == 0)))       //If Commission or Expense details is not exist with first set
                                          {
                                              detCode03 = StringUtils.rightPad(detCode03, 20, " ");      //Format the Detail Notice D03/D05 string values based on the length                                        
                                              detCode05 = StringUtils.rightPad(detCode05, 20, " ");
                                              eventCode = StringUtils.rightPad(eventCode, 5, " ");  
                                              currency = StringUtils.rightPad(currency, 5, " ");
                                              
                                              if(((!duePropertyVal.contains("BCIPEGAS")) || (!propertyDesVal.contains("Gasto"))) && ((commissionFlg == 0) && (commissionAddFlg == 0)))
                                              {
                                              //Form Detail Notice D03 Message                                               
                                                  commissionD03Cnt = commissionD03Cnt + 1;
                                                  commissionDets = detCode03+eventCode+dueProperty+propertyDes+currency+duePropertyAmt;                                                 
                                                  if(commissionD03Cnt == 1)
                                                  {
                                                     commissionDetails = commissionDets;
                                                  }else
                                                  {
                                                     commissionDetails = commissionDetails+'\n'+commissionDets;
                                                  }  
                                              }
                                              
                                              if((duePropertyVal.contains("BCIPEGAS") || propertyDesVal.contains("Gasto")) && ((expenseFlg == 0) && (expenseAddFlg == 0)))
                                              {
                                                //Form Detail Notice D05 Message                                                   
                                                  expenseD05Cnt = expenseD05Cnt + 1;
                                                  expenseDets = detCode05+eventCode+dueProperty+propertyDes+currency+duePropertyAmt;                                       
                                                  if(expenseD05Cnt == 1)
                                                  {
                                                      expenseDetails = expenseDets;
                                                  }else
                                                  {
                                                      expenseDetails = expenseDetails+'\n'+expenseDets;
                                                  }  
                                              }
                                          }                                       
                                      }
                                      
                                      if(!commissionDetails.equals(""))
                                      {
                                          commissionAddFlg = 1;
                                      }
                                      if(!expenseDetails.equals(""))
                                      {
                                          expenseAddFlg = 1;
                                      } 
                                      break;
                                  }
                              }
                              capitalBal = String.format("%.2f", capitalBalDbl);
                              expenseAmtFee = String.format("%.2f", expenseAmtFeeDbl);                             
                              principalAmt = String.format("%.2f", principalAmtDbl);
                              interestAmtFee = String.format("%.2f", interestAmtFeeDbl);
                              insuranceAmtFee = String.format("%.2f", insuranceAmtFeeDbl);
                              commissionAmtFee = String.format("%.2f", commissionAmtFeeDbl);
                              
                              totalFeeAmtDbl = principalAmtDbl + interestAmtFeeDbl + insuranceAmtFeeDbl + commissionAmtFeeDbl + expenseAmtFeeDbl;
                              totalFeeAmt = String.format("%.2f", totalFeeAmtDbl);

                              
                         //Format the Detail Notice D02 string values based on the length   
                              detCode02 = StringUtils.rightPad(detCode02, 20, " ");
                              eventCode = StringUtils.rightPad(eventCode, 5, " ");
                              noOfQuoto = StringUtils.leftPad(noOfQuoto, 5, "0");
                              dueDate = StringUtils.rightPad(dueDate, 8, "0");                                    
                              
                              totalFeeAmt = formatAmt(totalFeeAmt);       //Calling formatAmt Class for getting Amount Format
                              capitalBal = formatAmt(capitalBal);
                              principalAmt = formatAmt(principalAmt);
                              interestAmtFee = formatAmt(interestAmtFee);
                              insuranceAmtFee = formatAmt(insuranceAmtFee);
                              insuranceTaxAmtFee = formatAmt(insuranceTaxAmtFee);
                              otherInsuranceAmt = formatAmt(otherInsuranceAmt);
                              commissionAmtFee = formatAmt(commissionAmtFee);
                              largeAmtOtherFee = formatAmt(largeAmtOtherFee);
                              expenseAmtFee = formatAmt(expenseAmtFee);
                              itfAmtFee = formatAmt(itfAmtFee);
                              reducedAmtFee = formatAmt(reducedAmtFee);                            
                              
                         //Form Detail Notice D02 Message         
                              paymentScheduleDets = detCode02+eventCode+noOfQuoto+dueDate+totalFeeAmt+capitalBal+principalAmt+interestAmtFee+insuranceAmtFee+insuranceTaxAmtFee+otherInsuranceAmt+commissionAmtFee+expenseAmtFee+largeAmtOtherFee+itfAmtFee+reducedAmtFee;         
                              
                              if(k==startCnt)
                              {
                                  paymentScheduleDetails = paymentScheduleDets;
                              }else
                              {
                                  paymentScheduleDetails = paymentScheduleDetails+"\r\n"+paymentScheduleDets;
                              } 
                          }
                      
                       noOfD02Recs = totalLoanInstallment;
                       noOfD03Recs = Integer.toString(commissionD03Cnt);
                       noOfD05Recs = Integer.toString(expenseD05Cnt);
                       
                       detNoticeD02Msg = paymentScheduleDetails;
                       detNoticeD03Msg = commissionDetails;
                       detNoticeD05Msg = expenseDetails;
                  }
                  annualAmtLoanPrincipalInstallment = Integer.toString(annualAmtLoanPrincipalInstallmentInt);
                  annualAmtLoanInterestInstallment = Integer.toString(annualAmtLoanInterestInstallmentInt);
                
  //*----------------------------------------------Get D01 details--------------------------------------------------------*//

                   //Get the value of the field PAYIN.ACCOUNT from AA.ARR.SETTLEMENT table                   
                        AaPrdDesSettlementRecord AaPrdDesSettlementRec=null;
                        try
                        {
                            AaPrdDesSettlementRec = new AaPrdDesSettlementRecord(contract.getConditionForProperty("SETTLEMENT"));
                            payInAccountNo = AaPrdDesSettlementRec.getPayinCurrency(0).getDdMandateRef(0).getPayinAccount().getValue();                         
                        
                            if(!payInAccountNo.equals(""))
                            {
                                comment = "PAGO PROGRAMADO EN CUENTA CORRIENTE";                       
                            }
                            
                          //Get Payin Account Currency 
                            try
                            {
                                AccountRecord accRec = new AccountRecord(da.getRecord("ACCOUNT", payInAccountNo));                    
                                payInAccountCcy = accRec.getCurrency().getValue();                   
                            }
                            catch(Exception accErr)
                            {
                                payInAccountCcy = "";
                            } 
                            
                        }
                        catch(Exception aaArrSettleErr)
                        {
                            payInAccountCcy = "";
                        }                  
                         
                         finalMaturityDateLoan = maturityDate;
                         totalAmtGrantLoan = txnAmount;
                       
                        
                     //Get AA.ARR.PAYMENT.SCHEDULE Details                          
                         AaPrdDesPaymentScheduleRecord AaPrdDesPaymentScheduleRec = null;
                         try
                         {
                             AaPrdDesPaymentScheduleRec = new AaPrdDesPaymentScheduleRecord(contract.getConditionForProperty("SCHEDULE"));                     
                             List<PaymentTypeClass> paymentTypeList = AaPrdDesPaymentScheduleRec.getPaymentType();                            
                             int a  = paymentTypeList.size();
                             
                             for(int i=0; i<a; i++)
                             {     
                                 
                            //------------Get Unit Grace period and Loan grace period---------------//
                                 
                                 String billType = "";
                                 String paymentBillStartDate = "";
                                 billType = paymentTypeList.get(i).getBillType().getValue();     
                                 
                                 if((billType.equals("INSTALLMENT")) && (loanGracePeriod.equals("")))
                                 {                                 
                                     String daysUnit = "";
                                     String BillStartDate = "";
                                     try
                                     {
                                         paymentBillStartDate = paymentTypeList.get(i).getPercentage(0).getStartDate().getValue(); 
                                     }
                                     catch(Exception payStartDtErr)
                                     {
                                         paymentBillStartDate = "";
                                     }
                                     
                                     if(!paymentBillStartDate.equals(""))
                                     {
                                         if(!paymentBillStartDate.contains("+"))
                                         {
                                             if (paymentBillStartDate.length() > 8) 
                                             {
                                                 BillStartDate = paymentBillStartDate.substring(paymentBillStartDate.length() - 8);
                                             } 
                                             else
                                             {
                                                 BillStartDate = paymentBillStartDate;
                                             }
                                             
                                             SimpleDateFormat format2 = new SimpleDateFormat("yyyyMMdd");
                                             try 
                                             {
                                                 Date d1 = format2.parse(orgSystemDate);
                                                 Date d2 = format2.parse(BillStartDate);
                                                 
                                                 long diff = d2.getTime() - d1.getTime();
                                                 long loanGracePeriodLong = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
                                                 loanGracePeriod = Long.toString(loanGracePeriodLong);
                                                 unitGracePeriod = "DIAS";
                                             }
                                             catch (ParseException gracePeriodErr) {
                                                 loanGracePeriod = "";
                                             }                                     
                                         }
                                         else
                                         {
                                             try
                                             {
                                                 daysUnit = paymentBillStartDate.substring(paymentBillStartDate.indexOf("+")+1, paymentBillStartDate.length());
                                                 loanGracePeriod = daysUnit.replaceAll("[^0-9]", "");        //Get the numeric value from TERM                                                                    
                                                 unitGracePeriod = daysUnit.substring(daysUnit.length()-1);
                                                 switch(unitGracePeriod)
                                                 {
                                                     case "D":
                                                         unitGracePeriod = "DIAS";
                                                         break;
                                                     case "M":
                                                         unitGracePeriod = "MESES";
                                                         break;
                                                 }
                                             }
                                             catch(Exception gracePeriodErr)
                                             {
                                                 loanGracePeriod = "";
                                             }
                                         }
                                     }                                 
                                 }                                                          
                               
                             //------------Get Periodicity loan Capital Installment and Periodicity Interest Installment loan---------------//
                                 
                                 paymentFreq = paymentTypeList.get(i).getPaymentFreq().getValue();    
                                 paymentType = paymentTypeList.get(i).getPaymentType().getValue();
                                 paymentMethod = paymentTypeList.get(i).getPaymentMethod().getValue();                               
                                                               
                                 if(paymentMethod.equals("DUE") && ((paymentType.equals("LINEAR")) || (paymentType.equals("INTEREST.ONLY")) || (paymentType.equals("ACTUAL")) || (paymentType.equals("INTEREST")) || (paymentType.equals("CONSTANT"))))       //Mantis Issue - 397 & 398 (Include CONSTANT & INTEREST payment Type)
                                 {                                           
                                     List<com.temenos.t24.api.records.aaprddespaymentschedule.PropertyClass> propertylist = paymentTypeList.get(i).getProperty();
                                     int b = propertylist.size();
                                
                                     for(int j=0; j<b; j++)
                                     {                                                                                                    
                                         propertyName = propertylist.get(j).getProperty().getValue(); 
                                       
                                         switch(propertyName)
                                         {
                                             case "ACCOUNT":
                                                 if(periodicityLoanCapitalInstallment.equals(""))
                                                 {
                                                     periodicityLoanCapitalInstallment = paymentFreqCls(paymentFreq);      //Calling paymentFreqCls Class for getting Frequency Enrichment and Annual loan Principal Count
                                                 }
                                                 break; 
                                                  
                                             case "PRINCIPALINTE":
                                                 if(periodicityInterestInstallmentLoan.equals(""))
                                                 {
                                                     periodicityInterestInstallmentLoan = paymentFreqCls(paymentFreq);      //Calling paymentFreqCls Class for getting Frequency Enrichment and Annual loan Interest Count
                                                 }
                                                 break;                                            
                                           }  
                                       }
                                   }                           
                              }
                         }
                         catch(Exception aaScheduleErr)
                         {
                             periodicityInterestInstallmentLoan = "";
                         }             
                    
                     // Mantis issue - 220
                         if(periodicityLoanCapitalInstallment.equals("") || periodicityInterestInstallmentLoan.equals(""))
                         {
                             String BillstartDateVal ="";
                             String propertyNameInt ="";
                                        
                             AaPrdDesPaymentScheduleRecord AaPrdDesPaymentScheduleRecord = null;
                             try
                             {
                                 AaPrdDesPaymentScheduleRecord = new AaPrdDesPaymentScheduleRecord(contract.getConditionForProperty("SCHEDULE"));                     
                                 List<PaymentTypeClass> paymentTypeList = AaPrdDesPaymentScheduleRecord.getPaymentType();            

                                 try
                                 {
                                     BillStartDt = paymentTypeList.get(0).getPercentage(0).getStartDate().getValue();
                                 }
                                 catch(Exception payStartDtErr)
                                 {
                                     BillStartDt = "";   
                                 }
                                 
                                 try
                                 {
                                     BillstartDateVal = paymentTypeList.get(1).getPercentage(0).getStartDate().getValue();
                                 }
                                 catch(Exception billStartDtErr)
                                 {
                                     BillstartDateVal = ""; 
                                 }

                             //Get periodicityInterestInstallmentLoan and periodicityLoanCapitalInstallment based on conditions
                                 try
                                 {
                                     propertyName = AaPrdDesPaymentScheduleRecord.getPaymentType(0).getProperty(0).getProperty().getValue();
                                 }
                                 catch(Exception propertyErr)
                                 {
                                     propertyName = "";
                                 }
                                 
                                 try
                                 {
                                     propertyNameInt = AaPrdDesPaymentScheduleRecord.getPaymentType(1).getProperty(0).getProperty().getValue();
                                 }
                                 catch(Exception propertyValErr)
                                 {
                                     propertyNameInt = "";     
                                 }
                                 
                                 if(BillStartDt.contains("MATURITY") && propertyName.equals("ACCOUNT") && periodicityLoanCapitalInstallment.equals(""))
                                 {
                                     periodicityLoanCapitalInstallment = "Al Vencimiento";  
                                 }
                                   
                                 if(BillstartDateVal.contains("MATURITY") && propertyNameInt.equals("PRINCIPALINTE") && periodicityInterestInstallmentLoan.equals(""))
                                 {
                                     periodicityInterestInstallmentLoan = "Al Vencimiento";      
                                 }
                             }
                                         
                             catch(Exception scheduleErr)
                             {
                                 scheduleErr.getMessage();   
                             }  
                             
                             if(periodicityInterestInstallmentLoan.equals(""))
                             {
                                 periodicityInterestInstallmentLoan = periodicityLoanCapitalInstallment;
                             }
                         }
                         
                    //Set Collection Loan Grace Period
                         if(!loanGracePeriod.equals(""))    
                         {      
                             
                             collectionLoanGracePeriod = "SI";    //If Grace period is there, then set it as SI. Otherwise No
                         }
                         else
                         {
                             collectionLoanGracePeriod = "NO";
                         }   
                         
                         
                    //Get AA.ARR.LIMIT details                      
                         AaPrdDesLimitRecord AaPrdDesLimitRec=null;
                         try
                         {
                             AaPrdDesLimitRec = new AaPrdDesLimitRecord(contract.getConditionForProperty("LIMIT"));
                             LimitRef = AaPrdDesLimitRec.getLimit().getValue();      //Get Limit ID
                              
                             try
                             {
                                 LimitRecord limitRec = new LimitRecord(da.getRecord("LIMIT", LimitRef));     //Read Limit Record                  
                                 
                                 List<CollateralCodeClass> CodeTypelist = limitRec.getCollateralCode();       
                                 if (!CodeTypelist.isEmpty())
                                 {
                                     codeTypeGuaranteeLoan = CodeTypelist.get(0).getCollateralCode().getValue();     //Get COLLATERAL.CODE
                                     typeLoanGuarantee = CodeTypelist.get(0).getCollateralCode().getEnrichment();
                                 }
                             }
                             catch(Exception limitErr)
                             {
                                 typeLoanGuarantee = "";
                             }                                                 
                         }
                         catch(Exception aaLimitErr)
                         {
                             typeLoanGuarantee = "";
                         }
                   
              
                    //Get the value of the field CHARGE.TYPE from AA.ARR.CHARGE table 
                         AaPrdDesChargeRecord aaArrChargeRec = null;
                         try
                         {
                             aaArrChargeRec = new AaPrdDesChargeRecord(contract.getConditionForProperty("BCIPEGASTNOTCR"));
                             String chargeType = aaArrChargeRec.getChargeType().getValue();
                              
                             switch(chargeType)
                             {
                                 case "FIXED":
                                 loanFeeType = "FIJA";
                                 break;
                                 
                                 case "CALCULATED":
                                 loanFeeType = "VARIABLE";
                                 break;   
                             }
                         }
                         catch(Exception chrgErr)
                         {
                             loanFeeType = "";
                         }   
                         
                         
                   //Get the value of the field EFFECTIVE.RATE from AA.ARR.INTEREST table
                                                
                         AaPrdDesInterestRecord aaInterestRec = null;        //Fetch Interest Rate Rate and Penalty non Payment value for PENALTYINT
                         try
                         {
                              aaInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("PENALTYINT"));
                              penaltyNonPayment = aaInterestRec.getFixedRate(0).getEffectiveRate().getValue();       //Get EFFECTIVE.RATE field Value         
                         }
                         catch(Exception penaltyintErr)
                         {
                             penaltyNonPayment = "";
                         }                     
                 
                  //*--------------------------------------------------------------------*

                         if(penaltyNonPayment.equals(""))              //Fetch Penalty non Payment value for PENALINT
                         {
                             try
                             {
                                  aaInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("PENALINT"));
                                  penaltyNonPayment = aaArrInterestRec.getFixedRate(0).getEffectiveRate().getValue();         //Get EFFECTIVE.RATE field Value                                                
                             }
                             catch(Exception penalintErr)
                             {
                                 penaltyNonPayment = "";
                             }
                         }
         
    //*---------------------------------------Get D03 details--------------------------------------------------------*//

             if(detNoticeD03Msg.equals(""))      //If there is no commission details, then pass null values
             {                             
                 noOfD03Recs = "1";   
                 dueProperty = "";
                 duePropertyAmt = "";
                 propertyDes = "";
                 String commissionCcy = "";
                 
              //Format the Detail Notice D03 string values based on the length
                 detCode03 = StringUtils.rightPad(detCode03, 20, " ");       
                 eventCode = StringUtils.rightPad(eventCode, 5, " ");                                         
                 dueProperty = StringUtils.rightPad(dueProperty, 5, " ");                                      
                 propertyDes = StringUtils.rightPad(propertyDes, 30, " ");      
                 commissionCcy = StringUtils.rightPad(commissionCcy, 5, " ");                 
                 duePropertyAmt = formatAmt(duePropertyAmt);
                        
              //Form Detail Notice D03 Message         
                 detNoticeD03Msg = detCode03+eventCode+dueProperty+propertyDes+commissionCcy+duePropertyAmt;  
             } 
        
    //*---------------------------------------Get D04 details--------------------------------------------------------*//
             
             String secureLoanCode = "";
             String descriptLoanInsurance = "";
             String loanInsuranceCcy = "";
             String secureLoanAmt = "";
             noOfD04Recs = "1";
             
           //Format the Detail Notice D04 string values based on the length
             detCode04 = StringUtils.rightPad(detCode04, 20, " ");
             eventCode = StringUtils.rightPad(eventCode, 5, " ");
             secureLoanCode = StringUtils.rightPad(secureLoanCode, 5, " ");
             descriptLoanInsurance = StringUtils.rightPad(descriptLoanInsurance, 30, " ");
             loanInsuranceCcy = StringUtils.rightPad(loanInsuranceCcy, 5, " ");
             secureLoanAmt = StringUtils.leftPad(secureLoanAmt, 22, "0");
    
           //Form Detail Notice D04 Message
             detNoticeD04Msg = detCode04+eventCode+secureLoanCode+descriptLoanInsurance+loanInsuranceCcy+secureLoanAmt;  
             
    //*---------------------------------------Get D05 details--------------------------------------------------------*//
             
             if(detNoticeD05Msg.equals(""))       //If there is no Expense details, then pass null values
             {
                 noOfD05Recs = "1";
                 dueProperty = "";
                 duePropertyAmt = "";
                 propertyDes = "";
                 String commissionCcy = "";
                 
              //Format the Detail Notice D04 string values based on the length
                 detCode05 = StringUtils.rightPad(detCode05, 20, " ");         
                 eventCode = StringUtils.rightPad(eventCode, 5, " ");                                         
                 dueProperty = StringUtils.rightPad(dueProperty, 5, " ");                                      
                 propertyDes = StringUtils.rightPad(propertyDes, 30, " ");      
                 commissionCcy = StringUtils.rightPad(commissionCcy, 5, " ");                
                 duePropertyAmt = formatAmt(duePropertyAmt);
                        
              //Form Detail Notice D04 Message         
                 detNoticeD05Msg = detCode05+eventCode+dueProperty+propertyDes+commissionCcy+duePropertyAmt; 
             }                               
         }
               
 //************************************************************************************************************************************//
               
         if(eventCode.equals("N0001"))
         {
             String totalSaldoAmt = "";
             String paymentSysId = "";
             String InterestAmt = "";
             double InterestAmtDbl = 0;
             String captialAmt = "";
             String totalPay = "";
             String activityAmt = "";
             double activityAmtDbl = 0;
             double captialAmtDbl = 0;
             double totalPayDbl = 0;
             double accrualAmtDbl = 0;
             int dueDateFlg = 0;
             
             timeOfOperation = hdrEventTime;
             dateOfOperation = effectiveDate;
             dateOfLastModifyLoanTerms = "";
             interestRateType = "";
             
             switch(activity)
             {
                 case "LENDING-APPLYPAYMENT-PR.REPAYMENT":                                 
                     paymentType = "CANCELAC.PARCIAL";
                     break;
                    
                 case "LENDING-APPLYPAYMENT-PR.PRINCIPAL.DECREASE":
                     paymentType = "CANCELAC.PARCIAL";
                     break;
                         
                 case "LENDING-SETTLE-PAYOFF":                                    
                     paymentType = "CANCELAC.TOTAL";
                     break;
                 
                 case "LENDING-CANCEL-PAYOFF":                                    
                     paymentType = "CANCELAC.TOTAL";
                     break;
             }
           
          //Get total Balance movement for getting Saldo de Prestamo to few activity PR.REPAYMENT and PR.DUE.PAYMENT
             try
             {
                 List<BalanceMovement> curAccount = contract.getContractBalanceMovements("CURACCOUNT", "");
                 double curAccountBalDbl = curAccount.get(0).getBalance().doubleValue();
                 
                 List<BalanceMovement> dueAccount = contract.getContractBalanceMovements("DUEACCOUNT", "");
                 double dueAccountBalDbl = dueAccount.get(0).getBalance().doubleValue();
               
                 List<BalanceMovement> grcAccount = contract.getContractBalanceMovements("GRCACCOUNT", "");
                 double grcAccountBalDbl = grcAccount.get(0).getBalance().doubleValue();
                 
                 List<BalanceMovement> delAccount = contract.getContractBalanceMovements("DELACCOUNT", "");
                 double delAccountBalDbl = delAccount.get(0).getBalance().doubleValue();
                 
                 List<BalanceMovement> nabAccount = contract.getContractBalanceMovements("NABACCOUNT", "");
                 double nabAccountBalDbl = nabAccount.get(0).getBalance().doubleValue();
                
                 double totalSaldoAmtDbl = curAccountBalDbl + dueAccountBalDbl + grcAccountBalDbl + delAccountBalDbl + nabAccountBalDbl;
                 totalSaldoAmt = String.format("%.2f", totalSaldoAmtDbl);  
             }
             catch(Exception totAmtErr)
             {
                 totalSaldoAmt = "";
             }
            
         //Get the value of the field ACTUAL.AMT and CONTRACT.ID from AA.ACTIVITY.HISTORY
             try         
             {  
                 AaActivityHistoryRecord aaActivityHisRec = new AaActivityHistoryRecord(da.getRecord("AA.ACTIVITY.HISTORY", operationNo));            
                 List<EffectiveDateClass> effctiveDateClassList = aaActivityHisRec.getEffectiveDate();
                     
                 for(EffectiveDateClass effctiveDateList : effctiveDateClassList)
                 {
                     List<ActivityRefClass> activityRefClassList = effctiveDateList.getActivityRef();
                         
                     for(ActivityRefClass activityRefList : activityRefClassList)
                     {
                         String activityRef = activityRefList.getActivityRef().getValue();
                         String aaActivity = activityRefList.getActivity().getValue();
                             
                         if((activityRef.equals(aaaId)) && (aaActivity.equals(activity)))
                         {
                             activityAmt = activityRefList.getActivityAmt().getValue(); 
                             activityAmtDbl = Double.parseDouble(activityAmt);

                             paymentSysId = activityRefList.getContractId().getValue().substring(0, 16);                                     
                             break;
                         }
                     }
                     if(!activityAmt.equals(""))
                     {
                         break;
                     }
                 }
             }  
             catch(Exception aaActHisErr)
             {
                 activityAmt = "";  
             }          
             
     //------------Get Interest, Monto principal and Saldo de Prestamo (Loan Balance) for N0001-------------// 
             
             
             switch(activity)
             {
                 case "LENDING-APPLYPAYMENT-PR.REPAYMENT":                                 
                     
                    principalBalLoan = totalSaldoAmt;      //Saldo de Prestamo

                 //Get the value of the field OR.PROP.AMOUNT from AA.BILL.DETAILS for Monto Principal and Interest
                    try                   
                    {  
                        AaAccountDetailsRecord aaAcctDetailsRec = new AaAccountDetailsRecord(da.getRecord("AA.ACCOUNT.DETAILS", operationNo));
                        List<RepayReferenceClass> repayReferenceClsList = aaAcctDetailsRec.getRepayReference();
                        
                        for(RepayReferenceClass repayReferenceCls : repayReferenceClsList)
                        {
                            String repayRefId = repayReferenceCls.getRepayReference().getValue();
                            if(repayRefId.contains(aaaId))          //Mantis - 355 (Total amount of Interest and Monto Principal for all Bills)
                            {
                                List<TField> billIdClsList = repayReferenceCls.getRpyBillId();
                                
                                for(TField billIdCls : billIdClsList)
                                {
                                    String principalPropAmt = "";
                                    String feeInterestPropAmt = "";
                                    double principalPropAmtDbl = 0;
                                    double feeInterestPropAmtDbl = 0;
                                    String repayBillId = "";
                                    
                                    repayBillId = billIdCls.getValue();
                                    try
                                    {
                                        AaBillDetailsRecord aabillDetsRec = new AaBillDetailsRecord(da.getRecord("AA.BILL.DETAILS", repayBillId)); 
                                        List<PropertyClass> propertyClsList = aabillDetsRec.getProperty();
                                        
                                        for(PropertyClass propertyCls : propertyClsList)
                                        {
                                            propertyVal = "";
                                            propertyVal = propertyCls.getProperty().getValue();
                                            
                                            switch(propertyVal)
                                            {
                                            case "ACCOUNT":        //Get Monto Principal
                                                if(principalPropAmt.equals(""))
                                                {
                                                    principalPropAmt = propertyCls.getOrPropAmount().getValue();
                                                    principalPropAmtDbl = Double.parseDouble(principalPropAmt);
                                                    principalAmtCancelDbl = principalAmtCancelDbl + principalPropAmtDbl;
                                                }
                                                break;
                                                
                                            case "PRINCIPALINTE":       //Get Interest amount
                                                if(feeInterestPropAmt.equals(""))
                                                {
                                                    feeInterestPropAmt = propertyCls.getOrPropAmount().getValue();
                                                    feeInterestPropAmtDbl = Double.parseDouble(feeInterestPropAmt);
                                                    feeInterestCancelDbl = feeInterestCancelDbl + feeInterestPropAmtDbl;
                                                }
                                                break;
                                            }
                                        }
                                    }
                                    catch(Exception repayBillErr)
                                    {
                                        repayBillErr.getMessage();
                                    }
                                }
                            
                                principalAmtCancel = String.format("%.2f", principalAmtCancelDbl);
                                feeInterestCancel = String.format("%.2f", feeInterestCancelDbl);
                            }
                            
                            if((!principalAmtCancel.equals("")) && (!feeInterestCancel.equals("")))
                            { 
                                break;
                            }
                        }              
                    }  
                    catch(Exception aaAcctDetsErr)
                    {
                        aaAcctDetsErr.getMessage();  
                    } 
                    break;
                    
            //*****************************************************************************************
                 case "LENDING-APPLYPAYMENT-PR.ADV.TERM": case "LENDING-APPLYPAYMENT-PR.ADV.PAYMENT":     //Mantis - 357 & 358
  
                //Get Interest, Total to Pay and Capital amount from EB.BCI.UPDATE.LOAN.BALANCES.DETAILS table
                     String bciUpdLoanBalancesDetsId = operationNo+"-"+paymentSysId;    //ID of EB.BCI.UPDATE.LOAN.BALANCES.DETAILS Record
                     try
                     {
                         EbBciUpdateLoanBalancesDetailsRecord bciUpdLoanBalancesDetsRec = new EbBciUpdateLoanBalancesDetailsRecord(da.getRecord("EB.BCI.UPDATE.LOAN.BALANCES.DETAILS", bciUpdLoanBalancesDetsId));
                         
                         InterestAmt = bciUpdLoanBalancesDetsRec.getInterest().getValue();  
                         InterestAmtDbl = Double.parseDouble(InterestAmt);
                         
                         captialAmt = bciUpdLoanBalancesDetsRec.getCapital().getValue();
                         captialAmtDbl = Double.parseDouble(captialAmt);
                         
                         totalPay = bciUpdLoanBalancesDetsRec.getTotalPay().getValue();
                         totalPayDbl = Double.parseDouble(totalPay);   
                     }
                     catch(Exception bciUpdLoanbalDetsErr)
                     {
                         bciUpdLoanbalDetsErr.getMessage();
                     }
                     
                //Get Accrual Amount (ACCPRINCIPALINTE - Closing Balance) 
                     try
                     {
                         List<BalanceMovement> accPrincipalinte = contract.getBalanceMovements("ACCPRINCIPALINTE", "");  
                         
                         if(accPrincipalinte.get(accPrincipalinte.size()-1).getDate().toString().equals(today))
                         {
                             accrualAmtDbl = Math.abs(accPrincipalinte.get(accPrincipalinte.size()-2).getBalance().doubleValue());
                         }else
                         {
                             accrualAmtDbl = Math.abs(accPrincipalinte.get(accPrincipalinte.size()-1).getBalance().doubleValue());
                         }
                     }
                     catch(Exception accrualAmtErr)
                     {
                         accrualAmtDbl = 0;
                     }
                   
                //Find TODAY in EB.BCI.UPDATE.SCHEDULE.PROJECTOR
                     if(scheduleFlg == 0)
                     {
                         List<DueDateClass> dueDateClsList = scheduleProjectorRec.getDueDate();
                         for(DueDateClass dueDateCls : dueDateClsList)
                         {
                             String dueDate = dueDateCls.getDueDate().getValue();
                             if(dueDate.equals(today))
                             {
                                 dueDateFlg = 1;
                                 break;
                             }
                         }
                     }
                     
               //Calculate Interest and Monto Principal
                     if(dueDateFlg == 1)
                     {
                         feeInterestCancelDbl = InterestAmtDbl;    //Interest amount from Enquiry only
                         principalAmtCancelDbl = activityAmtDbl - totalPayDbl + captialAmtDbl;   //Payment Amount - Total Pay + Capital Amount
                     }
                     else
                     {
                         feeInterestCancelDbl = InterestAmtDbl + accrualAmtDbl;    //Interest amount from Enquiry + Accrual Interest
                         principalAmtCancelDbl = activityAmtDbl - accrualAmtDbl - totalPayDbl + captialAmtDbl;   //Payment Amount - Accrual amount - Total Pay + Capital Amount
                     }
                     feeInterestCancel = String.format("%.2f", feeInterestCancelDbl);
                     principalAmtCancel = String.format("%.2f", principalAmtCancelDbl);
                
               //Get Saldo de Prestamo
                     try     
                     {
                         EbContractBalancesRecord ecbRec = new EbContractBalancesRecord(da.getRecord("EB.CONTRACT.BALANCES", accountNo));      
                         principalBalLoan = ecbRec.getWorkingBalance().getValue();
                     }
                     catch(Exception ecbErr)
                     {
                         principalBalLoan = "";
                     }
                     break;
                         
            //*****************************************************************************************  
                 case "LENDING-APPLYPAYMENT-PR.DUE.PAYMENT":      //Mantis - 356                               
                     principalBalLoan = totalSaldoAmt;      //Saldo de Prestamo
                     
                     try
                     {
                         EbContractBalancesRecord ecbRec = new EbContractBalancesRecord(da.getRecord("EB.CONTRACT.BALANCES", accountNo));
                         List<TypeSysdateClass> typeSysDateClsList = ecbRec.getTypeSysdate();
                         
                         for(TypeSysdateClass typeSysDateCls : typeSysDateClsList)
                         {
                             String typeSysDate = "";
                             String creditMvmt = "";
                             String debitMvmt = ""; 
                             double creditMvmtDbl = 0;
                             double debitMvmtDbl = 0;
                             typeSysDate = typeSysDateCls.getTypeSysdate().getValue();
                             
                             if(typeSysDate.contains(today))
                             {
                                 creditMvmt = typeSysDateCls.getMatDate(0).getCreditMvmt().getValue();
                                 debitMvmt = typeSysDateCls.getMatDate(0).getDebitMvmt().getValue();
                                
                                 try
                                 {
                                     creditMvmtDbl = Double.parseDouble(creditMvmt);
                                 }
                                 catch(Exception creditMvmtDblErr)
                                 {
                                     creditMvmtDbl = 0;
                                 }
                                 
                                 try
                                 {
                                     debitMvmtDbl = Double.parseDouble(debitMvmt);
                                 }
                                 catch(Exception debitMvmtDblErr)
                                 {
                                     debitMvmtDbl = 0;
                                 }
                                
                                 if((typeSysDate.contains("DUEACCOUNT-")) || (typeSysDate.contains("DELACCOUNT-")) || (typeSysDate.contains("NABACCOUNT-")) || (typeSysDate.contains("CURACCOUNT-")))
                                 {
                                     principalAmtCancelDbl = principalAmtCancelDbl + creditMvmtDbl + debitMvmtDbl;
                                 }
                                
                                 if((typeSysDate.contains("ACCPRINCIPALINTE-")) || (typeSysDate.contains("DUEPRINCIPALINTE-")) || (typeSysDate.contains("DELPRINCIPALINTE-")) || (typeSysDate.contains("NABPRINCIPALINTE-")))
                                 {
                                     feeInterestCancelDbl = feeInterestCancelDbl + creditMvmtDbl + debitMvmtDbl;
                                 }
                             }
                         }
                         principalAmtCancel = String.format("%.2f", principalAmtCancelDbl);    //Monto Principal
                         feeInterestCancel = String.format("%.2f", feeInterestCancelDbl);     //Interest
                     }
                     catch(Exception ecbErr)
                     {
                         ecbErr.getMessage();
                     }
                     break;
             
            //*****************************************************************************************
                 case "LENDING-SETTLE-PAYOFF":     //Mantis - 166                                

                     List<String> aabillDetailsRecList = new ArrayList<String>();                      
                     String selAaBillDetsCmd = "WITH BILL.TYPE EQ 'PAYOFF' AND ARRANGEMENT.ID EQ '"+operationNo+"'";  //Select AA.BILL.DETAILS record with BILL>TYPE as PAYOFF
                     try            
                     {
                         aabillDetailsRecList = da.selectRecords("","AA.BILL.DETAILS","",selAaBillDetsCmd); 
                         billId = aabillDetailsRecList.get(0).toString();
                     } 
                     catch (Exception bciEngageErr) {   
                         billId = "";
                     } 
                     
                     try
                     {
                         AaBillDetailsRecord aabillDetsRec = new AaBillDetailsRecord(da.getRecord("AA.BILL.DETAILS", billId));    //Get INFO.PAY.PRP and INFO.PR.AMT from AA.BILL.DETAILS  
                    
                         List<PropertyClass> propertyClsList = new ArrayList<PropertyClass>();      //Get PROPERTY and OR.PROP.AMOUNT from AA.BILL.DETAILS  
                         propertyClsList = aabillDetsRec.getProperty();
                         
                         for(PropertyClass propertyList : propertyClsList)
                         {
                             propertyVal = "";
                             propertyVal = propertyList.getProperty().getValue();
                            
                             switch(propertyVal)
                             {
                                 case "ACCOUNT":           //Get Monto Principal
                                     if(principalAmtCancel.equals(""))      
                                     {
                                         principalAmtCancel = propertyList.getOrPropAmount().getValue();
                                     }                      
                                     break;
                                 
                              //Get Property Amount from Interest Property
                                 case "PRINCIPALINTE":         
                                     principalinteAmt = propertyList.getOrPropAmount().getValue();
                                     principalinteAmtDbl = Double.parseDouble(principalinteAmt);
                                     break; 
                                     
                                 case "PENALTYINT":
                                     penaltyintAmt = propertyList.getOrPropAmount().getValue();
                                     penaltyintAmtDbl = Double.parseDouble(penaltyintAmt);
                                     break;
                                     
                                 case "PENALINT":
                                     penalintAmt = propertyList.getOrPropAmount().getValue();
                                     penalintAmtDbl = Double.parseDouble(penalintAmt);
                                     break;
                              }      
                         }
                         feeInterestCancelDbl = principalinteAmtDbl + penaltyintAmtDbl + penalintAmtDbl;     //Calculate Interest Value
                         feeInterestCancel = String.format("%.2f", feeInterestCancelDbl);
                     }
                     catch(Exception aaBillDetsRecErr)
                     {
                         feeInterestCancel = "";
                     }
                     break;
                     
            //*****************************************************************************************
                 default: 

                 //Get Bill ID from AA.ACCOUNT.DETAILS record for other activities,
                    AaAccountDetailsRecord aaacctDetsRec = null;
                    try
                    {
                        aaacctDetsRec = new AaAccountDetailsRecord(da.getRecord("AA.ACCOUNT.DETAILS", operationNo));
                        List<BillPayDateClass> billPayDateClsList = aaacctDetsRec.getBillPayDate();
                        for(BillPayDateClass billPayDateList : billPayDateClsList)
                        {
                            List<BillIdClass> billIdClsList = new ArrayList<BillIdClass>();
                            billIdClsList = billPayDateList.getBillId();
                            for(BillIdClass billIdList : billIdClsList)
                            {
                                String activitReference = "";                            
                                activitReference = billIdList.getActivityRef().getValue();
                                if(activitReference.equals(aaaId))
                                {
                                    billId = billIdList.getBillId().getValue();
                                    break;
                                }
                            }
                            if(!billId.equals(""))
                            {
                                break;
                            }
                        }           
                    }
                    catch(Exception aaAcctDetsErr)
                    {
                        aaAcctDetsErr.getMessage();
                    }
                        
                 //For other activities, Read AA.BILL.DETAILS record  
                    if(!billId.equals(""))
                    {                  
                        try
                        {
                            AaBillDetailsRecord aabillDetsRec = new AaBillDetailsRecord(da.getRecord("AA.BILL.DETAILS", billId));    //Get INFO.PAY.PRP and INFO.PR.AMT from AA.BILL.DETAILS  
                                
                            List<PropertyClass> propertyClsList = new ArrayList<PropertyClass>();      //Get PROPERTY and OR.PROP.AMOUNT from AA.BILL.DETAILS  
                            propertyClsList = aabillDetsRec.getProperty();
                            for(PropertyClass propertyList : propertyClsList)
                            {
                                propertyVal = "";
                                propertyVal = propertyList.getProperty().getValue();
                                    
                                switch(propertyVal)
                                {
                                    case "ACCOUNT":
                                        if(principalAmtCancel.equals(""))        //Get Monto Principal
                                        {
                                            principalAmtCancel = propertyList.getOrPropAmount().getValue();
                                        }                      
                                        break;
                                        
                                    case "PRINCIPALINTE":
                                        if(intPrinicpalinteAmt.equals(""))
                                        {
                                            intPrinicpalinteAmt = propertyList.getOrPropAmount().getValue();
                                            intPrinicpalinteAmtDbl = Double.parseDouble(intPrinicpalinteAmt);
                                        }                      
                                        break; 
                                            
                                    case "PENALTYINT":
                                        if(intPenaltyintAmt.equals(""))
                                        {
                                            intPenaltyintAmt = propertyList.getOrPropAmount().getValue(); 
                                            intPenaltyintAmtDbl = Double.parseDouble(intPenaltyintAmt);
                                        }                      
                                        break;

                                    case "PENALINT":
                                        if(intPenalintAmt.equals(""))
                                        {
                                            intPenalintAmt = propertyList.getOrPropAmount().getValue(); 
                                            intPenalintAmtDbl = Double.parseDouble(intPenalintAmt);
                                        } 
                                        break;
                                }    
                            }
                                
                            List<InfoPayTypeClass> infoPayTypeList = new ArrayList<InfoPayTypeClass>();
                            infoPayTypeList = aabillDetsRec.getInfoPayType();
                            int infoPayTypeListCnt = infoPayTypeList.size();                        
                                                      
                            for(int i=infoPayTypeListCnt-1; i>=0; i--)
                            {                             
                                List<InfoPayPrpClass> infoPayPrpList = new ArrayList<InfoPayPrpClass>();
                                infoPayPrpList = infoPayTypeList.get(i).getInfoPayPrp();
                                int infoPayPrpListCnt = infoPayPrpList.size();
                                    
                                for(int j=infoPayPrpListCnt-1; j>=0; j--) 
                                {
                                    String infoPayPrp = "";
                                    infoPayPrp = infoPayPrpList.get(j).getInfoPayPrp().getValue();
                                        
                                    switch(infoPayPrp)
                                    {
                                        case "PRINCIPALINTE":
                                            if(intPrinicpalinteAmt.equals(""))
                                            {
                                                intPrinicpalinteAmt = infoPayPrpList.get(j).getInfoPrAmt().getValue(); 
                                                intPrinicpalinteAmtDbl = Double.parseDouble(intPrinicpalinteAmt);
                                            }                      
                                            break;
                                                
                                        case "PENALTYINT":
                                            if(intPenaltyintAmt.equals(""))
                                            {
                                                intPenaltyintAmt = infoPayPrpList.get(j).getInfoPrAmt().getValue(); 
                                                intPenaltyintAmtDbl = Double.parseDouble(intPenaltyintAmt);
                                            }                      
                                            break;

                                        case "PENALINT":
                                            if(intPenalintAmt.equals(""))
                                            {
                                                intPenalintAmt = infoPayPrpList.get(j).getInfoPrAmt().getValue(); 
                                                intPenalintAmtDbl = Double.parseDouble(intPenalintAmt);
                                            } 
                                            break;
                                      }                                  
                                 }                            
                            }                                       
                                
                            feeInterestCancelDbl = intPrinicpalinteAmtDbl + intPenaltyintAmtDbl + intPenalintAmtDbl;     //Calculate Interest Value
                            feeInterestCancel = String.format("%.2f", feeInterestCancelDbl);
                                
                            if(scheduleFlg == 0)  //Get Saldo de Prestamo Value
                            {
                                principalBalLoan = scheduleProjectorRec.getDueDate().get(0).getDueOutstandingBalance().getValue();
                            }
                        }
                        catch(Exception billDetsErr)
                        {
                            billDetsErr.getMessage();
                        }
                    }
                    else
                    {
                    //For other activities - Read the AA.SCHEDULE.PROJECTOR api values from EB.BCI.UPDATE.SCHEDULE.PROJECTOR When AA.BILL.DETAILS is not exist             
                                              
                        principalAmtCancel = activityAmt;    //Monto Principal
                        if(scheduleFlg == 0)
                        {
                            List<DueDateClass> dueDateList = scheduleProjectorRec.getDueDate();
                            dutDateCnt = dueDateList.size();
                            
                            dueTypeListStr = scheduleProjectorRec.getDueDate(0).getDueType().toString();
                            if(!dueTypeListStr.contains("DISBURSEMENT.%"))
                            {
                                startCnt = 0; 
                            }
                            else{
                                startCnt = 1;
                            }
                                
                            for(int k=startCnt; k<dutDateCnt; k++)
                            {        
                                principalBalLoan = dueDateList.get(0).getDueOutstandingBalance().getValue();      //Get Saldo de Prestamo Value

                                List<DueTypeClass> repayDueTypeList = scheduleProjectorRec.getDueDate().get(k).getDueType();
                                repayDueTypeCnt = repayDueTypeList.size();

                                for(int r=0; r<repayDueTypeCnt; r++)
                                {
                                    dueType = repayDueTypeList.get(r).getDueType().getValue();
                                        
                                    if((dueType.equals("INTEREST.ONLY")) || (dueType.equals("ACTUAL")) || (dueType.equals("INTEREST")))
                                    {
                                        feeInterestCancel = repayDueTypeList.get(r).getDueTypeAmount().toString();      //Get Interest Value
                                        break;
                                    }  
                                }
                                if(!feeInterestCancel.equals(""))
                                {
                                    break;
                                }
                            }  
                        }
                   } 
                   break;
              }
             
              if(activity.contains("PAYOFF"))
              {
                  principalBalLoan = "0";    //Set Saldo de Prestamo Value as 0 for PAYOFF activities
              }
         }
 
 //************************************************************************************************************************************//             

     //Format the Header Notice String value based on the length
         hdrCode = StringUtils.rightPad(hdrCode, 20, " ");
         eventCode = StringUtils.rightPad(eventCode, 5, " ");
         noOfD02Recs = StringUtils.leftPad(noOfD02Recs, 5, "0");
         noOfD03Recs = StringUtils.leftPad(noOfD03Recs, 5, "0");
         noOfD04Recs = StringUtils.leftPad(noOfD04Recs, 5, "0");
         noOfD05Recs = StringUtils.leftPad(noOfD05Recs, 5, "0");
         customerNo1 = StringUtils.rightPad(customerNo1, 20, " ");
         customerName1 = StringUtils.rightPad(customerName1, 120, " ");
         legalID1 = StringUtils.rightPad(legalID1, 20, " ");
         customerNo2 = StringUtils.rightPad(customerNo2, 20, " ");
         customerName2 = StringUtils.rightPad(customerName2, 120, " ");
         legalID2 = StringUtils.rightPad(legalID2, 20, " ");
         customerNo3 = StringUtils.rightPad(customerNo3, 20, " ");
         customerName3 = StringUtils.rightPad(customerName3, 120, " ");
         legalID3 = StringUtils.rightPad(legalID3, 20, " ");
         customerNo4 = StringUtils.rightPad(customerNo4, 20, " ");
         customerName4 = StringUtils.rightPad(customerName4, 120, " ");
         legalID4 = StringUtils.rightPad(legalID4, 20, " ");
         customerNo5 = StringUtils.rightPad(customerNo5, 20, " ");
         customerName5 = StringUtils.rightPad(customerName5, 120, " ");
         legalID5 = StringUtils.rightPad(legalID5, 20, " ");
         address = StringUtils.rightPad(address, 120, " ");
         email = StringUtils.rightPad(email, 50, " ");
         phoneNo = StringUtils.rightPad(phoneNo, 20, " ");
         hdrEventDate = StringUtils.rightPad(hdrEventDate, 8, "0");
         hdrEventTime = StringUtils.rightPad(hdrEventTime, 8, "0");
         loanNo = StringUtils.rightPad(loanNo, 30, " ");        
         
    //Form Header Notice Message
         hdrNoticeMsg = hdrCode+eventCode+noOfD02Recs+noOfD03Recs+noOfD04Recs+noOfD05Recs+customerNo1+customerName1+legalID1+customerNo2+customerName2+legalID2+customerNo3+customerName3+legalID3+customerNo4+customerName4+legalID4+customerNo5+customerName5+legalID5+address+email+phoneNo+hdrEventDate+hdrEventTime+loanNo; 
    
         
    //Format the Detail Notice D01 string values based on the length
         detCode01 = StringUtils.rightPad(detCode01, 20, " ");
         eventCode = StringUtils.rightPad(eventCode, 5, " ");  
         loanNo = StringUtils.rightPad(loanNo, 30, " ");        
         codeProduct = StringUtils.rightPad(codeProduct, 5, " ");        
         productDescript = StringUtils.rightPad(productDescript, 30, " ");        
         legalID1 = StringUtils.rightPad(legalID1, 20, " ");        
         bench = StringUtils.rightPad(bench, 50, " ");        
         bankOfficeCode = StringUtils.rightPad(bankOfficeCode, 5, " "); 
         branchShortName = StringUtils.rightPad(branchShortName, 30, " ");        
         codeExecutive = StringUtils.rightPad(codeExecutive, 5, " ");        
         executiveName = StringUtils.rightPad(executiveName, 100, " ");        
         executiveTelephone = StringUtils.rightPad(executiveTelephone, 20, " ");        
         executiveEmail = StringUtils.rightPad(executiveEmail, 50, " ");        
         paymentType = StringUtils.rightPad(paymentType, 30, " ");        
         paymentMethodPaidEvent = StringUtils.rightPad(paymentMethodPaidEvent, 30, " ");        
         formSubmissionStatement = StringUtils.rightPad(formSubmissionStatement, 30, " ");        
         noOfEvent = StringUtils.leftPad(noOfEvent, 5, "0");        
         noOfInstallmentPaid = StringUtils.leftPad(noOfInstallmentPaid,5, "0");        
         installmentDatePaid = StringUtils.rightPad(installmentDatePaid, 8, "0");        
         nextInstallmentExpireDate = StringUtils.rightPad(nextInstallmentExpireDate, 8, "0");        
         nextInstallmentduePay = StringUtils.rightPad(nextInstallmentduePay, 8, "0");        
         dateOfOperation = StringUtils.rightPad(dateOfOperation, 8, "0");        
         timeOfOperation = StringUtils.rightPad(timeOfOperation, 8, "0");        
         currency = StringUtils.rightPad(currency, 5, " ");        
         loanCcyPreCondition = StringUtils.rightPad(loanCcyPreCondition, 5, " ");              
         amtConceptOtherPrincipalIntFeeCancelInsurance = StringUtils.leftPad(amtConceptOtherPrincipalIntFeeCancelInsurance, 22, "0");
         payInAccountNo = StringUtils.rightPad(payInAccountNo, 30, " ");        
         payInAccountCcy = StringUtils.rightPad(payInAccountCcy, 5, " ");        
         comment = StringUtils.rightPad(comment, 50, " ");        
         dateOfGrantLoan = StringUtils.rightPad(dateOfGrantLoan, 8, "0");        
         Loandisbursementdate = StringUtils.rightPad(Loandisbursementdate, 8, "0");        
         dateOfLastModifyLoanTerms = StringUtils.rightPad(dateOfLastModifyLoanTerms, 8, "0");        
         firstLoanInstallmentDate = StringUtils.rightPad(firstLoanInstallmentDate, 8, "0");        
         finalMaturityDateLoan = StringUtils.rightPad(finalMaturityDateLoan, 8, "0");        
         finalMaturityDateLoanPreCondition = StringUtils.rightPad(finalMaturityDateLoanPreCondition, 8, "0");        
         unitestablishTerm = StringUtils.rightPad(unitestablishTerm, 5, " ");
         unitTermLoanExpressPreCondition = StringUtils.rightPad(unitTermLoanExpressPreCondition, 5, " ");
         establishTerm = StringUtils.leftPad(establishTerm, 5, "0");
         termLoanPreCondition = StringUtils.leftPad(termLoanPreCondition, 5, "0");
         periodicityLoanCapitalInstallment = StringUtils.rightPad(periodicityLoanCapitalInstallment, 30, " ");
         periodicityInterestInstallmentLoan = StringUtils.rightPad(periodicityInterestInstallmentLoan, 30, " ");
         annualAmtLoanPrincipalInstallment = StringUtils.leftPad(annualAmtLoanPrincipalInstallment, 5, "0");
         annualAmtLoanInterestInstallment = StringUtils.leftPad(annualAmtLoanInterestInstallment, 5, "0");
         unitGracePeriod = StringUtils.rightPad(unitGracePeriod, 5, " ");
         loanGracePeriod = StringUtils.leftPad(loanGracePeriod, 5, "0"); 
         codeTypeGuaranteeLoan = StringUtils.rightPad(codeTypeGuaranteeLoan, 5, " ");
         typeLoanGuarantee = StringUtils.rightPad(typeLoanGuarantee, 30, " ");
         typeLoanGuaranteePreCondition = StringUtils.rightPad(typeLoanGuaranteePreCondition, 30, " ");
         interestRateType = StringUtils.rightPad(interestRateType, 30, " ");
         interestRatePreCondition = StringUtils.rightPad(interestRatePreCondition, 30, " ");
         annualEffectiveInterestRateTEAPreCondition = StringUtils.leftPad(annualEffectiveInterestRateTEAPreCondition, 15, "0");
         annualEffectiveCostRateTCEAPreCondition = StringUtils.leftPad(annualEffectiveCostRateTCEAPreCondition, 15, "0");
         loanFeeType = StringUtils.rightPad(loanFeeType, 30, " ");
         collectionLoanGracePeriod = StringUtils.rightPad(collectionLoanGracePeriod, 2, " ");        
         totalLoanInstallment = StringUtils.leftPad(totalLoanInstallment, 5, "0");
         totalAmtLoanInstallmentPreCondition = StringUtils.leftPad(totalAmtLoanInstallmentPreCondition, 5, "0");
         totalNoUnpaidDueYear = StringUtils.leftPad(totalNoUnpaidDueYear, 5, "0");
         totalAmtInstallmentDueLoan = StringUtils.leftPad(totalAmtInstallmentDueLoan, 5, "0");
         totalAmtInstallmentCancelLoan = StringUtils.leftPad(totalAmtInstallmentCancelLoan, 5, "0");
         additionInsuranceContract = StringUtils.rightPad(additionInsuranceContract, 120, " ");
         additionInsuranceContractPreCondition = StringUtils.rightPad(additionInsuranceContractPreCondition, 120, " ");
         customerCommunication = StringUtils.rightPad(customerCommunication, 150, " "); 
         
         penaltyNonPayment = formatRate(penaltyNonPayment);      //Calling formatRate Class for getting rate Format
         penaltyNonPaymentPreCondition = formatRate(penaltyNonPaymentPreCondition);
         annualEffectiveInterestRateTEA = formatRate(annualEffectiveInterestRateTEA);
         annualEffectiveCostRateTCEA = formatRate(annualEffectiveCostRateTCEA);
         
         loanGracePeriodAmt = formatAmt(loanGracePeriodAmt);     //Calling formatAmt Class for getting Amount Format
         totFeeAmtCancel = formatAmt(totFeeAmtCancel);
         principalAmtCancel = formatAmt(principalAmtCancel);
         feeInterestCancel = formatAmt(feeInterestCancel);
         principalAmtFeeCancelInterest = formatAmt(principalAmtFeeCancelInterest);
         amtCancelFee = formatAmt(amtCancelFee);
         totalAmtFeeCancelInsurance = formatAmt(totalAmtFeeCancelInsurance);
         secureAmtFeeReliefCancel = formatAmt(secureAmtFeeReliefCancel);
         amtInsuranceFeeCancel = formatAmt(amtInsuranceFeeCancel);
         amtFeeCancel = formatAmt(amtFeeCancel);
         amtITFCancel = formatAmt(amtITFCancel);
         amtOtherConceptFeeCancel = formatAmt(amtOtherConceptFeeCancel);
         totalAmtGrantLoan = formatAmt(totalAmtGrantLoan);
         totalPrincipalAmtLoan = formatAmt(totalPrincipalAmtLoan);
         totalPrincipalAmtLoanPreCondition = formatAmt(totalPrincipalAmtLoanPreCondition);
         totalAmtGrantLoanPreCondition = formatAmt(totalAmtGrantLoanPreCondition);
         principalBalLoan = formatAmt(principalBalLoan);
         
         
     //Form Detail Notice D01 Message         
           detNoticeD01Msg = detCode01+eventCode+loanNo+codeProduct+productDescript+legalID1+bench+bankOfficeCode+branchShortName+codeExecutive+executiveName+executiveTelephone+executiveEmail+paymentType+
        paymentMethodPaidEvent+formSubmissionStatement+noOfEvent+noOfInstallmentPaid+installmentDatePaid+
        nextInstallmentExpireDate+nextInstallmentduePay+dateOfOperation+timeOfOperation+currency+loanCcyPreCondition+
        totFeeAmtCancel+principalAmtCancel+feeInterestCancel+principalAmtFeeCancelInterest+amtCancelFee+totalAmtFeeCancelInsurance+
        secureAmtFeeReliefCancel+amtInsuranceFeeCancel+amtFeeCancel+amtITFCancel+amtOtherConceptFeeCancel+amtConceptOtherPrincipalIntFeeCancelInsurance+payInAccountNo+payInAccountCcy+
        comment+dateOfGrantLoan+Loandisbursementdate+dateOfLastModifyLoanTerms+firstLoanInstallmentDate+
        finalMaturityDateLoan+finalMaturityDateLoanPreCondition+unitestablishTerm+unitTermLoanExpressPreCondition+
        establishTerm+termLoanPreCondition+periodicityLoanCapitalInstallment+periodicityInterestInstallmentLoan+annualAmtLoanPrincipalInstallment+annualAmtLoanInterestInstallment+
        unitGracePeriod+loanGracePeriod+codeTypeGuaranteeLoan+typeLoanGuarantee+typeLoanGuaranteePreCondition+
        interestRateType+interestRatePreCondition+annualEffectiveInterestRateTEA+annualEffectiveInterestRateTEAPreCondition+annualEffectiveCostRateTCEA+annualEffectiveCostRateTCEAPreCondition+
        loanFeeType+collectionLoanGracePeriod+loanGracePeriodAmt+penaltyNonPayment+penaltyNonPaymentPreCondition+
        totalAmtGrantLoan+totalAmtGrantLoanPreCondition+totalPrincipalAmtLoan+totalPrincipalAmtLoanPreCondition+
        totalLoanInstallment+totalAmtLoanInstallmentPreCondition+totalNoUnpaidDueYear+totalAmtInstallmentDueLoan+
        totalAmtInstallmentCancelLoan+principalBalLoan+additionInsuranceContract+additionInsuranceContractPreCondition+customerCommunication;

 
 //************************************************************************************************************************************//             

         switch(eventCode)
         {
         case "C0001":
             hdrDetNoticeMsg = hdrNoticeMsg+'\n'+detNoticeD01Msg+'\n'+detNoticeD02Msg+'\n'+detNoticeD03Msg+'\n'+detNoticeD04Msg+'\n'+detNoticeD05Msg;            
             break;
             
         case "N0001":
             hdrDetNoticeMsg = hdrNoticeMsg+'\n'+detNoticeD01Msg;
             break;
         }
  
         System.out.println(hdrDetNoticeMsg);
                                
         SoapClient soapClient = new SoapClient();                   
         try
         {
         //Pass the Header Notice and Detail Notice to third Party
             soapResponse = soapClient.processT24Request(hdrDetNoticeMsg);
             //soapResponse = "TAMILPROCESSING200";
                
         //Update the Request Message and Error Flag fields in EB.BCI.UPDATE.ENGAGEONE.DETAILS table     
             if(!soapResponse.equals(""))
             {                                             
                 try 
                 {
                     bciUpdEngageoneDetsRec.setRequestMessage(hdrDetNoticeMsg);                     
                         
                 //For successful Response, Update the field ERROR.FLAG as No
                     if((soapResponse.contains("PROCESSING") == true) && (soapResponse.contains("200") == true))
                     {                                                  
                         bciUpdEngageoneDetsRec.setErrorFlag("No");                                                
                     }                    
                         
                 //For Failed Response, Update the field ERROR.FLAG as Yes
                     if((soapResponse.contains("ERROR") == true) && (soapResponse.contains("200") == true))
                     {                        
                         bciUpdEngageoneDetsRec.setErrorFlag("Yes");                                                                          
                     }  
                         
                     bciUpdEngageoneDetsTable.write(bciUpdEngageoneDetsId, bciUpdEngageoneDetsRec);
                 }
                 catch (Exception bciUpdEngErr) 
                 {
                     bciUpdEngErr.getMessage();   
                 }                                       
             } 
         }
             
         catch (IOException resErr)        
         {
             return;
         }              
       }   
    }
 
    
  //*----------------------Format the Rate field values (15 fixed Length)-----------------------------*//
    
    public String formatRate(String rateVal){
      
        String c1 = "";
        if(rateVal.equals(""))
        {
            c1 = StringUtils.leftPad(rateVal, 15, "0");
        }else
        {        
            if((rateVal.indexOf("-") != -1))
            {
                rateVal = rateVal.substring(1);
            }
            
            if((rateVal.indexOf(".") == -1))
            {
                rateVal = rateVal+".0";
            }
            
            String a1 = rateVal.split("\\.")[0];
            a1 = StringUtils.leftPad(a1, 9, "0");
    
            String b1 = rateVal.split("\\.")[1];
            b1 = StringUtils.rightPad(b1, 6, "0");
    
            c1 = a1+b1;
            if(c1.length() > 15)
            {
                c1 = c1.substring(0, 15);
            }
        }
        return c1;
    }
    
 //*-----------------------Format the Amount field values (22 fixed Length)-----------------------------*//
    
    public String formatAmt(String amtVal){
        
        String c2 = "";

        if(amtVal.equals(""))
        {
            c2 = StringUtils.leftPad(amtVal, 22, "0");
        }else
        {         
            if((amtVal.indexOf("-") != -1))
            {
                amtVal = amtVal.substring(1);
            }
            
            if((amtVal.indexOf(".") == -1))
            {
                amtVal = amtVal+".0";
            }
            
            String a2 = amtVal.split("\\.")[0];
            a2 = StringUtils.leftPad(a2, 20, "0");
    
            String b2 = amtVal.split("\\.")[1];
            b2 = StringUtils.rightPad(b2, 2, "0");

            c2 = a2+b2; 
            if(c2.length() > 22)
            {
                c2 = c2.substring(0, 22);
            }
        }
        return c2;
     } 
   
//*------------Get Payment Frequency Enrichment, Annual Loan Principal Count and Annual loan Interest Count ------------------------------------------*//
    
    public String paymentFreqCls(String paymentFreqVal){
        
        String frequency = "";   
            
        if(!paymentFreqVal.equals(""))
        {
           String[] payFrequenyList = paymentFreqVal.split(" ", 5);             
           for (String payFrequeny : payFrequenyList)
           {
               String payFreqTerm = payFrequeny.substring(2, 3);
               String payFreqNum = payFrequeny.substring(1, 2);
               
               if(!payFreqNum.equals("0"))
               {
                   switch(payFreqTerm)
                   {
                       case "Y":                             //*For Yearly Frequency      
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "Anual";  
                           }else
                           {
                               frequency = "Cada "+payFreqNum+" Anos";
                           }                                                                              
                           break;
                           
    
                       case "M":                            //*For Monthly Frequency         
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "Mensual";  
                           }else
                           {
                               frequency = "Cada "+payFreqNum+" Meses";
                           }
                           break;
                           
                                                                             
                       case "W":                           //*For Weekly Frequency  
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "Semanal";  
                           }else
                           {
                               frequency = "Cada "+payFreqNum+" Semanas";
                           }
                           break;
                           
                         
                       case "D":                          //*For daily Frequency  
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "Diario";  
                           }else 
                           {
                               frequency = "Cada "+payFreqNum+" Dias";
                           }                      
                           break;
                           
                           
                       case "F":                         //*For Fortnight Frequency  
                           if(payFreqNum.equals("1"))
                           {
                             frequency = "QUINCENAL";  
                           }else
                           {
                               frequency = "Cada "+payFreqNum+" QUINCENAS";
                           }                        
                           break;
                   }                
                   break;  
               }
           }
        }
        return frequency;
    } 
}
