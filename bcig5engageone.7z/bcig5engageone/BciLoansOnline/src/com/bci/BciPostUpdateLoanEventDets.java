package com.bci;

import java.util.ArrayList;
import java.util.List;
import com.temenos.api.TDate;
import com.temenos.api.TStructure;
import com.temenos.api.exceptions.T24IOException;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentDueType;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentMethod;
import com.temenos.t24.api.complex.aa.contractapi.RepaymentSchedule;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EventCodeClass;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsTable;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueDateClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueTypeClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.EbBciUpdateScheduleProjectorRecord;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.EbBciUpdateScheduleProjectorTable;

/**
*
*----------------------------------------------------------------------------------------------------------------
* Description           : Update a record in EB.BCI.UPDATE.ENGAGEONE.DETAILS table
* Developed By          : Preethi I,Techmill Technologies
* Development Reference : BCI_G5_IDD051_Interface_Prestamos_Online_Reportes
* Attached To           : ACTIVITY.API >LOANS
* Attached As           : Post Routine
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)       
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/

public class BciPostUpdateLoanEventDets extends ActivityLifecycle {

    @Override
    public void postCoreTableUpdate(AaAccountDetailsRecord accountDetailRecord,
            AaArrangementActivityRecord arrangementActivityRecord, ArrangementContext arrangementContext,
            AaArrangementRecord arrangementRecord, AaArrangementActivityRecord masterActivityRecord,
            TStructure productPropertyRecord, AaProductCatalogRecord productRecord, TStructure record,
            List<TransactionData> transactionData, List<TStructure> transactionRecord) {
        
         String currAction =  arrangementContext.getActivityStatus().toString();
         if(currAction.equals("AUTH"))
         {
             String currActivityId = arrangementContext.getCurrentActivity().toString();
             DataAccess da = new DataAccess(this);
            
             int bciEngageoneIntRepParamRecFlag = 0;
             String eventCode = "";
             String bciUpdEngageoneDetsId = "";
             String operationNo  = "";
             String aaaId = "";
             String aaStartDate = "";
             
       //Get the fields EVENT.CODE from parameter table            
            EbBciEngageoneIntRepParamRecord bciEngageoneIntRepParamRec = null;  
             
            try
            {        
                bciEngageoneIntRepParamRec = new EbBciEngageoneIntRepParamRecord(da.getRecord("EB.BCI.ENGAGEONE.INT.REP.PARAM", "LOAN"));              
            }
            catch(Exception e1)
            {
                bciEngageoneIntRepParamRecFlag = 1;
            }
            
            if(bciEngageoneIntRepParamRecFlag == 0)
            {
                 List<EventCodeClass> eventCodeClsList = bciEngageoneIntRepParamRec.getEventCode();
                 
                 for(EventCodeClass eventCodeList : eventCodeClsList)
                 {             
                     String actvityNameList = eventCodeList.getActivityName().toString();
                     if(actvityNameList.contains(currActivityId))
                     {
                         eventCode = eventCodeList.getEventCode().getValue();
                         break;
                     }                    
                 }
            }      
             
        //Get the fields ARRANGMENT and AAA Id          
             operationNo = arrangementActivityRecord.getArrangement().getValue(); 
             aaaId = arrangementContext.getArrangementActivityId();           

             
  //----------------------- Write a record in EB.BCI.UPDATE.ENGAGEONE.DETAILS table --------------------------------//
             
             EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetsRec = new EbBciUpdateEngageoneDetailsRecord(this);        
             EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetsTable= new EbBciUpdateEngageoneDetailsTable(this);
             
             bciUpdEngageoneDetsId = operationNo+"-"+aaaId+"-"+eventCode;
             
             bciUpdEngageoneDetsRec.setArragementId(operationNo);
             bciUpdEngageoneDetsRec.setEventCode(eventCode);
             bciUpdEngageoneDetsRec.setActivityName(currActivityId);
             
             try
             {
                 bciUpdEngageoneDetsTable.write(bciUpdEngageoneDetsId, bciUpdEngageoneDetsRec);
             }
            
             catch(Exception bciUpdEngageoneDetsErr)
             {
                 bciUpdEngageoneDetsErr.getMessage();
             }    
             
             
     //----------------------- Update the AA.SCHEDULE.PROJECTOR api values to local table EB.BCI.UPDATE.SCHEDULE.PROJECTOR --------------------------------//
             
             Contract contract = new Contract(this);
             EbBciUpdateScheduleProjectorTable schProjTable = new EbBciUpdateScheduleProjectorTable(this);            
             EbBciUpdateScheduleProjectorRecord scheduleRec = new EbBciUpdateScheduleProjectorRecord();
             String scheduleProjectorRecId = bciUpdEngageoneDetsId;

             contract.setContractId(operationNo);            
             try
             {
                 aaStartDate = contract.getContract().getStartDate().getValue();
                 TDate startDate = new TDate(aaStartDate);
                 TDate endDate = contract.getMaturityDate();   
                 
                 List<RepaymentSchedule> repaymentScheduleList = contract.getRepaymentSchedule(startDate, endDate);
                 
                 int i = 0;
                 for(RepaymentSchedule repaymentSchedule :repaymentScheduleList)              
                 {
                     DueDateClass dueDateCls = new DueDateClass();
                     dueDateCls.setDueDate(repaymentSchedule.getDueDate().get());
                     dueDateCls.setDueOutstandingBalance(repaymentSchedule.getDueOutstandingBalance().get());
                     
                     List<RepaymentDueType> repayDueTypeClsList = new ArrayList<RepaymentDueType>();
                     repayDueTypeClsList = repaymentSchedule.getRepaymentDueType();
                     int j = 0;
                     for(RepaymentDueType repayDueTypeCls : repayDueTypeClsList)
                     {
                         DueTypeClass dueTypeCls = new DueTypeClass();
                         dueTypeCls.setDueType(repayDueTypeCls.getDueType());
                         dueTypeCls.setDueTypeAmount(repayDueTypeCls.getDueTypeAmount().get());
                         
                         String repayduemethod = "";
                         String repayDueprop = "";
                         String repayDuePropAmt = "";
                         List<RepaymentMethod> repayMethodClsList = new ArrayList<RepaymentMethod>();
                         repayMethodClsList = repayDueTypeCls.getRepaymentMethod();
                         
                         int k = 1;
                         for(RepaymentMethod repayMethodCls : repayMethodClsList)        //Extract Repayment Method value and make it as String
                         {
                             String dueMethodStr = "";
                             String DuePropertyStr = "";
                             String DuePropertyAmountStr = "";
                             
                             dueMethodStr = repayMethodCls.getDueMethod();
                             DuePropertyStr = repayMethodCls.getDueProperty();
                             DuePropertyAmountStr = repayMethodCls.getDuePropertyAmount();
                             
                             if(k == repayMethodClsList.size()) 
                             {
                                 repayduemethod = repayduemethod + dueMethodStr;
                                 repayDueprop = repayDueprop + DuePropertyStr;
                                 repayDuePropAmt = repayDuePropAmt + DuePropertyAmountStr;
                             }
                             else
                             {
                                 repayduemethod = repayduemethod + dueMethodStr + '/';        //Split the Due method, Due property and Due property amount by given '/'
                                 repayDueprop = repayDueprop + DuePropertyStr + '/';
                                 repayDuePropAmt = repayDuePropAmt + DuePropertyAmountStr + "/";
                             }                           
                             k++;
                         }
                         
                         dueTypeCls.setDueMethod(repayduemethod);
                         dueTypeCls.setDueProperty(repayDueprop);
                         dueTypeCls.setDuePropertyAmount(repayDuePropAmt);           
                         
                         dueDateCls.setDueType(dueTypeCls,j);         //Set Due Type, Due type amount and Repayment Method
                         j++;
                     }                 
                    
                     scheduleRec.setDueDate(dueDateCls,i); 
                     i++;
                 }
                 
                 try
                 {
                    schProjTable.write(scheduleProjectorRecId, scheduleRec);
                 } 
                 catch (T24IOException schProjTableErr)
                 {
                     schProjTableErr.getMessage();
                 }
                 
             }
             catch(Exception scheduleRecErr)
             {
                 scheduleRecErr.getMessage();
             }    
         }                              
    }
}
