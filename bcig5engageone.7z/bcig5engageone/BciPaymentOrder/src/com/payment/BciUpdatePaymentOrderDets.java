package com.payment;

import java.text.SimpleDateFormat;
import java.util.List;

import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.CommonData;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.Flags;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.PaymentApplicationUpdate;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.PaymentContext;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.StatusAction;
import com.temenos.t24.api.hook.payments.PaymentLifecycle;
import com.temenos.t24.api.records.aaactivityhistory.AaActivityHistoryRecord;
import com.temenos.t24.api.records.aaactivityhistory.ActivityRefClass;
import com.temenos.t24.api.records.aaactivityhistory.EffectiveDateClass;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.t24.api.records.aaprddesofficers.AaPrdDesOfficersRecord;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.category.CategoryRecord;
import com.temenos.t24.api.records.company.CompanyRecord;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.customer.LegalIdClass;
import com.temenos.t24.api.records.customer.Phone1Class;
import com.temenos.t24.api.records.deptacctofficer.DeptAcctOfficerRecord;
import com.temenos.t24.api.records.ebqueriesanswers.EbQueriesAnswersRecord;
import com.temenos.t24.api.records.paymentorder.ChargeTypeClass;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.poragreementandadvice.PorAgreementAndAdviceRecord;
import com.temenos.t24.api.records.poraudittrail.PorAuditTrailRecord;
import com.temenos.t24.api.records.porpostingandconfirmation.PorPostingAndConfirmationRecord;
import com.temenos.t24.api.records.porsupplementaryinfo.MainOrChargeAccountTypeClass;
import com.temenos.t24.api.records.porsupplementaryinfo.PartyTypeClass;
import com.temenos.t24.api.records.porsupplementaryinfo.PorSupplementaryInfoRecord;
import com.temenos.t24.api.records.portransaction.PorTransactionRecord;
import com.temenos.t24.api.records.ppcompanyproperties.PpCompanyPropertiesRecord;
import com.temenos.t24.api.records.pporderentry.PpOrderEntryRecord;
import com.temenos.t24.api.records.pptbictable.PptBictableRecord;
import com.temenos.t24.api.records.stmtentry.StmtEntryRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsTable;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import com.temenos.t24.api.records.customer.ContactTypeClass;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EventCodeClass;
import com.techmill.integration.SoapClient;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author Tamizharasi G 
 * 
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *Description           : Fetch inward and outward transfer details and form as string and passing into engageone, once reach engageone successfully generate a reports based on the event codes N0002,N0003,N0004,N0005,N0008
 *Developed By          : Tamizharasi G , Techmill Technologies
 *Development Reference : IRD - 050
 *Attached To           : PP.STATUS.ACTION
 *Attached as           : 
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *  M O D I F I C A T I O N S
 * ***************************        
 *-----------------------------------------------------------------------------------------------------------------
 * Defect Reference       Modified By                    Date of Change        Change Details
 * (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
 *-----------------------------------------------------------------------------------------------------------------
 * XXXX                   <<name of modifier>>                                 <<modification details goes here>>
 *-----------------------------------------------------------------------------------------------------------------
 * Include files
 *-----------------------------------------------------------------------------------------------------------------
 *   
 */ 
public class BciUpdatePaymentOrderDets extends PaymentLifecycle {

    @Override
    public void updateRequestToExternalCoreSystem(StatusAction arg0, PorTransactionRecord arg1, PaymentContext arg2,
            PorSupplementaryInfoRecord arg3, PorAgreementAndAdviceRecord arg4, PorPostingAndConfirmationRecord arg5,
            PorAuditTrailRecord arg6, PpCompanyPropertiesRecord arg7, CommonData arg8, EbQueriesAnswersRecord arg9,
            Flags arg10, PaymentApplicationUpdate arg11) {
        // TODO Auto-generated method stub

               
        DataAccess fRead = new DataAccess(this);
        AccountRecord acRec = new AccountRecord(this);
        Session se = new Session(this);
        CustomerRecord cusRec = new CustomerRecord(this);
        PpOrderEntryRecord ppRec = new PpOrderEntryRecord(this);
        BciEnglishWordstoSpanish bciSpanish = new BciEnglishWordstoSpanish();
        EbBciEngageoneIntRepParamRecord bciEngageoneIntRepParamRec = null;
        PpOrderEntryRecord ppOderRec = null;

        int bciEngageoneIntRepParamRecFlag = 0;
        double payIntAmt = 0;
        int cusFlag = 0;
        int cmpyFlag = 0;
        double chrgeIntAmount = 0;
        int poFlag = 0;
        int acFlag = 0;
        int creacFlag = 0;
        int creCusFlag = 0;
        int debCusFlag = 0;
        int categFlag = 0;
        String creditCustomer = "";
        String paymentOrderId = "";
        String payOrdPrd = "";
        String eventCode = "";
        String hdrCode = "";
        String detCode = "";
        String ordCus = "";
        String debAcct = "";
        String debCcy = "";
        String payAmt = "";
        String creAcct = "";
        String benName = "";
        String benIban = "";
        String ordCusBic = "";
        String DebAcctIban = "";
        String benAcNo = "";
        String eventDate = "";
        String eventTime = "";
        String operationNo = "";
        String amtWrd = "";
        String ftNum = "";
        String name = "";
        String legalID = "";
        String phoneNo = "";
        String eMail = "";
        String captureDate = "";
        String hdrEventTime = "";
        String companyName = "";
        String bank = "";
        String originAcNo = "";
        String destinationAcNo = "";
        String cmpy = "";
        String branchShrtName = "";
        String exeInformationEmail = "";
        String chequeNumber = "";
        String chrgCcy = "";
        String chrgAmt = "";
        String ccyTaxCharged = "";
        String bciCmisionCcy = "";
        String bciCmisionAmt = "";
        String ccyInterbankCommision = "";
        String transType = "";
        String channel = "";
        String totChrgCcy = "";
        String totAmtCharged = "";
        String ordExeDate = "";
        String paymentDt = "";
        String addInfo = "";
        String transferCmt = "";
        String typeOfExpense = "";
        String ordCustName = "";
        String address = "";
        String customerCommunication = "";
        String partyType = "";
        String timeVal = "";
        String approvedDtTime = "";
        String chargeccy = "";
        String chargeAmt = "";
        String chequeNo = "";
        String taxCollected = "";
        String taxCollect = "";
        String accountCode = "";
        String codeExecutive = "";
        String executiveName = "";
        String executiveEmail = "";
        String executiveTelephone = "";
        String CrEffRate = "";
        String DrEffRate = "";
        String treaRate = "";
        String debitBal = "";
        String codeProduct = "";
        String ccyCommisionCharged = "";
        String totCommissionExpenseCharged = "";
        String interbankCommisionAmt = "";
        String inComingMsgType = "";
        String hdrNoticeMsg = "";
        String detNoticeMsg = "";
        String hdrDetNoticeMsg = "";
        String soapResponse = "";
        String bciUpdActivityDetsId = "";
        String companyVal = "";
        String valOne = "";
        String valTwo = "";
        String arrId = "";
        String legacyVal = "";
        String decimalOne = "";
        String amtWrdOne = "";
        String decimalTwo = "";
        String amtWrdTwo = "";
        String creditCus = "";
        String debitCustomer = "";
        String creditClientId = "";
        String debitCurrency = "";
        String debMainAmt = "";
        String transactionCcy = "";
        double commisionAmt = 0;
        String actvityNameList = "";
        String destinationBank = "";
        String MainchrgAcType = "";
        String beneficiaryName = "";
        String source = "";
        String direction = "";
        String transfertype = "";
        String incomingMsgType = "";
        String outputChannel = "";
        String processDate ="";
        String bankVal = "";
        String oeId = "";
        String originAc = "";
        String debAcctName = "";
        String ftNumber = "";
        String selCmd = "";
        String bicCodeId = "";
        String bankValue = "";
        List<String> bankBicCodeList = new ArrayList<String>();
        List<String> selList = new ArrayList<String>();
        List<EffectiveDateClass> EffDtList = new ArrayList<EffectiveDateClass>();
        List<ActivityRefClass> ActivityRefList = new ArrayList<ActivityRefClass>();
        int mainAcCnt = 0;
        String chargeAmountOne = "";
        String chargeAmountTwo = "";
        String selCmdVal = "";
        int selCount = 0;
        String selValue = "";
        String debitChargeAmt = "";
        String debitChargeccy = "";
        String chargeCmisionAmt = "";
        String ArrId = "";
        double bcicmisionIntAmt = 0;
        String arrActId = "";
        String firstchildVal = "";
        String secChildVal = "";
        String stmtNo = "";
        String firstVal = "";
        String secVal = "";
        String StmtId = "";
        String Amount = "";
        String taxChargeAmt = "";
        String activityVal = "";
        String value1 = "";
        String actBnkId = "";
        String activity = "ACCOUNTS-DRAFT.DEBIT-ARRANGEMENT";
        String bnkNumber = "";
        String acCcy = "";
        String chargeLocAmt = "";
        String chrgeLocccy = "";
        
        // Get Payment order product
        
        inComingMsgType = arg1.getIncomingmessagetype().getValue();
        bnkNumber = arg1.getFtnumber().getValue();
        
        //get N0002 bci cmision amt
        try
        {
        chargeCmisionAmt = arg1.getPostingchargeamountdebitlcy().getValue();
        }
        catch(Exception e2)
        {
            
        }
              

                
        if (!inComingMsgType.equals("")) 
        {
            try  
           {
              payOrdPrd = inComingMsgType;
            } catch (Exception e9) {
                payOrdPrd = "";
            }
        }
                 
        // Get details for N0005
        
        source = arg1.getOriginatingsource().getValue();
        direction = arg1.getPaymentdirection().getValue();
        transfertype = arg1.getCtrbtrindicator().getValue();
        incomingMsgType = arg1.getIncomingmessagetype().getValue();
        outputChannel = arg1.getOutputchannel().getValue();
        bankVal = arg1.getCompanybic().getValue();
       
   
        
     // Select PPT.BICTABLE Record 
        
        if(!bankVal.equals(""))
        {
            try 
            {
              selCmd = "(WITH BICCode EQ "+bankVal+")";
              bankBicCodeList = fRead.selectRecords("","PPT.BICTABLE","",selCmd); 
              bicCodeId = bankBicCodeList.get(0).toString();
            }
           catch(Exception e1)
           {
           }
        }
        
        
      // Read PPT.BICTABLE Record
        PptBictableRecord bicRec = null;
        try
        {
            bicRec = new PptBictableRecord(fRead.getRecord("PPT.BICTABLE", bicCodeId));
            bankValue = bicRec.getFinancialinstitutionname().getValue();
        }
        catch(Exception e3)
        {
            bankValue = ""; 
        } 
        
       
        
        if(source.equals("OE") && direction.equals("I") && transfertype.equals("C"))
        {
            if(incomingMsgType.equals("RFCT") && outputChannel.equals("LEDGER"))
            {
                eventCode = "N0005";

            }
        }
        
        // Read param table
        
        try 
        {
            bciEngageoneIntRepParamRec = new EbBciEngageoneIntRepParamRecord(fRead.getRecord("EB.BCI.ENGAGEONE.INT.REP.PARAM", "TRANSFERS"));            
        } 
        
        catch (Exception e1)
        {
            
        }
                
        
     // Get the fields EVENT.CODE, HEADER.CODE and DETAIL.CODE from  parameter table
       try
        {
        if(eventCode.equals(""))
        {
      
        if (bciEngageoneIntRepParamRecFlag == 0)
        {
           List<EventCodeClass> eventCodeClsList = bciEngageoneIntRepParamRec.getEventCode();
                        
            for (EventCodeClass eventCodeList : eventCodeClsList)
            {
                actvityNameList = eventCodeList.getActivityName().toString();

                if (actvityNameList.contains(payOrdPrd))
                {
                    
                    eventCode = eventCodeList.getEventCode().getValue();

                    break;
                    
                }
            } 
            
            
        }
        
        }
        }
        catch(Exception e5)
        {
            bciEngageoneIntRepParamRecFlag = 1;

        }
        
                   
        if (bciEngageoneIntRepParamRecFlag == 0)
        {
            hdrCode = bciEngageoneIntRepParamRec.getHeaderCode(0).getValue();
            detCode = bciEngageoneIntRepParamRec.getDetailCode(0).getValue();
        }   
        

            

        if(!eventCode.equals("") && !eventCode.equals("N0004")) 
        {

        paymentOrderId = arg1.getFilereferenceincoming().getValue();
         
        eventDate = arg1.getDebitvaluedate().getValue();

        debAcct = arg1.getDebitmainaccount().getValue();

        creAcct = arg1.getCreditmainaccount().getValue();

        debCcy = arg1.getDebitmainaccountcurrencycode().getValue();
 
        payAmt = arg1.getTransactionamount().getValue();
        
        try
        {
        payIntAmt = Double.parseDouble(payAmt);
        }
        catch(Exception e2)
        {
              
        }
        
        debMainAmt = arg1.getDebitmainamount().getValue();

        ordCus = arg1.getDebitclientid().getValue();

        creditClientId = arg1.getCreditclientid().getValue();

        benIban = arg3.getCrditIbanAccNumber().getValue();

        ordCusBic = arg1.getCompanybic().getValue();

        DebAcctIban = arg3.getDebitIbanAccNumber().getValue();
        
        timeVal = arg1.getEntrydatetime().getValue();

        ordCustName = arg1.getDebitpartyline1().getValue();

        approvedDtTime = arg1.getApproveddatetime().getValue();

        transactionCcy = arg1.getTransactioncurrencycode().getValue();

        try
        {
            chargeccy = arg5.getChargePartyIndicator().get(0).getFeeCurrencyCode().getValue();
            chrgeLocccy = arg5.getChargePartyIndicator().get(0).getChargeAmountCurrency().getValue();
        } 
        catch (Exception e1) 
        {
            chargeccy = "";
        }

        try 
        {
            chargeAmt = arg5.getChargePartyIndicator().get(0).getChargeAmountFeeCurrency().getValue();
            chargeLocAmt = arg5.getChargePartyIndicator().get(0).getChargeAmountLocalCcy().getValue();
            
        } 
        catch (Exception e2)
        {
            chargeAmt = "";
        }
           
        taxCollect = arg1.getPercentagevatdebitchargeamnt().getValue();

        chequeNo = arg1.getChequenumber().getValue();
        

        if (!approvedDtTime.equals(""))
        {
            try 
            {
                eventTime = approvedDtTime.substring(8, 14);
            } 
            catch (Exception e3) 
            {
                eventTime = "";
            }
        }

        
        if (!paymentOrderId.equals(""))
        {
            try 
            {
                operationNo = paymentOrderId;
            } 
            catch (Exception e4) 
            {
                operationNo = "";
            }
        }


        if (!timeVal.equals("")) 
        {
            try 
            {
                ordExeDate = timeVal.substring(0, 8);
            } 
            catch (Exception e5)
            {
                ordExeDate = "";
            }
        }
        
        // Get debitacct name for N0005 & Arr id for N0006
        
        if(!debAcct.equals(""))
        {
            try
            {
                AccountRecord acRecval = new AccountRecord(fRead.getRecord("ACCOUNT", debAcct));
                debAcctName = acRecval.getShortTitle(0).getValue();
                ArrId = acRecval.getArrangementId().getValue();
                        
            }
            catch(Exception e5)
            {
                debAcctName = ""; 
            }
        }
        
        // Get Account currency using ArrId
        
        AaArrangementRecord aArec = null;
        try
        {
        aArec = new AaArrangementRecord(fRead.getRecord("AA.ARRANGEMENT", ArrId));
         acCcy = aArec.getCurrency().getValue();       
        }
       
        catch(Exception e6)
        {
            
        }
        
        // Get BenAco 

        if (!creAcct.equals(""))
        {
            try
            {
                benAcNo = creAcct;
            } 
            catch (Exception e6)
            {
                benAcNo = "";
            }
        }
        
        
        // Get ben name from POR.SUPPLEMENTRY.INFO 

        int partylen = 0;
        List<PartyTypeClass> partytypeList = arg3.getPartyType();
        
        try
        {
            partylen = partytypeList.size();
            for(int i=0;i<=partylen;i++)
            {
                
                try
                {
                    partyType = partytypeList.get(i).getPartyType().getValue();
                    
                } 
                catch (Exception e7) 
                {
                    partyType = "";
                }
                if (partyType.equals("CREDIT")) 
                {
                    try {
                        benName = partytypeList.get(i).getName().getValue();
                        } 
                    catch (Exception e8)
                    {
                        benName = "";
                    }
                    
                }
                
                if(!benName.equals(""))
                {
                    break;
                }
                
            }
        }
        catch(Exception e2)
        {
            
        }
        

        // N0005 - Get OE id from POR.SUPPLEMENTRY.INFO
        
        try
        {
           oeId = arg3.getOrderEntryId(0).getValue();
           ppRec = new PpOrderEntryRecord(fRead.getRecord("PP.ORDER.ENTRY", oeId));
           originAc = ppRec.getOrderinginstaccount().getValue();
        }
        catch(Exception e2)
        {
            originAc = "";
        }
                
        // Get Beneficiary name for CCETRANS - N0002
        
        try
        {
        
        List<MainOrChargeAccountTypeClass> MainAcTypeList = arg3.getMainOrChargeAccountType();  
        
        mainAcCnt = MainAcTypeList.size();
        
        for(int i=0; i<mainAcCnt;i++)
        {
            MainchrgAcType = MainAcTypeList.get(i).getMainOrChargeAccountType().getValue();
            
            if(MainchrgAcType.equals("C"))
            {
                beneficiaryName = MainAcTypeList.get(i).getCustomerName().getValue();
                
                break;
            }
            
        }
        }
        catch(Exception e4)
        {
            
        }
                        
            // Get ordering customer number, debit account, debit currency from PO application
            PaymentOrderRecord poRec = new PaymentOrderRecord(this);
            try
            {
                poRec = new PaymentOrderRecord(fRead.getRecord("PAYMENT.ORDER", operationNo));
                 ftNum = poRec.getPaymentSystemId().getValue();
                addInfo = poRec.getAdditionalInfo().toString();
                chargeAmountOne = poRec.getChargeType().get(0).getChargeAmount().getValue();
                chargeAmountTwo = poRec.getChargeType().get(1).getChargeAmount().getValue();
            } 
            catch (Exception e3) 
            {
                
            }
            
            
            // Get Interbank commision amt from Payment Order
            
            if(eventCode.equals("N0002"))
            {
                try
                {
                //interbankCommisionAmt = poRec.getLocalRefField("L.CCI.COMM.AMT").getValue();
                interbankCommisionAmt = chargeAmountTwo;
                commisionAmt = Double.parseDouble(interbankCommisionAmt);
                }
                catch(Exception e18)
                {
                    interbankCommisionAmt = "";
                }
                
            }
            
            // Get Destination bank from Payment order
            
            try
            {
                destinationBank = poRec.getLocalRefField("L.NAME.DRAWN.BNK").getValue();
            }
            catch(Exception e19)
            {
                destinationBank = "";
            }
            
            
            // Formatting intercommisionamt
            
                
                if (interbankCommisionAmt.equals("")) 
                {
                    interbankCommisionAmt = StringUtils.leftPad(interbankCommisionAmt, 22, "0");
                }
                else 
                {
                    if ((interbankCommisionAmt.indexOf(".") == -1)) 
                    {
                        interbankCommisionAmt = interbankCommisionAmt + ".0";
                        interbankCommisionAmt = formatAmount(interbankCommisionAmt); // Calling Method
                    }
                    else
                    {
                        interbankCommisionAmt = formatAmount(interbankCommisionAmt); // Calling Method
                    }
                }
                

            // Get amount in words for PAYMENT.AMOUNT field value

            if (!payAmt.equals("") && (payAmt.indexOf(".") == -1))
            {
                try
                {
                    amtWrd = bciSpanish.convert(Long.parseLong(payAmt));
                } 
                catch (Exception amte)
                {

                    amtWrd = "";
                }
            }
            else 
            {
                if (!payAmt.equals("")) 
                {
                    decimalOne = payAmt.split("\\.")[0];
                    amtWrdOne = bciSpanish.convert(Long.parseLong(decimalOne));
                    decimalTwo = payAmt.split("\\.")[1];
                    amtWrdTwo = bciSpanish.convert(Long.parseLong(decimalTwo));
                    amtWrd = amtWrdOne + " con " + amtWrdTwo;
                }

            }

            
            // Formatting payment amount
            
          if(!eventCode.equals("N0008") || eventCode.equals("N0005"))
          {

                if (payAmt.equals("")) 
                {
                    payAmt = StringUtils.leftPad(payAmt, 22, "0");
                }
                else 
                {
                    if ((payAmt.indexOf(".") == -1)) 
                    {
                        payAmt = payAmt + ".0";
                        payAmt = formatAmount(payAmt); // Calling Method
                    }
                    else
                    {
                        payAmt = formatAmount(payAmt); // Calling Method
                    }
                }
          }
          else           
          {
              payAmt = debMainAmt;
              
              if (payAmt.equals("")) 
              {
                  payAmt = StringUtils.leftPad(payAmt, 22, "0");
              }
              else 
              {
                  if ((payAmt.indexOf(".") == -1)) 
                  {
                      payAmt = payAmt + ".0";
                      payAmt = formatAmount(payAmt); // Calling Method
                  }
                  else
                  {
                      payAmt = formatAmount(payAmt); // Calling Method
                  }
              }
              
          }
          
          
          
       // Get legalId,phone and email from customer application
          if(eventCode.equals("N0005"))
          {
              try 
              {
                  cusRec = new CustomerRecord(fRead.getRecord("CUSTOMER", creditClientId));
              }
    
              catch (Exception e1) 
              {
                  cusFlag = 1;
              }
    
              if (cusFlag == 0)
              {
    
                  name = cusRec.getName1().get(0).getValue();
                  
               // Get the field CONTACT.DATA from customer table
                  List<ContactTypeClass> contactTypecList = cusRec.getContactType();
                  if (!contactTypecList.isEmpty()) 
                  {
                      try 
                      {
                          customerCommunication = contactTypecList.get(0).getContactData().getValue();
                      } catch (Exception e10)
                      {
                          customerCommunication = "";
                      }
                  }
              }
          }
          
          

            // Get legalId,phone and email from customer application
          
         
            try {
                cusRec = new CustomerRecord(fRead.getRecord("CUSTOMER", ordCus));
            }

            catch (Exception e1) 
            {
                cusFlag = 1;
            }

            if (cusFlag == 0)
            {

                List<LegalIdClass> legalIdlist = cusRec.getLegalId();

                if (!legalIdlist.isEmpty())
                {
                    try
                    {
                        legalID = legalIdlist.get(0).getLegalId().getValue();
                    } 
                    catch (Exception e8) 
                    {
                        legalID = "";
                    }

                }
                List<Phone1Class> phoneList = cusRec.getPhone1();
                if (!phoneList.isEmpty())
                {
                    try 
                    {
                        phoneNo = phoneList.get(0).getPhone1().getValue();
                        eMail = phoneList.get(0).getEmail1().getValue();
                    } 
                    catch (Exception e9) 
                    {
                        phoneNo = "";
                        eMail = "";
                    }

                }

                // Get the field CONTACT.DATA and customer name from customer table
                
                if(!eventCode.equals("N0005"))
                {
                     name = cusRec.getName1().get(0).getValue();
                    
                    List<ContactTypeClass> contactTypecList = cusRec.getContactType();
                    if (!contactTypecList.isEmpty()) 
                    {
                        try 
                        {
                            customerCommunication = contactTypecList.get(0).getContactData().getValue();
                        } catch (Exception e10)
                        {
                            customerCommunication = "";
                        }
                    }
                }
            }
          
          
            // Get event date in DD/MM/YYYY format
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            try 
            {
                Date parseaDate2 = new SimpleDateFormat("yyyyMMdd").parse(eventDate); // Format the date from YYYMMDD to DD/MM/YYYY 
                                                                                                                                                               
                captureDate = formatter.format(parseaDate2);
            } 
            catch (ParseException e6)
            {
                captureDate = "";
            }

            // get event time
            try 
            {
                hdrEventTime = eventTime.substring(6, 8) + ":" + eventTime.substring(8, 10) + ":00";
            } 
            catch (Exception e2)
            {
                hdrEventTime = "";
            }

            // get Companyname

            if (eventCode.equals("N0003") || eventCode.equals("N0008")) 
            {
                if (!ordCustName.equals("")) 
                {
                    companyName = ordCustName;
                } 
                else
                {
                    companyName = "";
                }
            }
            else 
            {
                if (eventCode.equals("N0006") || eventCode.equals("N0004"))
                 {
                    if (!benName.equals("")) 
                    {
                        companyName = benName;
                    } 
                    else 
                    {
                        companyName = "";
                    }

                }
                else
                {
                    if(eventCode.equals("N0002"))
                    {
                        if(payOrdPrd.equals("CCETRANS"))
                        {
                            if (!beneficiaryName.equals("")) 
                            {
                                companyName = beneficiaryName;
                            } 
                            else 
                            {
                                companyName = "";
                            }
                        }
                        else
                        {
                            try
                            {
                            acRec = new AccountRecord(fRead.getRecord("ACCOUNT", creAcct));
                            }
                            catch(Exception e18)
                            {
                                creacFlag = 1;
                            }
                            if(creacFlag == 0)
                            {
                                creditCus = acRec.getCustomer().getValue();
                                cusRec = new CustomerRecord(fRead.getRecord("CUSTOMER", creditCus));
                                try
                                {
                                companyName = cusRec.getName1().get(0).getValue();  
                                }
                                catch(Exception e21)
                                {
                                    companyName = "";
                                }
                                
                            }
                            
                         }
                        
                       }
                  }
                

            }
            
            // Get company name for N0005
            
            if(!debAcctName.equals("") && eventCode.equals("N0005"))
            {
                companyName = debAcctName;
            }

            
            // get transfer type
            
            switch (eventCode) 
            {
            case "N0002":
                if(payOrdPrd.equals("CCETRANS"))
                {
                    transType = "CCE Transfer";
                }
                else
                {
                    try
                    {
                    acRec = new AccountRecord(fRead.getRecord("ACCOUNT", creAcct));
                    }
                    catch(Exception e18)
                    {
                        creCusFlag = 1;
                    }
                    if(creCusFlag == 0)
                    {
                        creditCustomer = acRec.getCustomer().getValue();
                    }
                    
                    // get debit customer
                    
                    try
                    {
                    acRec = new AccountRecord(fRead.getRecord("ACCOUNT", debAcct));
                    }
                    catch(Exception e18)
                    {
                        debCusFlag = 1;
                    }
                    if(debCusFlag == 0)
                    {
                        debitCustomer = acRec.getCustomer().getValue();
                    }
                    
                        if(creditCustomer.equals(debitCustomer))
                        {
                            transType = "Mismo Titular";
                        }
                        else
                        {
                            transType = "Tercero";
                        }
                }
                break;
            case "N0003":
                transType = "CCE Transfer";
            default:
                transType = "";
                
            }
            
            // Get channel values based on conditions

            switch (eventCode) 
            {
            case "N0002":
                if(payOrdPrd.equals("CCETRANS"))
                {
                   channel = "CCE Transfer";
                }
                else
                {
                    channel = "Mismo banco";
                }
                break;
            case "N0003":
                channel = "CCE";
                break;
            case "N0008":
                channel = "Mismo banco";
                break;
            default:
                channel = " ";
            }
            
            // Get Bank

            switch (eventCode) 
            {
            case "N0008":
                bank = "BCI";
                break;
            case "N0006":
                bank = "BANCO DE CREDITO E INVERSIONES";
                break;
            case "N0002":
                if(payOrdPrd.equals("CCETRANS"))
                {
                    if(!destinationBank.equals(""))
                    {
                    bank = destinationBank;
                    } 
                }
                else
                {
                    bank = "BANCO DE CREDITO E INVERSIONES";
                }
                    break;
                    
            case "N0004":
                if(!destinationBank.equals(""))
                {
                bank = destinationBank;
                }
                else if(bank.equals(""))
                {
                    bank = "BANCO DE CREDITO E INVERSIONES"; 
                }
                break;
            case "N0003":
                if (!DebAcctIban.equals("")) 
                {
                    bank = DebAcctIban;
                } 
                break;
            case "N0005":
                if(!bankValue.equals(""))
                {
                    bank =  bankValue;
                }
                break;
              default:
                  bank = "";
            }         
            
            // Origin Acc Number
            if (!debAcct.equals("") && !eventCode.equals("N0005"))
            {
                originAcNo = debAcct;
            } 
            else 
            {
                originAcNo = originAc; // this is for only N0005
            }
            

            // destination Acc Number
            switch (eventCode) 
            {
            case "N0008":
                if(!debAcct.equals(""))
                {
                destinationAcNo = debAcct;
                }
                break;
            case "N0006":
                if(!creAcct.equals(""))
                {
                destinationAcNo = creAcct;
                }
                break;
            case "N0005":
                if(!creAcct.equals(""))
                {
                destinationAcNo = creAcct;
                }
                break;
            default:
                if(!benAcNo.equals(""))
                {
                destinationAcNo = benAcNo;
                }
            }
            
     
            // Get Company and fetch SHORT.NAME
            companyVal = "BCI";
            cmpy = se.getCompanyId();

            CompanyRecord cmpyRec = new CompanyRecord(this);

            try 
            {
                cmpyRec = new CompanyRecord(fRead.getRecord("COMPANY", cmpy));
            }
            catch (Exception e2)
            {
                cmpyFlag = 1;
            }

            if (cmpyFlag == 0) 
            {

                branchShrtName = cmpyRec.getCompanyName(0).getValue();
            }

            // get executive contact information Email

            exeInformationEmail = "";

            // Currency commision and expenses charged

            if (eventCode.equals("N0004") || eventCode.equals("N0006") || eventCode.equals("N0005"))
            {
                try 
                {
                    chrgCcy = chargeccy;
                    chrgAmt = chargeAmt;
                    try
                    {
                    chrgeIntAmount = Double.parseDouble(chrgAmt);
                    }
                    catch(Exception e34)
                    {
                        
                    }
                    ccyCommisionCharged = chrgCcy;
                    totCommissionExpenseCharged = chrgAmt;
                    
                } 
                catch (Exception e12) 
                {
                    chrgCcy = "";
                    chrgAmt = "";
                    ccyCommisionCharged = "";
                   

                }
                
                // totcommision expense charged - N0006
               if(eventCode.equals("N0006"))
               {
                    try
                    {
                        if(acCcy.equals(chargeccy))
                        {
                            totCommissionExpenseCharged = chargeAmt;
                        }
                        else
                        {
                            totCommissionExpenseCharged = chargeLocAmt;
                        }
                    }
                    catch(Exception e6)
                    {
                        totCommissionExpenseCharged = "";
                    }
               }
                

                // Formatting totCommissionExpenseCharged

                if (totCommissionExpenseCharged.equals(""))
                {
                    totCommissionExpenseCharged = StringUtils.leftPad(totCommissionExpenseCharged, 22, "0");
                } 
                else 
                {
                    if ((totCommissionExpenseCharged.indexOf(".") == -1))
                    {
                        totCommissionExpenseCharged = totCommissionExpenseCharged + ".0";
                        totCommissionExpenseCharged = formatAmount(totCommissionExpenseCharged); // Calling
                                                                                                 // Method
                    }
                    else 
                    {
                        totCommissionExpenseCharged = formatAmount(totCommissionExpenseCharged); // Calling
                                                                                                 // Method
                    }
                }

            }
            else 
            {
                chrgCcy = "";
                chrgAmt = "";
                ccyCommisionCharged = "";
                totCommissionExpenseCharged = "";
                totCommissionExpenseCharged = StringUtils.leftPad(totCommissionExpenseCharged, 22, "0");
            }
            
            // For tax charged - N0006
         if(eventCode.equals("N0006"))
         {
            AaActivityHistoryRecord AaactivityRec = null;
            try
            {
            AaactivityRec = new AaActivityHistoryRecord(fRead.getRecord("AA.ACTIVITY.HISTORY", ArrId));
            EffDtList = AaactivityRec.getEffectiveDate();
            
            
                for(EffectiveDateClass EffectiveVal:EffDtList)
                {
                   
                    ActivityRefList = EffectiveVal.getActivityRef();
                    
                    
                       for(ActivityRefClass ActivityRefVal:ActivityRefList)
                       {

                           activityVal = ActivityRefVal.getActivity().getValue();
                              actBnkId = ActivityRefVal.getContractId().getValue();
                                   try
                                   {
                                   String[] value = actBnkId.split("\\\\");
                                    value1 = value[0];
                                   }
                                   catch(Exception e4)
                                   {
                                       
                                   }

                                if(activityVal.equals(activity) && bnkNumber.equals(value1))
                                {
                                     arrActId = ActivityRefVal.getActivityRef().getValue();
                                     
                                    break;
                                }
                       }
                    
                    
                }
            }
            catch(Exception e11)
            {
                arrActId = "";
            }
                        
       // Read first level of AAA to fetch child activity
            
            try
            {
                AaArrangementActivityRecord AaaRec = null;
                
                AaaRec = new AaArrangementActivityRecord(fRead.getRecord("AA.ARRANGEMENT.ACTIVITY", arrActId));
                
                   firstchildVal = AaaRec.getChildActivity().get(0).getValue();    
            }
            catch(Exception e12)
            {
                
            }
            
            
            // Read second level of AAA to fetch child activity
            
            try
            {
                AaArrangementActivityRecord AaaRecVal = null;
                
                AaaRecVal = new AaArrangementActivityRecord(fRead.getRecord("AA.ARRANGEMENT.ACTIVITY", firstchildVal));

                   secChildVal = AaaRecVal.getChildActivity().get(0).getValue();
            }
            catch(Exception e13)
            {
                
            }
            
            
            // Read third level of AAA to read stmt id's
            
            try
            {
            AaArrangementActivityRecord AaaRecValue = null;
            
            AaaRecValue = new AaArrangementActivityRecord(fRead.getRecord("AA.ARRANGEMENT.ACTIVITY", secChildVal));
            
               stmtNo = AaaRecValue.getStmtNos().get(0).getValue();
            }
            catch(Exception e13)
            {
                
            }
            
          
            
            // To form STMT.ENTRY ID
            
            try
            {
                String[] wholeval = stmtNo.split("[.]", 0);
                
                 firstVal = wholeval[0];
                 secVal = wholeval[1];
        
                if(secVal.equals("00"))
                {
                    StmtId = firstVal+"."+"000001";
                }
                else
                {
                    StmtId = firstVal+"."+secVal+"0001";
                }
            }
            catch(Exception e14)
            {
                
            }

            
           //To read STMT.ENTRY app using stmt.no
            
            try
            {
                StmtEntryRecord stmtEntRec = null;
                
                stmtEntRec = new StmtEntryRecord(fRead.getRecord("STMT.ENTRY", StmtId));
                 
                
                
                
                if(acCcy.equals("PEN"))
                {
                    Amount = stmtEntRec.getAmountLcy().getValue();
                }
                else
                {
                    Amount = stmtEntRec.getAmountFcy().getValue();
                }
 
            }            
            
            catch(Exception e15)
            {
                
            }
            
            
            try
            {
             taxChargeAmt = Amount.replace("-", "");
            }
            catch(Exception e16)
            {
                
            }
            
         }
         
            // get cheque number and currency tax charged

            if (eventCode.equals("N0006"))
            {
                if (!chequeNo.equals(""))
                {
                    chequeNumber = chequeNo;
                } 
                else 
                {
                    chequeNumber = "";
                }
                if (!transactionCcy.equals(""))
                {
                    ccyTaxCharged = transactionCcy;
                } 
                
                if (!taxChargeAmt.equals(""))
                {
                    taxCollected = taxChargeAmt;

                    // Formatting taxcollected Amount
                    if ((taxCollected.indexOf(".") == -1))
                    {
                        taxCollected = taxCollected + ".0";
                        taxCollected = formatAmount(taxCollected); // Calling
                                                                   // Method
                    } 
                    else
                    {
                        taxCollected = formatAmount(taxCollected); // Calling
                                                                   // Method
                    }

                } 
                else
                {
                    taxCollect = "";
                    taxCollected = StringUtils.leftPad(taxCollected, 22, "0");
                }
            }
            else 
            {
                chequeNumber = "";
                ccyTaxCharged = "";
                taxCollect = "";
                taxCollected = StringUtils.leftPad(taxCollected, 22, "0");
            }
            
            // get BCI commision currency
            Double totAmtCharge;

            if (eventCode.equals("N0002"))
            {
                if (payOrdPrd.equals("ACTRF"))
                {
                    bciCmisionCcy =  debCcy;  
                    ccyInterbankCommision = debCcy;
                    totChrgCcy = debCcy;
                    bciCmisionAmt = chargeCmisionAmt;
                }
                else
                {
                    bciCmisionCcy = transactionCcy;   // issue fix mantis no 373
                    ccyInterbankCommision = transactionCcy;
                    totChrgCcy = transactionCcy;
                    bciCmisionAmt = chargeAmountOne;
                }

                    try
                    {
                    bcicmisionIntAmt = Double.parseDouble(bciCmisionAmt);
                    }
                    catch(Exception e3)
                    {
                        
                    }
                    // Formatting bciCmisionAmt
                    try
                    {
                        if ((bciCmisionAmt.indexOf(".") == -1))
                        {
                            bciCmisionAmt = bciCmisionAmt + ".0";
                            bciCmisionAmt = formatAmount(bciCmisionAmt); // Calling Method
                                                                         
                        } 
                        else
                        {
                            bciCmisionAmt = formatAmount(bciCmisionAmt); // Calling Method
                                                                         
                        }
                    }
                    catch(Exception e8)
                    {
                        
                    }
                

                try
                {
                    if(payOrdPrd.equals("ACTRF"))
                    {
                        totAmtCharged = debMainAmt;
                    }
                    else
                    {
                    totAmtCharge = bcicmisionIntAmt + payIntAmt + commisionAmt;
                    totAmtCharged = String.format("%.2f", totAmtCharge);
                    }

                    // Formatting totAmtcharged
                    try
                    {
                        if ((totAmtCharged.indexOf(".") == -1))
                        {
                            totAmtCharged = totAmtCharged + ".0";
                            totAmtCharged = formatAmount(totAmtCharged); // Calling  Method                                                               
                        } 
                        else
                        {
                            totAmtCharged = formatAmount(totAmtCharged); // Calling Method
                                                                         
                        }
                    }
                    catch(Exception e7)
                    {
                        
                    }
                } 
                catch (Exception e6)
                {
                    totAmtCharged = "";
                    totAmtCharged = StringUtils.leftPad(totAmtCharged, 22, "0");
                }

            } 
            
            else 
            {
                bciCmisionCcy = "";
                bciCmisionAmt = "";
                bciCmisionAmt = StringUtils.leftPad(bciCmisionAmt, 22, "0");
                ccyInterbankCommision = "";
                totChrgCcy = "";
                totAmtCharged = "";
                totAmtCharged = StringUtils.leftPad(totAmtCharged, 22, "0");
            }
            
            // get order execution date
     
            if(eventCode.equals("N0005"))
            {
            try
            {
                processDate = arg1.getProcessingdate().getValue();
                ordExeDate = processDate; 
                
            }
            catch (Exception e7)
            {
                ordExeDate = "";
            }
            }
            // Get payment date
            if (eventCode.equals("N0002") || eventCode.equals("N0003") || eventCode.equals("N0004")) 
            {
                if (!eventDate.equals(""))
                {
                    paymentDt = eventDate;
                }
                else
                {
                    paymentDt = "";
                }
            } 
            else 
            {
                if(eventCode.equals("N0005"))
                {
                    try
                    {
                    paymentDt = arg1.getCreditvaluedate().getValue();
                    }
                    catch(Exception e2)
                    {
                        paymentDt = "";  
                    }
                }
                 
            }

            // Get additional info and Remove [] in Additional.info value

            if (!eventCode.equals("N0006") && !eventCode.equals("N0005"))
            {
                if (!addInfo.equals(""))
                {
                    transferCmt = addInfo;
                    valOne = transferCmt.replace("[", "");
                    valTwo = valOne.replace("]", "");
                    transferCmt = valTwo;

                } 
                else 
                {
                    transferCmt = "";
                }
            } 
            
                if(eventCode.equals("N0005"))
                {
                    try
                    {
                    transferCmt = arg1.getAdditionalinformation().getValue(); 
                    }
                    catch(Exception e5)
                    {
                        transferCmt = ""; 
                    }
                }
                
            

            // Type of expenses

            if (eventCode.equals("N0008"))
            {
                if (!payOrdPrd.equals("")) 
                {
                    typeOfExpense = payOrdPrd;
                }
                else
                {
                    typeOfExpense = "";
                }
            }
            else
            {
                if(eventCode.equals("N0005") || eventCode.equals("N0004"))
                {
                    try
                    {
                        typeOfExpense = arg1.getDetailsofcharges().getValue();
                    }
                    catch(Exception e7)
                    {
                        typeOfExpense = "";
                    }
                }
            }

            // Get Address value
            if (eventCode.equals("N0008"))
            {
                try
                {
                    address = creAcct;
                }
                catch (Exception e11)
                {
                    address = "";
                }
            } 
            else
            {
                address = "";
            }

            // Get Operation number
            if(eventCode.equals("N0005"))
            {
                try 
                {
                    operationNo = arg1.getFtnumber().getValue();
                    ftNumber = operationNo;
                }
                    
                
                catch (Exception e12)
                {
                    operationNo = "";
                    ftNumber = "";
                }
            }

            // Get account code and code product

            try
            {
                acRec = new AccountRecord(fRead.getRecord("ACCOUNT", debAcct));
            } 
            catch (Exception e17)
            {
                acFlag = 1;
            }
            if (acFlag == 0) 
            {
                arrId = acRec.getArrangementId().getValue();

            }

            // Get AA ACCOUNT Details

            Contract contract = new Contract(this);
            contract.setContractId(arrId);
            AaPrdDesAccountRecord aaPrdDesAcctRec = null;
            try
            {
                aaPrdDesAcctRec = new AaPrdDesAccountRecord(contract.getConditionForProperty("BALANCE"));
                codeProduct = aaPrdDesAcctRec.getCategory().getValue();
                CategoryRecord categRec = new CategoryRecord(this);
                try
                {
                    categRec = new CategoryRecord(fRead.getRecord("CATEGORY", codeProduct));
                } 
                catch (Exception e13)
                {
                    categFlag = 1;
                }
                if (categFlag == 0)
                {
                    codeProduct = categRec.getDescription().get(1).getValue();
                }
                else 
                {
                    codeProduct = "";
                }
                legacyVal = aaPrdDesAcctRec.getAltIdType(0).getAltIdType().getValue();

                if (legacyVal.equals("LEGACY"))
                {
                    accountCode = aaPrdDesAcctRec.getAltIdType(0).getAltId().getValue();
                }

            }
            catch (Exception e)
            {
                codeProduct = "";
                accountCode = "";
            }

            // Get Code Executive
            contract.setContractId(arrId);
            AaPrdDesOfficersRecord aaPrdDesOfficerRec = null;
            try
            {
                aaPrdDesOfficerRec = new AaPrdDesOfficersRecord(contract.getConditionForProperty("OFFICERS"));
                codeExecutive = aaPrdDesOfficerRec.getPrimaryOfficer().getValue();
            }
            catch (Exception e)
            {
                codeExecutive = "";
            }

            // Get Executive Name and Executive Telephone
            if (!codeExecutive.equals("")) 
            {
                try
                {
                    DeptAcctOfficerRecord deptAcctOffRec = new DeptAcctOfficerRecord(fRead.getRecord("DEPT.ACCT.OFFICER", codeExecutive));  // Read DEPT.ACCT.OFFICER table and get the fields NAME and TELEPHONE.NO                                                                                  
                    executiveName = deptAcctOffRec.getName().getValue();
                    executiveTelephone = deptAcctOffRec.getTelephoneNo().getValue();
                } 
                catch (Exception e6)
                {
                    executiveName = "";
                    executiveTelephone = "";
                }
            }

            // Get transfer currency

            if (!debCcy.equals(""))
            {
                if (eventCode.equals("N0002") || eventCode.equals("N0004") || eventCode.equals("N0005")) 
                {
                    debCcy = transactionCcy;                  // Changed for issue no 127
                } 
                else 
                {
                    debitCurrency = debCcy;
                    debCcy = debitCurrency;
                }

            }
            
         // Defaulting ccyCommisionCharged, ccyTaxCharged, bciCmisionCcy,
            // ccyInterbankCommision, totChrgCcy

            if (ccyCommisionCharged.equals(""))

            {
                ccyCommisionCharged = debCcy;
            }
            if (ccyTaxCharged.equals(""))

            {
                ccyTaxCharged = debCcy;
            }
            if (bciCmisionCcy.equals(""))

            {
                bciCmisionCcy = debCcy;
            }
            if (ccyInterbankCommision.equals(""))

            {
                ccyInterbankCommision = debCcy;
            }
            if (totChrgCcy.equals(""))

            {
                totChrgCcy = debCcy;
            }
            if(eventCode.equals("N0006"))
            {
                ccyCommisionCharged = transactionCcy;
            }

            // Passing StringUtils Values

            hdrCode = StringUtils.rightPad(hdrCode, 20, " ");
            eventCode = StringUtils.rightPad(eventCode, 5, " ");
            ordCus = StringUtils.rightPad(ordCus, 20, " ");
            name = StringUtils.rightPad(name, 120, " ");
            legalID = StringUtils.rightPad(legalID, 20, " ");
            eMail = StringUtils.rightPad(eMail, 50, " ");
            phoneNo = StringUtils.rightPad(phoneNo, 20, " ");
            eventDate = StringUtils.rightPad(eventDate, 8, "0");
            eventTime = StringUtils.rightPad(eventTime, 8, "0");
            debAcct = StringUtils.rightPad(debAcct, 30, " ");
            creAcct = StringUtils.rightPad(creAcct, 30, " ");
            detCode = StringUtils.rightPad(detCode, 20, " ");
            debCcy = StringUtils.rightPad(debCcy, 5, " ");
            amtWrd = StringUtils.rightPad(amtWrd, 120, " ");
            companyName = StringUtils.rightPad(companyName, 120, " ");
            transType = StringUtils.rightPad(transType, 20, " ");
            channel = StringUtils.rightPad(channel, 20, " ");
            bank = StringUtils.rightPad(bank, 50, " ");
            originAcNo = StringUtils.rightPad(originAcNo, 30, " ");
            destinationAcNo = StringUtils.rightPad(destinationAcNo, 30, " ");
            accountCode = StringUtils.rightPad(accountCode, 30, " ");
            codeProduct = StringUtils.rightPad(codeProduct, 30, " ");
            companyVal = StringUtils.rightPad(companyVal, 5, " ");
            branchShrtName = StringUtils.rightPad(branchShrtName, 30, " ");
            codeExecutive = StringUtils.rightPad(codeExecutive, 5, " ");
            executiveName = StringUtils.rightPad(executiveName, 120, " ");
            executiveEmail = StringUtils.rightPad(executiveEmail, 50, " ");
            executiveTelephone = StringUtils.rightPad(executiveTelephone, 20, " ");
            chequeNumber = StringUtils.rightPad(chequeNumber, 30, " ");
            ccyCommisionCharged = StringUtils.rightPad(ccyCommisionCharged, 5, " ");
            ccyTaxCharged = StringUtils.rightPad(ccyTaxCharged, 5, " ");
            bciCmisionCcy = StringUtils.rightPad(bciCmisionCcy, 5, " ");
            ccyInterbankCommision = StringUtils.rightPad(ccyInterbankCommision, 5, " ");
            totChrgCcy = StringUtils.rightPad(totChrgCcy, 5, " ");
            ordExeDate = StringUtils.rightPad(ordExeDate, 8, "0");
            paymentDt = StringUtils.rightPad(paymentDt, 8, "0");
            transferCmt = StringUtils.rightPad(transferCmt, 150, " ");
            typeOfExpense = StringUtils.rightPad(typeOfExpense, 20, " ");
            address = StringUtils.rightPad(address, 30, " ");
            operationNo = StringUtils.rightPad(operationNo, 30, " ");
            customerCommunication = StringUtils.rightPad(customerCommunication, 150, " ");
            CrEffRate = StringUtils.leftPad(CrEffRate, 15, "0");
            DrEffRate = StringUtils.leftPad(DrEffRate, 15, "0");
            treaRate = StringUtils.leftPad(treaRate, 15, "0");
            debitBal = StringUtils.leftPad(debitBal, 15, "0");
            if(bciCmisionAmt.equals(""))
            {
                bciCmisionAmt = StringUtils.leftPad(bciCmisionAmt, 22, "0");  
            }
            
            ///Form Header Notice message    
            if(!eventCode.equals("N0005"))
            {
            hdrNoticeMsg = hdrCode+eventCode+ordCus+name+legalID+eMail+phoneNo+eventDate+eventTime+debAcct;
            }
            else
            {
              hdrNoticeMsg = hdrCode+eventCode+ordCus+name+legalID+eMail+phoneNo+eventDate+eventTime+creAcct; 
            }
            // Form Detail Notice message
              detNoticeMsg = detCode+eventCode+debCcy+payAmt+amtWrd+companyName+transType+channel+bank+originAcNo+destinationAcNo+accountCode+codeProduct+CrEffRate+DrEffRate+treaRate+debitBal+companyVal+branchShrtName+codeExecutive+executiveName+executiveEmail+executiveTelephone+chequeNumber+ccyCommisionCharged+totCommissionExpenseCharged+ccyTaxCharged+taxCollected+bciCmisionCcy+bciCmisionAmt+ccyInterbankCommision+interbankCommisionAmt+totChrgCcy+totAmtCharged+ordExeDate+paymentDt+transferCmt+typeOfExpense+address+operationNo+customerCommunication;   
                        
              // Form HeaderdetailNotice message
              hdrDetNoticeMsg = hdrNoticeMsg+"\n"+detNoticeMsg;
              
              
            // Pass the Header Notice and Detail Notice to third Party

            SoapClient soapClient = new SoapClient();
            try {
                // Pass the Header Notice and Detail Notice to third Party
                soapResponse = soapClient.processT24Request(hdrDetNoticeMsg);
                //soapResponse = "TAMILPROCESSING200";

                // Update the Engageone details in EB.BCI.UPDATE.ENGEGONE.DETAILS table
                
                if (!soapResponse.equals(""))
                {
                    EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetRec = new EbBciUpdateEngageoneDetailsRecord(this);
                    EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetTable = new EbBciUpdateEngageoneDetailsTable(this);

                    if(!eventCode.equals("N0005"))
                    {
                    bciUpdActivityDetsId = paymentOrderId + "-" + payOrdPrd + "-" + eventCode;
                    }
                    else
                    {
                        bciUpdActivityDetsId = ftNumber +"-"+ eventCode;

                    }
                 
                    
                    try {
                        
                        bciUpdEngageoneDetRec.setPaymentOrderProduct(payOrdPrd);
                        bciUpdEngageoneDetRec.setEventCode(eventCode);
                        bciUpdEngageoneDetRec.setRequestMessage(hdrDetNoticeMsg);

                        // For successful Response, Update the field ERROR.FLAG 
                        // as No
                        if ((soapResponse.contains("PROCESSING") == true) && (soapResponse.contains("200") == true))
                        {
                            bciUpdEngageoneDetRec.setErrorFlag("No");
                        }

                        // For Failed Response, Update the field ERROR.FLAG as
                        // Yes
                        if ((soapResponse.contains("ERROR") == true) && (soapResponse.contains("200") == true)) {
                            bciUpdEngageoneDetRec.setErrorFlag("Yes");
                        }

                        bciUpdEngageoneDetTable.write(bciUpdActivityDetsId, bciUpdEngageoneDetRec);
                    } 
                    catch (Exception bciUpdEngErr) 
                    {
                        bciUpdActivityDetsId = "";
                    }

                }

            }

            catch (IOException resErr)
            //catch(Exception e17)
            {
                return;
            }
            
            
            // Adding details for N0003 eventcode

            if (eventCode.equals("N0002"))
            {
                eventCode = "N0003";

                // Get legalId,phone and email from customer application

                try
                {
                    cusRec = new CustomerRecord(fRead.getRecord("CUSTOMER", creditClientId));
                }

                catch (Exception e1)
                {
                    cusFlag = 1;
                }

                if (cusFlag == 0)
                {

                    name = cusRec.getName1().get(0).getValue();

                    List<LegalIdClass> legalIdlist = cusRec.getLegalId();

                    if (!legalIdlist.isEmpty()) 
                    {
                        try 
                        {
                            legalID = legalIdlist.get(0).getLegalId().getValue();
                        } 
                        catch (Exception e8) 
                        {
                            legalID = "";
                        }

                    }
                    List<Phone1Class> phoneList = cusRec.getPhone1();
                    if (!phoneList.isEmpty())
                    {
                        try
                        {
                            phoneNo = phoneList.get(0).getPhone1().getValue();
                            eMail = phoneList.get(0).getEmail1().getValue();
                        } 
                        catch (Exception e9)
                        {
                            phoneNo = "";
                            eMail = "";
                        }

                    }

                    // Get the field CONTACT.DATA from customer table
                    List<ContactTypeClass> contactTypecList = cusRec.getContactType();
                    if (!contactTypecList.isEmpty())
                    {
                        try
                        {
                            customerCommunication = contactTypecList.get(0).getContactData().getValue();
                        } 
                        catch (Exception e10)
                        {
                            customerCommunication = "";
                        }
                    }
                }

                // Get company name

                int debitacFlag = 0;
                String debitCus = "";
                
                if(payOrdPrd.equals("CCETRANS"))
                {
                    if (!beneficiaryName.equals("")) 
                    {
                        companyName = beneficiaryName;
                    } 
                    else 
                    {
                        companyName = "";
                    }
                }
                else
                {
                    try
                    {
                        acRec = new AccountRecord(fRead.getRecord("ACCOUNT", debAcct));
                    } 
                    catch (Exception e18)
                    {
                        debitacFlag = 1;
                    }
                    if (debitacFlag == 0)
                    {
                        debitCus = acRec.getCustomer().getValue();
                        cusRec = new CustomerRecord(fRead.getRecord("CUSTOMER", debitCus));
                        try 
                        {
                            companyName = cusRec.getName1().get(0).getValue();
                        } 
                        catch (Exception e21)
                        {
                            companyName = "";
                        }
    
                    }
                }

                // Stringutills for N0003

                hdrCode = StringUtils.rightPad(hdrCode, 20, " ");
                eventCode = StringUtils.rightPad(eventCode, 5, " ");
                creditClientId = StringUtils.rightPad(creditClientId, 20, " ");
                name = StringUtils.rightPad(name, 120, " ");
                legalID = StringUtils.rightPad(legalID, 20, " ");
                eMail = StringUtils.rightPad(eMail, 50, " ");
                phoneNo = StringUtils.rightPad(phoneNo, 20, " ");
                eventDate = StringUtils.rightPad(eventDate, 8, "0");
                eventTime = StringUtils.rightPad(eventTime, 8, "0");
                creAcct = StringUtils.rightPad(creAcct, 30, " ");
                companyName = StringUtils.rightPad(companyName, 120, " ");
                customerCommunication = StringUtils.rightPad(customerCommunication, 150, " ");

              //Form Header Notice message    
                hdrNoticeMsg = hdrCode+eventCode+creditClientId+name+legalID+eMail+phoneNo+eventDate+eventTime+creAcct;
                
              // Form Detail Notice message
                detNoticeMsg = detCode+eventCode+debCcy+payAmt+amtWrd+companyName+transType+channel+bank+originAcNo+destinationAcNo+accountCode+codeProduct+CrEffRate+DrEffRate+treaRate+debitBal+companyVal+branchShrtName+codeExecutive+executiveName+executiveEmail+executiveTelephone+chequeNumber+ccyCommisionCharged+totCommissionExpenseCharged+ccyTaxCharged+taxCollected+bciCmisionCcy+bciCmisionAmt+ccyInterbankCommision+interbankCommisionAmt+totChrgCcy+totAmtCharged+ordExeDate+paymentDt+transferCmt+typeOfExpense+address+operationNo+customerCommunication;   
                          
                // Form HeaderdetailNotice message
                hdrDetNoticeMsg = hdrNoticeMsg+"\n"+detNoticeMsg;

                // Pass the Header Notice and Detail Notice to third Party

                SoapClient soapClientVal = new SoapClient();
                try {
                    // Pass the Header Notice and Detail Notice to third Party
                    soapResponse = soapClientVal.processT24Request(hdrDetNoticeMsg);
                    //soapResponse = "TAMILPROCESSING200";

                    // Update the Engageone details in EB.BCI.UPDATE.ENGEGONE.DETAILS table
                     
                    if (!soapResponse.equals(""))
                    {
                        EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetRec = new EbBciUpdateEngageoneDetailsRecord(this);
                        EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetTable = new EbBciUpdateEngageoneDetailsTable(this);

                        bciUpdActivityDetsId = paymentOrderId + "-" + payOrdPrd + "-" + eventCode;

                        try {
                            bciUpdEngageoneDetRec.setPaymentOrderId(paymentOrderId);
                            bciUpdEngageoneDetRec.setPaymentOrderProduct(payOrdPrd);
                            bciUpdEngageoneDetRec.setEventCode(eventCode);
                            bciUpdEngageoneDetRec.setRequestMessage(hdrDetNoticeMsg);

                            // For successful Response, Update the field ERROR.FLAG as No
                            
                            if ((soapResponse.contains("PROCESSING") == true) && (soapResponse.contains("200") == true))
                            {
                                bciUpdEngageoneDetRec.setErrorFlag("No");
                            }

                            // For Failed Response, Update the field ERROR.FLAG as Yes
                            
                            if ((soapResponse.contains("ERROR") == true) && (soapResponse.contains("200") == true))
                            {
                                bciUpdEngageoneDetRec.setErrorFlag("Yes");
                            }

                            bciUpdEngageoneDetTable.write(bciUpdActivityDetsId, bciUpdEngageoneDetRec);
                        } 
                        catch (Exception bciUpdEngErr) 
                        {
                            bciUpdActivityDetsId = "";
                        }
                    }

                }

                catch (IOException resErr)
                //catch(Exception e17)

                {
                    return;
                }

            }

        
      }

    }

    public String formatAmount(String amount)
    {
        
        String amountVal = "";
        try
        {
            
        String a1 = amount.split("\\.")[0];

        a1 = StringUtils.leftPad(a1, 20, "0");

        String b1 = amount.split("\\.")[1];
        b1 = StringUtils.rightPad(b1, 2, "0");

         amountVal = a1 + b1;

        }
        catch(Exception e1)
        {
            
        }
        
        return amountVal;
    }

}
