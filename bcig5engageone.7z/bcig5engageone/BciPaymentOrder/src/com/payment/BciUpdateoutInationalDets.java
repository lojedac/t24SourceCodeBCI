package com.bci.inational;

import java.util.ArrayList;
import java.util.List;

import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.CommonData;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.Flags;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.PaymentApplicationUpdate;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.PaymentContext;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.StatusAction;
import com.temenos.t24.api.hook.payments.PaymentLifecycle;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.t24.api.records.aaprddesofficers.AaPrdDesOfficersRecord;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.category.CategoryRecord;
import com.temenos.t24.api.records.company.CompanyRecord;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.customer.LegalIdClass;
import com.temenos.t24.api.records.customer.Phone1Class;
import com.temenos.t24.api.records.deptacctofficer.DeptAcctOfficerRecord;
import com.temenos.t24.api.records.ebqueriesanswers.EbQueriesAnswersRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.poragreementandadvice.PorAgreementAndAdviceRecord;
import com.temenos.t24.api.records.poraudittrail.PorAuditTrailRecord;
import com.temenos.t24.api.records.porpostingandconfirmation.PorPostingAndConfirmationRecord;
import com.temenos.t24.api.records.porsupplementaryinfo.PartyTypeClass;
import com.temenos.t24.api.records.porsupplementaryinfo.PorSupplementaryInfoRecord;
import com.temenos.t24.api.records.portransaction.PorTransactionRecord;
import com.temenos.t24.api.records.ppcompanyproperties.PpCompanyPropertiesRecord;
import com.temenos.t24.api.records.pptbictable.PptBictableRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsTable;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import java.io.IOException;
import com.temenos.t24.api.records.customer.ContactTypeClass;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EventCodeClass;
import com.techmill.integration.SoapClient;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author Tamizharasi G 
 * 
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *Description           : Fetch inward and outward transfer details and form as string and passing into engageone, once reach engageone successfully generate a reports based on the event codes N0002,N0003,N0004,N0005,N0008
 *Developed By          : Tamizharasi G , Techmill Technologies
 *Development Reference : IRD - 050
 *Attached To           : PP.STATUS.ACTION
 *Attached as           : 
 *-------------------------------------------------------------------------------------------------------------------------------------------
 *  M O D I F I C A T I O N S
 * ***************************        
 *-----------------------------------------------------------------------------------------------------------------
 * Defect Reference       Modified By                    Date of Change        Change Details
 * (RTC/TUT/PACS)                                        (YYYY-MM-DD)      
 *-----------------------------------------------------------------------------------------------------------------
 * XXXX                   <<name of modifier>>                                 <<modification details goes here>>
 *-----------------------------------------------------------------------------------------------------------------
 * Include files
 *-----------------------------------------------------------------------------------------------------------------
 *   
 */ 
public class BciUpdateoutInationalDets extends PaymentLifecycle {

    @Override
    public void updateRequestToExternalCoreSystem(StatusAction arg0, PorTransactionRecord arg1, PaymentContext arg2,
            PorSupplementaryInfoRecord arg3, PorAgreementAndAdviceRecord arg4, PorPostingAndConfirmationRecord arg5,
            PorAuditTrailRecord arg6, PpCompanyPropertiesRecord arg7, CommonData arg8, EbQueriesAnswersRecord arg9,
            Flags arg10, PaymentApplicationUpdate arg11) {
        // TODO Auto-generated method stub

        
        DataAccess fRead = new DataAccess(this);
        AccountRecord acRec = new AccountRecord(this);
        Session se = new Session(this);
        CustomerRecord cusRec = new CustomerRecord(this);
        EbBciEngageoneIntRepParamRecord bciEngageoneIntRepParamRec = null;

        int bciEngageoneIntRepParamRecFlag = 0;
        int cusFlag = 0;
        int cmpyFlag = 0;
        int poFlag = 0;
        int acFlag = 0;
        int categFlag = 0;
        String paymentOrderId = "";
        String payOrdPrd = "";
        String eventCode = "";
        String hdrCode = "";
        String detCode = "";
        String ordCus = "";
        String debAcct = "";
        String debCcy = "";
        String payAmt = "";
        String benName = "";
        String benAcNo = "";
        String eventDate = "";
        String eventTime = "";
        String operationNo = "";
        String amtWrd = "";
        String name = "";
        String legalID = "";
        String phoneNo = "";
        String eMail = "";
        String companyName = "";
        String bank = "";
        String originAcNo = "";
        String destinationAcNo = "";
        String cmpy = "";
        String branchShrtName = "";
        String chequeNumber = "";
        String chrgCcy = "";
        String chrgAmt = "";
        String ccyTaxCharged = "";
        String bciCmisionCcy = "";
        String bciCmisionAmt = "";
        String ccyInterbankCommision = "";
        String transType = "";
        String channel = "";
        String totChrgCcy = "";
        String totAmtCharged = "";
        String ordExeDate = "";
        String paymentDt = "";
        String addInfo = "";
        String transferCmt = "";
        String typeOfExpense = "";
        String address = "";
        String customerCommunication = "";
        String partyType = "";
        String timeVal = "";
        String approvedDtTime = "";
        String chargeccy = "";
        String chargeAmt = "";
        String taxCollected = "";
        String accountCode = "";
        String codeExecutive = "";
        String executiveName = "";
        String executiveEmail = "";
        String executiveTelephone = "";
        String CrEffRate = "";
        String DrEffRate = "";
        String treaRate = "";
        String debitBal = "";
        String codeProduct = "";
        String ccyCommisionCharged = "";
        String totCommissionExpenseCharged = "";
        String interbankCommisionAmt = "";
        String inComingMsgType = "";
        String hdrNoticeMsg = "";
        String detNoticeMsg = "";
        String hdrDetNoticeMsg = "";
        String soapResponse = "";
        String bciUpdActivityDetsId = "";
        String companyVal = "";
        String valOne = "";
        String valTwo = "";
        String arrId = "";
        String legacyVal = "";
        String debitCurrency = "";
        String destBank = "";
        String transactionCcy = "";
        String actvityNameList = "";
        String destinationBank = "";
        String selCmd = "";
        String bicCodeId = "";
        List<String> bankBicCodeList = new ArrayList<String>();
        
                
        // Get Payment order product
        
        inComingMsgType = arg1.getIncomingmessagetype().getValue();
                
        if (!inComingMsgType.equals("")) 
        {
            try  
           {
              payOrdPrd = inComingMsgType;
            } catch (Exception e9) {
                payOrdPrd = "";
            }
        }
        
        // Read param table
        
        try 
        {
            bciEngageoneIntRepParamRec = new EbBciEngageoneIntRepParamRecord(
                    fRead.getRecord("EB.BCI.ENGAGEONE.INT.REP.PARAM", "TRANSFERS"));
        } 
        
        catch (Exception e1)
        {
            bciEngageoneIntRepParamRecFlag = 1;
        }
        
        
     // Get the fields EVENT.CODE, HEADER.CODE and DETAIL.CODE from  parameter table
        
        if(eventCode.equals(""))
        {
      
        if (bciEngageoneIntRepParamRecFlag == 0)
        {
            List<EventCodeClass> eventCodeClsList = bciEngageoneIntRepParamRec.getEventCode();

            for (EventCodeClass eventCodeList : eventCodeClsList)
            {
                actvityNameList = eventCodeList.getActivityName().toString();
                
                if (actvityNameList.contains(payOrdPrd))
                {
                    eventCode = eventCodeList.getEventCode().getValue();

                    break;
                    
                }
            }
            
        }
        
        }
                   
        if (bciEngageoneIntRepParamRecFlag == 0)
        {
            hdrCode = bciEngageoneIntRepParamRec.getHeaderCode(0).getValue();
            detCode = bciEngageoneIntRepParamRec.getDetailCode(0).getValue();
        }          
            

        if(!eventCode.equals("") && eventCode.equals("N0004"))  
        {

        paymentOrderId = arg1.getFilereferenceincoming().getValue();
         
        eventDate = arg1.getDebitvaluedate().getValue();

        debAcct = arg1.getDebitmainaccount().getValue();

        debCcy = arg1.getDebitmainaccountcurrencycode().getValue();
 
        payAmt = arg1.getTransactionamount().getValue();
        
        ordCus = arg1.getDebitclientid().getValue();

        timeVal = arg1.getEntrydatetime().getValue();

        approvedDtTime = arg1.getApproveddatetime().getValue();

        transactionCcy = arg1.getTransactioncurrencycode().getValue();

        try
        {
            chargeccy = arg5.getChargePartyIndicator().get(0).getFeeCurrencyCode().getValue();
        } 
        catch (Exception e1) 
        {
            chargeccy = "";
        }

        try 
        {
            chargeAmt = arg5.getChargePartyIndicator().get(0).getChargeAmountFeeCurrency().getValue();
        } 
        catch (Exception e2)
        {
            chargeAmt = "";
        }
        
        
        if (!approvedDtTime.equals(""))
        {
            try 
            {
                eventTime = approvedDtTime.substring(8, 14);
            } 
            catch (Exception e3) 
            {
                eventTime = "";
            }
        }

        
        if (!paymentOrderId.equals(""))
        {
            try 
            {
                operationNo = paymentOrderId;
            } 
            catch (Exception e4) 
            {
                operationNo = "";
            }
        }


        if (!timeVal.equals("")) 
        {
            try 
            {
                ordExeDate = timeVal.substring(0, 8);
            } 
            catch (Exception e5)
            {
                ordExeDate = "";
            }
        }
        
        
        // Get ben name from POR.SUPPLEMENTRY.INFO 

        int partylen = 0;
        List<PartyTypeClass> partytypeList = arg3.getPartyType();
        
        try
        {
            partylen = partytypeList.size();
            for(int i=0;i<=partylen;i++)
            {
                
                try
                {
                    partyType = partytypeList.get(i).getPartyType().getValue();
                    
                } 
                catch (Exception e7) 
                {
                    partyType = "";
                }
                if (partyType.equals("CREDIT")) 
                {
                    try {
                        benName = partytypeList.get(i).getName().getValue();
                        } 
                    catch (Exception e8)
                    {
                        benName = "";
                    }
                        
                }
                
                if(!benName.equals(""))
                {
                    break;
                }
                
            }
        }
        catch(Exception e2)
        {
            
        }
        
                
            // Get ordering customer number, debit account, debit currency and destination bank from PO application
            PaymentOrderRecord poRec = new PaymentOrderRecord(this);
            try
            {
                poRec = new PaymentOrderRecord(fRead.getRecord("PAYMENT.ORDER", operationNo));
            } 
            catch (Exception e3) 
            {
                poFlag = 1;
            }
            if (poFlag == 0) 
            {
                addInfo = poRec.getAdditionalInfo().toString();
                benAcNo = poRec.getBeneficiaryAccountNo().getValue();   // For the issue id 276
                destBank = poRec.getAcctWithBankBic().getValue();        // For the issue id 276
            }
            
            // Select PPT.BICTABLE Record 
            
              if(!destBank.equals(""))
              {
                  try 
                  {
                    selCmd = "(WITH BICCode EQ "+destBank+")";
                    bankBicCodeList = fRead.selectRecords("","PPT.BICTABLE","",selCmd); 
                    bicCodeId = bankBicCodeList.get(0).toString();
                  }
                 catch(Exception e1)
                 {
                 }
              }
          
            // Read PPT.BICTABLE Record
              PptBictableRecord bicRec = new PptBictableRecord(this);
              try
              {
                  bicRec = new PptBictableRecord(fRead.getRecord("PPT.BICTABLE", bicCodeId));
                  destinationBank = bicRec.getFinancialinstitutionname().getValue();
              }
              catch(Exception e3)
              {
                  destinationBank = ""; 
              }
              
              System.out.println("selCmd"+""+selCmd);
              System.out.println("bicCodeId"+""+bicCodeId);
              System.out.println("bicRec"+""+bicRec);
              System.out.println("destinationBank"+""+destinationBank);
              
            
            // Formatting intercommisionamt
            
                
                if (interbankCommisionAmt.equals("")) 
                {
                    interbankCommisionAmt = StringUtils.leftPad(interbankCommisionAmt, 22, "0");
                }
                else 
                {
                    if ((interbankCommisionAmt.indexOf(".") == -1)) 
                    {
                        interbankCommisionAmt = interbankCommisionAmt + ".0";
                        interbankCommisionAmt = formatAmount(interbankCommisionAmt); // Calling Method
                    }
                    else
                    {
                        interbankCommisionAmt = formatAmount(interbankCommisionAmt); // Calling Method
                    }
                }

            
            // Formatting payment amount
            
    
          if(eventCode.equals("N0004"))           
          {
              
              if (payAmt.equals("")) 
              {
                  payAmt = StringUtils.leftPad(payAmt, 22, "0");  
              }
              else 
              {
                  if ((payAmt.indexOf(".") == -1)) 
                  {
                      payAmt = payAmt + ".0";
                      payAmt = formatAmount(payAmt); // Calling Method
                  }
                  else
                  {
                      payAmt = formatAmount(payAmt); // Calling Method
                  }
              }
              
          }
          
            // Get legalId,phone and email from customer application

            try {
                cusRec = new CustomerRecord(fRead.getRecord("CUSTOMER", ordCus));
            }

            catch (Exception e1) 
            {
                cusFlag = 1;
            }

            if (cusFlag == 0)
            {

                name = cusRec.getName1().get(0).getValue();

                List<LegalIdClass> legalIdlist = cusRec.getLegalId();

                if (!legalIdlist.isEmpty())
                {
                    try
                    {
                        legalID = legalIdlist.get(0).getLegalId().getValue();
                    } 
                    catch (Exception e8) 
                    {
                        legalID = "";
                    }

                }
                List<Phone1Class> phoneList = cusRec.getPhone1();
                if (!phoneList.isEmpty())
                {
                    try 
                    {
                        phoneNo = phoneList.get(0).getPhone1().getValue();
                        eMail = phoneList.get(0).getEmail1().getValue();
                    } 
                    catch (Exception e9) 
                    {
                        phoneNo = "";
                        eMail = "";
                    }

                }

                // Get the field CONTACT.DATA from customer table
                List<ContactTypeClass> contactTypecList = cusRec.getContactType();
                if (!contactTypecList.isEmpty()) 
                {
                    try 
                    {
                        customerCommunication = contactTypecList.get(0).getContactData().getValue();
                    } catch (Exception e10)
                    {
                        customerCommunication = "";
                    }
                }
            }

            // get Companyname

            
            if(eventCode.equals("N0004"))
            {
                
                    if (!benName.equals("")) 
                    {
                        companyName = benName;
                    } 
                    else 
                    {
                        companyName = "";
                    }

            }
            
            
            // Get Bank

                if(!destinationBank.equals(""))
                {
                bank = destinationBank;
                }
                else if(bank.equals(""))
                {
                    bank = "BANCO DE CREDITO E INVERSIONES"; 
                }
                   
            
            // Origin Acc Number
            if (!debAcct.equals(""))
            {
                originAcNo = debAcct;
            }
            else
            {
                originAcNo = ""; 
            }
            
            // destination Acc Number
           
                if(!benAcNo.equals(""))
                {
                destinationAcNo = benAcNo;
                }
                else
                {
                destinationAcNo = "";
                }
            
            
     
            // Get Company and fetch SHORT.NAME
            companyVal = "BCI";
            cmpy = se.getCompanyId();

            CompanyRecord cmpyRec = new CompanyRecord(this);

            try 
            {
                cmpyRec = new CompanyRecord(fRead.getRecord("COMPANY", cmpy));
            }
            catch (Exception e2)
            {
                cmpyFlag = 1;
            }

            if (cmpyFlag == 0) 
            {

                branchShrtName = cmpyRec.getCompanyName(0).getValue();
            }


            // Currency commision and expenses charged

            if (eventCode.equals("N0004"))
            {
                try 
                {
                    chrgCcy = chargeccy;
                    chrgAmt = chargeAmt;
                    ccyCommisionCharged = chrgCcy;
                    totCommissionExpenseCharged = chrgAmt;
                } 
                catch (Exception e12) 
                {
                    chrgCcy = "";
                    chrgAmt = "";
                    ccyCommisionCharged = "";
                    totCommissionExpenseCharged = "";

                }
                

                // Formatting totCommissionExpenseCharged

                if (totCommissionExpenseCharged.equals(""))
                {
                    totCommissionExpenseCharged = StringUtils.leftPad(totCommissionExpenseCharged, 22, "0");
                } 
                else 
                {
                    if ((totCommissionExpenseCharged.indexOf(".") == -1))
                    {
                        totCommissionExpenseCharged = totCommissionExpenseCharged + ".0";
                        totCommissionExpenseCharged = formatAmount(totCommissionExpenseCharged); // Calling
                                                                                                 // Method
                    }
                    else 
                    {
                        totCommissionExpenseCharged = formatAmount(totCommissionExpenseCharged); // Calling
                                                                                                 // Method
                    }
                }

            }
            else 
            {
                chrgCcy = "";
                chrgAmt = "";
                ccyCommisionCharged = "";
                totCommissionExpenseCharged = "";
                totCommissionExpenseCharged = StringUtils.leftPad(totCommissionExpenseCharged, 22, "0");
            }

            // get cheque number and currency tax charged

            if(eventCode.equals("N0004")) 
            {
                chequeNumber = "";
                ccyTaxCharged = "";
                taxCollected = StringUtils.leftPad(taxCollected, 22, "0");
            }

            // get BCI commision currency


            if (eventCode.equals("N0004"))
            {
                bciCmisionCcy = "";
                bciCmisionAmt = "";
                bciCmisionAmt = StringUtils.leftPad(bciCmisionAmt, 22, "0");
                ccyInterbankCommision = "";
                totChrgCcy = "";
                totAmtCharged = "";
                totAmtCharged = StringUtils.leftPad(totAmtCharged, 22, "0");
            } 

            
            // Get payment date
            if (eventCode.equals("N0004")) 
            {
                if (!eventDate.equals(""))
                {
                    paymentDt = eventDate;
                }
                else
                {
                    paymentDt = "";
                }
            } 


            // Get additional info and Remove [] in Additional.info value

                if (!addInfo.equals(""))
                {
                    transferCmt = addInfo;
                    valOne = transferCmt.replace("[", "");
                    valTwo = valOne.replace("]", "");
                    transferCmt = valTwo;

                } 
                else 
                {
                    transferCmt = "";
                }

            // Type of expenses

                if(eventCode.equals("N0004"))
                {
                    try
                    {
                        typeOfExpense = arg1.getDetailsofcharges().getValue();
                    }
                    catch(Exception e7)
                    {
                        typeOfExpense = "";
                    }
                }

            // Get account code and code product

            try
            {
                acRec = new AccountRecord(fRead.getRecord("ACCOUNT", debAcct));
            } 
            catch (Exception e17)
            {
                acFlag = 1;
            }
            if (acFlag == 0) 
            {
                arrId = acRec.getArrangementId().getValue();

            }

            // Get AA ACCOUNT Details

            Contract contract = new Contract(this);
            contract.setContractId(arrId);
            AaPrdDesAccountRecord aaPrdDesAcctRec = null;
            try
            {
                aaPrdDesAcctRec = new AaPrdDesAccountRecord(contract.getConditionForProperty("BALANCE"));
                codeProduct = aaPrdDesAcctRec.getCategory().getValue();
                CategoryRecord categRec = new CategoryRecord(this);
                try
                {
                    categRec = new CategoryRecord(fRead.getRecord("CATEGORY", codeProduct));
                } 
                catch (Exception e13)
                {
                    categFlag = 1;
                }
                if (categFlag == 0)
                {
                    codeProduct = categRec.getDescription().get(1).getValue();
                }
                else 
                {
                    codeProduct = "";
                }
                legacyVal = aaPrdDesAcctRec.getAltIdType(0).getAltIdType().getValue();

                if (legacyVal.equals("LEGACY"))
                {
                    accountCode = aaPrdDesAcctRec.getAltIdType(0).getAltId().getValue();
                }

            }
            catch (Exception e)
            {
                codeProduct = "";
                accountCode = "";
            }

            // Get Code Executive
            contract.setContractId(arrId);
            AaPrdDesOfficersRecord aaPrdDesOfficerRec = null;
            try
            {
                aaPrdDesOfficerRec = new AaPrdDesOfficersRecord(contract.getConditionForProperty("OFFICERS"));
                codeExecutive = aaPrdDesOfficerRec.getPrimaryOfficer().getValue();
            }
            catch (Exception e)
            {
                codeExecutive = "";
            }

            // Get Executive Name and Executive Telephone
            if (!codeExecutive.equals("")) 
            {
                try
                {
                    DeptAcctOfficerRecord deptAcctOffRec = new DeptAcctOfficerRecord(fRead.getRecord("DEPT.ACCT.OFFICER", codeExecutive));  // Read DEPT.ACCT.OFFICER table and get the fields NAME and TELEPHONE.NO                                                                                  
                    executiveName = deptAcctOffRec.getName().getValue();
                    executiveTelephone = deptAcctOffRec.getTelephoneNo().getValue();
                } 
                catch (Exception e6)
                {
                    executiveName = "";
                    executiveTelephone = "";
                }
            }

            // Get transfer currency

            if (!debCcy.equals(""))
            {
                
                    debCcy = transactionCcy;                  // Changed for issue no 127
            }
            else 
            {
                debitCurrency = debCcy;
                debCcy = debitCurrency;
            }    

            
            
         // Defaulting ccyCommisionCharged, ccyTaxCharged, bciCmisionCcy,
            // ccyInterbankCommision, totChrgCcy

            if (ccyCommisionCharged.equals(""))

            {
                ccyCommisionCharged = debCcy;
            }
            if (ccyTaxCharged.equals(""))

            {
                ccyTaxCharged = debCcy;
            }
            if (bciCmisionCcy.equals(""))

            {
                bciCmisionCcy = debCcy;
            }
            if (ccyInterbankCommision.equals(""))

            {
                ccyInterbankCommision = debCcy;
            }
            if (totChrgCcy.equals(""))

            {
                totChrgCcy = debCcy;
            }

            // Passing StringUtils Values

            hdrCode = StringUtils.rightPad(hdrCode, 20, " ");
            eventCode = StringUtils.rightPad(eventCode, 5, " ");
            ordCus = StringUtils.rightPad(ordCus, 20, " ");
            name = StringUtils.rightPad(name, 120, " ");
            legalID = StringUtils.rightPad(legalID, 20, " ");
            eMail = StringUtils.rightPad(eMail, 50, " ");
            phoneNo = StringUtils.rightPad(phoneNo, 20, " ");
            eventDate = StringUtils.rightPad(eventDate, 8, "0");
            eventTime = StringUtils.rightPad(eventTime, 8, "0");
            debAcct = StringUtils.rightPad(debAcct, 30, " ");
            detCode = StringUtils.rightPad(detCode, 20, " ");
            debCcy = StringUtils.rightPad(debCcy, 5, " ");
            amtWrd = StringUtils.rightPad(amtWrd, 120, " ");
            companyName = StringUtils.rightPad(companyName, 120, " ");
            transType = StringUtils.rightPad(transType, 20, " ");
            channel = StringUtils.rightPad(channel, 20, " ");
            bank = StringUtils.rightPad(bank, 50, " ");
            originAcNo = StringUtils.rightPad(originAcNo, 30, " ");
            destinationAcNo = StringUtils.rightPad(destinationAcNo, 30, " ");
            accountCode = StringUtils.rightPad(accountCode, 30, " ");
            codeProduct = StringUtils.rightPad(codeProduct, 30, " ");
            companyVal = StringUtils.rightPad(companyVal, 5, " ");
            branchShrtName = StringUtils.rightPad(branchShrtName, 30, " ");
            codeExecutive = StringUtils.rightPad(codeExecutive, 5, " ");
            executiveName = StringUtils.rightPad(executiveName, 120, " ");
            executiveEmail = StringUtils.rightPad(executiveEmail, 50, " ");
            executiveTelephone = StringUtils.rightPad(executiveTelephone, 20, " ");
            chequeNumber = StringUtils.rightPad(chequeNumber, 30, " ");
            ccyCommisionCharged = StringUtils.rightPad(ccyCommisionCharged, 5, " ");
            ccyTaxCharged = StringUtils.rightPad(ccyTaxCharged, 5, " ");
            bciCmisionCcy = StringUtils.rightPad(bciCmisionCcy, 5, " ");
            ccyInterbankCommision = StringUtils.rightPad(ccyInterbankCommision, 5, " ");
            totChrgCcy = StringUtils.rightPad(totChrgCcy, 5, " ");
            ordExeDate = StringUtils.rightPad(ordExeDate, 8, "0");
            paymentDt = StringUtils.rightPad(paymentDt, 8, "0");
            transferCmt = StringUtils.rightPad(transferCmt, 150, " ");
            typeOfExpense = StringUtils.rightPad(typeOfExpense, 20, " ");
            address = StringUtils.rightPad(address, 30, " ");
            operationNo = StringUtils.rightPad(operationNo, 30, " ");
            customerCommunication = StringUtils.rightPad(customerCommunication, 150, " ");
            CrEffRate = StringUtils.leftPad(CrEffRate, 15, "0");
            DrEffRate = StringUtils.leftPad(DrEffRate, 15, "0");
            treaRate = StringUtils.leftPad(treaRate, 15, "0");
            debitBal = StringUtils.leftPad(debitBal, 15, "0");

            ///Form Header Notice message    
            hdrNoticeMsg = hdrCode+eventCode+ordCus+name+legalID+eMail+phoneNo+eventDate+eventTime+debAcct;
            
            // Form Detail Notice message
              detNoticeMsg = detCode+eventCode+debCcy+payAmt+amtWrd+companyName+transType+channel+bank+originAcNo+destinationAcNo+accountCode+codeProduct+CrEffRate+DrEffRate+treaRate+debitBal+companyVal+branchShrtName+codeExecutive+executiveName+executiveEmail+executiveTelephone+chequeNumber+ccyCommisionCharged+totCommissionExpenseCharged+ccyTaxCharged+taxCollected+bciCmisionCcy+bciCmisionAmt+ccyInterbankCommision+interbankCommisionAmt+totChrgCcy+totAmtCharged+ordExeDate+paymentDt+transferCmt+typeOfExpense+address+operationNo+customerCommunication;   
                        
              // Form HeaderdetailNotice message
              hdrDetNoticeMsg = hdrNoticeMsg+"\n"+detNoticeMsg;
              
              
            // Pass the Header Notice and Detail Notice to third Party

            SoapClient soapClient = new SoapClient();
            try {
                // Pass the Header Notice and Detail Notice to third Party
                soapResponse = soapClient.processT24Request(hdrDetNoticeMsg);
                //soapResponse = "TAMILPROCESSING200";

                // Update the Engageone details in EB.BCI.UPDATE.ENGEGONE.DETAILS table
                
                if (!soapResponse.equals(""))
                {
                    EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetRec = new EbBciUpdateEngageoneDetailsRecord(this);
                    EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetTable = new EbBciUpdateEngageoneDetailsTable(this);

                    bciUpdActivityDetsId = paymentOrderId + "-" + payOrdPrd + "-" + eventCode;
                    
                    
                    try {
                        
                        bciUpdEngageoneDetRec.setPaymentOrderProduct(payOrdPrd);
                        bciUpdEngageoneDetRec.setEventCode(eventCode);
                        bciUpdEngageoneDetRec.setRequestMessage(hdrDetNoticeMsg);

                        // For successful Response, Update the field ERROR.FLAG 
                        // as No
                        if ((soapResponse.contains("PROCESSING") == true) && (soapResponse.contains("200") == true))
                        {
                            bciUpdEngageoneDetRec.setErrorFlag("No");
                        }

                        // For Failed Response, Update the field ERROR.FLAG as
                        // Yes
                        if ((soapResponse.contains("ERROR") == true) && (soapResponse.contains("200") == true)) {
                            bciUpdEngageoneDetRec.setErrorFlag("Yes");
                        }

                        bciUpdEngageoneDetTable.write(bciUpdActivityDetsId, bciUpdEngageoneDetRec);
                    } 
                    catch (Exception bciUpdEngErr) 
                    {
                        bciUpdActivityDetsId = "";
                    }

                }

            }

            catch (IOException resErr)
            //catch(Exception e17)
            {
                return;
            }
        
      }

    }

    public String formatAmount(String amount)
    {
        
        String amountVal = "";
        try
        {
            
        String a1 = amount.split("\\.")[0];

        a1 = StringUtils.leftPad(a1, 20, "0");

        String b1 = amount.split("\\.")[1];
        b1 = StringUtils.rightPad(b1, 2, "0");

         amountVal = a1 + b1;

        }
        catch(Exception e1)
        {
            
        }
        
        return amountVal;
    }

}
