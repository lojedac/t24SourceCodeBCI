package com.bci;

import java.util.List;
import java.io.IOException;
import java.util.ArrayList;
import com.temenos.api.TStructure;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import com.temenos.t24.api.complex.eb.servicehook.SynchronousTransactionData;
import com.temenos.t24.api.complex.eb.servicehook.TransactionControl;
import com.temenos.t24.api.hook.system.ServiceLifecycle;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaactivityhistory.AaActivityHistoryRecord;
import com.temenos.t24.api.records.aaactivityhistory.ActivityRefClass;
import com.temenos.t24.api.records.aaactivityhistory.EffectiveDateClass;
import com.temenos.t24.api.records.aaprddestermamount.AaPrdDesTermAmountRecord;
import com.temenos.t24.api.records.aaproduct.AaProductRecord;
import com.temenos.t24.api.records.aaprddesinterest.AaPrdDesInterestRecord;
import com.temenos.t24.api.records.aaprddesinterest.FixedRateClass;
import com.temenos.t24.api.records.aaprddesofficers.AaPrdDesOfficersRecord;
import com.temenos.t24.api.records.ebcontractbalances.EbContractBalancesRecord;
import com.temenos.t24.api.records.ebcontractbalances.TypeSysdateClass;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.t24.api.records.aaprddesaccount.AprTypeClass;
import com.temenos.t24.api.records.accountclosure.AccountClosureRecord;
import com.temenos.t24.api.records.stmtentry.StmtEntryRecord;
import com.temenos.t24.api.records.company.CompanyRecord;
import com.temenos.t24.api.records.customer.AddressClass;
import com.temenos.t24.api.records.customer.ContactTypeClass;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.customer.LegalIdClass;
import com.temenos.t24.api.records.customer.Phone1Class;
import com.temenos.t24.api.records.deptacctofficer.DeptAcctOfficerRecord;
import com.temenos.t24.api.records.aaprddescustomer.AaPrdDesCustomerRecord; 
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.api.TField;
import com.temenos.t24.api.records.aaprddescharge.AaPrdDesChargeRecord;
import com.temenos.t24.api.records.aaprddessettlement.AaPrdDesSettlementRecord;
import com.temenos.t24.api.tables.ebbciengageoneintrepparam.EbBciEngageoneIntRepParamRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsRecord;
import com.temenos.t24.api.tables.ebbciupdateengageonedetails.EbBciUpdateEngageoneDetailsTable;
import com.techmill.integration.SoapClient;
import org.apache.commons.lang3.StringUtils;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueDateClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.DueTypeClass;
import com.temenos.t24.api.tables.ebbciupdatescheduleprojector.EbBciUpdateScheduleProjectorRecord;
import com.temenos.t24.api.records.ebcashflow.EbCashflowRecord;
import com.temenos.t24.api.records.ebcashflow.CashFlowDateClass;

/**
*
*----------------------------------------------------------------------------------------------------------------
* Description           : Pass the Header Notice and detail Notice Message to third party using SoapClient method 
* Developed By          : Preethi I,Techmill Technologies
* Development Reference : BCI_G5_IDD053_Interfaz_Term_Deposit_Reports
* Attached To           : BATCH> BCI.MUL.DEP.ACTIVITY.DETS
* Attached As           : Service Routine
*-----------------------------------------------------------------------------------------------------------------
*  M O D I F I C A T I O N S
* ***************************
*-----------------------------------------------------------------------------------------------------------------
* Defect Reference       Modified By                    Date of Change        Change Details
* (RTC/TUT/PACS)                                        (YYYY-MM-DD)       
*-----------------------------------------------------------------------------------------------------------------
* XXXX                   <<name of modifier>>                                 <<modification details goes here>>
*-----------------------------------------------------------------------------------------------------------------
* Include files
*-----------------------------------------------------------------------------------------------------------------
*
*/

public class BciMulDepositActivityDets extends ServiceLifecycle {   
    
        
  //*------------ Select the records from EB.BCI.UPDATE.ENGAGEONE.DETAILS ----------------*//
    
    public List<String> getIds(ServiceData serviceData, List<String> controlList) {
        
        DataAccess fRead = new DataAccess(this);              
        List<String> bciUpdateDepActDetsList = new ArrayList<String>();
        String selCmd = "WITH (ERROR.FLAG EQ '') AND ((EVENT.CODE EQ 'C0007') OR (EVENT.CODE EQ 'C0008') OR (EVENT.CODE EQ 'N0009') OR (EVENT.CODE EQ 'N0010'))";
        try            
        {
            bciUpdateDepActDetsList = fRead.selectRecords("","EB.BCI.UPDATE.ENGAGEONE.DETAILS","",selCmd);    
        } 
        catch (Exception e) {   
            bciUpdateDepActDetsList.clear();        
        }                                                
        return bciUpdateDepActDetsList;         
    }       
    
  //*------------ Process----------------*//  
    
    @Override
    public void updateRecord(String id, ServiceData serviceData, String controlItem,
            TransactionControl transactionControl, List<SynchronousTransactionData> transactionData,
            List<TStructure> records) {
        
        DataAccess da = new DataAccess(this);
        Contract contract = new Contract(this);                          
        int flag = 0;
        String bciUpdEngageoneDetsId = id; 
        
        EbBciUpdateEngageoneDetailsRecord bciUpdEngageoneDetsRec = null;        
        EbBciUpdateEngageoneDetailsTable bciUpdEngageoneDetsTable= new EbBciUpdateEngageoneDetailsTable(this);
        
        try
        {
            bciUpdEngageoneDetsRec = new EbBciUpdateEngageoneDetailsRecord(da.getRecord("EB.BCI.UPDATE.ENGAGEONE.DETAILS", bciUpdEngageoneDetsId));  
        }        
        catch(Exception e)
        {   
            flag = 1;
        } 
     
        if(flag == 0)
        {
            
       //Initialize the Variable
            String eventCode = "";
            String hdrCode = "";
            int cusFlag = 0;
            String customerNo = "";
            String customerName = ""; 
            String legalID = "";
            String phoneNo = "";                    
            String email = "";
            int addressCnt = 0;
            String address = "";
            String customerCommunication = "";
            String hdrEventDate = "";
            String aaaDateTime = "";
            String hdrEventTime = "";          
            String detCode = "";
            String codeProduct = "";
            String operationNo  = "";
            String currency = "";
            String executiveEmail = "";
            String product = "";
            String aaaId = "";
            int productDescriptLen = 0;
            String productDescript = "";
            String termVal = "";
            char unitTermChar;
            String characteristic = "";
            String aaArrTermAmtId = "";
            String establishTerm = "";
            String unitestablishTerm = "";
            String effTermVal = "";
            char unitEffTermChar;
            String effectiveTerm = "";
            String unitEffectiveTerm = "";
            String chrgAmt = "";
            String itf = "";        
            double itfDbl = 0;
            String appliedRate = "";
            String companyId = "";
            String codeBranchOffice = "";
            String branchShortName = "";
            String codeExecutive = "";
            String executiveName  = "";
            String executiveTelephone = "";
            String captureDate = "";
            String dueDate = "";
            String acctCloseDateTime = "";
            String detEventDate = "";
            String aaArrCusDateTime = "";
            String detEventTime = "";
            String initialCapAmt  = "";
            String interestAmt = "";
            String accountNo = "";
            String finalCapitalAmt = "";
            String currAssetType = "";
            String penaltyAmtPreCancel = "";
            String netTotalPaidPreCancel = "";
            String CreditAcctNoPreCancel = "";
            String payoutAcct = "";
            String anotherFormPaymentPreCancel = "";
            String previousExpireDate = "";
            String previousUptakeDate = "";
            String previousInitialCapital = "";
            String previousInterest ="";
            String previousFinalCaptial = "";
            String annualEffectiveRate = "";
            String previousAnnualEffectiveReturnRate = "";
            String annualEffectiveRateofReturn = ""; 
            String hdrNoticeMsg = "";
            String detNoticeMsg = "";
            String hdrDetNoticeMsg = "";
            String soapResponse = "";  
            double finalCapitalAmtDbl = 0;
            String dueMethod = "";
            String duePropertyAmt = "";
            double duePropertyAmtDbl = 0;
            String activityRefId = "";
            String dueProperty = "";
            double interestAmtDbl = 0;
            String intDuePropertyAmt = "";
            double intDuePropertyAmtDbl = 0;
            String stmtNos = "";
            String stmtId = "";
            String stmtTotNos = "";
            int stmtTotNosInt = 0;
            String stmtEntRecId = "";
            String balType = "";
            String stmtAmt = "";
            double stmtAmtDbl = 0;
            double netTotalPaidPreCancelDbl = 0;
            String localCcy = "";
            double chrgAmtDbl = 0;
            int dutDateCnt = 0;
            int repayDueTypeCnt = 0;
            int duePropertyCnt = 0;
            String cashFlowType = "";
            
            
         //Get the EventCode and Arrangement ID from EB.BCI.UPDATE.ENGAGEONE.DETAILS table          
            eventCode = bciUpdEngageoneDetsRec.getEventCode().getValue();
            operationNo = bciUpdEngageoneDetsRec.getArragementId().getValue();
            contract.setContractId(operationNo);

         //Get the Header Code and Detail Code from EB.BCI.ENGAGEONE.INT.REP.PARAM table 
            EbBciEngageoneIntRepParamRecord bciEngageoneIntRepParamRec = null;  
            try
            {        
                bciEngageoneIntRepParamRec = new EbBciEngageoneIntRepParamRecord(da.getRecord("EB.BCI.ENGAGEONE.INT.REP.PARAM", "DEPOSITS"));
                hdrCode = bciEngageoneIntRepParamRec.getHeaderCode(0).getValue();
                detCode = bciEngageoneIntRepParamRec.getDetailCode(0).getValue();
            }
            catch(Exception engageRecErr)
            {
                engageRecErr.getMessage();
            }
            
            
         //Get the customer Number, Currency, Product, Capture Date, Account Number and Characteristics 
            AaArrangementRecord arrRec = null;          
            try
            {
                arrRec = new AaArrangementRecord(da.getRecord("AA.ARRANGEMENT", operationNo));
                customerNo = arrRec.getCustomer(0).getCustomer().getValue();
                currency = arrRec.getCurrency().getValue();
                product = arrRec.getProduct(0).getProduct().getValue();  
                captureDate = arrRec.getStartDate().getValue();
                accountNo = arrRec.getLinkedAppl(0).getLinkedApplId().getValue();
                try
                {
                    List<TField> propertyList = arrRec.getProduct(0).getProperty();
                    int propertyPos = propertyList.indexOf("RENEWAL");
                    if(propertyPos == -1)
                    {
                        characteristic = "FIJO"; 
                    }else
                    {
                        characteristic = "RENOVABLE";
                    }
                }
                catch(Exception propertyListErr)
                {
                    characteristic = "FIJO";
                }              
            }
            catch(Exception arrErr)
            {
                arrErr.getMessage();
            }
            

         //Get Header Event Date and Event Time (DATE.TIME)           
            aaaId = bciUpdEngageoneDetsId.split("-")[1];
            AaArrangementActivityRecord aaaRec = null;          
            try
            {
                aaaRec = new AaArrangementActivityRecord(da.getRecord("AA.ARRANGEMENT.ACTIVITY", aaaId));
                hdrEventDate = aaaRec.getEffectiveDate().getValue();
                aaaDateTime = aaaRec.getDateTime(0);
                hdrEventTime = aaaDateTime.substring(6)+"00"; 
            }
            catch(Exception aaaErr)
            {
                hdrEventTime = "";
            }
          
         //Read CUSTOMER table
            CustomerRecord cusRec = null;
            try
            {  
                cusRec = new CustomerRecord(da.getRecord("CUSTOMER", customerNo));
            }
            catch(Exception e2)
            {
                cusFlag = 1;
            }
            
            if(cusFlag == 0)
            {
                customerName = cusRec.getShortName(0).getValue();

          //Get the field LEGAL.ID from customer table       
                List<LegalIdClass> legalIdlist = cusRec.getLegalId();            
                if(!legalIdlist.isEmpty()){
                    legalID = legalIdlist.get(0).getLegalId().getValue();      
                }                
                
          //Get the fields PHONE.1 and EMAIL.1 from customer table 
                List<Phone1Class> phoneList = cusRec.getPhone1();             
                if(!phoneList.isEmpty())
                {
                phoneNo = phoneList.get(0).getPhone1().getValue();
                email = phoneList.get(0).getEmail1().getValue();
                }
                
          //Get the field ADDRESS from customer table 
                List<AddressClass> addressList = cusRec.getAddress();
                if(!addressList.isEmpty())
                {
                    addressCnt = addressList.size();
                    for(int i=0; i<addressCnt; i++)
                    {
                        String add = cusRec.getAddress().get(i).get(0).getValue();                   
                        String ad = add.concat(",");
                        address = address.concat(ad);
                    }
                    address = address.substring(0, address.length()-1);         
                }                 
                
          //Get the field CONTACT.DATA from customer table 
                List<ContactTypeClass> contactTypecList = cusRec.getContactType();            
                if(!contactTypecList.isEmpty()){
                   customerCommunication =  contactTypecList.get(0).getContactData().getValue();
                }
            }
              
       //Get product Description
            if(!product.equals(""))
            {               
                try
                {
                    AaProductRecord aaProductRec = new AaProductRecord(da.getRecord("AA.PRODUCT", product));   // Get the field DESCRIPTION from AA.PRODUCT
                    productDescript = aaProductRec.getDescription(0).getValue();
                    productDescriptLen = productDescript.length();
                    if(productDescriptLen >= 30)
                    {
                        productDescript = productDescript.substring(0, 30);
                    } 
                }
                catch(Exception e3)
                {
                    productDescript = "";
                }
            }  
            
        //Get Company ID and Company Name
            Session session = new Session(this);
            codeBranchOffice = "BCI";
            companyId = session.getCompanyId();
            localCcy = session.getLocalCurrency();
            try
            {
                CompanyRecord companyRec = new CompanyRecord(da.getRecord("COMPANY", companyId));   //Read COMPANY table and Get the value of NAME field 
                branchShortName = companyRec.getCompanyName(0).getValue();
            }
            catch(Exception companyErr)
            {
                branchShortName = "";
            }             
         
       //Get Code Product (Category)
            AaPrdDesAccountRecord aaPrdDesAcctRec = null;
            try
            {
             aaPrdDesAcctRec = new AaPrdDesAccountRecord(contract.getConditionForProperty("ACCOUNT"));
             codeProduct = aaPrdDesAcctRec.getCategory().getValue();
            }
            catch(Exception catErr)
            {
                codeProduct = "";
            }  
            
       //Get Code Executive           
            AaPrdDesOfficersRecord aaPrdDesOfficerRec = null;
            try
            {
                aaPrdDesOfficerRec = new AaPrdDesOfficersRecord(contract.getConditionForProperty("OFFICERS"));
                codeExecutive = aaPrdDesOfficerRec.getPrimaryOfficer().getValue(); 
            }
            catch(Exception offErr)
            {
                codeExecutive = "";
            }
             
        //Get Executive Name and Executive Telephone
              if(!codeExecutive.equals(""))
              {
                  try
                  {
                      DeptAcctOfficerRecord deptAcctOffRec = new DeptAcctOfficerRecord(da.getRecord("DEPT.ACCT.OFFICER", codeExecutive));   //Read DEPT.ACCT.OFFICER table and Get the fields NAME & TELERPHONE.NO 
                      executiveName = deptAcctOffRec.getName().getValue();
                      executiveTelephone = deptAcctOffRec.getTelephoneNo().getValue();
                  }
                  catch(Exception deptOffErr)
                  {
                      executiveTelephone = "";
                  }                  
              }    
              
         //Get Unit in which the established term is expressed & Establishes Term                
              AaPrdDesTermAmountRecord aaArrTermAmtRec = null;
              aaArrTermAmtId = operationNo+"-COMMITMENT-"+captureDate+".1";
              try
              {
                  aaArrTermAmtRec = new AaPrdDesTermAmountRecord(da.getRecord("AA.ARR.TERM.AMOUNT", aaArrTermAmtId));
                  termVal = aaArrTermAmtRec.getTerm().getValue();

                  if(!termVal.equals(""))
                  {
                      establishTerm = termVal.replaceAll("[^0-9]", "");        //Get the numeric value from TERM                         
                      unitTermChar = termVal.charAt(termVal.length()-1);       //Get the unit from TERM field
                      unitestablishTerm = Character.toString(unitTermChar);
                      switch(unitestablishTerm)
                      {
                          case "D":
                              unitestablishTerm = "DIAS";
                              break;
                          case "M":
                              unitestablishTerm = "MESES";
                               break;
                          case "Y":
                              unitestablishTerm = "ANOS";
                              break;                                   
                      }
                  }
              }
              catch(Exception termErr)
              {
                  unitestablishTerm = "";
              }
              
              
          //Get Annual Effective Rate of Return (EB.CASHFLOW > CALC.RATE) - MANTIS 280  
          //Get ITF (EB.CASHFLOW > CASH.FLOW.AMT) - Mantis 337
              EbCashflowRecord ebCashFlowRec = null; 
              try
              {  
                  ebCashFlowRec = new EbCashflowRecord(da.getRecord("EB.CASHFLOW", accountNo));
                  
                  try
                  {
                      annualEffectiveRateofReturn = ebCashFlowRec.getCalcType().get(0).getCalcRate().getValue();
                  }
                  catch(Exception annualEffReturnErr)
                  {
                      annualEffectiveRateofReturn = "";
                  }
                  
                  List<CashFlowDateClass> cashFlowDtList = ebCashFlowRec.getCashFlowDate();  
                  for(CashFlowDateClass cashFlowDt : cashFlowDtList)
                  {                      
                      cashFlowType = cashFlowDt.getCashFlowType().getValue();
                      if(cashFlowType.contains("ITF"))
                      {
                          itf = cashFlowDt.getCashFlowAmt().getValue();
                          itfDbl = Double.parseDouble(itf);
                          break;
                      }
                  }
              }
              catch(Exception ebCashFlowErr)
              {
                  itfDbl = 0;
              }
              
           //Get Applied Rate                
              AaPrdDesInterestRecord aaInterestRec = null;
              try
              {
                  aaInterestRec = new AaPrdDesInterestRecord(contract.getConditionForProperty("DEPOSITINT"));
                   
                  List<FixedRateClass> fixedRatelist = aaInterestRec.getFixedRate();       //Get the field EFFECTIVE.RATE value          
                  if(!fixedRatelist.isEmpty())
                  {
                      appliedRate = fixedRatelist.get(0).getEffectiveRate().getValue();
                  }  
                  if(eventCode.equals("C0008"))
                  {
                      previousInterest = fixedRatelist.get(0).getFixedRate().getValue();
                      annualEffectiveRate = appliedRate;
                  }
              }
              catch(Exception aaInterestErr)
              {
                  aaInterestErr.getMessage();
              }  
              
  //*-------------------------------------Fetch the details of event Code C0007, C0008 & N0010--------------------------------------------*// 
        
              if((eventCode.equals("C0007")) || (eventCode.equals("C0008")) || (eventCode.equals("N0010")))
              {
               //Set Unit in which the effective term is expressed & Effective Term details 
                  effectiveTerm = "";
                  unitEffectiveTerm = "";
                  
               //Get Interest Amount and Final Capital Amount  
                  EbBciUpdateScheduleProjectorRecord scheduleProjectorRec = null;
                  try
                  {
                      scheduleProjectorRec = new EbBciUpdateScheduleProjectorRecord(da.getRecord("EB.BCI.UPDATE.SCHEDULE.PROJECTOR", bciUpdEngageoneDetsId));                 
                      List<DueDateClass> dueDateList = scheduleProjectorRec.getDueDate();
                      dutDateCnt = dueDateList.size();
                      
                      for(int k=0; k<dutDateCnt; k++)
                      {        
                          List<DueTypeClass> repayDueTypeList = scheduleProjectorRec.getDueDate().get(k).getDueType();
                          repayDueTypeCnt = repayDueTypeList.size();

                          for(int r=0; r<repayDueTypeCnt; r++)
                          {                            
                              String[] duePropertyStringList = repayDueTypeList.get(r).getDueProperty().getValue().split("/");
                              String[] duePropertyAmtStringList = repayDueTypeList.get(r).getDuePropertyAmount().getValue().split("/");
                              String[] dueMethodStringList = repayDueTypeList.get(r).getDueMethod().getValue().split("/");
                              
                              List<String> duePropertyList = new ArrayList<String>();
                              List<String> duePropertyAmtList = new ArrayList<String>();
                              List<String> dueMethodList = new ArrayList<String>();
                              
                              for(String duePropertyStr : duePropertyStringList)       
                              {
                                  duePropertyList.add(duePropertyStr);
                              }
                              for(String duePropertyAmtStr : duePropertyAmtStringList)
                              {
                                  duePropertyAmtList.add(duePropertyAmtStr);
                              }
                              for(String dueMethodStr : dueMethodStringList)
                              {
                                  dueMethodList.add(dueMethodStr);
                              }
                              
                              duePropertyCnt = duePropertyList.size();
                              for(int m=0; m<duePropertyCnt; m++)
                              {
                                  dueProperty = "";
                                  dueProperty = duePropertyList.get(m);
                                  if(dueProperty.equals("DEPOSITINT"))
                                  {         
                                      intDuePropertyAmt = duePropertyAmtList.get(m);                                     
                                      intDuePropertyAmtDbl = Double.parseDouble(intDuePropertyAmt);
                                      interestAmtDbl = intDuePropertyAmtDbl + interestAmtDbl;
                                  }
                                  
                                  if(k == dutDateCnt-1)
                                  {
                                      dueMethod = dueMethodList.get(m);
                                      if(dueMethod.equals("PAY"))
                                      {                  
                                          duePropertyAmt = duePropertyAmtList.get(m);;
                                          duePropertyAmtDbl = Double.parseDouble(duePropertyAmt);
                                          finalCapitalAmtDbl = duePropertyAmtDbl + finalCapitalAmtDbl;
                                      }
                                  }
                              } 
                          }
                      }  
                      finalCapitalAmt = String.format("%.2f", finalCapitalAmtDbl);
                      interestAmt = String.format("%.2f", interestAmtDbl);  
                  }
                  catch(Exception schProjeErr)
                  {
                      schProjeErr.getMessage();
                  } 
                  
              //Get Initial Capital Amount     
                  AaPrdDesTermAmountRecord aaPrdDesTermAmtRec = null;
                  try
                  {
                       aaPrdDesTermAmtRec = new AaPrdDesTermAmountRecord(contract.getConditionForProperty("COMMITMENT"));
                       initialCapAmt = aaPrdDesTermAmtRec.getAmount().getValue();
                       
                       switch(eventCode)
                       {
                       case "C0008":
                           previousInitialCapital = initialCapAmt;
                           break;
                           
                       case "N0010":
                           interestAmt = "";
                           characteristic = "";
                           if(codeProduct.equals("6603") || codeProduct.equals("6604"))
                           {
                               initialCapAmt = "";
                           }
                           break;
                       }
                  }
                  catch(Exception aaTermErr)
                  {
                      aaTermErr.getMessage();
                  } 
                  
              //Get Event Time
                  AaPrdDesCustomerRecord aaArrcustomerRec = null;
                  try
                  {
                      aaArrcustomerRec = new AaPrdDesCustomerRecord(contract.getConditionForProperty("CUSTOMER"));
                      aaArrCusDateTime = aaArrcustomerRec.getDateTime(0);
                      detEventTime = aaArrCusDateTime.substring(6)+"00";
                  }
                  catch(Exception aaCustErr)
                  {
                      detEventTime = "";
                  }  
                  
              //Get Event Date and Due Date       
                  AaAccountDetailsRecord aaAcctDetsRec = null;
                  try
                  {
                      aaAcctDetsRec = new AaAccountDetailsRecord(da.getRecord("AA.ACCOUNT.DETAILS", operationNo));
                      detEventDate = aaAcctDetsRec.getStartDate().getValue();      //Get START.DATE from AA.ACCOUNT.DETAILS
                      dueDate = aaAcctDetsRec.getMaturityDate().getValue();       //Get MATURITY.DATE from AA.ACCOUNT.DETAILS
                      
                      if(eventCode.equals("C0008"))
                      {
                          previousUptakeDate = detEventDate;
                          try
                          {
                              previousExpireDate = aaAcctDetsRec.getBillPayDate(0).getBillId(0).getExpiryDate().getValue();      //Get EXPIRY.DATE
                          }
                          catch(Exception preExpDateErr)
                          {
                              previousExpireDate = "";
                          }
                          if(previousExpireDate.equals(""))
                          {
                              previousExpireDate= dueDate;
                          }
                      }
                  }
                  catch(Exception aaAcctDetErr)
                  {
                      aaAcctDetErr.getMessage();
                  }
              }         
                         
//*---------------------------------------Fetch the details of event Code C0008----------------------------------------------*//    
             
             if(eventCode.equals("C0008"))
             {           
                    
             //Get previous Annual Effective Return Rate from AA.ARR.ACCOUNT table
                 AaPrdDesAccountRecord aaArrAccRec = new AaPrdDesAccountRecord(); 
                 try
                 {  
                     aaArrAccRec = new AaPrdDesAccountRecord(contract.getConditionForProperty("ACCOUNT"));
                     List<AprTypeClass> aprTypeClsList = aaArrAccRec.getAprType();
                     for(AprTypeClass aprTypeCls : aprTypeClsList)
                     {
                         String aprType = "";
                         aprType = aprTypeCls.getAprType().getValue();
                         if(aprType.equals("PEACCT.TREA.DEPOSITS"))
                         {
                             previousAnnualEffectiveReturnRate = aprTypeCls.getAprRate().getValue();
                             break;
                         }
                     }
                 }
                 catch(Exception preAnnualEffRateErr)
                 {
                     previousAnnualEffectiveReturnRate = "";
                 }
                 if(previousAnnualEffectiveReturnRate.equals(""))
                 {
                     previousAnnualEffectiveReturnRate = annualEffectiveRateofReturn;
                 }
           
             //Get Previous Final Capital 
                 try
                 {
                     EbContractBalancesRecord ebContractBalRec = new EbContractBalancesRecord(da.getRecord("EB.CONTRACT.BALANCES", accountNo));                    
                     List<TypeSysdateClass> typeSysDateList = ebContractBalRec.getTypeSysdate();
                         
                     if(!typeSysDateList.isEmpty())
                     {
                         int typeSysDtCnt = typeSysDateList.size();
                         for(int j=0; j<typeSysDtCnt; j++)
                         {
                            currAssetType = typeSysDateList.get(j).getCurrAssetType().getValue();
                            if(currAssetType.equals("TOTCOMMITMENT"))
                            {
                               previousFinalCaptial = typeSysDateList.get(j).getMatDate(0).getOpenBalance().getValue();
                               break;
                            }
                         }
                     }                        
                 }
                 catch(Exception ecbErr)
                 {
                     ecbErr.getMessage();
                 }  
                
                 if(previousFinalCaptial.equals(""))
                 {
                     previousFinalCaptial = finalCapitalAmt;
                 }
             }
                  
  //*---------------------------------------Fetch the details of event Code N0009----------------------------------------------*//
           
             if(eventCode.equals("N0009"))
             {
            //Get Initial Capital amount, Due Date, Unit in which the established term is expressed & Establishes Term and Unit in which the effective term is expressed & Effective Term details and Get Pre-cancellation / cancellation                
                 AaPrdDesTermAmountRecord aaPrdDesTermAmtRec = null;
                 try
                 {
                      aaPrdDesTermAmtRec = new AaPrdDesTermAmountRecord(contract.getConditionForProperty("COMMITMENT"));
                      initialCapAmt = aaPrdDesTermAmtRec.getAmount().getValue();
                      dueDate = aaPrdDesTermAmtRec.getMaturityDate().getValue();
                      effTermVal = aaPrdDesTermAmtRec.getTerm().getValue();
                                          
                      if(!effTermVal.equals(""))
                      {
                          effectiveTerm = effTermVal.replaceAll("[^0-9]", "");        //Get the numeric value from TERM                         
                          unitEffTermChar = effTermVal.charAt(effTermVal.length()-1);       //Get the unit from TERM field
                          unitEffectiveTerm = Character.toString(unitEffTermChar);
                          switch(unitEffectiveTerm)
                          {
                              case "D":
                                  unitEffectiveTerm = "DIAS";
                                  break;
                              case "M":
                                  unitEffectiveTerm = "MESES";
                                   break;
                              case "Y":
                                  unitEffectiveTerm = "ANOS";
                                  break;                                   
                          }
                      }
                 }
                 catch(Exception aaTermAmtErr)
                 {
                     unitEffectiveTerm = "";
                 }                                     
          
             //Get Event Date & Event Time
                   try
                   {
                       AccountClosureRecord accountClosureRec = new AccountClosureRecord(da.getRecord("ACCOUNT.CLOSURE", accountNo));
                       acctCloseDateTime = accountClosureRec.getDateTime(0);
                       detEventDate = "20"+acctCloseDateTime.substring(0, 6);
                       detEventTime = acctCloseDateTime.substring(6)+"00";                       
                   }                   
                   catch(Exception acctClosureErr)
                   {
                       detEventTime = "";
                   }
                              
             //Get Credit account number for pre-cancellation / cancellation & Another form of payment for pre-cancellation / cancellation                    
                   AaPrdDesSettlementRecord aaPrdDesSettlementRec = null;
                   try
                   {
                       aaPrdDesSettlementRec = new AaPrdDesSettlementRecord(contract.getConditionForProperty("SETTLEMENT"));
                       payoutAcct = aaPrdDesSettlementRec.getPayoutCurrency(0).getPayoutAccount(0).getPayoutAccount().getValue();                 
                       if(!payoutAcct.equals(""))
                       {
                           CreditAcctNoPreCancel = payoutAcct;
                           anotherFormPaymentPreCancel = "";
                       }
                       else
                       {
                           anotherFormPaymentPreCancel = "Si"; 
                       } 
                   }
                   catch(Exception aaSettlementErr)
                   {
                       aaSettlementErr.getMessage();
                   }
                    
             //Get Charge Amount & Amount Penalty for pre-cancellation
                   AaPrdDesChargeRecord aaArrChargeRec = null;
                   try
                   {
                    aaArrChargeRec = new AaPrdDesChargeRecord(contract.getConditionForProperty("REDEMPTIONFEE"));
                    chrgAmt = aaArrChargeRec.getFixedAmount().getValue();
                    penaltyAmtPreCancel = chrgAmt; 
                    chrgAmtDbl = Double.parseDouble(chrgAmt);
                   }
                   catch(Exception aaChrgErr)
                   {
                       chrgAmtDbl = 0;
                   }
                   
             //Get Interest amount and Net total paid for Pre-cancellation / cancellation
                   try
                   {
                       AaActivityHistoryRecord aaActivityHisRec = new AaActivityHistoryRecord(da.getRecord("AA.ACTIVITY.HISTORY", operationNo));         //Get the activity ID of DEPOSITS-REDEEM-ARRANGEMENT from AA.ACTIVITY.HISTORY table   
                       List<EffectiveDateClass> effectiveDateList = aaActivityHisRec.getEffectiveDate();
                       if(!effectiveDateList.isEmpty())
                       {                           
                           List<ActivityRefClass> activityRefClassList = effectiveDateList.get(0).getActivityRef();
                           if(!activityRefClassList.isEmpty())
                           {
                               for(int i=0; i<activityRefClassList.size(); i++)
                               {
                                   activityRefId = activityRefClassList.get(i).getActivityRef().getValue();                                 
                                   if(activityRefId.equals(aaaId))
                                   {
                                       try   //Calculate Net total paid for Pre-cancellation/cancellation from STMT.ENTRY
                                       {
                                           AaArrangementActivityRecord aaArrActRec = new AaArrangementActivityRecord(da.getRecord("AA.ARRANGEMENT.ACTIVITY", activityRefId));
                                           stmtId = aaArrActRec.getStmtNos(0).getValue();
                                           stmtNos = aaArrActRec.getStmtNos(1).getValue();

                                           stmtTotNos = stmtNos.split("\\*")[0].split("-")[1];
                                           stmtTotNosInt = Integer.parseInt(stmtTotNos);
                                          
                                           for(int p=1; p<=stmtTotNosInt; p++)
                                           {
                                               stmtEntRecId = stmtId+"000"+p;
                                               try
                                               {
                                                   StmtEntryRecord stmtEntRec = new StmtEntryRecord(da.getRecord("STMT.ENTRY", stmtEntRecId));
                                                   balType = stmtEntRec.getBalanceType().getValue();
                                                                                                      
                                                   if(currency.equals(localCcy))
                                                   {
                                                       stmtAmt = stmtEntRec.getAmountLcy().getValue();
                                                   }else
                                                   {
                                                       stmtAmt = stmtEntRec.getAmountFcy().getValue(); 
                                                   }
                                                   stmtAmtDbl = Double.parseDouble(stmtAmt);

                                                   switch(balType)
                                                   {
                                                       case "PAYDEPOSITINT":  
                                                           netTotalPaidPreCancelDbl = netTotalPaidPreCancelDbl + stmtAmtDbl;
                                                           interestAmtDbl = interestAmtDbl + stmtAmtDbl;                                                
                                                           break;
                                                       case "PAYACCOUNT":
                                                           netTotalPaidPreCancelDbl = netTotalPaidPreCancelDbl + stmtAmtDbl;
                                                           break;                                  
                                                   }                                                                                                                       
                                               }
                                               catch(Exception stmtErr)
                                               {
                                                   stmtErr.getMessage(); 
                                               }
                                           }
                                           netTotalPaidPreCancelDbl = netTotalPaidPreCancelDbl - chrgAmtDbl - itfDbl;

                                           interestAmt = String.format("%.2f", interestAmtDbl);                     
                                           netTotalPaidPreCancel = String.format("%.2f", netTotalPaidPreCancelDbl); 
                                       }
                                       catch(Exception aaArrErr)
                                       {
                                           aaArrErr.getMessage();
                                       }
                                       break;
                                   }
                               }
                           }
                       }
                   }  
                   catch(Exception aaaHisErr)
                   {
                       aaaHisErr.getMessage();  
                   }  
                   finalCapitalAmt = netTotalPaidPreCancel;
             }          
             
   /*---------------------------------------------------------------------------------------------------------------------------*/ 
             
      //Format the field values based on the length
             hdrCode = StringUtils.rightPad(hdrCode, 20, " ");
             eventCode = StringUtils.rightPad(eventCode, 5, " ");
             customerNo = StringUtils.leftPad(customerNo, 20, "0");
             customerName = StringUtils.rightPad(customerName, 120, " ");
             legalID = StringUtils.rightPad(legalID, 20, " ");
             email = StringUtils.rightPad(email, 50, " ");
             phoneNo = StringUtils.rightPad(phoneNo, 20, " ");
             address = StringUtils.rightPad(address, 120, " ");
             hdrEventDate = StringUtils.rightPad(hdrEventDate, 8, "0");
             hdrEventTime = StringUtils.rightPad(hdrEventTime, 8, "0");
             operationNo = StringUtils.rightPad(operationNo, 30, " ");
             detCode = StringUtils.rightPad(detCode, 20, " ");
             codeProduct = StringUtils.rightPad(codeProduct, 5, " ");
             productDescript = StringUtils.rightPad(productDescript, 30, " ");
             characteristic = StringUtils.rightPad(characteristic, 30, " ");
             currency = StringUtils.rightPad(currency, 5, " ");
             unitestablishTerm = StringUtils.rightPad(unitestablishTerm, 5, " ");
             establishTerm = StringUtils.leftPad(establishTerm, 5, "0");
             unitEffectiveTerm = StringUtils.rightPad(unitEffectiveTerm, 5, " ");
             effectiveTerm = StringUtils.leftPad(effectiveTerm, 5, "0");
             codeBranchOffice = StringUtils.rightPad(codeBranchOffice, 5, " ");
             branchShortName = StringUtils.rightPad(branchShortName, 30, " ");
             codeExecutive = StringUtils.rightPad(codeExecutive, 5, " ");
             executiveName = StringUtils.rightPad(executiveName, 120, " ");
             executiveEmail = StringUtils.rightPad(executiveEmail, 50, " ");
             executiveTelephone = StringUtils.rightPad(executiveTelephone, 20, " ");
             captureDate = StringUtils.rightPad(captureDate, 8, "0");
             detEventDate = StringUtils.rightPad(detEventDate, 8, "0");
             detEventTime = StringUtils.rightPad(detEventTime, 8, "0");
             dueDate = StringUtils.rightPad(dueDate, 8, "0");
             CreditAcctNoPreCancel = StringUtils.rightPad(CreditAcctNoPreCancel, 30, " ");
             anotherFormPaymentPreCancel = StringUtils.rightPad(anotherFormPaymentPreCancel, 2, " ");
             previousUptakeDate = StringUtils.rightPad(previousUptakeDate, 8, "0");
             previousExpireDate = StringUtils.rightPad(previousExpireDate, 8, "0");
             customerCommunication = StringUtils.rightPad(customerCommunication, 150, " "); 
                         
             appliedRate = formatRate(appliedRate);
             annualEffectiveRateofReturn = formatRate(annualEffectiveRateofReturn);
             annualEffectiveRate = formatRate(annualEffectiveRate);
             previousAnnualEffectiveReturnRate = formatRate(previousAnnualEffectiveReturnRate);

             itf = formatAmt(itf);
             initialCapAmt = formatAmt(initialCapAmt);
             interestAmt = formatAmt(interestAmt);
             finalCapitalAmt = formatAmt(finalCapitalAmt);
             penaltyAmtPreCancel = formatAmt(penaltyAmtPreCancel);
             netTotalPaidPreCancel = formatAmt(netTotalPaidPreCancel);
             previousInitialCapital = formatAmt(previousInitialCapital);
             previousInterest = formatAmt(previousInterest);
             previousFinalCaptial = formatAmt(previousFinalCaptial);

    
 //*----------------------------------------------------------------------------------------------------------------------------------------*//
             
        //Form Header Notice message    
             hdrNoticeMsg = hdrCode+eventCode+customerNo+customerName+legalID+email+phoneNo+address+hdrEventDate+hdrEventTime+operationNo;
             
        //Form Detail Notice message
             detNoticeMsg = detCode+eventCode+codeProduct+productDescript+characteristic+operationNo+currency+unitestablishTerm+establishTerm+unitEffectiveTerm+effectiveTerm+itf+appliedRate+annualEffectiveRateofReturn+codeBranchOffice+branchShortName+codeExecutive+executiveName+executiveEmail+executiveTelephone+captureDate+detEventDate+detEventTime+dueDate+initialCapAmt+interestAmt+finalCapitalAmt+penaltyAmtPreCancel+netTotalPaidPreCancel+CreditAcctNoPreCancel+anotherFormPaymentPreCancel+previousUptakeDate+previousExpireDate+previousInitialCapital+previousInterest+previousFinalCaptial+annualEffectiveRate+previousAnnualEffectiveReturnRate+customerCommunication;

             hdrDetNoticeMsg = hdrNoticeMsg+'\n'+detNoticeMsg;
                                
             SoapClient soapClient = new SoapClient();                   
             try
             {
            //Pass the Header Notice and Detail Notice to third Party
                 soapResponse = soapClient.processT24Request(hdrDetNoticeMsg);
                
            //Update the Request Message and Error Flag fields in EB.BCI.UPDATE.ENGAGEONE.DETAILS table     
                 if(!soapResponse.equals(""))
                 {                                             
                     try
                     {
                         bciUpdEngageoneDetsRec.setRequestMessage(hdrDetNoticeMsg);                     
                         
                      //For successful Response, Update the field ERROR.FLAG as No
                         if((soapResponse.contains("PROCESSING") == true) && (soapResponse.contains("200") == true))
                         {                                                  
                             bciUpdEngageoneDetsRec.setErrorFlag("No");                                                
                         }                    
                         
                      //For Failed Response, Update the field ERROR.FLAG as Yes
                         if((soapResponse.contains("ERROR") == true) && (soapResponse.contains("200") == true))
                         {                        
                             bciUpdEngageoneDetsRec.setErrorFlag("Yes");                                                                          
                         }  
                         
                         bciUpdEngageoneDetsTable.write(bciUpdEngageoneDetsId, bciUpdEngageoneDetsRec);
                     }
                     catch (Exception bciUpdEngErr) 
                     {
                         bciUpdEngageoneDetsId = "";   
                     }                                       
                 } 
             }
             catch (IOException resErr)
             {
                 resErr.getMessage();
             }              
         }   
    }
   
 //*------------Format the Rate field values (15 fixed Length)------------------------------------------*//
    
    public String formatRate(String rateVal){
        
        String c1 = "";
        if(rateVal.equals(""))
        {
            c1 = StringUtils.leftPad(rateVal, 15, "0");
        }else
        {        
            if((rateVal.indexOf("-") != -1))
            {
                rateVal = rateVal.substring(1);
            }
            
            if((rateVal.indexOf(".") == -1))
            {
                rateVal = rateVal+".0";
            }
            
            String a1 = rateVal.split("\\.")[0];
            a1 = StringUtils.leftPad(a1, 9, "0");
    
            String b1 = rateVal.split("\\.")[1];
            b1 = StringUtils.rightPad(b1, 6, "0");
    
            c1 = a1+b1;
            if(c1.length() > 15)
            {
                c1 = c1.substring(0, 15);
            }
        }
        return c1;
    }
    
    
 //*------------Format the Amount field values (22 fixed Length)------------------------------------------*//
    
    public String formatAmt(String amtVal){
        
        String c2 = "";

        if(amtVal.equals(""))
        {
            c2 = StringUtils.leftPad(amtVal, 22, "0");
        }else
        {         
            if((amtVal.indexOf("-") != -1))
            {
                amtVal = amtVal.substring(1); 
            }
            
            if((amtVal.indexOf(".") == -1))
            {
                amtVal = amtVal+".0";
            }
            
            String a2 = amtVal.split("\\.")[0];
            a2 = StringUtils.leftPad(a2, 20, "0");
    
            String b2 = amtVal.split("\\.")[1];
            b2 = StringUtils.rightPad(b2, 2, "0");
    
            c2 = a2+b2;      
            if(c2.length() > 22)
            {
                c2 = c2.substring(0, 22);
            }
        }
        return c2;
     }   
}
