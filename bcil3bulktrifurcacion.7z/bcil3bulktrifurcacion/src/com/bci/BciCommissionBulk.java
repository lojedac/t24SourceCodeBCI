package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.paymentorder.ChargeTypeClass;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebbcibulkcommissionparam.CommissionTypeClass;
import com.temenos.t24.api.tables.ebbcibulkcommissionparam.EbBciBulkCommissionParamRecord;
import com.temenos.tafj.api.client.impl.T24Context;

/**
 * 
 *
 * @author haroldtabarez
 *
 */
public class BciCommissionBulk extends RecordLifecycle {

    @Override
    public void defaultFieldValues(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        String currency = "";
        // String typePlace = "";
        String channel = "";
        String commissionClientId = "";
        String poProduct = "";
        String amountClCom = "";
        String typeClCom = "";
        String currPoClCom = "";
        String descripClCom = "";
        String minCommissionCl = "";
        String maxCommissionCl = "";
        String debitAmmountCl = "";
        String persent = "";
        String debitAccount = "";
        String customerDebitAccount = "";
        String ccetrans = "CCETRANS";
        final DataAccess daObj = new DataAccess((T24Context) this);
        final PaymentOrderRecord paymentOrderRecordObj = new PaymentOrderRecord(currentRecord);
        ChargeTypeClass chargeClassComCl = new ChargeTypeClass();

        currency = paymentOrderRecordObj.getPaymentCurrency().getValue();
        paymentOrderRecordObj.getLocalRefField("L.TYPE.PLACE").getValue();
        poProduct = paymentOrderRecordObj.getPaymentOrderProduct().getValue();
        channel = paymentOrderRecordObj.getOrderInitiationType().getValue();
        if (poProduct.equals(ccetrans)) {
            try {
                DataAccess da = new DataAccess(this);
                debitAccount = paymentOrderRecordObj.getDebitAccount().getValue();
                AccountRecord accountRec = new AccountRecord(daObj.getRecord("ACCOUNT", debitAccount));
                customerDebitAccount = accountRec.getCustomer().getValue();
                List<String> commisionIDClassList = (List<String>) daObj.selectRecords("",
                        "EB.BCI.BULK.COMMISSION.PARAM", "", "");
                commissionClientId = String
                        .valueOf(customerDebitAccount + "." + channel + "." + poProduct + "." + currency);
                if (!validateIdAccount(commissionClientId, daObj, commisionIDClassList)) {
                    commissionClientId = String.valueOf(channel + "." + poProduct + "." + currency);
                }
                if (validateChannel(commissionClientId, daObj, commisionIDClassList, channel)) {
                    EbBciBulkCommissionParamRecord commissionRecord = new EbBciBulkCommissionParamRecord(
                            da.getRecord("EB.BCI.BULK.COMMISSION.PARAM", commissionClientId));
                    List<CommissionTypeClass> commisionTypeClassList = new ArrayList<>();
                    commisionTypeClassList = commissionRecord.getCommissionType();
                    typeClCom = commisionTypeClassList.get(0).getCommissionType().getValue();
                    descripClCom = commisionTypeClassList.get(0).getCommissionDescription().getValue();
                    currPoClCom = paymentOrderRecordObj.getPaymentCurrency().getValue();
                    persent = commisionTypeClassList.get(0).getCommPercentage().getValue();
                    minCommissionCl = commisionTypeClassList.get(0).getMinCommission().getValue();
                    maxCommissionCl = commisionTypeClassList.get(0).getMaxCommission().getValue();
                    debitAmmountCl = paymentOrderRecordObj.getPaymentAmount().getValue();
                    chargeClassComCl = new ChargeTypeClass();
                    chargeClassComCl.setChargeType(typeClCom);
                    chargeClassComCl.setChargeDescription(descripClCom);
                    chargeClassComCl.setChargeCurrency(currPoClCom);
                    amountClCom = calculatePersentCliCommission(persent, minCommissionCl, maxCommissionCl,
                            debitAmmountCl);
                    chargeClassComCl.setChargeAmount(amountClCom);

                    if (!paymentOrderRecordObj.getChargeType().get(1).getChargeType().getValue().equals(""))
                        paymentOrderRecordObj.setChargeType(chargeClassComCl, 2);

                }

            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        currentRecord.set(paymentOrderRecordObj.toStructure());
    }

    public String calculatePersentCliCommission(String persentCl, String minCommissionCl, String maxCommisionCl,
            String debitAmount) {
        Double persent = 0.0;
        Double min = 0.0;
        Double max = 0.0;
        Double debitAmt = 0.0;
        Double commission = 0.0;

        persent = toDouble(persentCl);
        min = toDouble(minCommissionCl);
        max = toDouble(maxCommisionCl);
        debitAmt = toDouble(debitAmount);
        commission = debitAmt * persent;
        if (commission <= min) {
            commission = min;
        } else if (commission >= max) {
            commission = max;
        }

        return commission.toString();
    }

    public static Double toDouble(String valor) {
        return Double.valueOf(valor);
    }

    @Override
    public TValidationResponse validateRecord(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        String debitAccount = "";
        String customerDebitAccount = "";
        String commissionClientId = "";
        String poProduct = "";
        String channel = "";
        String currency = "";
        String ccetrans = "CCETRANS";
        final DataAccess daObj = new DataAccess((T24Context) this);
        final PaymentOrderRecord paymentOrderRecordObj = new PaymentOrderRecord(currentRecord);
        try {

            if (paymentOrderRecordObj.getPaymentOrderProduct().getValue().equals(ccetrans)) {
                poProduct = paymentOrderRecordObj.getPaymentOrderProduct().getValue();
                channel = paymentOrderRecordObj.getOrderInitiationType().getValue();
                currency = paymentOrderRecordObj.getPaymentCurrency().getValue();
                debitAccount = paymentOrderRecordObj.getDebitAccount().getValue();
                AccountRecord accountRec = new AccountRecord(daObj.getRecord("ACCOUNT", debitAccount));
                customerDebitAccount = accountRec.getCustomer().getValue();
                List<String> commisionIDClassList = (List<String>) daObj.selectRecords("",
                        "EB.BCI.BULK.COMMISSION.PARAM", "", "");
                commissionClientId = String
                        .valueOf(customerDebitAccount + "." + channel + "." + poProduct + "." + currency);
                if (!validateIdAccount(commissionClientId, daObj, commisionIDClassList)) {
                    commissionClientId = String.valueOf(channel + "." + poProduct + "." + currency);

                    if (!validateChannel(commissionClientId, daObj, commisionIDClassList, channel)) {
                        paymentOrderRecordObj.getOrderInitiationType().setError("PI-CLEARING.CHANNEL.NO.MATCH");
                    }
                } else {
                    if (!validateChannel(commissionClientId, daObj, commisionIDClassList, channel)) {
                        paymentOrderRecordObj.getOrderInitiationType().setError("PI-CLEARING.CHANNEL.NO.MATCH");
                    }
                }
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return paymentOrderRecordObj.getValidationResponse();
    }

    public Boolean validateIdAccount(String id, DataAccess da, List<String> commRec) {
        List<String> commissionID = new ArrayList<String>();
        commissionID = commRec;
        Boolean bool = false;
        for (String commision : commissionID) {
            if (id.equals(commision)) {
                bool = true;
            }
        }
        return bool;
    }

    public Boolean validateChannel(String id, DataAccess da, List<String> commRec, String channel) {
        String[] parts;
        List<String> commissionID = new ArrayList<String>();
        Boolean bool = false;
        commissionID = commRec;
        for (String string : commissionID) {
            parts = string.split("\\.");
            if (channel.equals(parts[0])) {
                bool = true;
                break;
            } else if (channel.equals(parts[1])) {
                bool = true;
                break;
            }
        }

        return bool;
    }
}
