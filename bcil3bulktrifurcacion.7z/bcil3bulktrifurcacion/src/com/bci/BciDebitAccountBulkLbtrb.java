package com.bci;

import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;

/**
 * TODO: Document me!
 *
 * @author haroldtabarez
 *
 */
public class BciDebitAccountBulkLbtrb extends RecordLifecycle {

    @Override
    public void defaultFieldValues(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        // TODO Auto-generated method stub
        PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        String cciBenef = "";
        String debitAccount = "";
        String poProduct = "";
        String lbtrb = "LBTRB";
        poProduct = poRec.getPaymentOrderProduct().getValue();
        try {
            if (poProduct.equals(lbtrb)) {
                cciBenef = poRec.getLocalRefField("L.CCI.DESTINATION").getValue();
                debitAccount = generarDebitAccount(cciBenef);
                poRec.setDebitAccount(debitAccount);
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        currentRecord.set(poRec.toStructure());
    }

    public String generarDebitAccount(String cciBenef) {
        String sub = "";
        sub = cciBenef.substring(8, 18);
        return sub;
    }

}
