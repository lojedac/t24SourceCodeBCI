package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.bcicceinterfaceparameter.BciCceInterfaceParameterRecord;
import com.temenos.t24.api.tables.bcicceinterfaceparameter.FieldNameClass;

/**
 * TODO: Document me!
 *
 * @author haroldtabarez
 *
 */
public class BciTrifChangeNostroAccount extends RecordLifecycle {

    @Override
    public void defaultFieldValues(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        String numDestinAcctUSD = "DEBIT.ACCT.NUMBER.USD";
        String numDestinAcctPen = "DEBIT.ACCT.NUMBER";
        String idInterfaceCCE = "CCE.ACCOUNT.NUMBER";
        String idInterfaceLBTRB = "LBTRB.ACCT.NUMBER";
        String fieldName = "";
        String cuentaInterna = "";
        String poProd = "";
        String cceTrans = "CCETRANS";
        String lbtrb = "LBTRB";
        String currencyPo = "";
        List<FieldNameClass> listFieldName = new ArrayList<>();
        DataAccess da = new DataAccess(this);
        PaymentOrderRecord poReg = new PaymentOrderRecord(currentRecord);
        poProd = poReg.getPaymentOrderProduct().getValue();
        BciCceInterfaceParameterRecord recordInterface;
        currencyPo = poReg.getPaymentCurrency().getValue();
        if (poProd.equals(cceTrans)) {
            recordInterface = new BciCceInterfaceParameterRecord(
                    da.getRecord("EB.BCI.CCE.INTERFACE.PARAMETER", idInterfaceCCE));
            listFieldName = recordInterface.getFieldName();
            for (FieldNameClass fieldNameClass1 : listFieldName) {
                fieldName = fieldNameClass1.getFieldName().getValue();
                if (currencyPo.equals("PEN")) {
                    if (fieldName.equals(numDestinAcctPen)) {
                        cuentaInterna = fieldNameClass1.getFieldValue().getValue();
                        poReg.setCreditNostroAccount(cuentaInterna);
                        poReg.setBeneficiaryAccountNo(cuentaInterna);
                    }
                } else {
                    if (fieldName.equals(numDestinAcctUSD)) {
                        cuentaInterna = fieldNameClass1.getFieldValue().getValue();
                        poReg.setCreditNostroAccount(cuentaInterna);
                        poReg.setBeneficiaryAccountNo(cuentaInterna);
                    }
                }
            }
        } else if (poProd.equals(lbtrb)) {
            recordInterface = new BciCceInterfaceParameterRecord(
                    da.getRecord("EB.BCI.CCE.INTERFACE.PARAMETER", idInterfaceLBTRB));
            listFieldName = recordInterface.getFieldName();
            for (FieldNameClass fieldNameClass1 : listFieldName) {
                fieldName = fieldNameClass1.getFieldName().getValue();
                if (fieldName.equals(currencyPo)) {
                    cuentaInterna = fieldNameClass1.getFieldValue().getValue();
                    poReg.setCreditNostroAccount(cuentaInterna);
                    poReg.setBeneficiaryAccountNo(cuentaInterna);
                    break;
                }
            }
        }

        currentRecord.set(poReg.toStructure());
    }

}
