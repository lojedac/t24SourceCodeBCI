package com.bci;

import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.beneficiary.BeneficiaryRecord;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.eblookup.EbLookupRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebbcibcrpcwaccount.EbBciBcrpCwAccountRecord;

/**
 * TODO: Document me!
 *
 * @author andreavaca
 *
 */
public class BciValidateLbtrb extends RecordLifecycle {

    @Override
    public void defaultFieldValues(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        
        String paOrPro="";
        String preFix="";
        String bankCode="";
        String cciBen="";
        String currency="";
        String subFix ="";
        String cust ="";
        String[] iddocType;
        String address="";
        String nameBen="";
        String docTypeBen="";
        String docNumberBen="";
        String docTypeOrd="";
        String docNumberOrd="";
        String docTypeDesc="";
        String cciCode="";
        String fieldCode = "";
        String nomAcct = "";
        String noAcct = "";
        String acctDestino = "";
        String acctId = "";
        String ccy = "";
        String recId="CUS.LEGAL.DOC.NAME*";
        DataAccess daCust = new DataAccess(this);
        DataAccess daEblookup = new DataAccess(this);
        DataAccess daAcct = new DataAccess(this);
        DataAccess daBen = new DataAccess(this);
        DataAccess da = new DataAccess(this);
        
        PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        
        paOrPro=poRec.getPaymentOrderProduct().getValue();
        preFix=paOrPro.substring(4,5);
        currency=poRec.getPaymentCurrency().getValue();
        cciBen=poRec.getLocalRefField("L.CCI.DESTINATION").getValue();
        bankCode=poRec.getLocalRefField("L.CTA.MA.BANK.REC").getValue();
        cust=poRec.getOrderingCustomer().getValue();
        if (paOrPro.equals("LBTRB"))
        {
            //Try catch para el código concepto
            try {
                if (currency.equals("USD"))
                    {
                        subFix=preFix.concat("101");
                        poRec.getLocalRefField("L.CODE.CONCEPT").setValue(subFix);
                        
                    }else{
                        
                        subFix=preFix.concat("170");
                        poRec.getLocalRefField("L.CODE.CONCEPT").setValue(subFix);
                    }
             
            } catch (Exception e) {
                // TODO Auto-generated catch block
                // Uncomment and replace with appropriate logger
                // LOGGER.error(exception_var, exception_var);
                System.out.println(e.getMessage());
            }
           
            // Try catch para obtener datos del ordentante
            try {
                if (!cust.isEmpty()){
                    CustomerRecord custRec= new CustomerRecord(daCust.getRecord("CUSTOMER",cust));
                    docNumberOrd=custRec.getLegalId().get(0).getLegalId().getValue();
                    if (!docNumberOrd.isEmpty()){
                        iddocType=((custRec.getLegalIdDocName().get(0).getValue()).split("-", 2));  
                        EbLookupRecord docTypeRec=new EbLookupRecord(daEblookup.getRecord("EB.LOOKUP", recId.concat(iddocType[1].toString())));
                        docTypeOrd=docTypeRec.getDescription().get(0).getValue();
                        poRec.getLocalRefField("L.TIPODOC.ORDENANTE").setValue(docTypeOrd);
                        poRec.getLocalRefField("L.NUM.DOC.ORDENANTE").setValue(docNumberOrd);        
                    }
                }
            List<String> selIds = daBen.selectRecords("", "BENEFICIARY", "", " WITH CCI.DESTINATION EQ " + cciBen);
            String selCommissionId = "";
            if (selIds.size() == 1){
                
              selCommissionId = selIds.get(0); 
              BeneficiaryRecord benRec= new BeneficiaryRecord(daBen.getRecord("BENEFICIARY",selCommissionId));
              address=benRec.getLocalRefField("L.DIRECCION.BENEFICIARIO").getValue();
              nameBen=benRec.getNickname(0).getValue();
              docTypeBen=benRec.getLocalRefField("L.TIPODOC.BENEFICIARIO").getValue();
              docNumberBen=benRec.getLocalRefField("L.NUM.DOC.BENEFICIARIO").getValue();
              poRec.getLocalRefField("L.TIPODOC.BENEFICIARIO").setValue(docTypeBen);
              poRec.getLocalRefField("L.NUM.DOC.BENEFICIARIO").setValue(docNumberBen);
              poRec.getLocalRefField("L.DIRECCION.BENEFICIARIO").setValue(address);
              poRec.setBeneficiaryName(nameBen);
            }
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(exception_var, exception_var);
            System.out.println(e.getMessage());
        }
        
        try {
            docTypeBen=poRec.getLocalRefField("L.TIPODOC.BENEFICIARIO").getValue();
            EbLookupRecord docTypeRec=new EbLookupRecord(daEblookup.getRecord("EB.LOOKUP", recId.concat(docTypeBen.toString())));
            docTypeDesc=docTypeRec.getDescription().get(0).getValue();
            docNumberBen=poRec.getLocalRefField("L.NUM.DOC.BENEFICIARIO").getValue();
            docTypeOrd=poRec.getLocalRefField("L.TIPODOC.ORDENANTE").getValue();
            docNumberOrd=poRec.getLocalRefField("L.NUM.DOC.ORDENANTE").getValue();
            
            if (docTypeDesc.equals(docTypeOrd) )
            {
                if (docNumberBen.equals(docNumberOrd))
                {
                    poRec.getLocalRefField("L.SAME.OWNER").setValue("YES");
                }else
                {
                    poRec.getLocalRefField("L.SAME.OWNER").setValue("NO");
                }
           }else{
               poRec.getLocalRefField("L.SAME.OWNER").setValue("NO");
           }
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(exception_var, exception_var);
            System.out.println(e.getMessage());
        }
        
        // Try catch para obtener los datos del routing details
        try {
            bankCode = cciBen.substring(0, 3);
            EbBciBcrpCwAccountRecord bciRec = new EbBciBcrpCwAccountRecord(daAcct.getRecord("EB.BCI.BCRP.CW.ACCOUNT", bankCode));
            cciCode = poRec.getLocalRefField("L.CCI.CODE.ORIG").getValue();
            acctId = poRec.getCreditNostroAccount().getValue();
            for (int i = 0; i < bciRec.getCodeEntity().size(); i++) {
                fieldCode = bciRec.getCodeEntity(i).getCodeEntity().getValue();

                if (fieldCode.equals(bankCode)) {
                    String ccyEnt = "";
                    ccyEnt = bciRec.getCodeEntity(i).getDivT24().getValue();
                    if (ccyEnt.equals(currency)) {
                        nomAcct = bciRec.getCodeEntity(i).getName().getValue();
                        acctDestino = bciRec.getCodeEntity(i).getNumAccount().getValue();
                        poRec.getLocalRefField("L.CTA.NO.CTA.EXT").setValue(acctDestino);
                        break;
                    }
                }
            }

            AccountRecord acctRec = new AccountRecord(da.getRecord("ACCOUNT", acctId));
            ccy = acctRec.getCurrency().getValue();

            if (ccy.equals(currency)) {
                if (cciCode.isEmpty()) {
                    cciCode = "063";
                }
                noAcct = acctRec.getOurExtAcctNo().getValue();
                poRec.getLocalRefField("L.ACT.EXTERNO").setValue(noAcct);
                poRec.getLocalRefField("L.COD.BANK.ORIGEN").setValue(cciCode.substring(0, 3));
                poRec.getLocalRefField("L.CTA.MA.BANK.REC").setValue(cciBen.substring(0, 3));
                poRec.getLocalRefField("L.DESC.ACT.EXTERNO").setValue(nomAcct);
                poRec.getLocalRefField("L.CTA.NO.CTA.EXT").setValue(acctDestino);
            } 
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(exception_var, exception_var);
            System.out.println(e.getMessage());
        }
        currentRecord.set(poRec.toStructure());
    }
   }
} 