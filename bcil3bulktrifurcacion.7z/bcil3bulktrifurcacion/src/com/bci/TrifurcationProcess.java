package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.complex.eb.templatehook.TransactionData;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebbcihdrawerdoctype.EbBciHDrawerDocTypeRecord;
import com.temenos.t24.api.tables.ebbcitriflimitparam.EbBciTrifLimitParamRecord;
import com.temenos.t24.api.tables.ebbcitriflimitparam.PaymentOrderProductClass;
import com.temenos.t24.api.tables.ebbcitriflimitparam.TransTypeClass;

/**
 * @author Diego
 */
public class TrifurcationProcess extends RecordLifecycle {

    @Override
    public void defaultFieldValues(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {

        PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        poRec.setPaymentOrderProduct("CCETRANS");
        poRec.setDebitChargeImposed("YES");
        String paymnAmt = "";
        String currencyLimitParam = "";
        String montoMin = "";
        String montoMax = "";
        String transferType = "";
        String destino = "";
        String currencyPO = "";
        String creditAccount = "";
        String draID = "";
        String tableParamLimitRecord = "EB.BCI.TRIF.LIMIT.PARAM";
        String tableDrawerRecord = "EB.BCI.H.DRAWER.DOC.TYPE";
        String drawerType = "L.DRAWER.DOC.TYPE";
        String drawerNo = "L.DRAWER.DOC.NUMBER";
        String lbtrb = "LBTRB";
        String tipoDocBenef = "L.TIPODOC.BENEFICIARIO";
        String numDocBenef = "L.NUM.DOC.BENEFICIARIO";
        String bciactrf = "BULKACTRF";
        boolean bool = false;
        EbBciTrifLimitParamRecord ebRec = new EbBciTrifLimitParamRecord(this);
        List<TransTypeClass> transTypeList = new ArrayList<TransTypeClass>();
        List<PaymentOrderProductClass> transPoClassList = new ArrayList<PaymentOrderProductClass>();
        paymnAmt = poRec.getPaymentAmount().getValue();
        DataAccess da = new DataAccess(this);
        transferType = poRec.getLocalRefField("L.TRANSFER.TYPE").getValue();
        EbBciHDrawerDocTypeRecord draRec = new EbBciHDrawerDocTypeRecord();
        try {
            if (transferType.equals("220")) {
                ebRec = new EbBciTrifLimitParamRecord(da.getRecord(tableParamLimitRecord, "TRANSF.ORDINARIA"));
            } else if (transferType.equals("221")) {
                ebRec = new EbBciTrifLimitParamRecord(da.getRecord(tableParamLimitRecord, "PAGO.HABERES"));
            } else if (transferType.equals("222")) {
                ebRec = new EbBciTrifLimitParamRecord(da.getRecord(tableParamLimitRecord, "PAGO.PROVEEDORES"));
            } else {
                bool = true;
            }
            transPoClassList = ebRec.getPaymentOrderProduct();
            for (PaymentOrderProductClass paymentOrderProductClass : transPoClassList) {
                transTypeList = paymentOrderProductClass.getTransType();
                if (bool) {
                    break;
                } else {
                    for (TransTypeClass transTypeClass : transTypeList) {
                        montoMin = transTypeClass.getMinLimit().getValue();
                        montoMax = transTypeClass.getMaxLimit().getValue();
                        currencyLimitParam = transTypeClass.getCurrency().getValue();
                        creditAccount = poRec.getCreditAccount().getValue();
                        currencyPO = poRec.getPaymentCurrency().getValue();
                        destino = paymentOrderProductClass.getPaymentOrderProduct().getValue();
                        if (creditAccount.isEmpty()) {
                            if (enRango(toDouble(montoMin), toDouble(montoMax), toDouble(paymnAmt))
                                    && currencyPO.equals(currencyLimitParam)) {
                                poRec.setPaymentOrderProduct(destino);
                                if (destino.equals(lbtrb)) {
                                    draID = poRec.getLocalRefField(drawerType).getValue();
                                    draRec = new EbBciHDrawerDocTypeRecord(da.getRecord(tableDrawerRecord, draID));
                                    poRec.getLocalRefField(tipoDocBenef)
                                            .setValue(draRec.getDocTypeDescription().getValue());
                                    poRec.getLocalRefField(numDocBenef)
                                            .setValue(poRec.getLocalRefField(drawerNo).getValue());
                                    poRec.getLocalRefField(drawerType).setValue("");
                                    poRec.getLocalRefField(drawerNo).setValue("");
                                    poRec.setDebitChargeImposed("NO");
                                }
                                bool = true;
                                break;
                            }
                        } else {
                            poRec.setPaymentOrderProduct(bciactrf);
                            poRec.setDebitChargeImposed("NO");
                            bool = true;
                            break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        currentRecord.set(poRec.toStructure());
    }

    public boolean enRango(double min, double max, double num) {
        return (num >= min && num <= max);
    }

    public static Double toDouble(String valor) {
        return Double.valueOf(valor);
    }

    @Override
    public TValidationResponse validateRecord(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        PaymentOrderRecord poRec = new PaymentOrderRecord(currentRecord);
        String paymnAmt = "";
        String currencyLimitParam = "";
        String montoMin = "";
        String montoMax = "";
        String transferType = "";
        String destino = "";
        String procesoLimitParam = "";
        String creditAccount = "";
        String currencyPO = "";
        String tableParamLimitRecord = "EB.BCI.TRIF.LIMIT.PARAM";
        String errorMaxLimit = "FT-GREATER.THAN.MAX";
        String bciactrf = "BULKACTRF";
        boolean bool = false;

        EbBciTrifLimitParamRecord ebRec = new EbBciTrifLimitParamRecord(this);
        List<TransTypeClass> transTypeList = new ArrayList<TransTypeClass>();
        List<PaymentOrderProductClass> transPoClassList = new ArrayList<PaymentOrderProductClass>();
        paymnAmt = poRec.getPaymentAmount().getValue();
        DataAccess da = new DataAccess(this);
        transferType = poRec.getLocalRefField("L.TRANSFER.TYPE").getValue();
        try {
            if (transferType.equals("220")) {
                ebRec = new EbBciTrifLimitParamRecord(da.getRecord(tableParamLimitRecord, "TRANSF.ORDINARIA"));
            } else if (transferType.equals("221")) {
                ebRec = new EbBciTrifLimitParamRecord(da.getRecord(tableParamLimitRecord, "PAGO.HABERES"));
            } else if (transferType.equals("222")) {
                ebRec = new EbBciTrifLimitParamRecord(da.getRecord(tableParamLimitRecord, "PAGO.PROVEEDORES"));
            } else {
                bool = true;
            }
            bool = false;
            transPoClassList = ebRec.getPaymentOrderProduct();
            for (PaymentOrderProductClass paymentOrderProductClass : transPoClassList) {
                transTypeList = paymentOrderProductClass.getTransType();
                if (bool) {
                    break;
                } else {
                    for (TransTypeClass transTypeClass : transTypeList) {
                        montoMin = transTypeClass.getMinLimit().getValue();
                        montoMax = transTypeClass.getMaxLimit().getValue();
                        currencyLimitParam = transTypeClass.getCurrency().getValue();
                        procesoLimitParam = transTypeClass.getProceso().getValue();
                        creditAccount = poRec.getCreditAccount().getValue();
                        currencyPO = poRec.getPaymentCurrency().getValue();
                        destino = paymentOrderProductClass.getPaymentOrderProduct().getValue();
                        if (creditAccount.isEmpty()) {
                            if (enRango(toDouble(montoMin), toDouble(montoMax), toDouble(paymnAmt))
                                    && currencyPO.equals(currencyLimitParam)) {
                                if (procesoLimitParam.equals("DETENER")) {
                                    poRec.getPaymentOrderProduct().setError(errorMaxLimit);
                                    
                                }
                                bool = true;
                                break;
                            }
                        } else {
                            if (procesoLimitParam.equals("DETENER")) {
                                poRec.getPaymentOrderProduct().setError(errorMaxLimit);
                                
                            }
                            bool = true;
                            break;
                        }
                    }
                }

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return poRec.getValidationResponse();
    }

    @Override
    public void updateRecord(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext,
            List<TransactionData> transactionData, List<TStructure> currentRecords) {
        // TODO Auto-generated method stub
        PaymentOrderRecord payRec = new PaymentOrderRecord(currentRecord);
        TransactionData transData = new TransactionData();
        transData.setFunction("I");
        transData.setNumberOfAuthoriser("1");
        transData.setVersionId("PAYMENT.ORDER,BCI.BULK.TEFORD.PEN");    
        transData.setTransactionId("");  
        transactionData.add(transData);
        currentRecords.add(payRec.toStructure());
    }   
}
