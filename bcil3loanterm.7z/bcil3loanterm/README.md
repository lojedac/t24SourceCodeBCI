# BciL3LoanTerm

Este es el repositorio de GitLab para el proyecto BciL3LoanTerm. Este software está diseñado para manejar operaciones de compensación en transacciones de préstamos de los niveles L2 y L3, que hacen uso del sistema core "AA".

## Descripción

BciL3LoanTerm es una solución que facilita la gestión de las transacciones reversas en los pagos de préstamos en los niveles L2 y L3, interactuando con el sistema core "AA". Este proceso es vital para el manejo adecuado de las transacciones de préstamos y la integridad del sistema financiero.

## Requisitos de Instalación

Para clonar y ejecutar este proyecto, necesitarás tener instalado [Git](https://git-scm.com) y un entorno de ejecución de [Java](https://www.oracle.com/java/technologies/javase-jdk11-downloads.html). Desde tu terminal:

```bash
# Clonar este repositorio
$ git clone https://gitlab.com/HaroldNag/bcil3loanterm.git

# Navegar al directorio del repositorio
$ cd bcil3loanterm

# Compilar el proyecto
$ javac [nombre_del_archivo_principal].java

# Ejecutar el proyecto
$ java [nombre_del_archivo_principal]
```

## Uso

Se recomienda revisar la documentación interna del proyecto para entender cómo utilizarlo adecuadamente y los diversos parámetros de configuración disponibles.

## Desarrolladores

Este proyecto fue desarrollado por:

- [@damaigualcaNagarro](https://gitlab.com/damaigualcaNagarro)
- [@David_KtL](https://gitlab.com/David_KtL)
- [@andrea.vaca](https://gitlab.com/andrea.vaca)
- [@HaroldNag](https://gitlab.com/HaroldNag)
- [@dsgallegos](https://gitlab.com/dsgallegos)

## Licencia

BciL3LoanTerm está licenciado bajo Nagarro EC.