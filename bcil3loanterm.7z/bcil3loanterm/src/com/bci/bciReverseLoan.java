package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TField;
import com.temenos.api.TStructure;
import com.temenos.t24.api.complex.eb.servicehook.TransactionData;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.PaymentContext;
import com.temenos.t24.api.complex.pp.paymentlifecyclehook.StatusAction;
import com.temenos.t24.api.hook.payments.PaymentLifecycle;
import com.temenos.t24.api.records.ebqueriesanswers.EbQueriesAnswersRecord;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.records.poragreementandadvice.PorAgreementAndAdviceRecord;
import com.temenos.t24.api.records.poraudittrail.PorAuditTrailRecord;
import com.temenos.t24.api.records.porpostingandconfirmation.PorPostingAndConfirmationRecord;
import com.temenos.t24.api.records.porsupplementaryinfo.PorSupplementaryInfoRecord;
import com.temenos.t24.api.records.portransaction.PorTransactionRecord;
import com.temenos.t24.api.records.ppcompanyproperties.PpCompanyPropertiesRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.BalanceTypeClass;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementRecord;
import com.temenos.t24.api.tables.ebbcilloancapitalizemovement.EbBciLLoanCapitalizeMovementTable;

/**
 * TODO: Document me!
 *
 * @author haroldtabarez/ diegomaigualca
 *
 */
public class bciReverseLoan extends PaymentLifecycle {

    @Override
    public void postUpdateRequest(StatusAction arg0, PpCompanyPropertiesRecord arg1, EbQueriesAnswersRecord arg2,
            PorTransactionRecord arg3, PorSupplementaryInfoRecord arg4, PorAgreementAndAdviceRecord arg5,
            PorPostingAndConfirmationRecord arg6, PorAuditTrailRecord arg7, PaymentContext arg8,
            List<TransactionData> arg9, List<TStructure> arg10) {
        String idFee = "";
        String bnk = "BNK-";
        String bnkPoCurr = "";
        String adjAmt = "";
        DataAccess daPo = new DataAccess(this);
        EbBciLLoanCapitalizeMovementRecord loanRec = new EbBciLLoanCapitalizeMovementRecord(this);
        EbBciLLoanCapitalizeMovementTable loanTable = new EbBciLLoanCapitalizeMovementTable(this);
        List<BalanceTypeClass> lstBalaClass = new ArrayList<BalanceTypeClass>();
        List<TField> lstAdjAmt = new ArrayList<TField>();
        String paymentOrderId = arg3.getFilereferenceincoming().getValue();
        PaymentOrderRecord poRec = new PaymentOrderRecord(this);
        poRec = new PaymentOrderRecord(daPo.getRecord("PAYMENT.ORDER", paymentOrderId));
        Session sessObj = new Session(this);
        String mnemonic = sessObj.getCompanyRecord().getMnemonic().getValue();
        bnkPoCurr = poRec.getPaymentSystemId().getValue();
        try {
            List<String> lstMovement = daPo.selectRecords(mnemonic, "EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT", "",
                    "WITH ID.BNK.PO EQ '" + bnkPoCurr + "'");
            for (String movementId : lstMovement) {
                
                loanRec = new EbBciLLoanCapitalizeMovementRecord(daPo.getRecord("EB.BCI.L.LOAN.CAPITALIZE.MOVEMENT", movementId));
                loanRec.setReservado1("REVERSADO");
                lstBalaClass = loanRec.getBalanceType();
                for (BalanceTypeClass balanceClass : lstBalaClass) {
                    lstAdjAmt = balanceClass.getAdjAmt();
                    for (TField adjAmtField : lstAdjAmt) {
                        adjAmt = adjAmtField.getValue();
                        balanceClass.getBalance().setValue(adjAmt);
                        adjAmtField.setValue("");
                    }
                    idFee = bnk.concat(balanceClass.getBnkreference().getValue());
                    loanTable.write(movementId, loanRec);
                    TransactionData transData = new TransactionData();
                    transData.setFunction("I");
                    transData.setNumberOfAuthoriser("0");
                    transData.setVersionId("POR.POSTING.REVERSAL,BCI.REVERSE");
                    transData.setCompanyId("PE0010001");
                    transData.setTransactionId(idFee);
                    transData.setSourceId("BCI.CREATE.ACCT");
                    arg9.add(transData);
                }
            }

        } catch (Exception e) {

        }

    }

}
