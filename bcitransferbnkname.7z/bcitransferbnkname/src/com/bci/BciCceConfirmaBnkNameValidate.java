package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebbcicceparticipantsbankname.EbBciCceParticipantsBankNameRecord;

/**
 * 
 *
 * @author Diego Maigualca
 *
 */
public class BciCceConfirmaBnkNameValidate extends RecordLifecycle {

    @Override
    public TValidationResponse validateRecord(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        
        String cciDestino = "";
        String transferTypePO = "";
        String entidadCci = "";
        String entidadBnkName = "";
        final static String LCCIDESTINATION = "L.CCI.DESTINATION";
        
        DataAccess da = new DataAccess(this);

        
        Boolean flgTransfTypPO = false;
        List<String> lstEntidad = new ArrayList<>();
        
        PaymentOrderRecord poOrderRecord = new PaymentOrderRecord(currentRecord);
        cciDestino = poOrderRecord.getLocalRefField(LCCIDESTINATION).getValue();
        transferTypePO = poOrderRecord.getLocalRefField("L.TRANSFER.TYPE").getValue();
        
        try {
            
            if (transferTypePO.equals("") || transferTypePO.isEmpty()){
                flgTransfTypPO = true;
            }
            
            entidadCci = cciDestino.substring(0,3);
            EbBciCceParticipantsBankNameRecord bnkNameRecord = new EbBciCceParticipantsBankNameRecord(this);
            lstEntidad = da.selectRecords("", "EB.BCI.CCE.PARTICIPANTS.BANK.NAME", "", " WITH @ID EQ " + entidadCci);
            if (lstEntidad.size() == 0){
                
                poOrderRecord.getLocalRefField(LCCIDESTINATION).setError("PP-NOT.EXIST.ENTITY");
            }
            else if (lstEntidad.size() == 1 && !flgTransfTypPO){
                entidadBnkName = lstEntidad.get(0);
                bnkNameRecord = new EbBciCceParticipantsBankNameRecord(da.getRecord("EB.BCI.CCE.PARTICIPANTS.BANK.NAME", entidadBnkName));

            } else if (lstEntidad.size() > 1){
                poOrderRecord.getLocalRefField(LCCIDESTINATION).setError("PP-BAD.CONF.ENTITY.DUPLICATE");
            }
            
            if(flgTransfTypPO){
                poOrderRecord.getLocalRefField("L.TRANSFER.TYPE").setError("PP-TRANS.TYPE.MANDATORY");
            }
            
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            
        }
        
        return poOrderRecord.getValidationResponse();
    }

    
    
}
