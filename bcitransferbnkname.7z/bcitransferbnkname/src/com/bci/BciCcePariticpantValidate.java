package com.bci;

import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TField;
import com.temenos.api.TStructure;
import com.temenos.api.TValidationResponse;
import com.temenos.t24.api.complex.eb.templatehook.TransactionContext;
import com.temenos.t24.api.hook.system.RecordLifecycle;
import com.temenos.t24.api.records.paymentorder.PaymentOrderRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebbcicceparticipantsbankname.EbBciCceParticipantsBankNameRecord;
import com.temenos.t24.api.tables.ebbcicceparticipantsbankname.TransTypeClass;

/**
 *
 *
 * @author Diego Maigualca
 *
 */
public class BciCcePariticpantValidate extends RecordLifecycle {

    @Override
    public TValidationResponse validateRecord(String application, String currentRecordId, TStructure currentRecord,
            TStructure unauthorisedRecord, TStructure liveRecord, TransactionContext transactionContext) {
        
        String cciDestino = "";
        String transferTypePO = "";
        String entidadCci = "";
        String entidadBnkName = "";

        // Validacion para telefono
        String numberPhone = "";

        Boolean flgTransfTyp = false;
        Boolean flgTransfTypPO = false;
        Boolean flgRolEntityPO = false;
        List<String> lstEntidad = new ArrayList<>();
        List<TransTypeClass> listTranfType = new ArrayList<TransTypeClass>();
        String turnInt = "";
        String turnMna = "";
        String turnTrt = "";

        DataAccess da = new DataAccess(this);
        PaymentOrderRecord poOrderRecord = new PaymentOrderRecord(currentRecord);
        cciDestino = poOrderRecord.getLocalRefField("L.CCI.DESTINATION").getValue();
        transferTypePO = poOrderRecord.getLocalRefField("L.TRANSFER.TYPE").getValue();
        

        try {
            numberPhone = poOrderRecord.getBeneficiaryContMob().getValue();
            if (numberPhone.length() > 10) {
                poOrderRecord.getBeneficiaryContMob()
                        .setError("La longitud máxima del campo debe ser de 10 caracteres.");
            }
        } catch (Exception ex) {

        }

        try {

            if (transferTypePO.equals("") || transferTypePO.isEmpty()) {
                flgTransfTypPO = true;
            }

            entidadCci = cciDestino.substring(0, 3);
            EbBciCceParticipantsBankNameRecord bnkNameRecord = new EbBciCceParticipantsBankNameRecord(this);

            lstEntidad = da.selectRecords("", "EB.BCI.CCE.PARTICIPANTS.BANK.NAME", "", " WITH @ID EQ " + entidadCci);
            
            
            
            if (lstEntidad.size() == 0) {

                poOrderRecord.getLocalRefField("L.CCI.DESTINATION").setError("PP-NOT.EXIST.ENTITY");
            } else if (lstEntidad.size() == 1 && !flgTransfTypPO) {
                entidadBnkName = lstEntidad.get(0);
                bnkNameRecord = new EbBciCceParticipantsBankNameRecord(
                        da.getRecord("EB.BCI.CCE.PARTICIPANTS.BANK.NAME", entidadBnkName));
                try {
                    
                    
                    turnInt = bnkNameRecord.getTurnoEctri().getValue();
                    turnMna = bnkNameRecord.getTurnoEctrm().getValue();
                    turnTrt = bnkNameRecord.getTurnoEctrt().getValue();
                    
                    
                    if (turnInt.equals("NO") && turnMna.equals("NO") && turnTrt.equals("NO")) {
                        poOrderRecord.getLocalRefField("L.CCI.DESTINATION").setError("EB-BCI-CCE-NOT-TR");
                    }
                    
                    listTranfType = bnkNameRecord.getTransType();
                    if (listTranfType.size() != 0) {
                        for (TransTypeClass transTypeClass : listTranfType) {
                            String transTypeStrBnk = "";
                            List<TField> roleBnk = null;
                            transTypeStrBnk = transTypeClass.getTransType().getValue();
                            roleBnk = transTypeClass.getTransRole();
                            if (transTypeStrBnk.equals(transferTypePO)) {
                                flgTransfTyp = true;
                                for (TField roleTfl : roleBnk) {
                                    String rolStr = "";
                                    rolStr = roleTfl.getValue();
                                    if (rolStr.equals("R")) {
                                        flgRolEntityPO = true;
                                    }
                                }
                            } else if ((!transferTypePO.equals("") && !transferTypePO.isEmpty())
                                    && !transTypeStrBnk.equals(transferTypePO)) {
                                if (!flgTransfTyp) {
                                    flgTransfTyp = false;
                                }

                            }
                        }

                        if (!flgRolEntityPO) {

                            poOrderRecord.getLocalRefField("L.CCI.DESTINATION").setError("PP-ONLY.NOT.ENTITY.CREATE");
                        }

                        if (!flgTransfTyp) {

                            poOrderRecord.getLocalRefField("L.CCI.DESTINATION").setError("PP-EMPTY.ENTITY.CREATE");
                        }
                    } else {

                        poOrderRecord.getLocalRefField("L.CCI.DESTINATION").setError("PP-EMPTY.CONF.ENTITY.CREATE");
                    }

                } catch (Exception e) {

                    poOrderRecord.getLocalRefField("L.CCI.DESTINATION").setError("PP-EMPTY.CONF.ENTITY.CREATE");
                }
            } else if (lstEntidad.size() > 1) {

                poOrderRecord.getLocalRefField("L.CCI.DESTINATION").setError("PP-BAD.CONF.ENTITY.DUPLICATE");
            }

            if (flgTransfTypPO) {

                poOrderRecord.getLocalRefField("L.TRANSFER.TYPE").setError("PP-TRANS.TYPE.MANDATORY");
            }

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

        return poOrderRecord.getValidationResponse();
    }

}
